<?php
//	Script Version 7.7.3

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth();

$atPath = get_input("ATTACHMENTS_PATH", "post");
if ($atPath && $atPath == $config['UPLOADED_AVATAR_PATH']) {
	$admin->error($ubbt_lang['DUP_PATH']);
	exit;
}

// What config vars are we updating?
$newconfig = array("DATABASE_SERVER", "DATABASE_NAME", "DATABASE_USER", "DATABASE_PASSWORD", "PERSISTENT_DB_CONNECTION", "UTF8",
	"FULL_URL", "BASE_URL", "FULL_PATH", "SESSION_PATH", "ATTACHMENTS_PATH", "ATTACHMENTS_URL", "CONVERT_PATH", "MOGRIFY_PATH");

// Update the config file
include("doeditconfig.php");

admin_log("PATHS_DB_SETTINGS", "$log_diffs");

$admin->redirect($ubbt_lang['SET_UPDATED'], "{$config['BASE_URL']}/admin/paths_db.php?returntab=$returntab", $ubbt_lang['DB_F_LOC']);

?>