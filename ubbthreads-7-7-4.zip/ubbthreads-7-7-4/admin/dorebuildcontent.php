<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/dorebuildcontent.php");

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();

$html = new html;

@include("{$config['FULL_PATH']}/cache/custom_tag_cache.php");

require_once("{$config['FULL_PATH']}/libs/content_rebuild.inc.php");

$mode = get_input("mode", "get");
$start = get_input("start", "get", "int", 0);
$convert = get_input("convert", "get");
$pretotal = get_input("pretotal", "get", "int", 0);

// -----------------
// Pre-2012 / PHP4 ERA (UBBThreads 7.5.x DEFAULTS)
//	"posts" => 200,
//	"posts_utf8" => 100,
//	"forums" => 100,
//	"pruneptorphans" => 50,
//	"signatures" => 200,
//	"topics" => 500,
//	"private_messages" => 200,
//	"postcounts" => 200,

// -----------------
// Post-2012 / PHP5 ERA (UBBThreads 7.6.x DEFAULTS)
//	"posts" => 800,
//	"posts_utf8" => 400,
//	"forums" => 200,
//	"pruneptorphans" => 100,
//	"signatures" => 800,
//	"topics" => 1000,
//	"private_messages" => 800,
//	"postcounts" => 800,

// -----------------
// Post-2017 / PHP7 ERA (UBBThreads 7.7.x DEFAULTS)
//	"posts" => 1000,
//	"posts_utf8" => 1000,
//	"forums" => 200,
//	"pruneptorphans" => 100,
//	"signatures" => 1000,
//	"topics" => 1000,
//	"private_messages" => 1000,
//	"postcounts" => 1000,
//	"likecounts" => 1000,
// 	"updatescheme" => 1,

$limits = array(
	"posts" => 1000,
	"posts_utf8" => 1000,
	"forums" => 200,
	"prunepostorphans" => 100,
	"pruneptorphans" => 100,
	"signatures" => 1000,
	"topics" => 1000,
	"private_messages" => 1000,
	"postcounts" => 1000,
	"likecounts" => 1000,
	"updatescheme" => 1,
);

$limit = array_get($limits, $mode, null);

if ($limit == null) {
	$admin->error("Invalid mode specified");
}

$redirect = "";
$message = "";

switch ($mode) {
	case "posts":
		if (!$start) {
			admin_log("REBUILD_POSTS", $ubbt_lang['ACTION_BEGIN']);
		}
		$query = "
			SELECT COUNT(POST_ID) AS COUNT
			FROM {$config['TABLE_PREFIX']}POSTS
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT POST_ID
			FROM {$config['TABLE_PREFIX']}POSTS
			ORDER BY POST_ID ASC
			LIMIT ?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$posts[] = $result['POST_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_posts($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_POSTS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=posts&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_POSTS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
			$time = 10;
			admin_log("REBUILD_POSTS", $message);
		}
		break;

	// The following option is not shown for a reason.
	/*	case "posts_utf8":
			$query = "
				SELECT COUNT(POST_ID) AS COUNT
				FROM {$config['TABLE_PREFIX']}POSTS
			";

			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$total = $tmp['COUNT'];

			$query = "
				SELECT POST_ID, POST_BODY
				FROM {$config['TABLE_PREFIX']}POSTS
				ORDER BY POST_ID ASC
				LIMIT ?, ?
			";

			$posts = array();

			$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
			while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
				$posts[] = $result;
			}
			$dbh->finish_sth($sth);

			$sizeof_posts = count($posts);

			if ($sizeof_posts > 0) {

				for ($i = 0; $i < $sizeof_posts; $i++) {
					if (is_utf8($posts[$i]['POST_BODY'])) {
						$query = "
							UPDATE {$config['TABLE_PREFIX']}POSTS
							SET POST_BODY = ?
							WHERE POST_ID = ?
						";

						$dbh->do_placeholder_query($query, array(utf8_encode($posts[$i]['POST_BODY']), $posts[$i]['POST_ID']), __LINE__, __FILE__);
					}
				}

				$next_start = $start + $limit;

				if ($next_start > $total) {
					$next_start = $total;
				}

				$message = sprintf($ubbt_lang['REBUILDING_POSTS'], $start + 1, $next_start, $total);
				$redirect = "dorebuildcontent.php?mode=posts_utf8&amp;start=" . ($start + $limit);
				set_board_is_open(false);
			} else {
				// This is our last page.
				$message = sprintf($ubbt_lang['REBUILD_POSTS_COMPLETE'], $total);
				$redirect = "rebuildcontent.php";
				set_board_is_open(true);
			}

			break;
	*/

	case "signatures":
		if (!$start) {
			admin_log("REBUILD_SIGNATURES", $ubbt_lang['ACTION_BEGIN']);
		}
		$query = "
			SELECT COUNT(USER_ID) AS COUNT
			FROM {$config['TABLE_PREFIX']}USER_PROFILE
			WHERE USER_DEFAULT_SIGNATURE <> ''
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT USER_ID
			FROM {$config['TABLE_PREFIX']}USER_PROFILE
			WHERE USER_DEFAULT_SIGNATURE <> ''
			ORDER BY USER_ID ASC
			LIMIT ?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$posts[] = $result['USER_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_signatures($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_SIGNATURES'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=signatures&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_SIGNATURES_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
			$time = 10;
			admin_log("REBUILD_SIGNATURES", $message);
		}

		break;

	case "postcounts":
		if (!$start) {
			admin_log("REBUILD_POSTCOUNTS", $ubbt_lang['ACTION_BEGIN']);
		}
		// Set everybody's count to zero first, then let it rip
		if ($start == 0) {
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
				SET USER_TOTAL_POSTS = 0
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
		}

		$query = "
			SELECT COUNT(USER_ID) AS COUNT
			FROM {$config['TABLE_PREFIX']}USER_PROFILE
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT USER_ID
			FROM {$config['TABLE_PREFIX']}USER_PROFILE
			ORDER BY USER_ID ASC
			LIMIT ?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$posts[] = $result['USER_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_user_postcounts($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_POST_COUNTS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=postcounts&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_POST_COUNTS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
			$time = 10;
			admin_log("REBUILD_POSTCOUNTS", $message);
		}

		break;

	case "likecounts":
		if (!$start) {
			admin_log("REBUILD_LIKECOUNTS", $ubbt_lang['ACTION_BEGIN']);
		}
		// Set everybody's count to zero first, then let it rip
		if ($start == 0) {
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
				SET USER_LIKES = 0
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
		}

		$query = "
			SELECT COUNT(USER_ID) AS COUNT
			FROM {$config['TABLE_PREFIX']}USER_PROFILE
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT USER_ID
			FROM {$config['TABLE_PREFIX']}USER_PROFILE
			ORDER BY USER_ID ASC
			LIMIT ?, ?
		";

		$likes = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$likes[] = $result['USER_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($likes) > 0) {
			rebuild_user_likecounts($likes);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_LIKE_COUNTS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=likecounts&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_LIKE_COUNTS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
			$time = 10;
			admin_log("REBUILD_LIKECOUNTS", $message);
		}

		break;

	case "private_messages":
		if (!$start) {
			admin_log("REBUILD_MESSAGES", $ubbt_lang['ACTION_BEGIN']);
		}
		$query = "
			SELECT COUNT(POST_ID) AS COUNT
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT POST_ID
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			ORDER BY POST_ID ASC
			LIMIT ?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$posts[] = $result['POST_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_private_messages($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_PMS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=private_messages&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_PMS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
			$time = 10;
			admin_log("REBUILD_MESSAGES", $message);
		}
		break;

	case "topics":
		if (!$start) {
			admin_log("REBUILD_TOPICS", $ubbt_lang['ACTION_BEGIN']);
		}
		$query = "
			SELECT FORUM_ID, TOPIC_ID
			FROM {$config['TABLE_PREFIX']}ANNOUNCEMENTS
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$stickies = array();
		while (list($fid, $tid) = $dbh->fetch_array($sth)) {
			$stickes[$tid] = $fid;
		}
		$query = "
			SELECT COUNT(TOPIC_ID) AS COUNT
			FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_STATUS <> 'M'
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT TOPIC_ID
			FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_STATUS <> 'M'
			ORDER BY TOPIC_ID ASC
			LIMIT ?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$posts[] = $result['TOPIC_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_topics($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_TOPICS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=topics&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_TOPICS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
			$time = 10;
			admin_log("REBUILD_TOPICS", $message);
		}
		break;

	case "prunepostorphans":
		if (!$start) {
			admin_log("PRUNE_ORPHANS", $ubbt_lang['ACTION_BEGIN']);
		}
		$time = "5";

		// Grab an initial count for display purposes
		$query = "
			SELECT COUNT(TOPIC_ID) AS COUNT
			FROM {$config['TABLE_PREFIX']}POSTS
			WHERE POST_IS_TOPIC = 0
			  AND TOPIC_ID NOT IN (
				SELECT TOPIC_ID
				FROM {$config['TABLE_PREFIX']}TOPICS
			)
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$total = $tmp['COUNT'];
		$query = "
			DELETE
			FROM {$config['TABLE_PREFIX']}POSTS
			WHERE POST_IS_TOPIC = 0
			  AND TOPIC_ID NOT IN (
				SELECT TOPIC_ID
				FROM {$config['TABLE_PREFIX']}TOPICS
			)
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$dbh->finish_sth($sth);

		// This is our last page.
		$message = sprintf($ubbt_lang['PRUNE_POSTS_COMPLETE'], $total);
		$redirect = "rebuildcontent.php";
		set_board_is_open(true);
		$time = 10;
		admin_log("PRUNE_ORPHANS", $message);
	break;

	case "pruneptorphans":
		if (!$start) {
			admin_log("PRUNE_ORPHANS", $ubbt_lang['ACTION_BEGIN']);
		}
		// Get current number of orphans left (the hard way, because of mysql 4.0 restriction)

		/* For future (4.1+)
				$query = "
					SELECT TOPIC_ID
					FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
					WHERE
						TOPIC_ID IN (
							SELECT TOPIC_ID
							FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
							WHERE USER_ID = 1
					)
					AND TOPIC_ID NOT IN (
						SELECT TOPIC_ID
						FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
						WHERE USER_ID <> 1
					)
				";
		*/
		$query = "
			SELECT TOPIC_ID
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			WHERE USER_ID = 1
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$uber_in = array();
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$uber_in[] = $result['TOPIC_ID'];
		}
		$query = "
			SELECT TOPIC_ID
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			WHERE USER_ID <> 1
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$uber_notin = array();
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$uber_notin[] = $result['TOPIC_ID'];
		}
		// Setup for the IN (xx), but add safety net for empties
		if (count($uber_in) > 0) {
			$in_list = '(' . implode(',', $uber_in) . ')';
		} else {
			$in_list = '(-1)';
		}
		if (count($uber_notin) > 0) {
			$notin_list = '(' . implode(',', $uber_notin) . ')';
		} else {
			$notin_list = '(-1)';
		}

		// Grab an initial count for display purposes
		if ($start == 0) {
			$query = "
				SELECT COUNT(TOPIC_ID) AS COUNT
				FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
				WHERE TOPIC_ID IN $in_list
				  AND TOPIC_ID NOT IN $notin_list
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$total = $tmp['COUNT'];
		} else {
			$total = $pretotal;
		}

		$query = "
			SELECT TOPIC_ID
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			WHERE TOPIC_ID IN $in_list
			  AND TOPIC_ID NOT IN $notin_list
			LIMIT ?
		";
		$sth = $dbh->do_placeholder_query($query, array($limit), __LINE__, __FILE__);
		$topics = array();
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$topics[] = $result['TOPIC_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($topics) > 0) {
			prune_empty_private_topics($topics);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['PRUNING_PRIVATE_TOPICS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=pruneorphans&amp;start=" . ($start + $limit) . "&amp;pretotal=" . $total;
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['PRUNE_PRIVATE_TOPICS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
			$time = 10;
			admin_log("PRUNE_ORPHANS", $message);
		}
		break;

	case "updatescheme":
		if (!$start) {
			admin_log("UPDATE_SCHEME", $ubbt_lang['ACTION_BEGIN']);
		}
		$time = "5";

//	This can be useful for quickly performing custom text replacements in posts.
//	When enabled, this will only update the content within ubbt_POSTS.POST_DEFAULT_BODY and ubbt_POSTS.POST_BODY
	// 0 = off (for production use) default
	// 1 = custom replacements
	$custom = 0;

	if ($custom) {
		// WARNING: MAKE THESE PHRASES AS LONG AND COMPLETE AS POSIBLE.
		// THERE IS NO "UNDO" AFTER THE REPLACEMENTS ARE DONE!
		$oldphrase = "https://EXAMPLE.com/photos/download/12345/picture.jpg";
		$newphrase = "https://EXAMPLE.com/gallery/data/picture.jpg";
	} else {
		$oldphrase = str_replace("https://", "http://", $config['FULL_URL']);
		$newphrase = str_replace("http://", "https://", $config['FULL_URL']);
	}

// ** BE VERY CAREFUL OF "POST_DEFAULT_BODY" and "POST_BODY" USAGE - DO NOT INTERCHANGE THEM
// * POST_DEFAULT_BODY - [BBCode] This is the original post. CONTENT REBUILDER > REBUILD POSTS takes this and converts it to POST_BODY [HTML]
// * POST_BODY - [HTML] This is shown to the user. it is generated from POST_DEFAULT_BODY

		if ($start == 0) {
// -----------------
// ** Update posts:
// * ubbt_POSTS.POST_DEFAULT_BODY
			$query = "
				UPDATE {$config['TABLE_PREFIX']}POSTS
				SET POST_DEFAULT_BODY = replace(POST_DEFAULT_BODY, '$oldphrase', '$newphrase');
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$dbh->finish_sth($sth);
			$message = sprintf($ubbt_lang['UPDATING_POSTS_DEFAULT_BODY'], $config['TABLE_PREFIX']);
			$message = ($config['ALLOW_DEBUGGING']) ? $message . "<pre class=\"debug\">\n$query\n</pre>" : $message;
			$redirect = "dorebuildcontent.php?mode=updatescheme&amp;start=1";
			set_board_is_open(false);
		} else if ($start == 1) {
//	* ubbt_POSTS.POST_BODY
			$query = "
				UPDATE {$config['TABLE_PREFIX']}POSTS
				SET POST_BODY = replace(POST_BODY, '$oldphrase', '$newphrase');
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$dbh->finish_sth($sth);
			$message = sprintf($ubbt_lang['UPDATING_POSTS_BODY'], $config['TABLE_PREFIX']);
			$message = ($config['ALLOW_DEBUGGING']) ? $message . "<pre class=\"debug\">\n$query\n</pre>" : $message;
			$redirect = "dorebuildcontent.php?mode=updatescheme&amp;start=2";
			set_board_is_open(false);
		} else if ($start == 2) {
// -----------------
// ** Update private messages:
// * ubbt_PRIVATE_MESSAGE_POSTS.POST_DEFAULT_BODY
			$query = "
				UPDATE {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
				SET POST_DEFAULT_BODY = replace(POST_DEFAULT_BODY, '$oldphrase', '$newphrase');
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$dbh->finish_sth($sth);
			$message = sprintf($ubbt_lang['UPDATING_PM_POST_DEFAULT_BODY'], $config['TABLE_PREFIX']);
			$message = ($config['ALLOW_DEBUGGING']) ? $message . "<pre class=\"debug\">\n$query\n</pre>" : $message;
			$redirect = "dorebuildcontent.php?mode=updatescheme&amp;start=3";
			set_board_is_open(false);
		} else if ($start == 3) {
// * ubbt_PRIVATE_MESSAGE_POSTS.POST_BODY
			$query = "
				UPDATE {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
				SET POST_BODY = replace(POST_BODY, '$oldphrase', '$newphrase');
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$dbh->finish_sth($sth);
			$message = sprintf($ubbt_lang['UPDATING_PM_POST_BODY'], $config['TABLE_PREFIX']);
			$message = ($config['ALLOW_DEBUGGING']) ? $message . "<pre class=\"debug\">\n$query\n</pre>" : $message;
			$redirect = "dorebuildcontent.php?mode=updatescheme&amp;start=4";
			set_board_is_open(false);
		} else if ($start == 4) {
// -----------------
// ** Update user avatars:
// * ubbt_USER_PROFILE.USER_AVATAR
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
				SET USER_AVATAR = replace(USER_AVATAR, '$oldphrase', '$newphrase');
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$dbh->finish_sth($sth);
			$message = sprintf($ubbt_lang['UPDATING_USER_AVATAR'], $config['TABLE_PREFIX']);
			$message = ($config['ALLOW_DEBUGGING']) ? $message . "<pre class=\"debug\">\n$query\n</pre>" : $message;
			$redirect = "dorebuildcontent.php?mode=updatescheme&amp;start=5";
			set_board_is_open(false);
		} else if ($start == 5) {
// -----------------
// ** Update profile comments:
// * ubbt_PROFILE_COMMENTS.COMMENT_BODY
			$query = "
				UPDATE {$config['TABLE_PREFIX']}PROFILE_COMMENTS
				SET COMMENT_BODY = replace(COMMENT_BODY, '$oldphrase', '$newphrase');
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$dbh->finish_sth($sth);
			$message = sprintf($ubbt_lang['UPDATING_PROFILE_COMMENTS_BODY'], $config['TABLE_PREFIX']);
			$message = ($config['ALLOW_DEBUGGING']) ? $message . "<pre class=\"debug\">\n$query\n</pre>" : $message;
			$redirect = "dorebuildcontent.php?mode=updatescheme&amp;start=6";
			set_board_is_open(false);
		} else if ($start == 6) {
// -----------------
// ** Update user signatures:
// * ubbt_USER_PROFILE.USER_DEFAULT_SIGNATURE
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
				SET USER_DEFAULT_SIGNATURE = replace(USER_DEFAULT_SIGNATURE, '$oldphrase', '$newphrase');
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$dbh->finish_sth($sth);
			$message = sprintf($ubbt_lang['UPDATING_USER_DEFAULT_SIGNATURE'], $config['TABLE_PREFIX']);
			$message = ($config['ALLOW_DEBUGGING']) ? $message . "<pre class=\"debug\">\n$query\n</pre>" : $message;
			$redirect = "dorebuildcontent.php?mode=updatescheme&amp;start=7";
			set_board_is_open(false);
		} else if ($start == 7) {
// * ubbt_USER_PROFILE.USER_SIGNATURE
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
				SET USER_SIGNATURE = replace(USER_SIGNATURE, '$oldphrase', '$newphrase');
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$dbh->finish_sth($sth);
			$message = sprintf($ubbt_lang['UPDATING_USER_SIGNATURE'], $config['TABLE_PREFIX']);
			$message = ($config['ALLOW_DEBUGGING']) ? $message . "<pre class=\"debug\">\n$query\n</pre>" : $message;
			$redirect = "dorebuildcontent.php?mode=updatescheme&amp;start=8";
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = $ubbt_lang['UPDATE_SCHEME_COMPLETE'];
			if ($custom) {
				$message = $ubbt_lang['CUSTOM_REPLACEMENTS_COMPLETE'];
			}
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
			$time = 10;
			admin_log("UPDATE_SCHEME", $message);
		}
	break;

	case "forums":
		if (!$start) {
			admin_log("REBUILD_FORUMS", $ubbt_lang['ACTION_BEGIN']);
		}
		$query = "
			SELECT COUNT(FORUM_ID) AS COUNT
			FROM {$config['TABLE_PREFIX']}FORUMS
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT FORUM_ID
			FROM {$config['TABLE_PREFIX']}FORUMS
			ORDER BY FORUM_ID ASC
			LIMIT ?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
			$posts[] = $result['FORUM_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_forums($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_FORUMS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=forums&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_FORUMS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
			$time = 10;
			admin_log("REBUILD_FORUMS", $message);
		}
		break;
	default:
		$admin->error("Ian forgot to account for the mode: " . $mode);
}

// I love people who post their code!
function is_utf8($string) {
	// From https://www.w3.org/International/questions/qa-forms-utf-8.en.html
	return preg_match('%(?:
		[\xC2-\xDF][\x80-\xBF]
		|\xE0[\xA0-\xBF][\x80-\xBF]
		|[\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}
		|\xED[\x80-\x9F][\x80-\xBF]
		|\xF0[\x90-\xBF][\x80-\xBF]{2}
		|[\xF1-\xF3][\x80-\xBF]{3}
		|\xF4[\x80-\x8F][\x80-\xBF]{2}
	)+%xs', $string);
} // function is_utf8

function set_board_is_open($on = true) {
	require("../includes/config.inc.php");
	$on = $on ? '0' : '1';
	if ($config['BOARD_IS_CLOSED'] != $on) {
		$config['BOARD_IS_CLOSED'] = $on;
		lock_and_write("{$config['FULL_PATH']}/includes/config.inc.php", '<?php $config = ' . var_export($config, true) . '; ?>');
	}
}

$time = ($time) ? $time : 2;

$admin->redirect($message, "{$config['BASE_URL']}/admin/" . $redirect, $ubbt_lang['REBUILD_FORWARDED'], $time);

?>