<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/viewboard.php");

// -------------
// Get the input
$returntab = get_input("returntab", "get");

// -----------------
// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$forumimage = "{$config['BASE_URL']}/images/{$style_array['general']}/blank.gif";
$avurl = "";

// Grab the categories
$query = "
	SELECT
		CATEGORY_TITLE, CATEGORY_ID
	FROM
		{$config['TABLE_PREFIX']}CATEGORIES
	ORDER BY
		CATEGORY_ID
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$catlist = "";
while (list($Catlist, $Catnumlist) = $dbh->fetch_array($sth)) {
	$thisisit = "";
	$catlist .= "<option value=\"cat_$Catnumlist\">$Catlist</option>";
	$query = "
		SELECT
			FORUM_TITLE, FORUM_ID
		FROM
			{$config['TABLE_PREFIX']}FORUMS
		WHERE
			(FORUM_PARENT IS NULL OR FORUM_PARENT = '')
		AND CATEGORY_ID = '$Catnumlist'
		ORDER BY
			FORUM_SORT_ORDER
	";
	$sti = $dbh->do_query($query, __LINE__, __FILE__);
	while (list($forum_title, $forum_id) = $dbh->fetch_array($sti)) {
		$catlist .= "<option value=\"forum_$forum_id\">&nbsp;&nbsp;&nbsp;$forum_title</option>";
	}
}
$dbh->finish_sth($sth);

include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree, $style_cache, $lang_cache) = build_forum_cache();
}

$catlist = "";
$category = "";
$forums = 0;
foreach ($tree['categories'] as $cat => $cat_title) {
	$category = "";
	$category .= "<option value=\"category_$cat\">$cat_title ------</option>";
	if (!isset($tree[$cat])) {
		$catlist .= $category;
		continue;
	}
	foreach ($tree[$cat] as $forum_id => $forum_title) {
		$category .= "<option value=\"forum_$forum_id\">$forum_title</option>";
	}
	$catlist .= $category;
}

// What options exists for captcha?
$gd = true;
$im = true;
if (!function_exists(imagefttext)) {
	$gd = false;
}
if (!$config['CONVERT_PATH']) {
	$im = false;
}

$captcha_disabled = "selected=\"selected\"";
$captcha_gd = "";
$captcha_im = "";

$no_captcha = "";
if (!$gd && !$im) {
	$no_captcha = $ubbt_lang['NO_CAPTCHA'];
}


// Grab the stylesheets
$stylelist = "";
$query = "
	SELECT
		STYLE_ID, STYLE_NAME
	FROM
		{$config['TABLE_PREFIX']}STYLES
	WHERE
		STYLE_IS_ACTIVE = '1'
	ORDER BY
		STYLE_NAME
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($stylesheet, $desc) = $dbh->fetch_array($sth)) {
	$stylenames[$stylesheet] = $desc;
	$stylelist .= "<option value=\"$stylesheet\">$desc</option>";
}

$query = "
	SELECT
		PORTAL_ID, PORTAL_NAME
	FROM
		{$config['TABLE_PREFIX']}PORTAL_BOXES
	WHERE
		PORTAL_CUSTOM = '1'
	ORDER BY
		PORTAL_ID
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$island_selection = "<option value=\"0\">{$ubbt_lang['NO_INSERT']}</option>";
while (list($portal_id, $portal_name) = $dbh->fetch_array($sth)) {
	$island_selection .= "<option value=\"$portal_id\">$portal_name</option>";
}

// Update language string substitutions
$ubbt_lang['FORUM_GALLERY_DESC'] = $html->substitute($ubbt_lang['FORUM_GALLERY_DESC'], array("BASE_URL" => $config['BASE_URL']));
$ubbt_lang['NO_WRITE_FORUM_INTRO'] = $html->substitute($ubbt_lang['NO_WRITE_FORUM_INTRO'], array("FULL_PATH" => $config['FULL_PATH']));
$ubbt_lang['ISLAND_INSERT_1'] = $html->substitute($ubbt_lang['ISLAND_INSERT_1'], array("BASE_URL" => $config['BASE_URL']));
$ubbt_lang['ATTACH_ON_1'] = $html->substitute($ubbt_lang['ATTACH_ON_1'], array("BASE_URL" => $config['BASE_URL']));

$tabs = array(
	"{$ubbt_lang['FORUM_BASICS']}" => "",
	"{$ubbt_lang['HEADFOOT']}" => "",
	"{$ubbt_lang['RSS']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['FORUM_SET']);
$admin->setParentTitle($ubbt_lang['FORUM_SET'], "forummanage.php");
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['ADD_NEW']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);
$admin->setCommonSubmit($ubbt_lang['ADD_NEW']);

// Include the template
include("../templates/default/admin/createforum.tmpl");

$admin->sendFooter();

?>