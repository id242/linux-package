<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/languageeditor2.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();

// get the input
$returntab = 1;
$language = get_input("language", "both");
$filename = get_input("filename", "both");
$keyhigh = get_input("keyhigh", "both");
$searchstring = get_input("searchstring", "both");
$searchfilename = get_input("searchfilename", "both");

$tempfile = file("{$config['FULL_PATH']}/languages/$language/$filename");

// We need to grab the charset for the language file we are going to edit
require("../languages/$language/generic.php");
$charset = $ubbt_lang['CHARSET'];
require("../languages/{$config['LANGUAGE']}/generic.php");

// -----------------------------------------------
// We need to put each language file entry on one line
$langarray = check_lang_file("{$config['FULL_PATH']}/languages/$language/$filename");

$stringlist = "";
foreach ($langarray as $key => $value) {

	if ($key == "searchfilename") {
		continue;
	}
	// -----------------------------------------------------------
	// Let's see how many rows we should have for these text areas
	if (!preg_match("/\n/", $value)) {
		$valuelength = strlen($value);
		$rows = intval($valuelength / 50);

	} else {
		$rows = 1;
		$breaks = preg_split("#\n#", $value);
		for ($i = 0; $i < sizeof($breaks); $i++) {
			$rows = $rows + 1;
			$valuelength = strlen($breaks[$i]);
			$morerows = intval($valuelength / 50);
			$rows = $rows + $morerows;
		}
	}
	if ($rows < 2) {
		$rows = 2;
	}
	$value = ubbchars($value);
	$keyprint = $key;
	if ($keyhigh == $key) {
		$keyprint = sprintf('<span class="mswarning">%s</span>', $key);
	}
	$stringlist .= "<tr>
<td class=\"colored-row stdautorow alvt\"><a name=\"$key\"></a>$keyprint</td>
<td class=\"colored-row stdautorow alvt\"><textarea name=\"$key\" rows=\"$rows\" class=\"formboxes fw\">$value</textarea></td>
</tr>\n";
}

$newstrings = "";

for ($i = 0; $i < 5; $i++) {
	$newstrings .= "<tr>
<td class=\"colored-row stdautorow alvt\"><input type=\"text\" name=\"key$i\" class=\"formboxes fw\"></td>
<td class=\"colored-row stdautorow alvt\"><textarea name=\"string$i\" rows=\"3\" class=\"formboxes fw\"></textarea></td>
</tr>\n";
}

$searchstring = urlencode($searchstring);
$searchfilename = urlencode($searchfilename);


$tabs = array(
	"{$ubbt_lang['LANG_EDIT']}" => ""
);

function check_lang_file($file, $search = "") {
	require($file);
	return $ubbt_lang;
}

// Create the Page
$admin->setCurrentMenu($ubbt_lang['LANGS']);
$admin->setParentTitle($ubbt_lang['LANGS'], "availablelangs.php");
$admin->setPageTitle($ubbt_lang['LANG_EDIT']);
$admin->sendHeader($charset);
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/languageeditor2.tmpl");

$admin->sendFooter();

?>