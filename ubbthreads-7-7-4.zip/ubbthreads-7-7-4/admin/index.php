<!doctype html>
<html>
<head>
	<title>index.html</title>
	<meta charset="utf-8"/>
	<meta http-equiv="refresh" content="0;url=dashboard.php"/>
</head>
<body></body>
</html>