<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/paths_db.php");

// Get the input
$returntab = get_input("returntab", "both");

// Get the user info
$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth();

// Set the default values
$ischecked = 'checked="checked"';

$config['TABLE_PREFIX'] = (!isset($config['TABLE_PREFIX'])) ? "ubbt_" : $config['TABLE_PREFIX'];

$PERSISTENT_DB_CONNECTION = ($config['PERSISTENT_DB_CONNECTION']) ? $ischecked : "";

$UTF8 = ($config['UTF8']) ? $ischecked : "";

// Update language string substitutions
$ubbt_lang['UTF8_1'] = $html->substitute($ubbt_lang['UTF8_1'], array("BASE_URL" => $config['BASE_URL']));

$tabs = array(
	"{$ubbt_lang['PATH_URL']}" => "",
	"{$ubbt_lang['DATABASE_CONFIG']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['DB_P_URL']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['DB_P_URL']);
$admin->sendHeader();
$admin->createTopTabs($tabs);
$admin->setCommonSubmit($ubbt_lang['UPDATE']);

// Include the template
include("../templates/default/admin/paths_db.tmpl");

$admin->sendFooter();

?>