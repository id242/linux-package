<?php
//	Script Version 7.7.0

$changes = array(
	"7.1" => array(
		".newtotal" => array(
			"copy" => ".small",
		),
		".popup_content" => array(
			"copy" => ".t_standard",
		),
		".post-buttons" => array(
			"copy" => ".t_standard",
		),
	),
	"7.2b1" => array(
		".forum_extras" => array(
			"copy" => ".small",
		),
		".author-content" => array(
			"copy" => ".alt-2",
		),
		".alt-newintopic" => array(
			"copy" => ".newintopic",
		),
		".alt-topicicon" => array(
			"copy" => ".topicicon",
		),
		".alt-topicsubject" => array(
			"copy" => ".topicsubject",
		),
		".alt-topicreplies" => array(
			"copy" => ".topicreplies",
		),
		".alt-topicviews" => array(
			"copy" => ".topicviews",
		),
		".alt-topictime" => array(
			"copy" => ".topictime",
		),
		".new-newintopic" => array(
			"copy" => ".newintopic",
		),
		".new-topicicon" => array(
			"copy" => ".topicicon",
		),
		".new-topicsubject" => array(
			"copy" => ".topicsubject",
		),
		".new-topicreplies" => array(
			"copy" => ".topicreplies",
		),
		".new-topicviews" => array(
			"copy" => ".topicviews",
		),
		".new-topictime" => array(
			"copy" => ".topictime",
		),
	),
	"7.2b2" => array(
		".new-alt-newintopic" => array(
			"copy" => ".newintopic",
		),
		".new-alt-topicicon" => array(
			"copy" => ".topicicon",
		),
		".new-alt-topicsubject" => array(
			"copy" => ".topicsubject",
		),
		".new-alt-topicreplies" => array(
			"copy" => ".topicreplies",
		),
		".new-alt-topicviews" => array(
			"copy" => ".topicviews",
		),
		".new-alt-topictime" => array(
			"copy" => ".topictime",
		),
	),
	"7.3a1" => array(
		".ubb_popup_body" => array(
			"copy" => "body",
		),
		".inline_selected" => array(
			"copy" => ".tdheader",
		),
		".inline_selector" => array(
			"copy" => ".new_topicsubject",
		),
		".post_top_link" => array(
			"copy" => ".private_unread",
		),
		".globalmodname" => array(
			"set" => "color: #00AAFF;",
		),
		".bbcodecomment" => array(
			"set" => "color: green;",
		),
		".bbcodedefault" => array(
			"set" => "color: #000000;",
		),
		".bbcodekeyword" => array(
			"set" => "color: maroon;",
		),
		".bbcodestring" => array(
			"set" => "color: goldenrod;",
		),
		".bbcodehtml" => array(
			"set" => "color: dodgerblue;",
		),
		".popup_content_header" => array(
			"set" => "width: 500px;
display: block;
font-weight: bold;
padding: 4px;
color: #666666;
background: #EEEECC;
border: 1px solid #AAAAAA;",
		),
		".popup_content" => array(
			"set" => "width: 500px;
overflow: auto;
font-size: 10pt;
display: block;
background: white;
border: 1px solid #AAAAAA;
padding: 4px;",
		),
	),
	"7.3a2" => array(
		".email-header" => array(
			"set" => "background: #0066A7;
color: #F0F0F0;
font-size: 10pt;
padding: 4px;
border-bottom: 1px solid #224988;
text-align: center;",
		),
		".email-tdheader" => array(
			"set" => "padding: 4px 6px;
color: #E0E0E0;
background: #2E669A;
border: 1px solid #224988;
border-bottom: 0px;
font-size: 10pt;",
		),
		".email-tdbody" => array(
			"set" => "background: E9F5F7;
color: #000;
padding: 4px 6px;
border: 1px solid #224988;
font-size: 1pt;",
		),
		".email-footer" => array(
			"set" => "background: #0066A7;
color: #F0F0F0;
font-size: 10pt;
padding: 4px;
border-top: 1px solid navy;
text-align: center;",
		),
		".email-body" => array(
			"set" => "background: #FDFBE7;
color: #F0F0F0;
padding: 4px;
border-collapse: collapse;
border: 1px solid #0F0F0F;
font-family: Verdana, Arial, Helvetica, sans-serif;",
		),
	),
	"7.3a3" => array(
		".de0" => array(
			"set" => "border: 2px solid #AAAA11;
padding-left: 4px;",
		),
		".kw0" => array(
			"set" => "color: #FF9460;",
		),
		".co0" => array(
			"set" => "color: #11AA22;",
		),
		".st0" => array(
			"set" => "color: #59AF59;",
		),
		".br0" => array(
			"set" => "color: #000000;",
		),
		".es0" => array(
			"set" => "color: #002299;",
		),
		".nu0" => array(
			"set" => "color: #FF1111;",
		),
		".me0" => array(
			"set" => "color: #0000FF;",
		),
		".li1" => array(
			"set" => "color: #FFF;",
		),
		".li2" => array(
			"set" => "color: #F8F8F8;",
		),
		".li0" => array(
			"set" => "color: #E8E8E8",
		),
		".search_highlight" => array(
			"set" => "background: #FFFF00;
color: #000000;",
		),
	),
);

?>