<?php
//	Script Version 7.7.2

// Require the library
require("../libs/admin.inc.php");
require("../languages/" . $config["LANGUAGE"] . "/admin/primary.php");
require("../languages/" . $config["LANGUAGE"] . "/admin/generic.php");
require("../languages/" . $config["LANGUAGE"] . "/admin/stop_forum_spam.php");

// Utilized to submit data to the Stop Forum Spam database
// Stop Forum Spam - PostToHost function
function PostToHost($data) {
	$fp = fsockopen("www.stopforumspam.com", 80);
	fputs($fp, "POST /add.php HTTP/1.1\n");
	fputs($fp, "Host: www.stopforumspam.com\n");
	fputs($fp, "Content-type: application/x-www-form-urlencoded\n");
	fputs($fp, "Content-length: " . strlen($data) . "\n");
	fputs($fp, "Connection: close\n\n");
	fputs($fp, $data);
	$output = "";
	while (!feof($fp)) {
		$output .= fgets($fp, 1024);
	}
	fclose($fp);
}

// Stop Forum Spam - check_ip helps ensure only IPv4 addresses are being passed
function check_ip($str) {
	if (filter_var($str, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
		return ("IPv4");
	} elseif (filter_var($str, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
		return ("IPv6");
	} else {
		return ("Unknown");
	}
}

// Fetch supplied information
$op = get_input("op", "both");
$id = get_input("id", "both", "int");

// Fetch user information
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");
$html = new html;

$admin = new Admin;
$admin->doAuth(array("EDIT_USERS"));

// Validate API status
if ($op == "test") {
	$xmlResult = @file_get_contents("https://www.stopforumspam.com/api?ip=" . $_SERVER["SERVER_ADDR"]);

	if ($xmlResult != false) {
		$xml = new SimpleXMLElement($xmlResult);
		if ($xml->appears == "no") {
			$SFS_Status_Class = "sfsgood";
			$SFS_Status = $ubbt_lang["SFS_STAT_GOOD"];
		} else {
			$SFS_Status_Class = "sfsbad";
			$SFS_Status = $ubbt_lang["SFS_STAT_BAD"];
		}
	}

	echo <<<UBBTPRINT
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>{$ubbt_lang["SFS_TITLE"]}</title>
<link rel="stylesheet" href="{$config["BASE_URL"]}/styles/common.css">
<link rel="stylesheet" href="{$config["BASE_URL"]}/styles/admin.css">
<link rel="shortcut icon" href="{$config['BASE_URL']}/images/general/default/favicon.ico">
</head>
<body class="p10">

<table class="fw">
	<tr>
		<td class="sfs-header bold p6 alvm">{$ubbt_lang["SFS_TITLE"]}</td>
	</tr>
	<tr>
		<td class="sfs-info-row p10">
			<span class="{$SFS_Status_Class}">{$ubbt_lang["SFS_STAT_DESC"]}{$SFS_Status}</span>
		</td>
	</tr>
</table>

</body>
</html>
UBBTPRINT;
} elseif ($op == "info" || $op == "spammer") {
// Check EMail and 2 IP Addresses
	$q = "
		SELECT u.USER_LOGIN_NAME,u.USER_REGISTRATION_EMAIL,
			u.USER_REGISTERED_ON,u.USER_REGISTRATION_IP,
			ud.USER_LAST_POST_TIME,ud.USER_LAST_IP
		FROM " . $config["TABLE_PREFIX"] . "USERS u, " . $config["TABLE_PREFIX"] . "USER_DATA ud
		WHERE u.USER_ID='" . $id . "'
		AND u.USER_ID = ud.USER_ID
	";
	$sth = $dbh->do_query($q);
	list($userName, $regEmail,
		$regdate, $regIP,
		$lastpost, $lastIP) = $dbh->fetch_array($sth);

// Setup the default values
	if (strlen($regdate) < 8) {
		$regdate = $ubbt_lang['UNAVAIL'];
	} else {
		$regdate = $html->convert_time($regdate, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
	}

	if ($lastpost) {
		$lastpost = $html->convert_time($lastpost, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
	}

// Check the EMail and Registration IP Addresses first
	list($retStat, $retEmail, $retRegIp) = $userob->sfsCheck($regEmail, $regIP);

	$sfsError = 0;
	if ($retStat == 0) {
		if ($retEmail == 1) {
			$emailStat = "<span class=\"sfs-bad-stat\">" . $ubbt_lang["SFS_BAD_EMAIL"] . "</span>";
			$emailStatBAD = " (SFS!)";
		} else {
			$emailStat = "<span class=\"sfs-good-stat\">" . $ubbt_lang["SFS_GOOD_EMAIL"] . "</span>";
		}
		if ($retRegIp == 1) {
			$ipRegStat = "<span class=\"sfs-bad-stat\">" . $ubbt_lang["SFS_BAD_IP"] . "</span>";
			$ipRegStatBAD = " (SFS!)";
		} else {
			$ipRegStat = "<span class=\"sfs-good-stat\">" . $ubbt_lang["SFS_GOOD_IP"] . "</span>";
		}
	} else {
		$sfsError = 1;
	}

// Check Last IP
	$ipLastStat = "";
	$ipLastStatLOG = "";
	if ($lastIP != "") {
		list($retStat, $retEmail, $retLastIp) = $userob->sfsCheck($regEmail, $lastIP);

		$sfsError = 0;
		if ($retStat == 0) {
			if ($retRegIp == 1) {
				$ipLastStat = "<span class=\"sfs-bad-stat\">" . $ubbt_lang["SFS_BAD_IP"] . "</span>";
				$ipLastStatLOG = "<br>LastIP: $lastIP (SFS!)";
			} else {
				$ipLastStat = "<span class=\"sfs-good-stat\">" . $ubbt_lang["SFS_GOOD_IP"] . "</span>";
				$ipLastStatLOG = "<br>LastIP: $lastIP";
			}
		} else {
			$sfsError = 1;
		}
	}

	admin_log("SFS_CHECK", "<a href='{$config['BASE_URL']}/admin/showuser.php?uid=$id' target='_blank'>" . $id . ": " . $userName . " (" . $regEmail . ") " . $emailStatBAD . "<br>RegIP: $regIP $ipRegStatBAD" . "$ipLastStatLOG</a>");

	echo <<<UBBTPRINT
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>{$ubbt_lang["SFS_TITLE"]}</title>
<link rel="stylesheet" href="{$config["BASE_URL"]}/styles/common.css">
<link rel="stylesheet" href="{$config["BASE_URL"]}/styles/admin.css">
<link rel="shortcut icon" href="{$config['BASE_URL']}/images/general/default/favicon.ico">
</head>
<body style="background:transparent;">

<table class="fw">
	<tr>
		<td class="autorow-header-2 bold autobottom fw alvm" colspan="2">{$ubbt_lang["SPAM_CHECK"]}</td>
	</tr>
	<tr>
		<td class="sfs-info-row" style="width:75%;">
<span class="autorow-title">{$ubbt_lang["SFS_EMAIL_STATUS"]}</span>
<span class="autorow-description">{$regEmail}</span>
		</td>
		<td class="sfs-info-row nw" style="width:25%;">
{$emailStat}
		</td>
	</tr>
	<tr>
		<td class="sfs-info-row" style="width:75%;">
<span class="autorow-title">{$ubbt_lang["SFS_REG_IP_STATUS"]}</span>
<span class="autorow-description">{$regdate}<br>{$regIP}</span>
		</td>
		<td class="sfs-info-row nw" style="width:25%;">
{$ipRegStat}
		</td>
	</tr>
UBBTPRINT;
	if ($ipLastStat != "") {
		echo <<<UBBTPRINT
	<tr>
		<td class="sfs-info-row" style="width:75%;">
<span class="autorow-title">{$ubbt_lang["SFS_LAST_IP_STATUS"]}</span>
<span class="autorow-description">{$lastpost}<br>{$lastIP}</span>
		</td>
		<td class="sfs-info-row nw" style="width:25%;">
{$ipLastStat}
		</td>
	</tr>
UBBTPRINT;
	}

// Generate a "Report Spammer" button with a warning about abusing the Stop Forum Spam service
	if ($config["SFS_KEY"] != "") {
		if ($op == "spammer") {
			$ubbt_lang["SFS_REPORT_SPAMMER"] = $ubbt_lang["SFS_REPORTED_SPAMMER"];
			$safeEmail = urlencode(iconv("GBK", "UTF-8", $regEmail));
			$safeName = urlencode(iconv("GBK", "UTF-8", $userName));
			PostToHost("username=" . $safeName . "&ip_addr=" . $regIP . "&email=" . $safeEmail . "&api_key=" . $config["SFS_KEY"]);
			admin_log("SFS_REPORT", "<a href='{$config['BASE_URL']}/admin/showuser.php?uid=$id' target='_blank'>User: " . $userName . "<br>Email: " . $regEmail . "<br>regIP: " . $regIP . "</a>");
		}
		echo <<<UBBTPRINT
	<tr>
		<td class="colored-row padding stdautorow bold" colspan="2">
{$ubbt_lang["SFS_REPORT_INSTRUCTIONS"]}
		</td>
	</tr>
	<tr>
		<td class="paddingtop paddingbottom stdautorow acvt" colspan="2">
<form method="post" id="spamform" action="{$config["BASE_URL"]}/admin/test_stopforumspam.php">
	<input type="hidden" name="valid_post" value="1" />
	<input type="hidden" name="op" value="spammer" />
	<input type="hidden" name="id" value="{$id}" />
	<input type="submit" class="form-button" value="{$ubbt_lang["SFS_REPORT_SPAMMER"]}" />
	<button type="button" onclick="parent.jQuery.colorbox.close();return false;" class="form-button">Close</button>
</form>
		</td>
	</tr>
UBBTPRINT;
	}
	echo <<<UBBTPRINT
</table>

</body>
</html>
UBBTPRINT;
}

?>