<?php
//	Script Version 7.7.0

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/suhosin.php");

// -------------
// Get the input
$returntab = get_input("returntab", "get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['PHPINFO']}" => "",
	"{$ubbt_lang['SUHOSIN']}" => "{$config['BASE_URL']}/admin/suhosin.php?returntab=1",
);

$admin->setCurrentMenu($ubbt_lang['PHPINFO']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['PHPINFO']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);

function phpinfo_output() {

	ob_start();
	phpinfo(-1);
	$phpinfo_content = ob_get_contents();
	ob_end_clean();

	if (!empty($phpinfo_content))
		$phpinfo_array = explode('<table', $phpinfo_content);

	if (!empty($phpinfo_array)) {
		unset($phpinfo_array[0]);
		foreach ($phpinfo_array as $phpinfo_element) {
			$phpinfo_element = str_replace('<tr', '<tr valign="top"', $phpinfo_element);
			echo '<table class="phpinfo" ' . $phpinfo_element;
			echo '<div style="clear:both"></div>';
		}

	}
}

$phpinfo_output = phpinfo_output(phpinfo_output);

// Include the template
include("../templates/default/admin/phpinfo.tmpl");

$admin->sendFooter();

?>