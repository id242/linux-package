<?php
//	Script Version 7.7.0

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
error_reporting(7);

// -------------
// Get the input
$returntab = get_input("returntab", "get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("");

$admin = new Admin;

$admin->doAuth();

$check = @fopen("{$config['FULL_PATH']}/cache_builders/custom/test.file", "w");

if (!$check) {
	$admin->error($ubbt_lang['NO_CUSTOM']);
}

@unlink("{$config['FULL_PATH']}/cache_builders/custom/test.file");

$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
	values
	('0,','0','0','1')
";
$dbh->do_query($query);

header("Location: {$config['FULL_URL']}/admin/customislands.php");

?>