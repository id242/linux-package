<?php
//	Script Version 7.7.0

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/selecttemplate.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab the templates
// ------------------------
// List out the templates
$path = "{$config['FULL_PATH']}/templates/default";
$dir = opendir($path);
while ($file = readdir($dir)) {
	if (preg_match('#(^\.|^admin$|~$)#', $file)) continue;
	$template[] = $file;
}
closedir($dir);
sort($template);

$tstring = "";
foreach ($template as $t) {
	$tstring .= "<option>$t</option>";
}

$tabs = array(
	"{$ubbt_lang['TEMPLATE_EDIT']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['TEMPLATES']);
$admin->setPageTitle($ubbt_lang['TEMPLATES']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);

// Include the template
include("../templates/default/admin/selecttemplate.tmpl");

$admin->sendFooter();

?>