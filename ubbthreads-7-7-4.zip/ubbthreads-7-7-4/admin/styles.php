<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/styles.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// Get the input
$returntab = get_input("returntab", "get");

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();


// Setup the defaults
$StyleSheet = $config['DEFAULT_STYLE'];
$stylelist = "";
$query = "
	SELECT
		STYLE_ID, STYLE_NAME, STYLE_IS_ACTIVE, STYLE_EDITED_TIME
	FROM
		{$config['TABLE_PREFIX']}STYLES
	ORDER BY
		UPPER(STYLE_NAME) ASC, STYLE_ID ASC
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$available = "";
while (list($style, $desc, $active, $edited) = $dbh->fetch_array($sth)) {
	$unixts = $edited;
	$edited = date("Y-m-d H:i", $edited);
	$checked = "";
	$default = "";
	$desc = str_replace("_", " ", $desc);
	if ($active) {
		$checked = "checked=\"checked\"";
	}
	if ($config['DEFAULT_STYLE'] == $style) {
		$default = "checked=\"checked\"";
	}
	$available .= "<tr>\n";
	$available .= "<td class=\"autobottom stdautorow acvm\"><input type=\"radio\" name=\"DEFAULT_STYLE\" value=\"$style\" $default /></td>\n";
	$available .= "<td class=\"autobottom stdautorow acvm\"><input type=\"checkbox\" name=\"active[$style]\" value=\"1\" $checked /></td>\n";
	$available .= "<td class=\"autobottom stdautorow alvm\"><a href=\"javascript:void(0)\" onclick=\"javascript:window.open('" . make_ubb_url("ubb=previewskin&skin=$style", "", false) . "','_blank','scrollbars=yes,toolbar=no,menubar=no,location=no,directories=no,status=no,width=800,height=600');\" title=\"{$ubbt_lang['PREVIEW_IT']}\"><i class=\"fas fa-search fa-fw\"></i></a></td>\n";
	$available .= "<td class=\"autobottom stdautorow alvm\" style=\"min-width:200px;\"><a href=\"{$config['BASE_URL']}/admin/editstyle.php?style=$style\">$desc</a></td>\n";
	$available .= "<td class=\"autobottom stdautorow arvm nw\" title=\"$unixts\"><span class=\"op5 smaller\">$edited</span></td>\n";
	$available .= "<td class=\"autobottom stdautorow acvm nw\"><a href=\"{$config['BASE_URL']}/admin/exportstyle.php?style=$style\" title=\"{$ubbt_lang['EXPORT']} {$ubbt_lang['PRIMARY_S']}\"><i class=\"fas fa-file-download fa-lg fa-fw\"></i></a> [<a href=\"{$config['BASE_URL']}/admin/exportstyle.php?style=$style&w=1\" title=\"{$ubbt_lang['EXPORT']}  {$ubbt_lang['PRIMARY_S']} {$ubbt_lang['EXPORT_WRAPPER']}\"><i class=\"fas fa-file-download fa-lg fa-fw\"></i></a>]</td>\n";
	$available .= "<td class=\"autobottom stdautorow acvm nw\"><a href=\"javascript:void(0);\" onclick=\"confirm_delete('$style')\" title=\"{$ubbt_lang['DELETE']}\"><i class=\"far fa-trash-alt fa-lg fa-fw\"></i></a></td>\n";
	$available .= "</tr>\n";
}

$tabs = array(
	"{$ubbt_lang['STYLES']}" => "",
	"{$ubbt_lang['WRAPPERS']}" => "{$config['BASE_URL']}/admin/wrappers.php",
);

$admin->setCurrentMenu($ubbt_lang['STYLES']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['STYLES']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);

// Include the template
include("../templates/default/admin/styles.tmpl");

$bottomtabs = array(
	"{$ubbt_lang['ADD_S']}" => "{$config['BASE_URL']}/admin/editstyle.php",
	"{$ubbt_lang['IMPORT_STYLE']}" => "{$config['BASE_URL']}/admin/importstyle.php",
);
$admin->createBottomTabs($bottomtabs, 0);

$admin->sendFooter();

?>