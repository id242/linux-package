<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/reg_settings.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


// Set the default values
$suspendreg = "";
if ($config['SUSPEND_REGISTRATIONS']) {
	$suspendreg = "checked=\"checked\"";
}

$nodchange = "";
$yesdchange = "";
$appdchange = "";
if ($config['DISPLAY_NAME_CHANGE'] == "1") {
	$yesdchange = "selected=\"selected\"";
} elseif ($config['DISPLAY_NAME_CHANGE'] == "2") {
	$appdchange = "selected=\"selected\"";
} else {
	$nodchange = "selected=\"selected\"";
}

$specialc = "";
if ($config['SPECIAL_CHARACTERS']) {
	$specialc = "checked=\"checked\"";
}

$verify = "";
if ($config['EMAIL_VERIFICATION']) {
	$verify = "checked=\"checked\"";
}

$userreg = "";
if ($config['NEW_USER_MODERATION']) {
	$userreg = "checked=\"checked\"";
}

$checkage = "";
if ($config['DO_AGE_CHECK']) {
	$checkage = "checked=\"checked\"";
}

$under13 = "";
if ($config['ALLOW_UNDER_13']) {
	$under13 = "checked=\"checked\"";
}

if (!$config['MINIMUM_AGE']) {
	$config['MINIMUM_AGE'] = "13";
}

$unique_email = "";
if ($config['REQUIRE_UNIQUE_EMAIL']) {
	$unique_email = "checked=\"checked\"";
}

// What options exists for CAPTCHA?
$gd = true;
$im = true;
$rc = true;
if (!function_exists(imagefttext)) {
	$gd = false;
}
if (!$config['CONVERT_PATH']) {
	$im = false;
}
if (!$config['RECAPTCHA_SITE']) {
	$rc = false;
}

$no_captcha = "";
if (!$gd && !$im && !$rc) {
	$no_captcha = $ubbt_lang['NO_CAPTCHA'];
}

$captcha = "";
if (isset($config['CAPTCHA']) && !empty($config['CAPTCHA']) && ($config['CAPTCHA'] != "disabled")) {
	$captcha = "checked=\"checked\"";
}


// --------------------------------------------------------------------------
// List out all of the current groups besides the admin/moderator/guest group
$newusergroups = "<table width=\"100%\">";
$query = "
    SELECT GROUP_NAME, GROUP_ID
    FROM   {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED <> '1'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);

// --------------------------------------------------------------------
// This gets somewhat confusing.  Basically we are echoing out a table
// with 2 colums.  When we are done listing the groups then we need
// to fill out the rest of the table with nbsp;
$row = 0;
if (!$config['DEFAULT_USER_GROUPS']) {
	$config['DEFAULT_USER_GROUPS'][] = "4";
}
while (list($Name, $Id) = $dbh->fetch_array($sth)) {
	$checked = "";
	if (($Id <= 5) && ($Id != 4)) {
		continue;
	}
	if ($row == 0) {
		$newusergroups .= "<tr>";
	}
	$row++;
	$newusergroups .= "<td width=\"50%\" class=\"colored-row stdautorow\">";
	$checky = "-$Id-";
	if (in_array($Id, $config['DEFAULT_USER_GROUPS'])) {
		$checked = "checked=\"checked\"";
	}
	$newusergroups .= "<input type=\"checkbox\" name=\"GROUP$Id\" $checked value=\"$Id\" id=\"GROUP$Id\" /> ";
	$newusergroups .= "<label class=\"radio\" for=\"GROUP$Id\">$Name</label>";
	$newusergroups .= "</td>";
	if ($row == 2) {
		$newusergroups .= "</tr>";
		$row = 0;
	}
}
if ($row > 0) {
	for ($i = 0; $i < (2 - $row); $i++) {
		$newusergroups .= "<td width=\"50%\">&nbsp;</TD>";
	}
	$newusergroups .= "</tr>";
}
$newusergroups .= "</td></tr></table>";

// Get current time for board rules
$html = new html;
$current_time = $html->get_date();

// Grab the current board rules
$boardrules = "";
$boardfile = file("{$config['FULL_PATH']}/includes/boardrules.php");
foreach ($boardfile as $linenum => $line) {
	$line = str_replace("&nbsp;", "&amp;nbsp;", $line);
	$boardrules .= "$line";
}

// Grab the current bad names
$query = "
	SELECT RESERVED_USERNAME
	FROM {$config['TABLE_PREFIX']}RESERVED_NAMES
	ORDER BY RESERVED_USERNAME
";
$sth = $dbh->do_query($query);
$badnames = "";
while (list($bname) = $dbh->fetch_array($sth)) {
	$badnames .= "$bname\n";
}

// Grab the current coppa insert
$coppa = "";
$coppafile = file("{$config['FULL_PATH']}/includes/coppainsert.php");
foreach ($coppafile as $linenum => $line) {
	$line = str_replace("&nbsp;", "&amp;nbsp;", $line);
	$coppa .= "$line";
}

// Setup an array that holds the reg screen options
$regoptions = array('USER_DISPLAY_EMAIL', 'USER_BIRTHDAY', 'USER_AVATAR', 'USER_ACCEPT_PM', 'USER_SIGNATURE', 'USER_HOMEPAGE', 'USER_OCCUPATION', 'USER_HOBBIES', 'USER_LOCATION', 'USER_VISIBLE_ONLINE_STATUS', 'USER_TIME_FORMAT', 'USER_TIME_OFFSET', 'USER_SHOW_SIGNATURES', 'USER_TOPIC_VIEW_TYPE', 'USER_TOPICS_PER_PAGE', 'USER_POSTS_PER_TOPIC', 'USER_SHOW_AVATARS', 'USER_ACCEPT_ADMIN_EMAILS', 'USER_NOTIFY_ON_PM');

// Grab the settings out of the database
$query = "
	SELECT REGISTRATION_FIELD,REGISTRATION_SHOW_FIELD,REGISTRATION_REQUIRE_FIELD
	FROM {$config['TABLE_PREFIX']}REGISTRATION_FIELDS
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($field, $show, $require) = $dbh->fetch_array($sth)) {
	if ($show) {
		$default[$field]['show'] = $show;
	}
	if ($require) {
		$default[$field]['require'] = $require;
	}
}

// Set up the default reg options
for ($i = 0; $i < sizeof($regoptions); $i++) {
	$name = $regoptions[$i] . "_hide";
	${$name} = "";
	$name = $regoptions[$i] . "_show";
	${$name} = "";
	$name = $regoptions[$i] . "_require";
	${$name} = "";
	if (isset($default[$regoptions[$i]]['require'])) {
		${$regoptions[$i] . "_require"} = "checked=\"checked\"";
	} elseif (isset($default[$regoptions[$i]]['show'])) {
		${$regoptions[$i] . "_show"} = "checked=\"checked\"";
	} else {
		${$regoptions[$i] . "_hide"} = "checked=\"checked\"";
	}
}

$extra1_hide = "";
$extra1_show = "";
$extra1_require = "";
if (isset($default['USER_EXTRA_FIELD_1']['require'])) {
	$extra1_require = "checked=\"checked\"";
} elseif (isset($default['USER_EXTRA_FIELD_1']['show'])) {
	$extra1_show = "checked=\"checked\"";
} else {
	$extra1_hide = "checked=\"checked\"";
}


$extra2_hide = "";
$extra2_show = "";
$extra2_require = "";
if (isset($default['USER_EXTRA_FIELD_2']['require'])) {
	$extra2_require = "checked=\"checked\"";
} elseif (isset($default['USER_EXTRA_FIELD_2']['show'])) {
	$extra2_show = "checked=\"checked\"";
} else {
	$extra2_hide = "checked=\"checked\"";
}

$extra3_hide = "";
$extra3_show = "";
$extra3_require = "";
if (isset($default['USER_EXTRA_FIELD_3']['require'])) {
	$extra3_require = "checked=\"checked\"";
} elseif (isset($default['USER_EXTRA_FIELD_3']['show'])) {
	$extra3_show = "checked=\"checked\"";
} else {
	$extra3_hide = "checked=\"checked\"";
}

$extra4_hide = "";
$extra4_show = "";
$extra4_require = "";
if (isset($default['USER_EXTRA_FIELD_4']['require'])) {
	$extra4_require = "checked=\"checked\"";
} elseif (isset($default['USER_EXTRA_FIELD_4']['show'])) {
	$extra4_show = "checked=\"checked\"";
} else {
	$extra4_hide = "checked=\"checked\"";
}

$extra5_hide = "";
$extra5_show = "";
$extra5_require = "";
if (isset($default['USER_EXTRA_FIELD_5']['require'])) {
	$extra5_require = "checked=\"checked\"";
} elseif (isset($default['USER_EXTRA_FIELD_5']['show'])) {
	$extra5_show = "checked=\"checked\"";
} else {
	$extra5_hide = "checked=\"checked\"";
}

// need to check for html in extra fields
$config['CUSTOM_FIELD_1'] = ubbchars($config['CUSTOM_FIELD_1']);
$config['CUSTOM_FIELD_2'] = ubbchars($config['CUSTOM_FIELD_2']);
$config['CUSTOM_FIELD_3'] = ubbchars($config['CUSTOM_FIELD_3']);
$config['CUSTOM_FIELD_4'] = ubbchars($config['CUSTOM_FIELD_4']);
$config['CUSTOM_FIELD_5'] = ubbchars($config['CUSTOM_FIELD_5']);

$tabs = array(
	"{$ubbt_lang['BASIC']}" => "",
	"{$ubbt_lang['REG_SCREEN']}" => "",
	"{$ubbt_lang['RESERVED_N']}" => "",
	"{$ubbt_lang['COPPA_SET']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['REG_SET']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['REG_SET']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);

// Include the template
include("../templates/default/admin/reg_settings.tmpl");

$admin->sendFooter();

?>