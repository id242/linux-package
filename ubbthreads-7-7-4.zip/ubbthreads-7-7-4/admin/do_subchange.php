<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/do_subchange.php");

// Get the input
$returntab = get_input("returntab", "both");

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();
$html = new html;

$id = get_input("id", "post", "int");
$custom = get_input("custom", "post", "");
$status = get_input("status", "post", "");
$month = get_input("month", "post", "");
$day = get_input("day", "post", "");
$year = get_input("year", "post", "");


// Grab the current info on this subscription
$query = "
	SELECT
		t1.USER_ID, t1.GROUP_ID, t2.SUBSCRIPTION_NAME
	FROM
		{$config['TABLE_PREFIX']}SUBSCRIPTION_DATA AS t1,
		{$config['TABLE_PREFIX']}SUBSCRIPTIONS AS t2
	WHERE
		t1.CUSTOM_ID = ?
	AND t1.GROUP_ID = t2.GROUP_ID
";
$sth = $dbh->do_placeholder_query($query, array($custom), __LINE__, __FILE__);
list($uid, $group, $name) = $dbh->fetch_array($sth);

if ($status == "delete") {
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		WHERE CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query, array($custom), __LINE__, __FILE__);

	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}CHECK_DATA
		WHERE CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query, array($custom), __LINE__, __FILE__);

	// Remove User from Group
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}USER_GROUPS
		WHERE USER_ID = ?
		AND GROUP_ID = ?
	";
	$dbh->do_placeholder_query($query, array($uid, $group), __LINE__, __FILE__);

	// Remove Group Image from User
	$group_images = "";
	$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
		SET USER_GROUP_IMAGES = ?
		WHERE USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($group_images, $uid), __LINE__, __FILE__);

	// Send user a confirmation PM
	$message = $html->substitute($ubbt_lang['EXPIRE_BODY'], array('GROUP' => $name));

	$html->send_message($config['MAIN_ADMIN_ID'], $uid, $ubbt_lang['EXPIRE_SUB'], $message);

	// Log it
	admin_log("DELETE_SUB", "$uid: $name ($group)");

}


if ($status == "activate") {

	// Add this user to the group
	$query = "
		REPLACE INTO
			{$config['TABLE_PREFIX']}USER_GROUPS
			(USER_ID, GROUP_ID)
		VALUES
			(?, ?)
	";
	$dbh->do_placeholder_query($query, array($uid, $group), __LINE__, __FILE__);

	// Update the SUBSCRIPTION_DATA table
	$query = "
		UPDATE
			{$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		SET
			SUBSCRIPTION_STATUS = ? ,
			SUBSCRIPTION_IS_ACTIVE = 1
		WHERE
			CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query, array("MANUAL ACTIVATION", $custom), __LINE__, __FILE__);

	// Send user a confirmation PM
	$message = $html->substitute($ubbt_lang['ACTIVATE_BODY'], array('GROUP' => $name));

	$html->send_message($config['MAIN_ADMIN_ID'], $uid, $ubbt_lang['ACTIVATE_SUB'], $message);

	// Log it
	admin_log("ACTIVATE_SUB", "$uid: $name ($group)");

}

if ($status == "expire") {

	// Remove User from Group
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}USER_GROUPS
		WHERE USER_ID = ?
		AND GROUP_ID = ?
	";
	$dbh->do_placeholder_query($query, array($uid, $group), __LINE__, __FILE__);

	// Remove Group Image from User
	$group_images = "";
	$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
		SET USER_GROUP_IMAGES = ?
		WHERE USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($group_images, $uid), __LINE__, __FILE__);

	// Update the SUBSCRIPTION_DATA table
	$query = "
		UPDATE
			{$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		SET
			SUBSCRIPTION_STATUS = ? ,
			SUBSCRIPTION_IS_ACTIVE = 0
		WHERE
			CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query, array("MANUAL EXPIRATION", $custom), __LINE__, __FILE__);

	// Send user a confirmation PM
	$message = $html->substitute($ubbt_lang['EXPIRE_BODY'], array('GROUP' => $name));

	$html->send_message($config['MAIN_ADMIN_ID'], $uid, $ubbt_lang['EXPIRE_SUB'], $message);


	// Log it
	admin_log("EXPIRE_SUB", "$uid: $name ($group)");
}


// Modify End Date?
if ($day && $month && $year) {
	$month = sprintf('%02d', $month);
	$day = sprintf('%02d', $day);
	$newtime = strtotime("$year-$month-$day");

	// Update the SUBSCRIPTION_DATA table
	$query = "
		UPDATE {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		SET SUBSCRIPTION_END_DATE = ?
		WHERE CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query, array($newtime, $custom), __LINE__, __FILE__);
}

$admin->redirect($ubbt_lang['SUB_MODIFIED'], "{$config['BASE_URL']}/admin/sub_history.php?id=$id", $ubbt_lang['USER_SUB_F_LOC']);

?>