<?php
//	Script Version 7.7.0

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab all current boards
$query = "
	SELECT FORUM_ID,FORUM_TITLE,FORUM_SORT_ORDER,CATEGORY_ID,FORUM_IS_ACTIVE
	FROM {$config['TABLE_PREFIX']}FORUMS
	ORDER BY CATEGORY_ID, FORUM_SORT_ORDER
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$i = 0;
while (list($number, $title, $sort, $catn, $active) = $dbh->fetch_array($sth)) {
	$forums[$i]['number'] = $number;
	$forums[$i]['title'] = $title;
	$forums[$i]['sort'] = $sort;
	$forums[$i]['cat'] = $catn;
	$forums[$i]['active'] = $active;
	$i++;
}
for ($x = 0; $x < $i; $x++) {
	$fnum = $forums[$x]['number'];
	$titles = get_input("forum", "post");
	$orders = get_input("order", "post");
	$active = get_input("active", "post");
	if (!isset($active[$fnum])) {
		$active[$fnum] = '0';
	}
	$update = 0;
	$params = "";
	if ($titles[$fnum] != $forums[$x]['title']) {
		$update = 1;

		$newtitle = addslashes($titles[$fnum]);
		$newtitle = ubbchars($newtitle);
		$params .= "FORUM_TITLE = '$newtitle',";
	}
	if ($orders[$fnum] != $forums[$x]['sort']) {
		$update = 1;
		$neworder = addslashes($orders[$fnum]);
		$params .= "FORUM_SORT_ORDER='$neworder',";
	}
	if ($active[$fnum] != $forums[$x]['active']) {
		$update = 1;
		$newactive = addslashes($active[$fnum]);
		$params .= "FORUM_IS_ACTIVE = '$newactive'";
	}
	if ($update) {
		$params = preg_replace("/,$/", "", $params);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}FORUMS
			SET $params
			WHERE FORUM_ID='$fnum'
		";
		$dbh->do_query($query, __LINE__, __FILE__);
	}
}
admin_log("FORUM_MANAGE", "");
build_forum_cache();

$admin->redirect($ubbt_lang['FORUMS_UPDATED'], "{$config['BASE_URL']}/admin/forummanage.php?returntab=0", $ubbt_lang['FORUMS_F_LOC']);

?>