<?php
//	Script Version 7.7.4

require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/editstyle.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

error_reporting(7);

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();

// Get the input
$style = get_input("style", "get");
$copyfrom = get_input("copyfrom", "get");

$style_id = (!$style) ? $config['DEFAULT_STYLE'] : $style;

if ($copyfrom) {
	$style_id = $copyfrom;
}

$style_list = "";
$query = "
	SELECT
		STYLE_ID, STYLE_NAME
	FROM
		{$config['TABLE_PREFIX']}STYLES
	ORDER BY
		STYLE_NAME
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($cid, $cname) = $dbh->fetch_array($sth)) {
	$sel = "";
	$cname = str_replace("_", " ", $cname);
	if ($cid == $style) $sel = "selected=\"selected\"";
	$ds1 = "";
	$ds2 = "";
	if ($cid == $config['DEFAULT_STYLE']) {
		$ds1 = "&nbsp;&nbsp;&nbsp;";
		$ds2 = " {$ubbt_lang['SITE_DEFAULT']}";
	}
	$style_list .= "<option value=\"$cid\" $sel>$ds1$cname$ds2</option>";
}

$style_vars = array();
if ($style_id) {
	$query = "
		SELECT
			STYLE_VARS, STYLE_NAME
		FROM
			{$config['TABLE_PREFIX']}STYLES
		WHERE
			STYLE_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($style_id), __LINE__, __FILE__);
	list($style_settings, $style_name) = $dbh->fetch_array($sth);
	$style_name = str_replace("_", " ", $style_name);
	$style_vars = unserialize($style_settings);
}

if ($copyfrom) {
	$style_name = "{$style_name}_copy";
}

include("{$config['FULL_PATH']}/styles/$style_id.php");

// General Image Sets
$dir = opendir("{$config['FULL_PATH']}/images/general/");
$general_images = "";
while ($file = readdir($dir)) {
	if ($file == "." || $file == "..") continue;
	$selected = "";
	if ($style_array['general'] == "general/$file") {
		$selected = "selected=\"selected\"";
	}
	$general_images .= "<option $selected>$file</option>";
}

// Avatar Image Sets
$dir = opendir("{$config['FULL_PATH']}/images/avatars/");
$avatar_images = "";
while ($file = readdir($dir)) {
	if ($file == "." || $file == "..") continue;
	$selected = "";
	if ($style_array['avatars'] == "avatars/$file") {
		$selected = "selected=\"selected\"";
	}
	$avatar_images .= "<option $selected>$file</option>";
}

// Forum Image Sets
$dir = opendir("{$config['FULL_PATH']}/images/forumimages/");
$forum_images = "";
while ($file = readdir($dir)) {
	if ($file == "." || $file == "..") continue;
	$selected = "";
	if ($style_array['forumimages'] == "forumimages/$file") {
		$selected = "selected=\"selected\"";
	}
	$forum_images .= "<option $selected>$file</option>";
}

// Graemlin Image Sets
$dir = opendir("{$config['FULL_PATH']}/images/graemlins/");
$graemlin_images = "";
while ($file = readdir($dir)) {
	if ($file == "." || $file == "..") continue;
	$selected = "";
	if ($style_array['graemlins'] == "graemlins/$file") {
		$selected = "selected=\"selected\"";
	}
	$graemlin_images .= "<option $selected>$file</option>";
}

// Graemlin Image Sets
$dir = opendir("{$config['FULL_PATH']}/images/icons/");
$icon_images = "";
while ($file = readdir($dir)) {
	if ($file == "." || $file == "..") continue;
	$selected = "";
	if ($style_array['icons'] == "icons/$file") {
		$selected = "selected=\"selected\"";
	}
	$icon_images .= "<option $selected>$file</option>";
}

// News Image Sets
$dir = opendir("{$config['FULL_PATH']}/images/news/");
$news_images = "";
while ($file = readdir($dir)) {
	if ($file == "." || $file == "..") continue;
	$selected = "";
	if ($style_array['news'] == "news/$file") {
		$selected = "selected=\"selected\"";
	}
	$news_images .= "<option $selected>$file</option>";
}

// Mood Image Sets
$dir = opendir("{$config['FULL_PATH']}/images/moods/");
$mood_images = "";
while ($file = readdir($dir)) {
	if ($file == "." || $file == "..") continue;
	$selected = "";
	if ($style_array['mood'] == "moods/$file") {
		$selected = "selected=\"selected\"";
	}
	$mood_images .= "<option $selected>$file</option>";
}

// Markup Image Sets
$dir = opendir("{$config['FULL_PATH']}/images/markup_panel/");
$markup_images = "";
while ($file = readdir($dir)) {
	if ($file == "." || $file == "..") continue;
	$selected = "";
	if ($style_array['markup_panel'] == "markup_panel/$file") {
		$selected = "selected=\"selected\"";
	}
	$markup_images .= "<option $selected>$file</option>";
}

// Wrapper Sets
$wrapper_sets = "";
include("{$config['FULL_PATH']}/styles/wrappers.php");
$wrapper_js = "";
foreach ($wrappers as $k => $data) {
	$data['open'] = str_replace('"', '\"', $data['open']);
	$data['close'] = str_replace('"', '\"', $data['close']);

	$data['open'] = preg_replace("/(\r\n|\n)/", "", $data['open']);
	$data['close'] = preg_replace("/(\r\n|\n)/", "", $data['close']);

	$selected = "";
	if ($style_array['wrappers'] == $k) {
		$selected = "selected=\"selected\"";
	}
	$wrapper_sets .= "<option value=\"$k\" $selected>{$data['name']}</option>";
}

// Here's the array that holds the entire style block and how it's displayed
$categories = array(
	0 => "STYLE_BASICS",
	1 => "STYLE_GENERAL",
	2 => "STYLE_COLUMNS",
	3 => "STYLE_CFRM",
	4 => "STYLE_FORUM",
	5 => "STYLE_POST",
	6 => "STYLE_MARKUP",
	7 => "STYLE_POPUP",
	8 => "STYLE_UBBCODE",
	9 => "STYLE_TABS",
	10 => "STYLE_FORMS",
	11 => "STYLE_PAGINATION",
	12 => "STYLE_MISC",
	13 => "STYLE_EMAIL",
);

$classes = array(
	1 => array(
		"1" => array(
			"class" => "body",
			"type" => "block",
		),
		"12" => array(
			"class" => ".ubb_popup_body",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 1,
			),
		),
		"2" => array(
			"class" => ".t_outer",
			"type" => "",
		),
		"3" => array(
			"class" => ".t_inner",
			"type" => "",
		),
		"4" => array(
			"class" => ".t_standard",
			"type" => "",
		),
		"5" => array(
			"class" => ".tdheader",
			"type" => "block",
		),
		"6" => array(
			"class" => ".alt-1",
			"type" => "block",
		),
		"7" => array(
			"class" => ".alt-2",
			"type" => "block",
		),
		"8" => array(
			"class" => ".breadcrumbs",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 5,
			),
		),
		"9" => array(
			"class" => ".navigation",
			"type" => "block",
		),
		"10" => array(
			"class" => ".footer",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 5,
			),
		),
		"11" => array(
			"class" => ".body_col",
			"type" => "",
		),
	),
	2 => array(
		"1" => array(
			"class" => ".lefttdheader",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 5,
			),
		),
		"2" => array(
			"class" => ".leftalt-1",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 6,
			),
		),
		"3" => array(
			"class" => ".leftalt-2",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 7,
			),
		),
		"4" => array(
			"class" => ".righttdheader",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 5,
			),
		),
		"5" => array(
			"class" => ".rightalt-1",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 6,
			),
		),
		"6" => array(
			"class" => ".rightalt-2",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 7,
			),
		),
		"7" => array(
			"class" => ".left_col",
			"type" => "",
		),
		"8" => array(
			"class" => ".right_col",
			"type" => "",
		),
	),
	3 => array(
		"1" => array(
			"class" => ".category",
			"type" => "block",
		),
		"2" => array(
			"class" => ".newinforum",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 6,
			),
		),
		"3" => array(
			"class" => ".forumtitle",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 7,
			),
		),
		"4" => array(
			"class" => ".forumdescript",
			"type" => "block",
		),
		"5" => array(
			"class" => ".threadtotal",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 6,
			),
		),
		"6" => array(
			"class" => ".posttotal",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 7,
			),
		),
		"7" => array(
			"class" => ".posttime",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 6,
			),
		),
		"8" => array(
			"class" => ".newtotal",
			"type" => "block",
			"copy" => array(),
		),
		"9" => array(
			"class" => ".forum_extras",
			"type" => "block",
			"copy" => array(),
		),
		"10" => array(
			"class" => ".forum_viewing",
			"type" => "",
			"copy" => array(),
		),
	),
	4 => array(
		"1" => array(
			"class" => ".newintopic",
			"type" => "",
			"copy" => array(
				"cat" => 1,
				"class" => 6,
			),
		),
		"2" => array(
			"class" => ".topicicon",
			"type" => "",
			"copy" => array(
				"cat" => 1,
				"class" => 7,
			),
		),
		"3" => array(
			"class" => ".topicsubject",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 6,
			),
		),
		"4" => array(
			"class" => ".topicreplies",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 7,
			),
		),
		"6" => array(
			"class" => ".topicviews",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 6,
			),
		),
		"7" => array(
			"class" => ".topictime",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 7,
			),
		),
		"8" => array(
			"class" => ".alt-newintopic",
			"type" => "",
			"copy" => array(
				"cat" => 4,
				"class" => 1,
			),
		),
		"9" => array(
			"class" => ".alt-topicicon",
			"type" => "",
			"copy" => array(
				"cat" => 4,
				"class" => 2,
			),
		),
		"10" => array(
			"class" => ".alt-topicsubject",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 3,
			),
		),
		"11" => array(
			"class" => ".alt-topicreplies",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 4,
			),
		),
		"12" => array(
			"class" => ".alt-topicviews",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 6,
			),
		),
		"13" => array(
			"class" => ".alt-topictime",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 7,
			),
		),
		"14" => array(
			"class" => ".new-newintopic",
			"type" => "",
			"copy" => array(
				"cat" => 4,
				"class" => 1,
			),
		),
		"15" => array(
			"class" => ".new-topicicon",
			"type" => "",
			"copy" => array(
				"cat" => 4,
				"class" => 2,
			),
		),
		"16" => array(
			"class" => ".new-topicsubject",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 3,
			),
		),
		"17" => array(
			"class" => ".new-topicreplies",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 4,
			),
		),
		"18" => array(
			"class" => ".new-topicviews",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 6,
			),
		),
		"19" => array(
			"class" => ".new-topictime",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 7,
			),
		),
		"20" => array(
			"class" => ".new-alt-newintopic",
			"type" => "",
			"copy" => array(
				"cat" => 4,
				"class" => 8,
			),
		),
		"21" => array(
			"class" => ".new-alt-topicicon",
			"type" => "",
			"copy" => array(
				"cat" => 4,
				"class" => 9,
			),
		),
		"22" => array(
			"class" => ".new-alt-topicsubject",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 10,
			),
		),
		"23" => array(
			"class" => ".new-alt-topicreplies",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 11,
			),
		),
		"24" => array(
			"class" => ".new-alt-topicviews",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 12,
			),
		),
		"25" => array(
			"class" => ".new-alt-topictime",
			"type" => "block",
			"copy" => array(
				"cat" => 4,
				"class" => 13,
			),
		),
		"26" => array(
			"class" => ".announce_css",
			"type" => "block",
		),
		"27" => array(
			"class" => ".sticky_css",
			"type" => "block",
		),
		"28" => array(
			"class" => ".inline_selected",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 5,
			),
		),
		"29" => array(
			"class" => ".inline_selector",
			"type" => "",
			"copy" => array(
				"cat" => 4,
				"class" => 16,
			),
		),
	),
	5 => array(
		"1" => array(
			"class" => ".subjecttable",
			"type" => "block",
			"copy" => array(
				"cat" => 1,
				"class" => 5,
			),
		),
		"2" => array(
			"class" => ".author-content",
			"type" => "block",
		),
		"3" => array(
			"class" => ".author-title",
			"type" => "block",
		),
		"4" => array(
			"class" => ".author-picture",
			"type" => "block",
		),
		"5" => array(
			"class" => ".author-registered",
			"type" => "",
		),
		"6" => array(
			"class" => ".author-totalposts",
			"type" => "",
		),
		"7" => array(
			"class" => ".author-location",
			"type" => "block",
		),
		"8" => array(
			"class" => ".post-content",
			"type" => "block",
		),
		"9" => array(
			"class" => ".post-options",
			"type" => "block",
		),
		"10" => array(
			"class" => ".post-buttons",
			"type" => "block",
		),
		"11" => array(
			"class" => ".post_inner",
			"type" => "",
		),
		"12" => array(
			"class" => ".edited-wording",
			"type" => "",
		),
		"13" => array(
			"class" => ".signature",
			"type" => "",
		),
		"14" => array(
			"class" => ".pollcolor",
			"type" => "",
		),
		"15" => array(
			"class" => ".private_unread",
			"type" => "",
		),
		"16" => array(
			"class" => ".post-nav",
			"type" => "button",
		),
		"17" => array(
			"class" => ".post-new",
			"type" => "",
		),
		"18" => array(
			"class" => ".post-op",
			"type" => "",
		),
	),
	6 => array(
		"1" => array(
			"class" => ".markup_panel",
			"type" => "",
		),
		"2" => array(
			"class" => ".markup_panel_normal_button",
			"type" => "",
		),
		"3" => array(
			"class" => ".markup_panel_hover_button",
			"type" => "",
		),
		"4" => array(
			"class" => ".markup_panel_down_button",
			"type" => "",
			"copy" => array(
				"cat" => 6,
				"class" => 3,
			),
		),
		"5" => array(
			"class" => ".markup_panel_popup",
			"type" => "",
			"copy" => array(
				"cat" => 7,
				"class" => 1,
			),
		),
		"6" => array(
			"class" => ".markup_panel_unselect_text",
			"type" => "",
			"copy" => array(
				"cat" => 7,
				"class" => 3,
			),
		),
		"7" => array(
			"class" => ".markup_panel_select_text",
			"type" => "",
			"copy" => array(
				"cat" => 7,
				"class" => 4,
			),
		),
	),
	7 => array(
		"1" => array(
			"class" => ".popup_menu",
			"type" => "",
		),
		"2" => array(
			"class" => ".popup_menu_header",
			"type" => "",
		),
		"3" => array(
			"class" => ".popup_menu_content",
			"type" => "block",
		),
		"4" => array(
			"class" => ".popup_menu_highlight",
			"type" => "block",
		),
	),
	8 => array(
		"1" => array(
			"class" => ".ubbcode-block",
			"type" => "",
		),
		"2" => array(
			"class" => ".ubbcode-header",
			"type" => "block",
		),
		"3" => array(
			"class" => ".ubbcode-body",
			"type" => "block",
		),
		"4" => array(
			"class" => ".bbcodecomment",
			"type" => "",
		),
		"5" => array(
			"class" => ".bbcodedefault",
			"type" => "",
		),
		"6" => array(
			"class" => ".bbcodekeyword",
			"type" => "",
		),
		"7" => array(
			"class" => ".bbcodestring",
			"type" => "",
		),
		"8" => array(
			"class" => ".bbcodehtml",
			"type" => "",
		),
	),
	9 => array(
		"1" => array(
			"class" => ".tab_grippy",
			"type" => "block",
		),
		"2" => array(
			"class" => ".tab_grippy_sel",
			"type" => "block",
		),
	),
	10 => array(
		"1" => array(
			"class" => "form",
			"type" => "",
		),
		"2" => array(
			"class" => ".form-input",
			"type" => "",
		),
		"3" => array(
			"class" => ".form-select",
			"type" => "",
		),
		"4" => array(
			"class" => ".form-radio",
			"type" => "",
		),
		"5" => array(
			"class" => ".form-checkbox",
			"type" => "",
		),
		"6" => array(
			"class" => ".form-button",
			"type" => "button",
		),
		"7" => array(
			"class" => ".major-button",
			"type" => "",
		),
	),
	11 => array(
		"1" => array(
			"class" => ".pagination",
			"type" => "",
		),
		"2" => array(
			"class" => ".pages",
			"type" => "",
		),
		"3" => array(
			"class" => ".page-cur",
			"type" => "",
		),
		"4" => array(
			"class" => ".page-n",
			"type" => "",
		),
		"5" => array(
			"class" => ".pagenav",
			"type" => "",
		),
		"6" => array(
			"class" => ".pagenavall",
			"type" => "",
		),
	),
	12 => array(
		"1" => array(
			"class" => ".date",
			"type" => "",
		),
		"2" => array(
			"class" => ".time",
			"type" => "",
		),
		"3" => array(
			"class" => ".small",
			"type" => "",
		),
		"4" => array(
			"class" => ".standouttext",
			"type" => "",
		),
		"5" => array(
			"class" => ".adminname",
			"type" => "block",
		),
		"6" => array(
			"class" => ".modname",
			"type" => "block",
		),
		"7" => array(
			"class" => ".globalmodname",
			"type" => "block",
			"copy" => array(
				"cat" => 11,
				"class" => 6,
			),
		),
		"8" => array(
			"class" => ".bots",
			"type" => "block",
		),
		"9" => array(
			"class" => ".shout_border",
			"type" => "",
		),
		"10" => array(
			"class" => ".shout_delete",
			"type" => "",
		),
		"11" => array(
			"class" => ".popup_content_header",
			"type" => "",
			"copy" => array(
				"cat" => 8,
				"class" => 2,
			),
		),
		"12" => array(
			"class" => ".popup_content",
			"type" => "",
		),
		"13" => array(
			"class" => ".search_highlight",
			"type" => "",
		),
		"14" => array(
			"class" => ".avatar",
			"type" => "",
		),
		"15" => array(
			"class" => ".avatar-none",
			"type" => "",
		),
		"16" => array(
			"class" => "#top-button",
			"type" => "button",
		),
	),
	13 => array(
		"1" => array(
			"class" => ".email-body",
			"type" => "",
		),
		"2" => array(
			"class" => ".email-header",
			"type" => "",
			"copy" => array(
				"cat" => 8,
				"class" => 2,
			),
		),
		"3" => array(
			"class" => ".email-tdheader",
			"type" => "",
			"copy" => array(
				"cat" => 8,
				"class" => 2,
			),
		),
		"4" => array(
			"class" => ".email-tdbody",
			"type" => "",
			"copy" => array(
				"cat" => 8,
				"class" => 3,
			),
		),
		"5" => array(
			"class" => ".email-footer",
			"type" => "",
		),
	),
);

// Update language string substitutions
$ubbt_lang['INSTR'] = $html->substitute($ubbt_lang['INSTR'], array("FULL_URL" => $config['FULL_URL']));

$tabs = array(
	"{$ubbt_lang['EDIT_STYLE']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['STYLES']);
$admin->setParentTitle($ubbt_lang['STYLES'], "styles.php");
$admin->setPageTitle($ubbt_lang['EDIT_STYLE']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/editstyle.tmpl");

$admin->sendFooter();

?>