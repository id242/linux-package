<?php
//	Script Version 7.7.0

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$forum = get_input("forum", "post");

if ($forum == 0) $forum = "New Forum Template";

// Get the max upload size in php.ini
$max_size = ini_get("upload_max_filesize");
if (preg_match("/K/", $max_size)) $multi = 1024;
if (preg_match("/M/", $max_size)) $multi = 1048576;
if (preg_match("/G/", $max_size)) $multi = 1073741824;
if (!$multi) $multi = 1;
$max_size_num = preg_replace("/(K|M|G| +)/", "", $max_size);
$max_size_bytes = $max_size_num * $multi;

// Get the list of forum permissions
$perms = array();
$query = "
	select PERMISSION_NAME
	from {$config['TABLE_PREFIX']}PERMISSION_LIST
	where PERMISSION_TYPE='forum'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($name) = $dbh->fetch_array($sth)) {
	$perms[] = $name;
}

// Get list of groups
$query = "
	select GROUP_ID
	from {$config['TABLE_PREFIX']}GROUPS
	order by GROUP_ID
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($gid) = $dbh->fetch_array($sth)) {
	$groups[] = $gid;
}

foreach ($groups as $k => $gid) {
	$keys = "GROUP_ID,FORUM_ID,";
	$values = "$gid,'$forum',";
	foreach ($perms as $k => $perm) {
		$keys .= "$perm,";
	}
	foreach ($perms as $k => $perm) {
		$value = $_POST[$perm][$gid];
		if (!$value) $value = "0";
		// Convert shorthand byte values
		if (($perm == "FILE_SIZE" || $perm == "GALLERY_SIZE") && (preg_match("/(K|M|G)/", $value))) {
			if (preg_match("/K/", $value)) $multi = 1024;
			if (preg_match("/M/", $value)) $multi = 1048576;
			if (preg_match("/G/", $value)) $multi = 1073741824;
			if (!$multi) $multi = 1;
			$value_num = preg_replace("/(K|M|G| +)/", "", $value);
			$value = (int)$value;
			$value_bytes = $value_num * $multi;
			$value = $value_bytes;
		}
		if (($perm == "FILE_SIZE" || $perm == "GALLERY_SIZE") && $value > $max_size_bytes) {
			$value = $max_size_bytes;
		}
		$value = addslashes($value);
		$values .= "'$value',";
	}
	$keys = preg_replace("/,$/", "", $keys);
	$values = preg_replace("/,$/", "", $values);

	$query = "
		replace into {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		($keys)
		values
		($values)
	";
	$dbh->do_query($query, __LINE__, __FILE__);

}

admin_log("FORUM_PERMISSIONS", "$forum");

$userob->clear_cached_perms();

$admin->redirect($ubbt_lang['FORUM_PERM_UPDATED'], "{$config['BASE_URL']}/admin/forumperms.php?returntab=0&edit_forum=$forum", $ubbt_lang['FORUM_PERM_F_LOC']);

?>