<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/dodbbackup.php");

// -------------
// Get the input
$ctable = get_input("ctable", "both");
$crow = get_input("crow", "both");
$table = get_input("table", "both");
$dumpdir = get_input("dumpdir", "post");
$returntab = get_input("returntab", "both");
$analyzeoptimize = get_input("analyzeoptimize", "both");
$droptables = get_input("droptables", "both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

if (empty($config['dumpdir']) || !isset($config['dumpdir'])) {
	$config['dumpdir'] = "";
}
if ((!empty($dumpdir)) && ($dumpdir != $config['dumpdir'])) {
	// What config vars are we updating?
	$newconfig = array("dumpdir");

	// Update the config file
	include("doeditconfig.php");
	$admin->redirect($ubbt_lang['DUMPDIR'], "{$config['BASE_URL']}/admin/dbbackup.php?returntab=2", $ubbt_lang['F_LOC']);
	exit;
}

$tabs = array(
	"{$ubbt_lang['INFO']}" => "dbinfo.php?returntab=0",
	"{$ubbt_lang['COMMAND']}" => "database.php?returntab=1",
	"{$ubbt_lang['BACKUP']}" => ""
);

// Get the list of tables
$search_prefix = str_replace("_", "\_", $config['TABLE_PREFIX']) . "%";
$query = "
	SHOW TABLES LIKE ?
";
$tables = $dbh->do_placeholder_query($query, array($search_prefix), __LINE__, __FILE__);

$catch = 0;
$currtable = $ctable;


if ($ctable && !$crow && !$table) {
	while (list($gtable) = $dbh->fetch_array($tables)) {
		if ($catch == 1) {
			$ctable = $gtable;
			break;
		}
		if ($gtable == $ctable) {
			$catch = 1;
		}
	}
}

$end = 0;

if (($currtable == $ctable) && $ctable && !$crow) {
	$end = 1;
}

if (!$table && !$ctable) {
	while (list($gtable) = $dbh->fetch_array($tables)) {
		if (!$ctable) {
			$ctable = $gtable;
			$catch = 1;
			break;
		}
		if ($catch == 1) {
			$ctable = $gtable;
			break;
		}
		$catch = 1;
	}
}
if (!$ctable && $table) {
	$ctable = $table;
}

$backuptext = "";
$statustext = "";
$append = 1;
if (!$crow) {

	if ($analyzeoptimize) {
		// Optimize a specific table.	
		$statustext .= "{$ubbt_lang['OPTIMIZE']} $ctable...\n";
		$query = "
			OPTIMIZE TABLE $ctable
			";
		$sth = $dbh->do_query($query);
		list($result) = $dbh->fetch_array($sth);
		$statustext .= "OK<br>";

		// Analyze a specific table.	
		$statustext .= "{$ubbt_lang['ANALYZE']} $ctable...\n";
		$query = "
			ANALYZE TABLE $ctable
			";
		$sth = $dbh->do_query($query);
		list($result) = $dbh->fetch_array($sth);
		$statustext .= "OK<br>";
	}

	$statustext .= "{$ubbt_lang['DATA']} $ctable...<br>";
	$dump_file = "{$config['dumpdir']}/$ctable.sql";
	$query = "
		SHOW CREATE TABLE $ctable
	";
	$sth = $dbh->do_query($query);
	list($result, $backuptext) = $dbh->fetch_array($sth);
	if ($droptables) {
		$backuptext = "DROP TABLE IF EXISTS `$ctable`;\n" . $backuptext;
	}
	$backuptext .= ";\n\n";
	$append = 0;
} else {
	$query = "
		SELECT COUNT(*)
		FROM $ctable
	";
	$sth = $dbh->do_query($query);
	list($trow) = $dbh->fetch_array($sth);
	$statustext .= "{$ubbt_lang['DATA']} $ctable... " . $crow . " of " . $trow . "<br>";
	$dump_file = "{$config['dumpdir']}/$ctable.sql";
}

$field_list = array();
$query = "
	SHOW FIELDS FROM $ctable
";
$sth = $dbh->do_query($query);
while (list($field) = $dbh->fetch_array($sth)) {
	$field_list[] = $field;
}
$fields = "`" . implode("`,`", $field_list) . "`";

// Figure out what rows to grab
if (!$crow) {
	$crow = 0;
}
$query = "
	SELECT * FROM $ctable
	LIMIT $crow, 2001
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$numFields = $dbh->num_fields($sth);
$x = 1;
$more = 0;

while ($vals = $dbh->fetch_array($sth)) {
	if ($x == '2001') {
		$more = 1;
		break;
	}
	$backuptext .= "INSERT INTO `$ctable` ($fields) VALUES (";
	$comma = '';
	for ($i = 0; $i < $numFields; $i++) {
		if (!isset($vals[$i]) || is_null($vals[$i])) {
			$backuptext .= $comma . "NULL";
		} else {
//			$vals[$i] = addslashes($vals[$i]);
//			$backuptext .= "'$vals[$i]',";
			$backuptext .= $comma . $dbh->escape_string($vals[$i]);
		}
		$comma = ',';
	}
	$backuptext = preg_replace("/,$/", "", $backuptext);
	$backuptext .= ");\n";
	$x++;
}

if ($more) {
	$crow = $crow + 2000;
} else {
	if ($table) {
		$end = 1;
	}
	$crow = 0;
}
// Create the Page
$admin->setCurrentMenu($ubbt_lang['DATABASE']);
$admin->setPageTitle($ubbt_lang['BACKUP']);
$admin->setReturnTab($returntab);
if (!$end) {
	$admin->setRedirect("{$config['BASE_URL']}/admin/dodbbackup.php?returntab=2&crow=$crow&ctable=$ctable&table=$table&droptables=$droptables&analyzeoptimize=$analyzeoptimize");
	$admin->setRedirectTime(2);
	$admin->sendHeader();
} else {
	admin_log("DB_BACKUP", "");
	$datefin = $html->convert_time(time(), $user['USER_TIME_OFFSET'], 'Y-m-d H:i:s', true, false);
//	$admin->setRedirect("{$config['BASE_URL']}/admin/dbbackup.php?returntab=2");
//	$admin->setRedirectTime(10);
	$statustext .= "<br><br>" . $ubbt_lang['COMPLETE'] . " " . strip_tags($datefin);
	$statustext .= "<br><br><b>&raquo; <a href=\"{$config['BASE_URL']}/admin/dbbackup.php?returntab=2\">{$ubbt_lang['REDIR']}</a>";
	$admin->sendHeader();
}

if (!$append) {
// Create the sql file header
	$datebeg = $html->convert_time(time(), $user['USER_TIME_OFFSET'], 'Y-m-d H:i:s', true, false);
	list($server_software, $junk) = preg_split("# #", $_SERVER['SERVER_SOFTWARE']);
	$sth = $dbh->do_query("select VERSION()");
	list($sql_version) = $dbh->fetch_array($sth);
	$backuptext = "-- UBB.threads Database Backup
-- Version " . $VERSION . " (" . $VERBUILD . ")
-- https://www.ubbcentral.com
--
-- Host: " . $config['DATABASE_SERVER'] . "
-- Generation Time: " . strip_tags($datebeg) . "
-- " . $dbtype . " Version: " . $sql_version . "
-- PHP Version: " . phpversion() . "
--
-- Database: `" . $config['DATABASE_NAME'] . "`
-- Table: `" . $ctable . "`
--\n\n" . $backuptext;
}

$admin->createTopTabs($tabs, $returntab);

// Now grab the data
include("../templates/default/admin/dodbbackup.tmpl");

// Write out the file
$check = lock_and_write($dump_file, $backuptext, $append);

$admin->sendFooter();

?>