<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/features.php");

// Get the input
$returntab = get_input("returntab", "get");

// Get the user info
$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth();

// Set the default values
$ischecked = 'checked="checked"';
$isselected = 'selected="selected"';

$calendar = ($config['CALENDAR']) ? $ischecked : "";

$comments = ($config['COMMENTS']) ? $ischecked : "";

$config['COMMENTS_MIN_POST'] = (!$config['COMMENTS_MIN_POST']) ? "0" : $config['COMMENTS_MIN_POST'];

$b_notice_on = ($config['BIRTHDAY_NOTICE']) ? $ischecked : "";

$active_on = ($config['ENABLE_ACTIVE_TEXT']) ? $ischecked : "";

$displayname_0_checked = (!$config['DISPLAY_NAME_CHANGE']) ? $ischecked : "";
$displayname_1_checked = ($config['DISPLAY_NAME_CHANGE'] == 1) ? $ischecked : "";
$displayname_2_checked = ($config['DISPLAY_NAME_CHANGE'] == 2) ? $ischecked : "";

$markupoption_checked = ($config['MARKUP_HTML_TOGGLE']) ? $ischecked : "";

$uratings_checked = ($config['USER_RATINGS']) ? $ischecked : "";

$mood_checked = ($config['ENABLE_MOODS']) ? $ischecked : "";

$tratings_checked = ($config['TOPIC_RATINGS']) ? $ischecked : "";

$allowimages_checked = ($config['ALLOW_IMAGE_MARKUP']) ? $ischecked : "";

$httpsimages_checked = ($config['HTTPS_IMAGES']) ? $ischecked : "";

$urlhost_checked = ($config['URLHOST']) ? $ischecked : "";

$ipgeo_checked = ($config['IPGEO_LOOKUP']) ? $ischecked : "";

$fulltext = "";
$ubb = "";
if (!$config['SEARCH_METHOD'] || $config['SEARCH_METHOD'] == "fulltext") {
	$fulltext = $isselected;
} else {
	$ubb = $isselected;
}

$config['MAX_SEARCH_RANGE_VALUE'] = ($config['MAX_SEARCH_RANGE_VALUE']) ? $config['MAX_SEARCH_RANGE_VALUE'] : "1";
$config['MAX_SEARCH_RANGE_TYPE'] = ($config['MAX_SEARCH_RANGE_TYPE']) ? $config['MAX_SEARCH_RANGE_TYPE'] : "years";
$rangedays = ($config['MAX_SEARCH_RANGE_TYPE'] == "days") ? $isselected : "";
$rangeweeks = ($config['MAX_SEARCH_RANGE_TYPE'] == "weeks") ? $isselected : "";
$rangemonths = ($config['MAX_SEARCH_RANGE_TYPE'] == "months") ? $isselected : "";
$rangeyears = ($config['MAX_SEARCH_RANGE_TYPE'] == "years") ? $isselected : "";

$config['MIN_SEARCH_LENGTH'] = ($config['MIN_SEARCH_LENGTH']) ? $config['MIN_SEARCH_LENGTH'] : "3";
$config['MAX_SEARCH_RESULTS'] = ($config['MAX_SEARCH_RESULTS']) ? $config['MAX_SEARCH_RESULTS'] : "200";

$active_text_list = "";
if (isset($config['ACTIVE_TEXT_LIST'])) {
	foreach ($config['ACTIVE_TEXT_LIST'] as $target => $replace) {
		$replace = str_replace('\"', '"', $replace);
		$active_text_list .= "$target|$replace\n";
	}
}

$markup_font_list = "";
foreach ($config['MARKUP_FONTS'] as $k => $font) {
	$markup_font_list .= "$font\n";
}

$markup_font_sizes = "";
foreach ($config['MARKUP_FONT_SIZES'] as $k => $size) {
	$markup_font_sizes .= "$size\n";
}

// Update language string substitutions
$ubbt_lang['HTTPS_IMAGES_1'] = $html->substitute($ubbt_lang['HTTPS_IMAGES_1'], array("BASE_URL" => $config['BASE_URL']));
$ubbt_lang['URLHOST_1'] = $html->substitute($ubbt_lang['URLHOST_1'], array("BASE_URL" => $config['BASE_URL']));

$tabs = array(
	"{$ubbt_lang['FEATURES']}" => "",
	"{$ubbt_lang['SEARCH_ENGINE']}" => "",
	"{$ubbt_lang['ACTIVE_TEXT']}" => "",
	"{$ubbt_lang['MARKUP_PANEL']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['FEATURES']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['FEATURES']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE']);

// Include the template
include("../templates/default/admin/features.tmpl");

$admin->sendFooter();

?>