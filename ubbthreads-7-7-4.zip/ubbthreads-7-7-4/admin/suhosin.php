<?php
//	Script Version 7.7.3
//	Created by VNC Web Services (https://www.virtualnightclub.net/)

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/suhosin.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "get");

// Do admin bits
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();

// Fetch total forums
$query = "
	SELECT COUNT(*)
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_IS_ACTIVE = '1'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($totalforums) = $dbh->fetch_array($sth);

$max_vars = $totalforums * 30;
if ($max_vars > 2048) {
	$recommended = $max_vars;
} else {
	$recommended = 2048;
}

// Test hook, force page to display vars.
$suhosin_test = 1;

// Gather data for the "max_input_vars" setting
$about_max_vars = str_replace(array("%%current%%", "%%default%%", "%%recommended%%"), array(ini_get("max_input_vars"), "1000", $recommended), $ubbt_lang["MAX_VARS_ABOUT"]);

// Build the suhosin array
if ((extension_loaded("suhosin")) || ($suhosin_test == 1)) {
	$suhosin_array = array(
		0 => array(
			"about" => $ubbt_lang["SUHOSIN_ABOUT_REQUEST-MAX_VARS"],
			"current" => ini_get("suhosin.request.max_vars"),
			"default" => 1000,
			"name" => "request.max_vars",
			"recommended" => $recommended,
			"url" => "https://suhosin.org/stories/configuration.html#suhosin-request-max-vars",
		),
		array(
			"about" => $ubbt_lang["SUHOSIN_ABOUT_POST-MAX_VARS"],
			"current" => ini_get("suhosin.post.max_vars"),
			"default" => 1000,
			"name" => "post.max_vars",
			"recommended" => $recommended,
			"url" => "https://suhosin.org/stories/configuration.html#suhosin-post-max-vars",
		),
		array(
			"about" => $ubbt_lang["SUHOSIN_ABOUT_REQUEST-ARRAY"],
			"current" => ini_get("suhosin.request.max_array_index_length"),
			"default" => 64,
			"name" => "request.max_array_index_length",
			"recommended" => 256,
			"url" => "https://suhosin.org/stories/configuration.html#suhosin-request-max-array-index-length",
		),
		array(
			"about" => $ubbt_lang["SUHOSIN_ABOUT_POST-ARRAY-LENGTH"],
			"current" => ini_get("suhosin.post.max_array_index_length"),
			"default" => 64,
			"name" => "post.max_array_index_length",
			"recommended" => 256,
			"url" => "https://suhosin.org/stories/configuration.html#suhosin-post-max-array-index-length",
		),
		array(
			"about" => $ubbt_lang["SUHOSIN_ABOUT_REQUEST-TOTALNAME"],
			"current" => ini_get("suhosin.request.max_totalname_length"),
			"default" => 256,
			"name" => "request.max_totalname_length",
			"recommended" => 8192,
			"url" => "https://suhosin.org/stories/configuration.html#suhosin-request-max-totalname-length",
		),
		array(
			"about" => $ubbt_lang["SUHOSIN_ABOUT_POST-TOTALNAME"],
			"current" => ini_get("suhosin.post.max_totalname_length"),
//			"current" => 8192,
			"default" => 256,
			"name" => "post.max_totalname_length",
			"recommended" => 8192,
			"url" => "https://suhosin.org/stories/configuration.html#suhosin-post-max-totalname-length",
		),
		array(
			"about" => $ubbt_lang["SUHOSIN_ABOUT_GET-VALUE_LENGTH"],
			"current" => ini_get("suhosin.get.max_value_length"),
//			"current" => 512,
			"default" => 512,
			"name" => "get.max_value_length",
			"recommended" => 1024,
			"url" => "https://suhosin.org/stories/configuration.html#suhosin-get-max-value-length",
		),
		array(
			"about" => $ubbt_lang["SUHOSIN_ABOUT_SQL-BAILOUT"],
			"current" => ini_get("suhosin.sql.bailout_on_error"),
			"default" => 0,
			"name" => "sql.bailout_on_error",
			"recommended" => 0,
			"url" => "https://suhosin.org/stories/configuration.html#suhosin-sql-bailout-on-error",
		),
	);
	$suhosin_status = 1;
} else {
	$suhosin_array = "";
	$suhosin_status = 0;
}

if ($suhosin_status == 1) {
	if (extension_loaded("suhosin")) {
		$suhosin_data .= <<<EOF
	<tr>
		<td class="colored-row stdautorow alvt">
{$ubbt_lang["SUHOSIN_STATUS_HEADING"]}
		</td>
		<td class="colored-row stdautorow alvt">
<span style="font-weight: bold; color: #4caf50;">{$ubbt_lang["SUHOSIN_DISABLED"]}</span>
		</td>
		<td class="colored-row stdautorow alvt">
<span style="font-weight: bold; color: #4caf50;">{$ubbt_lang["SUHOSIN_ENABLED"]}</span>
		</td>
		<td class="colored-row stdautorow alvt">
<span style="font-weight: bold; color: #4caf50;">{$ubbt_lang["SUHOSIN_DISABLED"]}</span>
		</td>
	</tr>
EOF;
	} else {
		$suhosin_data .= <<<EOF
	<tr>
		<td class="colored-row stdautorow alvt">
{$ubbt_lang["SUHOSIN_STATUS_HEADING"]}
		</td>
		<td class="colored-row stdautorow alvt">
<span style="font-weight: bold; color: #4caf50;">{$ubbt_lang["SUHOSIN_DISABLED"]}</span>
		</td>
		<td class="colored-row stdautorow alvt">
<span style="font-weight: bold; color: #4caf50;">{$ubbt_lang["SUHOSIN_DISABLED"]}</span>
		</td>
		<td class="colored-row stdautorow alvt">
<span style="font-weight: bold; color: #4caf50;">{$ubbt_lang["SUHOSIN_DISABLED"]}</span>
		</td>
	</tr>
EOF;
	}

	foreach ($suhosin_array as $value) {
		if ($value["current"] == "") {
			$value["current"] = $ubbt_lang["SUHOSIN_UNSET"];
			$value["recommended"] = $ubbt_lang["SUHOSIN_UNSET"];
		}

		$suhosin_recommend_color = "#4caf50";
		if ($value["current"] == $value["recommended"]) {
			$suhosin_recommend_color = "#0d47a1";
		}
		if ($value["current"] == $ubbt_lang["SUHOSIN_UNSET"]) {
			$suhosin_color = "#0d47a1";
			$suhosin_recommend_color = "#0d47a1";
		} elseif (($value["current"] < $value["recommended"]) || ($value["current"] == $ubbt_lang["SUHOSIN_UNSET"])) {
			$suhosin_color = "#f44336";
		} else {
			$suhosin_color = "#4caf50";
		}

		if (($value["name"] == "sql.bailout_on_error") && ($value["default"] == null)) {
			$suhosin_default_color = "#4caf50";
		} else {
			$suhosin_default_color = "#f44336";
		}
// May need to add an else, once sql.bailout_on_error is finalized.
		if ($value["default"] == null) {
			$value["default"] = $ubbt_lang["SUHOSIN_DISABLED"];
		}
		if ($value["recommended"] == null) {
			$value["recommended"] = $ubbt_lang["SUHOSIN_DISABLED"];
		}

		$suhosin_data .= <<<EOF
	<tr>
		<td class="colored-row stdautorow alvt">
<a href="{$value["url"]}" target="{$value["about"]}" title="{$value["about"]}">suhosin.{$value["name"]}</a>
		</td>
		<td class="colored-row stdautorow alvt">
<span style="font-weight: bold; color: {$suhosin_default_color};">{$value["default"]}</span>
		</td>
		<td class="colored-row stdautorow alvt">
<span style="font-weight: bold; color: {$suhosin_color};">{$value["current"]}</span>
		</td>
		<td class="colored-row stdautorow alvt">
<span style="font-weight: bold; color: {$suhosin_recommend_color};">{$value["recommended"]}</span>
		</td>
	</tr>
EOF;
	}

	$suhosin_data .= <<<EOF
	<tr>
		<td colspan="4" class="colored-row stdautorow alvt">
suhosin.log.* {$ubbt_lang["SUHOSIN_SQL-LOG"]}
		</td>
	</tr>
EOF;
}

$tabs = array(
	"{$ubbt_lang['PHPINFO']}" => "{$config['BASE_URL']}/admin/phpinfo.php?returntab=0",
	"{$ubbt_lang['SUHOSIN']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['PHPINFO']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['SUHOSIN']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);

// Include the template
include("../templates/default/admin/suhosin.tmpl");

$admin->sendFooter();
?>