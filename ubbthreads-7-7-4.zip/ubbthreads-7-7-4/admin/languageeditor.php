<?php
//	Script Version 7.7.0

require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/languageeditor.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// get the input
$returntab = get_input("returntab", "post");
$language = get_input("language", "both");
$filename = get_input("filename", "both");
$searchstring = get_input("searchstring", "both");
$searchfilename = get_input("searchfilename", "both");
$searchstring = str_replace("/", "\\/", $searchstring);
$searchstring = urldecode($searchstring);
// if filename is set then we forward them to the editor for that file
if ($filename) {
	header("Location: {$config['FULL_URL']}/admin/languageeditor2.php?language=$language&filename=$filename");
	exit;
}
if (strlen($searchstring) < 3) {
	$admin->error($ubbt_lang['SEARCH_LEN']);
}

// Now we need to search the language files:
$currlang = $ubbt_lang;
unset($ubbt_lang);
$dir = opendir("../languages/$language");
$matches = array();
$i = 0;
while ($file = readdir($dir)) {
	if ($file == "." || $file == ".." || $file == "admin" || $file == "oldadmin" || !preg_match("#php$#", $file)) {
		continue;
	}
	if (($searchfilename != "all") && ($searchfilename != $file)) {
		continue;
	}
	@include("../languages/$language/$file");
	if (!is_array($ubbt_lang)) {
		$ubbt_lang = array();
	}
	foreach ($ubbt_lang as $key => $value) {
		if (preg_match("/$searchstring/i", $value)) {
			$matches[$i]['key'] = $key;
			$matches[$i]['value'] = $value;
			$matches[$i]['file'] = $file;
			$i++;
		}
	}
	unset($ubbt_lang);
}

$dir = opendir("{$config['FULL_PATH']}/languages/$language/admin");
while ($file = readdir($dir)) {
	if ($file == "." || $file == "..") {
		continue;
	}
	if (($searchfilename != "all") && ($searchfilename != $file)) {
		continue;
	}
	@include("../languages/$language/admin/$file");
	foreach ($ubbt_lang as $key => $value) {
		if (preg_match("/$searchstring/", $value)) {
			$matches[$i]['key'] = $key;
			$matches[$i]['value'] = $value;
			$matches[$i]['file'] = "admin/$file";
			$i++;
		}
	}
	unset($ubbt_lang);
}

$ubbt_lang = $currlang;

if (!sizeof($matches)) {
	$admin->error($ubbt_lang['NO_MATCHES']);
}
$ubbt_lang = $currlang;

// urlencode the searchstuff if necessary
$searchstring = urlencode($searchstring);
$searchfilename = urlencode($searchfilename);

// Create the Page
$tabs = array(
	"{$ubbt_lang['LANG_EDIT']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['LANGS']);
$admin->setParentTitle($ubbt_lang['LANGS'], "availablelangs.php");
$admin->setPageTitle($ubbt_lang['LANG_EDIT']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/languageeditor.tmpl");

$admin->sendFooter();

?>