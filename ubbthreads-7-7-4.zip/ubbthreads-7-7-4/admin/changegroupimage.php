<?php
//	Script Version 7.7.0

require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/changegroupimage.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$group = get_input("group", "get");

$tabs = array(
	$ubbt_lang['TAB_HEADER'] => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['GROUP_SET']);
$admin->setParentTitle($ubbt_lang['GROUP_SET'], "groupmanage.php?returntab=$returntab");
$admin->setPageTitle($ubbt_lang['TAB_HEADER']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/changegroupimage.tmpl");

$admin->sendFooter();

?>