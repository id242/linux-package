<?php
//	Script Version 7.7.2

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/forumperms.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "get");
$edit_group = get_input("edit_group", "both");
$copy_group = get_input("copy_group", "both");

if (!$edit_forum) $edit_forum = 0;

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the max size for file uploads
$max_size = ini_get("upload_max_filesize");
if (preg_match("/K/", $max_size)) $multi = 1024;
if (preg_match("/M/", $max_size)) $multi = 1048576;
if (preg_match("/G/", $max_size)) $multi = 1073741824;
if (!$multi) $multi = 1;
$max_size_num = preg_replace("/(K|M|G| +)/", "", $max_size);
$max_size_bytes = $max_size_num * $multi;

// Change some of the wordlets to include this size
$ubbt_lang['FILE_SIZE_1'] = $html->substitute($ubbt_lang['FILE_SIZE_1'], array("MAX_SIZE" => $max_size, "MAX_SIZE_BYTES" => $max_size_bytes));
$ubbt_lang['GALLERY_SIZE_1'] = $html->substitute($ubbt_lang['GALLERY_SIZE_1'], array("MAX_SIZE" => $max_size, "MAX_SIZE_BYTES" => $max_size_bytes));

include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree, $style_cache, $lang_cache) = build_forum_cache();
}


$perm_list = array();
$query = "
	select PERMISSION_NAME,PERMISSION_IS_HIGH,PERMISSION_IS_LOW
	from {$config['TABLE_PREFIX']}PERMISSION_LIST
	where PERMISSION_TYPE='forum'
	order by PERMISSION_ORDER
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while ($row = $dbh->fetch_array($sth)) {
	$perm_list[] = $row;
}

$gselect = $edit_group;

if ($copy_group) {
	$gselect = $copy_group;
}

$perms = array();
$query = "
	select *
	from {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
	where GROUP_ID = ?
";
$sth = $dbh->do_placeholder_query($query, array($gselect), __LINE__, __FILE__);
while ($row = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
	foreach ($row as $k => $v) {
		if ($k == "GROUP_ID") continue;
		if ($k == "FORUM_ID") {
			$fid = $v;
			continue;
		}
		$perms[$k][$fid] = $v;
	}
}

// Now grab all groups
$groups = array();
$query = "
	select GROUP_ID,GROUP_NAME
	from {$config['TABLE_PREFIX']}GROUPS
	where GROUP_IS_DISABLED ='0'
	order by GROUP_ID
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($gid, $gname) = $dbh->fetch_array($sth)) {
	$groups[$gid] = $gname;
}


$tabs = array(
	"{$ubbt_lang['FORUM_PERMS']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['GROUP_SET']);
$admin->setParentTitle($ubbt_lang['GROUP_SET'], "groupmanage.php");
$admin->setPageTitle($ubbt_lang['FORUM_PERMS']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);

// Include the template
include("../templates/default/admin/group_forumperms.tmpl");

$admin->sendFooter();

?>