<?php
//	Script Version 7.7.0

require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/edittemplate.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$template = get_input("template", "both");

if (!$template) {
	$admin->error($ubbt_lang['NONE']);
}

$tempstring = file_get_contents("{$config['FULL_PATH']}/templates/default/$template");
$tempstring = ubbchars($tempstring);

$tabs = array(
	"{$ubbt_lang['TEMPLATE_EDIT']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['TEMPLATES']);
$admin->setParentTitle($ubbt_lang['TEMPLATES'], "selecttemplate.php");
$admin->setPageTitle($ubbt_lang['TEMPLATE_EDIT']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/edittemplate.tmpl");

$admin->sendFooter();

?>