<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/gen_display.php");

// Get the input
$returntab = get_input("returntab", "get");

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME, USER_REAL_EMAIL");
$html = new html;

$admin = new Admin;
$admin->doAuth();

// Set the default values
$ischecked = 'checked="checked"';
$isselected = 'selected="selected"';

$newcount = ($config['NEW_COUNT']) ? $ischecked : "";

$newreplies = ($config['NEW_REPLIES']) ? $ischecked : "";

$showage_checked = ($config['AGE_WITH_BIRTHDAYS']) ? $ischecked : "";

$cal_bday_checked = ($config['BIRTHDAYS_IN_CALENDAR']) ? $ischecked : "";

$showmods_checked = ($config['LIST_MODERATORS']) ? $ischecked : "";

$intro_checked = ($config['COMMUNITY_INTRO']) ? $ischecked : "";

$facebook_checked = $config['FACEBOOK'] ? $ischecked : "";
$twitter_checked = $config['TWITTER'] ? $ischecked : "";
$reddit_checked = $config['REDDIT'] ? $ischecked : "";
$shareaholic = $config['SHAREAHOLIC'];

$layout_side = $ischecked;
$layout_top = ($config['POST_LAYOUT'] == "top") ? $ischecked : "";

// Default forum email address
$config['SITE_EMAIL'] = (!$config['SITE_EMAIL']) ? $user['USER_REAL_EMAIL'] : $config['SITE_EMAIL'];

// What options exists for captcha?
$gd = true;
$im = true;
if (!function_exists(imagefttext)) {
	$gd = false;
}
if (!$config['CONVERT_PATH']) {
	$im = false;
}

$captcha_disabled = "";
$captcha_gd = "";
$captcha_im = "";
if ($config['POST_CAPTCHA'] == "gd" && $gd) {
	$captcha_gd = $isselected;
} elseif ($config['POST_CAPTCHA'] == "im" && $im) {
	$captcha_im = $isselected;
}

$no_captcha = (!$gd && !$im) ? $ubbt_lang['NO_CAPTCHA'] : "";

$display_both = "";
$display_flat = "";
$display_threaded = "";
if ($config['TOPIC_DISPLAY_OPTIONS'] == "flat") {
	$display_flat = $ischecked;
} elseif ($config['TOPIC_DISPLAY_OPTIONS'] == "threaded") {
	$display_threaded = $ischecked;
} else {
	$display_both = $ischecked;
}

$catonlymode_checked = ($config['CATEGORY_ONLY_MODE']) ? $ischecked : "";

$teaserlatest_checked = ($config['SHOW_TEASER_LATEST_POST']) ? $ischecked : "";

$enablepostcounts_checked = ($config['ENABLE_POST_COUNTS']) ? $ischecked : "";

$showallgraemlins_checked = ($config['SHOW_ALL_GRAEMLINS']) ? $ischecked : "";

$days = array(
	$ubbt_lang['SUNDAY_FULL'],
	$ubbt_lang['MONDAY_FULL'],
	$ubbt_lang['TUESDAY_FULL'],
	$ubbt_lang['WEDNESDAY_FULL'],
	$ubbt_lang['THURSDAY_FULL'],
	$ubbt_lang['FRIDAY_FULL'],
	$ubbt_lang['SATURDAY_FULL'],
);

$calendar_week_start = '<select name="CALENDAR_START_DAY" id="cal_startweek">';

for ($i = 0; $i < 7; $i++) {
	if ($i == array_get($config, 'CALENDAR_START_DAY', 0)) {
		$calendar_week_start .= sprintf('<option value="%s" selected="selected">%s</option>', $i, $days[$i]);
	} else {
		$calendar_week_start .= sprintf('<option value="%s">%s</option>', $i, $days[$i]);
	}
}

$calendar_week_start .= "</select>";

// Text Editor interface to use
$std_sel = ($config['EDITOR'] == "standard") ? $isselected : "";
$stdfa_sel = ($config['EDITOR'] == "standard_fa") ? $isselected : "";
$sce_sel = ($config['EDITOR'] == "sceditor") ? $isselected : "";
$tmce_sel = ($config['EDITOR'] == "tinymce") ? $isselected : "";

$flat_checked = "";
$thread_checked = "";
if ($config['TOPIC_DISPLAY_STYLE'] == "flat") {
	$flat_checked = $ischecked;
} else {
	$thread_checked = $ischecked;
}

$url_link_checked = "";
$email_link_checked = "";
if ($config['CONTACT_LINK_TYPE'] == "url") {
	$url_link_checked = $ischecked;
} else {
	$email_link_checked = $ischecked;
}

$show_avatars_checked = ($config['SHOW_AVATARS']) ? $ischecked : "";

$priv_none_c = "";
$priv_text_c = "";
$priv_url_c = "";
$privacy_checked = "";
if ($config['PRIVACY_STATEMENT'] == "url") {
	$priv_url_c = $ischecked;
} elseif ($config['PRIVACY_STATEMENT'] == "text") {
	$priv_text_c = $ischecked;
} else {
	$priv_none_c = $ischecked;
}

$invisible_checked = ($config['DISABLE_ONLINE_INVISIBLE']) ? $ischecked : "";

// Get search agents
$query = "
	SELECT
		AGENTS
	FROM
		{$config['TABLE_PREFIX']}SEARCH_AGENTS
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($search_agents) = $dbh->fetch_array($sth);

// Get the privacy text
$privacy_text = file_get_contents("{$config['FULL_PATH']}/includes/privacy.php");
$privacy_text = ubbchars($privacy_text);

// Get the community intro text
$intro_body = file_get_contents("{$config['FULL_PATH']}/includes/community_intro.php");
$intro_body = ubbchars($intro_body);

// Create the timezone list
$TimeOffset = ($config['SERVER_TIME_OFFSET']);
if (!$TimeOffset || !in_array($TimeOffset, DateTimeZone::listIdentifiers())) {
	$TimeOffset = "UTC";
}
$tzlist = $html->generate_timezone_list();

// Do some math for the additional items
$stz = date_default_timezone_get();
$servertime = $html->convert_time(time(), "", "", 1);

$gtz = "{$config['SERVER_TIME_OFFSET']}";
$gdtz = new DateTimeZone($TimeOffset);
$gdt = new DateTime('now', $gdtz);
$gt = $gdtz->getOffset($gdt);								// difference in seconds	ex. -28800
$guesttime = $html->convert_time(time() + $gt, "", "", 1);	// Time display using forum default settings
$tzdif = ($gt / 3600);										// difference in hours		ex. -8

// Quicky reply enabled?
$quickreply_c = ($config['ENABLE_QUICK_REPLY']) ? $ischecked : "";

// Enable Likes?
$enablelikes_c = ($config['ENABLE_LIKES']) ? $ischecked : "";
// Display a list of which members liked each post?
$showuserlikes_c = ($config['SHOW_USER_LIKES']) ? $ischecked : "";
// Allowed to like their own content? (and button display)?
$likeself_c = ($config['LIKE_SELF']) ? $ischecked : "";
// Require active (non-banned/only approved) members on the summary?
$likesrequireactive_c = ($config['LIKES_REQUIRE_ACTIVE']) ? $ischecked : "";

// Grab the default header
$headerfile = file_get_contents("{$config['FULL_PATH']}/includes/header.php");
$headerfile = ubbchars($headerfile);

// Grab the default insert
$insertfile = file_get_contents("{$config['FULL_PATH']}/includes/header-insert.php");
$insertfile = ubbchars($insertfile);

// Grab the non-showflat header insert
$descripinsertfile = file_get_contents("{$config['FULL_PATH']}/includes/header-insert-descrip.php");
$descripinsertfile = ubbchars($descripinsertfile);

// Grab the shareaholic header insert
$shareaholicfile = file_get_contents("{$config['FULL_PATH']}/includes/header-shareaholic.php");
$shareaholicfile = ubbchars($shareaholicfile);

// Grab the default footer
$footerfile = file_get_contents("{$config['FULL_PATH']}/includes/footer.php");
$footerfile = ubbchars($footerfile);

$timeformats = join($config['TIME_FORMATS'], "\n");

$relative = ($config['RELATIVE_TIME']) ? $ischecked : "";

// Update language string substitutions
$ubbt_lang['URL_1'] = $html->substitute($ubbt_lang['URL_1'], array("BASE_URL" => $config['BASE_URL']));

$tabs = array(
	"{$ubbt_lang['PRIMARY_DISP']}" => "",
	"{$ubbt_lang['DATE_DISP']}" => "",
	"{$ubbt_lang['INCLUDES']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['GENERAL']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['PRIMARY_DISP']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE_GEN']);

foreach ($config as $key => $value) {
	$config[$key] = ubbchars($value);
}
// Include the template
include("../templates/default/admin/gen_display.tmpl");

$admin->sendFooter();

?>