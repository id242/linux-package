<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$query = "
	UPDATE {$config['TABLE_PREFIX']}CACHE
	SET CACHE_VALUE = ''
	WHERE CACHE_FIELD not in ('max_online','max_online_timestamp')
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);

// Update post view counters
update_views_counter();

// Purge inactive users from whosonline table
clear_online();

// Purge pointers to moved topics that have expired
trigger_pointer_delete();

// Purge expired bans
trigger_ban_expiration();

// Rebuild the content islands
rebuild_islands(1);

// Rebuild the rss feeds
generate_rss_feeds(1);

// Rebuild the forum list cache
build_forum_cache();

// Rebuild any custom tags
build_custom_tag_cache();

// Clear any cached permissions
$userob->clear_cached_perms();

// Clear any compiled smarty templates
$smarty->clearCompiledTemplate();

// Purge files in the /tmp directory older than 2 hours
$dir = opendir("{$config['FULL_PATH']}/tmp");
while (($file = readdir($dir)) != false) {
	if (($file == ".") || ($file == "..") || ($file == "index.html")) {
		continue;
	}
	$modified = time() - filemtime("{$config['FULL_PATH']}/tmp/$file");
	if ($modified > 7200) {
		@unlink("{$config['FULL_PATH']}/tmp/$file");
	}
}

// Purge orphaned file entries in the database older than 2 hours
$query = "
	DELETE FROM
		{$config['TABLE_PREFIX']}FILES
	WHERE
		POST_ID = '0' AND
		FILE_ADD_TIME < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 2 HOUR))
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);


admin_log("CLEAR_CACHE", "");

$admin->redirect($ubbt_lang['CACHE_CLEARED'], "{$config['BASE_URL']}/admin/cache.php", $ubbt_lang['CACHE_F_LOC']);

?>