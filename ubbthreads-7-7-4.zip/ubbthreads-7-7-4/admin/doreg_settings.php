<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Clear our previous registration options
$query = "
	TRUNCATE TABLE {$config['TABLE_PREFIX']}REGISTRATION_FIELDS
";
$dbh->do_query($query, __LINE__, __FILE__);

// Get our new registration options
$regopt = get_input("regopt", "post");

// Insert our new registration options
foreach ($regopt as $key => $value) {
	$show = 0;
	$require = 0;
	if ($value == "show") {
		$show = 1;
	}
	if ($value == "require") {
		$require = 1;
	}
	$query = "
		REPLACE INTO
			{$config['TABLE_PREFIX']}REGISTRATION_FIELDS
			(REGISTRATION_FIELD, REGISTRATION_SHOW_FIELD, REGISTRATION_REQUIRE_FIELD)
		VALUES
			('$key', '$show', '$require')
	";
	$dbh->do_query($query, __LINE__, __FILE__);
}

// What config vars are we updating?
$newconfig = array("NEW_USER_MODERATION", "EMAIL_VERIFICATION", "SPECIAL_CHARACTERS", "MIN_PDN_LENGTH", "MAX_PDN_LENGTH", "DO_AGE_CHECK", "ALLOW_UNDER_13", "SUSPEND_REGISTRATIONS", "CUSTOM_FIELD_1", "CUSTOM_FIELD_2", "CUSTOM_FIELD_3", "CUSTOM_FIELD_4", "CUSTOM_FIELD_5", "MINIMUM_AGE", "REQUIRE_UNIQUE_EMAIL", "CAPTCHA");

// Forcing the forum rules to be accepted?
if (get_input("FORCE_RULES", "post")) {
	array_push($newconfig, "FORCE_RULES");
}

// Update newusergroup
$newusergroups = '1';

// Update the config file
include("doeditconfig.php");

// Update the forum rules file if necessary
$oldboardrules = "";
$boardfile = file("{$config['FULL_PATH']}/includes/boardrules.php");
foreach ($boardfile as $linenum => $line) {
	$oldboardrules .= "$line";
}
$boardrulestext = get_input("boardrulestext", "post");
$boardrulestext = trim($boardrulestext);
if ($boardrulestext != $oldboardrules) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/boardrules.php", $boardrulestext);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_RULES']);
	}
}

// Get current badips
$badnames = get_input("badnames", "post");
$query = "
SELECT RESERVED_USERNAME
FROM {$config['TABLE_PREFIX']}RESERVED_NAMES
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$currnames = array();
while (list($bname) = $dbh->fetch_array($sth)) {
	$currnames[] = $bname;
}
$badnames = str_replace("\r", "", $badnames);
$newnames = preg_split("#\n#", $badnames);

// Update the ReservedName List
for ($i = 0; $i < sizeof($newnames); $i++) {
	if (!in_array($newnames[$i], $currnames)) {
		$name_q = addslashes($newnames[$i]);
		if ($name_q) {
			$query = "
				INSERT INTO
					{$config['TABLE_PREFIX']}RESERVED_NAMES
					(RESERVED_USERNAME)
				VALUES
					('$name_q')
			";
			$dbh->do_query($query, __LINE__, __FILE__);
		}
	}
}

for ($i = 0; $i < sizeof($currnames); $i++) {
	if (!in_array($currnames[$i], $newnames)) {
		$name_q = addslashes($currnames[$i]);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}RESERVED_NAMES
			WHERE RESERVED_USERNAME = '$name_q'
		";
		$dbh->do_query($query, __LINE__, __FILE__);
	}
}


// Update the coppa file if necessary
$oldcoppa = "";
$file = file("{$config['FULL_PATH']}/includes/coppainsert.php");
foreach ($file as $linenum => $line) {
	$oldcoppa .= "$line";
}
$coppa = get_input("coppa", "post");
$coppa = trim($coppa);
if ($coppa != $oldcoppa) {

	$check = lock_and_write("{$config['FULL_PATH']}/includes/coppainsert.php", $coppa);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_COPPA']);
	}
}

admin_log("REGISTRATION_SETTINGS", "$log_diffs");

$admin->redirect($ubbt_lang['SET_UPDATED'], "{$config['BASE_URL']}/admin/reg_settings.php?returntab=$returntab", $ubbt_lang['REG_SET_F_LOC']);

?>