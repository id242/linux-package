<?php
//	Script Version 7.7.0

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/styles.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$style = get_input("style", "get");

$query = "
	select STYLE_NAME,STYLE_IMG,STYLE_VARS,STYLE_WRAPPERS,STYLE_EDITED_TIME
	from {$config['TABLE_PREFIX']}STYLES
	where STYLE_ID = ?
";
$sth = $dbh->do_placeholder_query($query, array($style), __LINE__, __FILE__);
list($style_name, $style_img, $style_vars, $style_wrapper, $last_edit) = $dbh->fetch_array($sth);

include("{$config['FULL_PATH']}/styles/wrappers.php");

unlink("{$config['FULL_PATH']}/styles/{$style_name}_{$last_edit}.css");
unlink("{$config['FULL_PATH']}/styles/{$style}.php");
$query = "
	delete from {$config['TABLE_PREFIX']}STYLES
	where STYLE_ID = ?
";
$dbh->do_placeholder_query($query, array($style), __LINE__, __FILE__);

admin_log("DELETE_STYLE", "$style: $style_name");

header("Location: {$config['FULL_URL']}/admin/styles.php?returntab=0");


?>