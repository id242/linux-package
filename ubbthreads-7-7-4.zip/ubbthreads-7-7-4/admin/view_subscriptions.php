<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/view_subscriptions.php");

// Get the input
$returntab = get_input("returntab", "both");

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();

// Grab any filter params
$active = get_input("active", "post", "");
$status = get_input("status", "post", "");
$group = get_input("group", "post", "");
$display_name = get_input("display_name", "post", "");
$mail = get_input("mail", "post", "");
$invoice = get_input("invoice", "post", "");
$custom = get_input("custom", "post", "");
$txn = get_input("txn", "post", "");
$filter = get_input("filter", "post", "");
$page = get_input("page", "get", "");

if (!$page) $page = 1;

if (!$filter) {
	$filter_array = unserialize($_SESSION['filter_array']);
	$active = $filter_array['active'];
	$status = $filter_array['status'];
	$group = $filter_array['group'];
	$display_name = $filter_array['display_name'];
	$mail = $filter_array['mail'];
	$invoice = $filter_array['invoice'];
	$custom = $filter_array['custom'];
	$txn = $filter_array['txn'];
}

$clause = "";

$any_active = "";
$yes_active = "";
$no_active = "";

if ($active == "") {
	$any_active = "selected='selected'";
}
if ($active == "0") {
	$no_active = "selected='selected'";
}
if ($active == "1") {
	$yes_active = "selected='selected'";
}


if ($status == "") {
	$any_status = "selected='selected'";
}
if ($status == "FREE TRIAL") {
	$ft_status = "selected='selected'";
}
if ($status == "PAYMENT RECEIVED") {
	$pr_status = "selected='selected'";
}
if ($status == "PAYMENT PENDING") {
	$pp_status = "selected='selected'";
}
if ($status == "DONATION") {
	$d_status = "selected='selected'";
}
if ($status == "PAYMENT FAILED") {
	$pf_status = "selected='selected'";
}
if ($status == "PAYMENT DENIED") {
	$pd_status = "selected='selected'";
}
if ($status == "SUBSCRIPTION FAILED") {
	$sf_status = "selected='selected'";
}
if ($status == "EOT") {
	$eot_status = "selected='selected'";
}
if ($status == "CANCELED") {
	$c_status = "selected='selected'";
}
if ($status == "REFUND") {
	$ref_status = "selected='selected'";
}
if ($status == "REVERSAL") {
	$rev_status = "selected='selected'";
}
if ($status == "CANCELED REVERSAL") {
	$cr_status = "selected='selected'";
}

if ($filter || sizeof($filter_array)) {

	$filter_array['active'] = $active;
	if ($active != "") {
		$active = addslashes($active);
		$clause = " and t1.SUBSCRIPTION_IS_ACTIVE = '$active'";
	}

	$filter_array['status'] = $status;
	if ($status != "") {
		$status = addslashes($status);
		$clause .= " and t1.SUBSCRIPTION_STATUS = '$status'";
	}

	$filter_array['group'] = $group;
	if ($group != "") {
		$group = addslashes($group);
		$clause .= " and t3.GROUP_ID = '$group'";
	}

	$filter_array['display_name'] = $display_name;
	if ($display_name != "") {
		$query = "
			SELECT
				USER_ID
			FROM
				{$config['TABLE_PREFIX']}USERS
			WHERE
				UPPER(USER_DISPLAY_NAME) LIKE UPPER(?)
		";
		$sth = $dbh->do_placeholder_query($query, array($display_name), __LINE__, __FILE__);
		list ($uid) = $dbh->fetch_array($sth);

		$clause .= " and t1.USER_ID = '$uid'";
	}

	$filter_array['mail'] = $mail;
	if ($mail != "") {
		$query = "
			SELECT
				USER_ID
			FROM
				{$config['TABLE_PREFIX']}USER_PROFILE
			WHERE
				UPPER(USER_REAL_EMAIL) LIKE UPPER(?)
		";
		$sth = $dbh->do_placeholder_query($query, array($mail), __LINE__, __FILE__);
		list ($uid) = $dbh->fetch_array($sth);

		$clause .= " and t1.USER_ID = '$uid'";
	}

	$filter_array['invoice'] = $invoice;
	if ($invoice != "") {
		$invoice = addslashes($invoice);
		$clause .= " and t1.SUBSCRIPTION_ID = '$invoice'";
	}


	$filter_array['custom'] = $custom;
	if ($custom != "") {
		$custom = addslashes($custom);
		$clause .= " and t1.CUSTOM_ID = '$custom'";
	}

	$filter_array['txn'] = $txn;
	if ($txn != "") {
		$query = "
			SELECT
				CUSTOM_ID
			FROM
				{$config['TABLE_PREFIX']}PAYPAL_DATA
			WHERE
				TXN_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($txn), __LINE__, __FILE__);
		list ($inv) = $dbh->fetch_array($sth);

		$clause .= " and t1.CUSTOM_ID = '$inv'";
	}

	$_SESSION['filter_array'] = serialize($filter_array);

}

// Get all groups
$query = "
	SELECT
		SUBSCRIPTION_NAME, GROUP_ID
	FROM
		{$config['TABLE_PREFIX']}SUBSCRIPTIONS
	WHERE
		(SUBSCRIPTION_NAME <> '' AND SUBSCRIPTION_NAME IS NOT NULL)
	ORDER BY
		GROUP_ID
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$sub_groups = "";
while (list($sub_name, $g_id) = $dbh->fetch_array($sth)) {
	$selected = "";
	if ($group == $g_id) {
		$selected = "selected='selected'";
	}
	$sub_groups .= "<option $selected value='$g_id'>$sub_name</option>";
}

$query = "
	SELECT
		count(t1.SUBSCRIPTION_ID)
	FROM
		{$config['TABLE_PREFIX']}SUBSCRIPTION_DATA AS t1,
		{$config['TABLE_PREFIX']}USERS AS t2,
		{$config['TABLE_PREFIX']}SUBSCRIPTIONS AS t3
	WHERE
		t1.USER_ID = t2.USER_ID
	AND	t1.GROUP_ID = t3.GROUP_ID
		$clause
	ORDER BY
		t1.SUBSCRIPTION_ID DESC
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($total_rows) = $dbh->fetch_array($sth);


if ($page == 1) {
	$limit = "LIMIT 25";
} else {
	$limit = "LIMIT " . (($page - 1) * 25) . ",25";
}

// Setup the pages
$totalpages = ceil($total_rows / 25);
for ($i = 1; $i <= $totalpages; $i++) {
	if ($i == $page) {
		$pageprint .= $i . " ";
	} else {
		$pageprint .= "<a href=\"view_subscriptions.php?page=$i\">$i</a> ";
	}
}

$query = "
	SELECT
		t1.SUBSCRIPTION_ID, t2.USER_DISPLAY_NAME, t4.USER_REAL_EMAIL, t3.SUBSCRIPTION_NAME, t1.SUBSCRIPTION_START_DATE,
		t1.SUBSCRIPTION_END_DATE, t1.SUBSCRIPTION_STATUS, t1.SUBSCRIPTION_IS_ACTIVE, t1.SUBSCRIPTION_PAYMENT, t1.USER_ID,
		t3.GROUP_ID
	FROM
		{$config['TABLE_PREFIX']}SUBSCRIPTION_DATA AS t1,
		{$config['TABLE_PREFIX']}USERS AS t2,
		{$config['TABLE_PREFIX']}SUBSCRIPTIONS AS t3,
		{$config['TABLE_PREFIX']}USER_PROFILE AS t4
	WHERE
		t1.USER_ID = t2.USER_ID AND
		t1.GROUP_ID = t3.GROUP_ID AND
		t1.USER_ID = t4.USER_ID
		$clause
	ORDER BY t1.SUBSCRIPTION_ID	DESC
		$limit
";

$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($invoice_no, $userdisplay, $email, $name, $start, $end, $status, $active, $payment, $uid, $group_id) = $dbh->fetch_array($sth)) {

	$status = ($status) ? $status : "NONE";

	if ($active) {
		$active = "<span style=\"color:#0b8043;font-weight:900;\">" . $ubbt_lang['TEXT_YES'] . "</span>";
	} else {
		$active = $ubbt_lang['TEXT_NO'];
	}

	if (!$end) {
		$end = $ubbt_lang['NO_END'];
	} else {
		$end = $html->convert_time($end, $user['USER_TIME_OFFSET'], "Y-m-d H:i:s", true, false);
	}

	if (!$start) {
		$start = $ubbt_lang['NOT_STARTED'];
	} else {
		$start = $html->convert_time($start, $user['USER_TIME_OFFSET'], "Y-m-d H:i:s", true, false);
	}

	$subs[] = array(
		"invoice_no" => $invoice_no,
		"display_name" => $userdisplay,
		"email" => $email,
		"name" => $name,
		"start" => $start,
		"end" => $end,
		"status" => $status,
		"active" => $active,
		"payment" => $payment,
		"uid" => $uid,
		"group_id" => $group_id,
	);
}

$tabs = array(
	"{$ubbt_lang['VIEW_SUBS']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['VIEW_SUBS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['VIEW_SUBS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/view_subscriptions.tmpl");

$admin->sendFooter();

?>
