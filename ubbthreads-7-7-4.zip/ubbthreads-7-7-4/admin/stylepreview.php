<?php
//	Script Version 7.7.0

require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/stylepreview.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$html = new html;

$admin->doAuth();

// Get the input
$style = get_input("style", "get");
$previewid = get_input("previewid", "get");
$wrapper = get_input("wrapper", "get");
$general = get_input("general", "get");
$avatar = get_input("avatar", "get");
$forum = get_input("forum", "get");
$graemlin = get_input("graemlin", "get");
$markup = get_input("markup", "get");
$icon = get_input("icon", "get");

if (!$previewid) $previewid = 1;

for ($i = 1; $i <= 20; $i++) {
	if ($i == $previewid) {
		${"display$i"} = "";
	} else {
		${"display$i"} = "display:none;";
	}
}

if (!$style) {
	$style = $config['DEFAULT_STYLE'];
}

include("{$config['FULL_PATH']}/styles/$style.php");

if ($general) {
	$style_array['general'] = "general/$general";
}
if ($avatar) {
	$style_array['avatars'] = "avatars/$avatar";
}
if ($forum) {
	$style_array['forumimages'] = "forumimages/$forum";
}
if ($graemlin) {
	$style_array['graemlins'] = "graemlins/$graemlin";
}
if ($icon) {
	$style_array['icons'] = "icons/$icon";
}
if ($markup) {
	$style_array['markup_panel'] = "markup_panel/$markup";
}

$css_file = file("{$config['FULL_PATH']}/styles/{$style_array['css']}");
$new_file = "";
foreach ($css_file as $line => $data) {
	$data = trim($data);
	if (preg_match("/^\/\*/", $data)) continue;
	$new_file .= $data;
}
$css_file = "<style>$new_file</style>";

// Wrapper Sets
$wrapper_sets = "";
include("{$config['FULL_PATH']}/styles/wrappers.php");
foreach ($wrappers as $k => $data) {
	$selected = "";
	if ($style_array['wrappers'] == $k) {
		$selected = "selected=\"selected\"";
	}
	$wrapper_sets .= "<option value=\"$k\">{$data['name']}</option>";
}

if ($wrapper) $style_array['wrappers'] = $wrapper;

$tbopen = $wrappers[$style_array['wrappers']]['open'];
$tbclose = $wrappers[$style_array['wrappers']]['close'];

$time = $html->convert_time(time(), "", "", 1);

// Include the template
include("../templates/default/admin/stylepreview.tmpl");

?>