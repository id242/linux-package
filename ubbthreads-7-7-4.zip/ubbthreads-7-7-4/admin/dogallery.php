<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// ---------------------------------
// Make sure sizes don't have commas
$config['INLINE_IMAGE'] = str_replace(",", "", $config['INLINE_IMAGE']);

// Convert from readable File Size
// 1 MB = 1,048,576 Bytes
$_POST['INLINE_IMAGE'] = ($_POST['INLINE_IMAGE'] * 1048576);

// What config vars are we updating?
$newconfig = array(
	"ATTACHMENT_TYPES",
	"GRAPHICS_LIBRARY", "IMAGE_DISPLAY", "INLINE_IMAGE",
	"MAX_THUMB_W_H", "MAX_MEDIUM_W_H", "MAX_FULL_W_H", "IMAGE_DL_BUTTON",
	"THUMB_QUALITY", "MEDIUM_QUALITY", "FULL_QUALITY");

include("./doeditconfig.php");

admin_log("ATTACHMENTS_SETTINGS", "$log_diffs");

$admin->redirect($ubbt_lang['SET_UPDATED'], "{$config['BASE_URL']}/admin/gallery.php?returntab=$returntab", $ubbt_lang['GALLERY_F_LOC']);

?>