<?php
//	Script Version 7.7.0

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the list of cp permissions
$perms = array();
$query = "
	select PERMISSION_NAME
	from {$config['TABLE_PREFIX']}PERMISSION_LIST
	where PERMISSION_TYPE='cp'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($name) = $dbh->fetch_array($sth)) {
	$perms[] = $name;
}

// Get list of groups
$query = "
	select GROUP_ID
	from {$config['TABLE_PREFIX']}GROUPS
	order by GROUP_ID
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($gid) = $dbh->fetch_array($sth)) {
	$groups[] = $gid;
}

foreach ($groups as $k => $gid) {
	$keys = "GROUP_ID,";
	$values = "$gid,";
	foreach ($perms as $k => $perm) {
		$keys .= "$perm,";
	}
	foreach ($perms as $k => $perm) {
		$value = $_POST[$perm][$gid];
		if (!$value) $value = "0";
		$value = addslashes($value);
		$values .= "'$value',";
	}
	$keys = preg_replace("/,$/", "", $keys);
	$values = preg_replace("/,$/", "", $values);

	$query = "
		replace into {$config['TABLE_PREFIX']}CP_PERMISSIONS
		($keys)
		values
		($values)
	";
	$dbh->do_query($query, __LINE__, __FILE__);

}
admin_log("CP_PERMISSIONS", "");

$userob->clear_cached_perms();

$admin->redirect($ubbt_lang['CP_PERM_UPDATED'], "{$config['BASE_URL']}/admin/cpperms.php?returntab=0", $ubbt_lang['CP_PERM_F_LOC']);

?>