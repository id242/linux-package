<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/wrappers.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// Get the input
$returntab = 1;

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['PRIMARY_S']}" => "{$config['BASE_URL']}/admin/styles.php",
	"{$ubbt_lang['WRAPPERS']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['STYLES']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['WRAPPERS']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);

// Get the current wrappers
include("{$config['FULL_PATH']}/styles/wrappers.php");

// Include the template
include("../templates/default/admin/wrappers.tmpl");

$bottomtabs = array(
	"{$ubbt_lang['ADD_WRAPPER']}" => "{$config['BASE_URL']}/admin/editwrapper.php?new=1&wrapper=$newid"
);
$admin->createBottomTabs($bottomtabs, 1);

$admin->sendFooter();

?>