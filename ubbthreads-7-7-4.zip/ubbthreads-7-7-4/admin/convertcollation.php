<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/convertcollation.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();

// We need to close the forum for this process
function set_board_is_open($on = true) {
	require("../includes/config.inc.php");
	$on = $on ? '0' : '1';
	if ($config['BOARD_IS_CLOSED'] != $on) {
		$config['BOARD_IS_CLOSED'] = $on;
		lock_and_write("{$config['FULL_PATH']}/includes/config.inc.php", '<?php $config = ' . var_export($config, true) . '; ?>');
	}
}
set_board_is_open(false);

$tabs = array(
	"Database Collation Conversion" => "",
);

// Executing the query or just displaying it?
$execute_sql = true;

// This process may require more time, so we will extend it here
// 600 seconds = 10 minutes
ini_set('max_execution_time', 600);
set_time_limit(600);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['CONT_REBUILD']);
$admin->setReturnTab(0);
$admin->setPageTitle($ubbt_lang['COLLATION']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

echo <<<UBBTPRINT
<table class="tab-outsider fw">
<div class="msbox msimportant alvt">{$ubbt_lang['NOTICE']}</div><br>
<div class="msbox msinfo alvt">{$ubbt_lang['CLOSING_BOARD']}</div>
<tr><td class="stdautorow alvt fw" style="font-size:11px;">
UBBTPRINT;

$collationPK = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci';
$collation = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci';

$result = $dbh->do_query("SET foreign_key_checks = 0");

if ($execute_sql) {
	$query = "ALTER DATABASE " . $config['DATABASE_NAME'] . " $collation";
	$dbh->do_query($query, __LINE__, __FILE__);
}

// Get the list of tables
$search_prefix = $config['TABLE_PREFIX'] . "%";
$query = "SHOW TABLES LIKE ?";
$result = $dbh->do_placeholder_query($query, array($search_prefix), __LINE__, __FILE__);

$count = 0;
while ($row = $result->fetch_assoc()) {
	$table = $row['Tables_in_' . $config['DATABASE_NAME'] . " (" . $search_prefix . ")"];
	if ($execute_sql) $dbh->do_query("ALTER TABLE $table DEFAULT $collation");
	$result1 = $dbh->do_query("SHOW FULL COLUMNS FROM $table");
	$alter = '';
	$detail = "";
	while ($row1 = $result1->fetch_assoc()) {
		if (preg_match('~char|text|enum|set~', $row1["Type"])) {
			// support a different collation for primary keys
			if ($row1["Key"] == "PRI" || $row1["Key"] == "MUL") {
				$newCollation = $collationPK;
			} else {
				$newCollation = $collation;
			}
			$detail = "(" . $row1["Key"] . ": " . $row1["Field"] . " " . $row1["Type"] . ")";
			// check if we actually need to change the collation
			$alter .= (strlen($alter) ? ", \n" : " ") . "MODIFY `$row1[Field]` $row1[Type] $newCollation" . ($row1["Null"] ? "" : " NOT NULL") . ($row1["Default"] && $row1["Default"] != "NULL" ? " DEFAULT '$row1[Default]'" : "");
		}
	}
	if (strlen($alter)) {
		$sql = "ALTER TABLE $table" . $alter . ";";
		echo "\n<div class=\"colored-row padding\">\n$sql\n";
		if ($execute_sql) {
			if (!$dbh->do_query($sql)) {
				echo "\n<div style=\"color:#f00;\">\nError: $dbh->error $detail\n</div><br>\n\n";
				$execute_sql = false;
				break;
			}
		}
		echo "<i class=\"fas fa-check\" style=\"color:#0b8043\"></i></div>\n";
	}
	$count++;
}
echo "</td></tr></table>";

$results = ($execute_sql ? "$count " . $ubbt_lang['TABLES_CONV'] : $ubbt_lang['TABLES_NOT_CONV']);

// Open the forum again
set_board_is_open(true);

// Include the template
include("../templates/default/admin/convertcollation.tmpl");

admin_log("DB_COLLATION", $results);

$admin->sendFooter();

?>