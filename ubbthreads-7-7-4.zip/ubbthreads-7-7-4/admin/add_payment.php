<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/add_payment.php");

// Get the input
$returntab = get_input("returntab", "both");

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();
$html = new html;

$id = get_input("id", "post", "int");
$custom = get_input("custom", "post", "");
$check_no = get_input("check_no", "post", "");
$check_amount = get_input("check_amount", "post", "");

// Grab the current info on this subscription
$query = "
	SELECT
		t1.USER_ID, t1.SUBSCRIPTION_STATUS, t1.SUBSCRIPTION_START_DATE, t1.SUBSCRIPTION_END_DATE, t1.GROUP_ID, t1.SUBSCRIPTION_METHOD, t2.SUBSCRIPTION_NAME, t2.SUBSCRIPTION_REGULAR_DURATION, SUBSCRIPTION_REGULAR_INTERVAL
	FROM
		{$config['TABLE_PREFIX']}SUBSCRIPTION_DATA AS t1,
		{$config['TABLE_PREFIX']}SUBSCRIPTIONS AS t2
	WHERE
		CUSTOM_ID = ?
	AND t1.GROUP_ID = t2.GROUP_ID
";
$sth = $dbh->do_placeholder_query($query, array($custom), __LINE__, __FILE__);
list($uid, $status, $start, $end, $group, $method, $name, $dur, $int) = $dbh->fetch_array($sth);

$right_now = $html->get_date();

// Insert the payment into the database
$query = "
	INSERT INTO
		{$config['TABLE_PREFIX']}CHECK_DATA
		(CUSTOM_ID, CHECK_NUMBER, PAYMENT_AMOUNT, PAYMENT_DATE)
	VALUES
		(?, ?, ?, ?)
";
$dbh->do_placeholder_query($query, array($custom, $check_no, $check_amount, $right_now), __LINE__, __FILE__);

if ($status == "PENDING") {
	// New Subscription - Donation
	if ($method == "donate") {
		$new_status = "DONATION";
		$new_start = $right_now;
		$new_end = 0;
		$msg = 'NEW_DONATION';
		$subject = $ubbt_lang['DONATION_SUBJECT'];
	} else {
		$new_start = $right_now;
		$new_status = "PAYMENT RECEIVED";
		$new_end = $right_now;
		$msg = 'NEW_SUB';
		$subject = $ubbt_lang['PAYMENT_SUBJECT'];
	}
} else {
	// Ongoing Subscription - Donation
	// New Subscription - Donation
	if ($method == "donate") {
		$new_status = "DONATION";
		$new_start = $start;
		$new_end = 0;
		$msg = 'ONGOING_DONATION';
		$subject = $ubbt_lang['DONATION_SUBJECT'];
	} else {
		$new_status = "PAYMENT RECEIVED";
		$new_start = $start;
		$new_end = $end;
		$msg = 'ONGOING_SUB';
		$subject = $ubbt_lang['PAYMENT_SUBJECT'];
	}
}

// Figure out the new end date
if ($int == "D") {
	$new_end = $new_end + (86400 * $dur);
} elseif ($int == "W") {
	$new_end = $new_end + (86400 * ($dur * 7));
} elseif ($int == "M") {
	$new_end = $new_end + (86400 * ($dur * 30));
} elseif ($int == "Y") {
	$new_end = $new_end + (86400 * ($dur * 365));
}

// Update the SUBSCRIPTION_DATA table
$query = "
	UPDATE
		{$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
	SET
		SUBSCRIPTION_START_DATE = ? ,
		SUBSCRIPTION_END_DATE = ? ,
		SUBSCRIPTION_STATUS = ? ,
		SUBSCRIPTION_IS_ACTIVE = 1
	WHERE
		CUSTOM_ID = ?
";
$dbh->do_placeholder_query($query, array($new_start, $new_end, $new_status, $custom), __LINE__, __FILE__);

// Add this user to the group
$query = "
	REPLACE INTO
		{$config['TABLE_PREFIX']}USER_GROUPS
		(USER_ID, GROUP_ID)
	VALUES
		(?, ?)
";
$dbh->do_placeholder_query($query, array($uid, $group), __LINE__, __FILE__);

// Send user a confirmation PM
$message = $html->substitute($ubbt_lang[$msg], array('GROUP' => $name));

$html->send_message($config['MAIN_ADMIN_ID'], $uid, $subject, $message);

// Log it
admin_log("ADD_PAYMENT", "$uid: $check_amount -> $name ($group)");

// Redirect
$admin->redirect($ubbt_lang['M_PAYMENT_ADDED'], "{$config['BASE_URL']}/admin/sub_history.php?id=$id", $ubbt_lang['M_PAYMENT_F_LOC']);

?>