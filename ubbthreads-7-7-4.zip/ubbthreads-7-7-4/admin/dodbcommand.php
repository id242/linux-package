<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/dodbcommand.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

$returntab = 0;

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();

// Get the input
$command = get_input("command", "post");
$commandno = get_input("commandno", "post");
$desc = get_input("description", "post");
$save = get_input("save", "post");
$execute = get_input("execute", "post");
$entry = get_input("entry", "get");
$action = get_input("action", "get");

if ($action == "optimize") {
	$table = get_input("table", "get");
	$query = "
		OPTIMIZE TABLE {$table}
	";
	$dbh->do_query($query, __LINE__, __FILE__);
	$admin->redirect($ubbt_lang['OPTIMIZED'], "{$config['BASE_URL']}/admin/dbinfo.php?returntab=0", $ubbt_lang['F_LOC']);
	exit;
}

if ($action == "delete") {
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}SAVED_QUERIES
		WHERE QUERY_ID = ?
	";
	$dbh->do_placeholder_query($query, array($entry), __LINE__, __FILE__);
	$admin->redirect($ubbt_lang['DELETED'], "{$config['BASE_URL']}/admin/database.php?returntab=1", $ubbt_lang['F_LOC']);
	exit;
}

// -------------------------
// Are we saving this query?
if ($save) {
	if ($commandno) {
		$query = "
			UPDATE
				{$config['TABLE_PREFIX']}SAVED_QUERIES
			SET
				QUERY_DESCRIPTION = ?,
				QUERY_SYNTAX = ?
			WHERE
				QUERY_ID = ?
		";
		$dbh->do_placeholder_query($query, array(ubbchars($desc), $command, $commandno), __LINE__, __FILE__);
	} else {
		$command = str_replace("\n", "\\n", $command);
		$query = "
			INSERT INTO
				{$config['TABLE_PREFIX']}SAVED_QUERIES
				(QUERY_SYNTAX, QUERY_DESCRIPTION)
			VALUES
				(?, ?)
		";
		$dbh->do_placeholder_query($query, array($command, ubbchars($desc)), __LINE__, __FILE__);
	}
	$admin->redirect($ubbt_lang['SAVED'], "{$config['BASE_URL']}/admin/database.php?returntab=1", $ubbt_lang['F_LOC']);
	exit;
}

if (!$command) {
	$admin->error($ubbt_lang['NO_COMMAND']);
}

// -------------------------------------------------------------------------
// If it was some type of a select command, we want to display things nicely

$sth = $dbh->do_query($command, __LINE__, __FILE__);
$showquery = $command;
$showquery = str_replace("<", "&lt;", $showquery);
//$showquery = str_replace("\\n", "", nl2br($showquery));

$affected = $dbh->affected_rows();
if ($affected > 0) {
	$ms = "msgood";
} else {
	$ms = "msinfo";
}

$results .= "<tr><td class=\"colored-row stdautorow\"></td></tr>";
$results .= "<tr><td class=\"colored-row smaller alvt\"><pre class=\"debug\">\n" . trim($showquery) . "\n</pre></td></tr>";

$numFields = $dbh->num_fields($sth);
$results .= "<table class='fw'>";
$results .= "<tr><td class=\"paddingtop paddingbottom stdautorow acvt\" colspan='$numFields'><a href='database.php?returntab=1'><button class='form-button'>{$ubbt_lang['GO_BACK']}</button></a></td></tr>";
$results .= "<tr>";
for ($i = 0; $i < $numFields; $i++) {
	$results .= "<td class=\"autorow-header-1 autoleft autoright autotop autobottom bold\">" . $dbh->field_name($sth, $i) . "</td>";
}
$results .= "</tr>";
while ($vals = $dbh->fetch_array($sth)) {
	$results .= "<tr>";
	$valsize = sizeof($vals);
	for ($i = 0; $i < $numFields; $i++) {
		$results .= "<td valign=\"top\" class=\"colored-row stdautorow autoleft autoright autotop autobottom\">" . ubbchars($vals[$i]) . "</td>";
	}
	$results .= "</tr>";
}
$results .= "</table>";


$tabs = array(
	"{$ubbt_lang['INFO']}" => "dbinfo.php?returntab=0",
	"{$ubbt_lang['COMMAND']}" => "database.php?returntab=1",
	"{$ubbt_lang['BACKUP']}" => "dbbackup.php?returntab=2"
);

$admin->setCurrentMenu($ubbt_lang['DATABASE']);
$admin->setReturnTab(1);
$admin->setParentTitle($ubbt_lang['DATABASE'], "database.php?returntab=1");
$admin->setPageTitle($ubbt_lang['SQL_HEAD']);
$admin->sendHeader();
$admin->createTopTabs($tabs, 1);

// Include the template
include("../templates/default/admin/dodbcommand.tmpl");

admin_log("DB_COMMAND", $command);

$admin->sendFooter();

?>