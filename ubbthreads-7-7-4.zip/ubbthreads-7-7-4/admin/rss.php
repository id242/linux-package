<?php
//	Script Version 7.7.0

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/rss.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("");

$admin = new Admin;
$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['SINGLE_RSS']}" => "",
	"{$ubbt_lang['MULTI_RSS']}" => "",
	"{$ubbt_lang['MY_RSS']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['RSS_FEEDS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['RSS_FEEDS']);
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE']);

// Single forum query

$query = "
	select t1.FORUM_TITLE,t1.FORUM_ID,t2.FEED_ID,t2.FEED_NAME,t2.FEED_IS_ACTIVE,FEED_CACHE_TIME
	from {$config['TABLE_PREFIX']}FORUMS as t1,
	{$config['TABLE_PREFIX']}RSS_FEEDS as t2,
	{$config['TABLE_PREFIX']}CATEGORIES as t3
	where t1.FORUM_ID = t2.FEED_FORUM
	and t1.CATEGORY_ID = t3.CATEGORY_ID
	ORDER BY t3.CATEGORY_SORT_ORDER, t1.FORUM_SORT_ORDER
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$singles = array();
while (list($title, $forum_id, $id, $name, $active, $cache) = $dbh->fetch_array($sth)) {
	if ($active) {
		$active = "checked=\"checked\"";
	} else {
		$active = "";
	}
	if (!$cache) $cache = 300;
	$cache = $cache / 60;

	$name = ubbchars($name);
	$singles[] = array(
		"NAME" => $name,
		"ID" => $id,
		"SOURCE" => $title,
		"ACTIVE" => $active,
		"CACHE" => $cache,
		"FORUM_ID" => $forum_id,
	);
}

// Multi forums query
$query = "
	select FEED_ID,FEED_NAME,FEED_FORUM_ARRAY,FEED_IS_ACTIVE,FEED_CACHE_TIME
	from {$config['TABLE_PREFIX']}RSS_FEEDS
	where FEED_IS_MULTI = '1'
	ORDER BY FEED_NAME
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$multies = array();
while (list($id, $name, $forums, $active, $cache) = $dbh->fetch_array($sth)) {
	if ($active) {
		$active = "checked=\"checked\"";
	} else {
		$active = "";
	}
	if ($forums) {
		$forums = unserialize($forums);
	}
	$source = sizeof($forums);

	if (!$cache) $cache = 300;
	$cache = $cache / 60;
	$multies[] = array(
		"NAME" => $name,
		"ID" => $id,
		"SOURCE" => $source,
		"ACTIVE" => $active,
		"CACHE" => $cache,
	);
}

// Checkbox for the My Feeds enable
$myfeeds = ($config['MY_FEEDS']) ? "checked=\"checked\"" : "";

// Include the template
include("../templates/default/admin/rss.tmpl");

$bottomtabs = array(
	"{$ubbt_lang['NEW_MULTI']}" => "{$config['BASE_URL']}/admin/edit_multi_rss.php",
);
$admin->createBottomTabs($bottomtabs, 1);
$admin->sendFooter();

?>