<?php
//	Script Version 7.7.3

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab", "post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// What config vars are we updating?
$newconfig = array("ALLOW_PAYPAL", "PAYPAL_EMAIL", "ALLOW_MAIL", "PAYMENT_ADDRESS", "CURRENCY");

// Update the config file
include("doeditconfig.php");

admin_log("PAYMENT_SETTINGS", $log_diffs);

$admin->redirect($ubbt_lang['PAYMENT_UPDATED'], "{$config['BASE_URL']}/admin/payment_settings.php?returntab=$returntab", $ubbt_lang['PAYMENT_F_LOC']);

?>