<?php
//	Script Version 7.7.4

// Require the library
require("../libs/admin.inc.php");
include("../languages/{$config['LANGUAGE']}/admin/generic.php");
include("../languages/{$config['LANGUAGE']}/admin/showuser.php");
include("../languages/{$config['LANGUAGE']}/admin/stop_forum_spam.php");
include("../languages/{$config['LANGUAGE']}/social.php");

// Expire any old bans
trigger_ban_expiration();

// Get the user info
$userob = new user;
$user = $userob->authenticate("USER_TIME_OFFSET,USER_TIME_FORMAT");
$html = new html;

$admin = new Admin;
$admin->doAuth(array("EDIT_USERS"));

// Get the input
$uid = get_input("uid", "both");
$returntab = get_input("returntab", "both");

if ($uid == "1") {
	$admin->error($ubbt_lang['NO_EDIT_ANON']);
}

if (($uid == $config['MAIN_ADMIN_ID']) && ($user['USER_ID'] != $config['MAIN_ADMIN_ID'])) {
	$admin->error($ubbt_lang['NO_EDIT_MAIN']);
}

include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree, $style_cache, $lang_cache) = build_forum_cache();
}


// If this is a moderator, let's see what groups they belong to
$my_group_list = array();
if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
	$query = "
		SELECT GROUP_ID
		FROM {$config['TABLE_PREFIX']}USER_GROUPS
		WHERE USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	while (list($gid) = $dbh->fetch_array($sth)) {
		$my_group_list[] = $gid;
	}
}
// Grab all of the current information on this user
$query = "
	SELECT
		t1.USER_LOGIN_NAME, t1.USER_DISPLAY_NAME, t2.USER_REAL_EMAIL, t2.USER_DISPLAY_EMAIL, t2.USER_DEFAULT_SIGNATURE, t2.USER_HOMEPAGE,
		t2.USER_OCCUPATION, t2.USER_HOBBIES, t2.USER_LOCATION,
		t2.USER_SOCIAL1, t2.USER_SOCIAL2, t2.USER_SOCIAL3, t2.USER_SOCIAL4, t2.USER_SOCIAL5, t2.USER_SOCIAL6, t2.USER_SOCIAL7, t2.USER_SOCIAL8, t2.USER_SOCIAL9,
		t2.USER_EXTRA_FIELD_1, t2.USER_EXTRA_FIELD_2, t2.USER_EXTRA_FIELD_3, t2.USER_EXTRA_FIELD_4, t2.USER_EXTRA_FIELD_5,
		t2.USER_AVATAR, t2.USER_VISIBLE_ONLINE_STATUS,
		t2.USER_ACCEPT_PM, t2.USER_BIRTHDAY, t2.USER_PUBLIC_BIRTHDAY, t2.USER_AVATAR_WIDTH, t2.USER_AVATAR_HEIGHT,
		t2.USER_STYLE, t2.USER_TOPIC_VIEW_TYPE, t2.USER_TOPICS_PER_PAGE, t2.USER_SHOW_AVATARS, t2.USER_POSTS_PER_TOPIC, t2.USER_TIME_OFFSET, t2.USER_TOTAL_POSTS, t2.USER_SHOW_SIGNATURES,
		t2.USER_TIME_FORMAT, t2.USER_NOTIFY_ON_PM, t2.USER_EMAIL_WATCHLISTS, t1.USER_REGISTERED_ON, t1.USER_REGISTRATION_IP,
		t3.USER_LAST_POST_TIME, t3.USER_LAST_VISIT_TIME, t3.USER_LAST_IP, t2.USER_RATING, t2.USER_CUSTOM_TITLE, t2.USER_NAME_COLOR, t1.USER_MEMBERSHIP_LEVEL,
		t1.USER_IS_BANNED, t1.USER_IS_UNDERAGE, t2.USER_FLOOD_CONTROL_OVERRIDE, t1.USER_REGISTRATION_EMAIL, t2.USER_ACCEPT_ADMIN_EMAILS, t2.USER_GROUP_IMAGES
	FROM
		{$config['TABLE_PREFIX']}USERS AS t1,
		{$config['TABLE_PREFIX']}USER_PROFILE AS t2,
		{$config['TABLE_PREFIX']}USER_DATA AS t3
	WHERE
		t1.USER_ID = ?
	AND t1.USER_ID = t2.USER_ID
	AND t1.USER_ID = t3.USER_ID
";
$sth = $dbh->do_placeholder_query($query, array($uid), __LINE__, __FILE__);
list($lname, $dname, $email, $femail, $sig, $homepage,
	$occ, $hobbies, $loc,
	$social1, $social2, $social3, $social4, $social5, $social6, $social7, $social8, $social9,
	$CUSTOM_FIELD_1, $CUSTOM_FIELD_2, $CUSTOM_FIELD_3, $CUSTOM_FIELD_4, $CUSTOM_FIELD_5,
	$picture, $visible,
	$acceptpriv, $birthday, $showbday, $picwidth, $picheight,
	$style, $display, $postsper, $SHOW_AVATARS, $flatposts, $TimeOffset, $totalposts, $showsigs,
	$timeformat, $notify, $watch, $regdate, $regip,
	$lastpost, $lastvisit, $lastip, $rating, $usertitle, $namecolor, $status,
	$banned, $coppa, $floodcontrol, $regemail, $acceptadmin, $s_my_images) = $dbh->fetch_array($sth);

$myimages = unserialize($s_my_images);

$usertitle = ubbchars($usertitle);

$bandisplay = "display:none";
$expires = "";
$reason = "";
$ban_text = $ubbt_lang['EXPIRES'];
if ($banned) {
	$bandisplay = "";
	$query = "
		SELECT BAN_EXPIRATION, BAN_REASON
		FROM {$config['TABLE_PREFIX']}BANNED_USERS
		WHERE USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($uid), __LINE__, __FILE__);
	list ($expires, $reason) = $dbh->fetch_array($sth);
	$ban_text = $ubbt_lang['EXPIRES_ON'];
	if ($expires) {
		$expires_on = $html->convert_time($expires, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
	}
	if ($expires == 0) {
		$expires_on = $ubbt_lang['NEVER_EXPIRE'];
	}
	$banned_notice = <<<EOF
<tr><td colspan="2">
<div class="msbox msinfo alvt">
<span class="bold" style="text-transform:uppercase;">{$ubbt_lang['HAS_ACCESS']}.</span> $ban_text: $expires_on</span>
</div>
</td></tr>
EOF;
}


// Moderators cannot edit admins or other moderators
if (($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") && ($status == "Moderator" || $status == "Administrator")) {
	$admin->error($ubbt_lang['NO_ADMOD_EDIT']);
}

// Default flood control
if ((!$floodcontrol && $floodcontrol != "0") || ($floodcontrol == "-1")) {
	$floodcontrol = '';
}

// Grab user's groups
$query = "
	SELECT GROUP_ID
	FROM {$config['TABLE_PREFIX']}USER_GROUPS
	WHERE USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query, array($uid), __LINE__, __FILE__);
$user_groups = array();
while (list($gid) = $dbh->fetch_array($sth)) {
	$user_groups[] = $gid;
}

// Grab any notes about this user
$query = "
	SELECT NOTE_TEXT
	FROM {$config['TABLE_PREFIX']}USER_NOTES
	WHERE USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query, array($uid), __LINE__, __FILE__);
list($notes) = $dbh->fetch_array($sth);

// Grab name of user's preferred forum style
$query = "
	SELECT STYLE_NAME
	FROM {$config['TABLE_PREFIX']}STYLES
	WHERE STYLE_ID = ?
	AND STYLE_IS_ACTIVE = 1
";
$sth = $dbh->do_placeholder_query($query, array($style), __LINE__, __FILE__);
list($stylename) = $dbh->fetch_array($sth);
$stylename = str_replace("_", " ", $stylename);
if (($style == "0") || (!$stylename)) {
	$stylename = $ubbt_lang['DEFAULT'];
}

// Setup the default values
if (strlen($regdate) < 8) {
	$regdate = $ubbt_lang['UNAVAIL'];
} else {
	$regdate = $html->convert_time($regdate, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
}

$totalposts = number_format($totalposts);
$lastposts = make_ubb_url("ubb=userposts&id=$uid", "", false);
if ($lastpost) {
	$lastpost = $html->convert_time($lastpost, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']) . "<br>";
}

if ($lastvisit) {
	$lastvisit = $html->convert_time($lastvisit, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
}

// -------------------------------------------------------------------------
// Lets do some IP address processing
// IP Geolocation API usage http://ip-api.com/docs/api:json

// Reverse Geo-IP lookup for Registration IP
$regiploc = "";
if ($config['IPGEO_LOOKUP'] && !empty($regip) && ($regip != "127.0.0.1") && ($regip != "::1")) {
	$queryregip = json_decode(utf8_encode(file_get_contents("http://ip-api.com/json/" . $regip . "?fields=status,continent,country,countryCode,region,city,isp")), true);
	if ($queryregip && $queryregip['status'] == "success") {
		if ($queryregip['mobile']) {
			$queryregipm = "(" . $ubbt_lang['GEOIP_MOBILE'] . ")";
		} else {
			$queryregipm = "(" . $ubbt_lang['GEOIP_BROADBAND'] . ")";
		}
		$regiploc = $queryregip['isp'] . " " . $queryregipm . "<br>" . $queryregip['city'] . ", " . $queryregip['region'] . " " . $queryregip['countryCode'] . " (" . $ubbt_lang['GEOIP_ESTIMATED'] . ")<br><i>" . $queryregip['country'] . ", " . $queryregip['continent'] . "</i>";
	} else {
		$regiploc = $ubbt_lang['GEOIP_NOLOC'];
	}
}

// Reverse Geo-IP lookup for Last Visit IP
$lastiploc = "";
if ($config['IPGEO_LOOKUP'] && !empty($lastip) && ($lastip != "127.0.0.1") && ($lastip != "::1")) {
	$querylastip = json_decode(utf8_encode(file_get_contents("http://ip-api.com/json/" . $lastip . "?fields=status,continent,country,countryCode,region,city,isp")), true);
	if ($querylastip && $querylastip['status'] == "success") {
		if ($querylastip['mobile']) {
			$querylastipm = "(" . $ubbt_lang['GEOIP_MOBILE'] . ")";
		} else {
			$querylastipm = "(" . $ubbt_lang['GEOIP_BROADBAND'] . ")";
		}
		$lastiploc = $querylastip['isp'] . " " . $querylastipm . "<br>" . $querylastip['city'] . ", " . $querylastip['region'] . " " . $querylastip['countryCode'] . " (" . $ubbt_lang['GEOIP_ESTIMATED'] . ")<br><i>" . $querylastip['country'] . ", " . $querylastip['continent'] . "</i>";
	} else {
		$lastiploc = $ubbt_lang['GEOIP_NOLOC'];
	}
}

// IP Address lookups
if ($config['IPINFO_URL'] && !empty($regip) && ($regip != "127.0.0.1") && ($regip != "::1")) {
	$regip = "<a href=\"{$config['IPINFO_URL']}$regip\" target=\"_blank\">$regip</a>";
}
if ($config['IPINFO_URL'] && !empty($lastip) && ($lastip != "127.0.0.1") && ($lastip != "::1")) {
	$lastip = "<a href=\"{$config['IPINFO_URL']}$lastip\" target=\"_blank\">$lastip</a>";
}

$stars = $rating;
$rating = "";
for ($x = 1; $x <= $stars; $x++) {
	$rating .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/star.gif\" title=\"*\" alt=\"*\">";
}
if (!$rating) {
	$rating = $ubbt_lang['NOT_RATED'];
}

// Does user have access rights?
$ban_checked = "";
if ($banned) {
	$ban_checked = "checked=\"checked\"";
}

// Get all active groups
$query = "
	SELECT GROUP_NAME, GROUP_ID, GROUP_IMAGE
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED <> 1
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);

// Create a table to hold the group selections
$groupselection = "<table class=\"fw\">";
$row = 0;
$i = 0;
$gparraysize = 0;
while (list($Name, $Id, $Image) = $dbh->fetch_array($sth)) {
	if (($Id < 4) || ($Id == 5)) {
		continue;
	}
	if ($row == 0) {
		$groupselection .= "<tr>";
	}
	$row++;
	$groupselection .= "<td class=\"paddingbottom stdautorow alvt\" style=\"width:50%;\">";
	$checked = "";
	if (in_array($Id, $user_groups)) {
		$checked = "checked=\"checked\"";
	}
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator" && !in_array($Id, $my_group_list)) {
		$hidden = "";
		if ($checked == "checked=\"checked\"") {
			$hidden = "value=\"$Id\"";
		}
		$groupselection .= "<input type=\"hidden\" name=\"group[$i]\" $hidden>";
		$gparraysize++;
		$i++;
		continue;
	}
	$groupselection .= "<input type=\"checkbox\" id=\"group-$i\" name=\"group[$i]\" $checked value=\"$Id\"> ";
	$groupselection .= "<label for=\"group-$i\" class=\"radio\">$Name</label>";
	if ($Image) {
		$groupselection .= "<br><img src=\"{$config['BASE_URL']}/images/groups/$Image\" class=\"lmar p2\" style=\"vertical-align:text-top;\">";
	}
	if (in_array($Id, $myimages)) {
		$groupselection .= " <i class=\"fas fa-certificate fa-fw\" title=\"{$ubbt_lang['ACTIVE']}\"></i>";
	}
	$groupselection .= "</td>";
	$gparraysize++;
	$i++;
	if ($row == 2) {
		$groupselection .= "</tr>";
		$row = 0;
	}
}
$groupselection .= "<input type=\"hidden\" name=\"grouparr_size\" value=\"{$gparraysize}\">";
$dbh->finish_sth($sth);

if ($row > 0) {
	for ($i = 0; $i < (2 - $row); $i++) {
		$groupselection .= "<td class=\"alvt\" style=\"width:50%;\">&nbsp;</td>";
	}
	$groupselection .= "</tr>";
}
$groupselection .= "</table>";

$isuser_checked = "";
if ($status == "User") {
	$isuser_checked = "checked=\"checked\"";
}

// Is user a moderator
$moddisplay = "";
$ismod_checked = "";
if ($status == "Moderator") {
	$ismod_checked = "checked=\"checked\"";
}

// Is user a global moderator
$moddisplay = "";
$isgmod_checked = "";
if ($status == "GlobalModerator") {
	$isgmod_checked = "checked=\"checked\"";
}

if ($status == "User") {
	$moddisplay = "display:none;";
}

// Create forum list and figure out what they moderate
$query = "
	SELECT FORUM_ID
	FROM {$config['TABLE_PREFIX']}MODERATORS
	WHERE USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query, array($uid), __LINE__, __FILE__);
$modboards = array();
while (list($modboard) = $dbh->fetch_array($sth)) {
	$modboards[] = $modboard;
}

$modforumlist = "<select name=\"modforums[]\" multiple=\"multiple\" size=\"10\">";
$initialcat = "";
foreach ($tree['categories'] as $cat => $cat_title) {
	if (!isset($tree[$cat])) continue;
	$modforumlist .= "<optgroup label='{$tree['categories'][$cat]}'>";
	foreach ($tree[$cat] as $forum_id => $forum_title) {
		if (in_array($forum_id, $modboards)) {
			$modforumlist .= "<option value='$forum_id' selected='selected'>$forum_title</option>";
		} else {
			$modforumlist .= "<option value='$forum_id'>$forum_title</option>";
		}
	}
}

$modforumlist .= "</select>";
$adminforumlist = $modforumlist;
$adminforumlist = str_replace("modforums[]", "adminforums[]", $adminforumlist);

// Is the user an admin?
$isadmin_checked = "";
$admindisplay = "";
if ($status == "Administrator") {
	$isadmin_checked = "checked=\"checked\"";
} else {
	$admindisplay = "display:none;";
}

// Is coppa user
$under13_checked = "";
if ($coppa) {
	$under13_checked = "checked=\"checked\"";
}

// Setup the social profiles
$social1text = "";
$social2text = "";
$social3text = "";
$social4text = "";
$social5text = "";
$social6text = "";
$social7text = "";
$social8text = "";
$social9text = "";

// Handle Social fields 1 - 9
for ($i = 1; $i <= 9; $i++) {
	$key = 'SOCIAL' . $i;
	$keyx = 'social' . $i;
	$keyurl = 'SOCIAL' . $i . '_URL';
	$keyfa = 'SOCIAL' . $i . '_FA';
	$keyfai = 'social' . $i . 'fa';
	$keylink = 'social' . $i . 'link';
	$keytext = 'social' . $i . 'text';
	if ($ubbt_lang[$key]) {
		if ($keyx) {
			${$keylink} = <<<EOF
&nbsp;<a href="{$ubbt_lang[$keyurl]}$social1" target="_blank"><i class="fas fa-external-link-alt fa-fw" aria-hidden="true"></i></a>
EOF;
		}
		if ($ubbt_lang[$keyfa]) {
			${$keyfai} = <<<EOF
<i class="{$ubbt_lang[$keyfa]} fa-fw"></i>&nbsp;
EOF;
		}
		${$keytext} = <<<EOF
<tr><td class="autorow colored-row padding alvt">
<span class="autorow-title">
<label class="radio" for="social{$i}">
Social {$i}: {${$keyfai}}{$ubbt_lang[$key]}
</label>
</span>
</td><td class="autorow colored-row padding alvt nw">
<input type="text" name="social{$i}" value="${$keyx}" size="32" id="social{$i}">
${$keylink}
</td></tr>
EOF;
	}
}

// Do they have the extra settings enabled?
$extra1text = "";
$extra2text = "";
$extra3text = "";
$extra4text = "";
$extra5text = "";
if ($config['CUSTOM_FIELD_1']) {
	$extra1text = <<<EOF
<tr><td class="autorow colored-row padding alvt">
<span class="autorow-title">
<label class="radio" for="extra1">
Custom 1: {$config['CUSTOM_FIELD_1']}
</label>
</span>
</td><td class="autorow colored-row padding alvt">
<input type="text" name="CUSTOM_FIELD_1" value="$CUSTOM_FIELD_1" class="fw" id="extra1">
</td></tr>
EOF;
}
if ($config['CUSTOM_FIELD_2']) {
	$extra2text = <<<EOF
<tr><td class="autorow colored-row padding alvt">
<span class="autorow-title">
<label class="radio" for="extra2">
Custom 2: {$config['CUSTOM_FIELD_2']}
</label>
</span>
</td><td class="autorow colored-row padding alvt">
<input type="text" name="CUSTOM_FIELD_2" value="$CUSTOM_FIELD_2" class="fw" id="extra2">
</td></tr>
EOF;
}
if ($config['CUSTOM_FIELD_3']) {
	$extra3text = <<<EOF
<tr><td class="autorow colored-row padding alvt">
<span class="autorow-title">
<label class="radio" for="extra3">
Custom 3: {$config['CUSTOM_FIELD_3']}
</label>
</span>
</td><td class="autorow colored-row padding alvt">
<input type="text" name="CUSTOM_FIELD_3" value="$CUSTOM_FIELD_3" class="fw" id="extra3">
</td></tr>
EOF;
}
if ($config['CUSTOM_FIELD_4']) {
	$extra4text = <<<EOF
<tr><td class="autorow colored-row padding alvt">
<span class="autorow-title">
<label class="radio" for="extra4">
Custom 4: {$config['CUSTOM_FIELD_4']}
</label>
</span>
</td><td class="autorow colored-row padding alvt">
<input type="text" name="CUSTOM_FIELD_4" value="$CUSTOM_FIELD_4" class="fw" id="extra4">
</td></tr>
EOF;
}
if ($config['CUSTOM_FIELD_5']) {
	$extra5text = <<<EOF
<tr><td class="autorow colored-row padding alvt">
<span class="autorow-title">
<label class="radio" for="extra5">
Custom 5: {$config['CUSTOM_FIELD_5']}
</label>
</span>
</td><td class="autorow colored-row padding alvt">
<input type="text" name="CUSTOM_FIELD_5" value="$CUSTOM_FIELD_5" class="fw" id="extra5">
</td></tr>
EOF;
}

// Attempt to correct the homepage url
if ($homepage && !parse_url($homepage, PHP_URL_SCHEME)) {
	$homepage = "http://" . $homepage;
}

// Change quotes to &quot;
$sig = str_replace("\"", "&quot;", $sig);
$occ = str_replace("\"", "&quot;", $occ);
$hobbies = str_replace("\"", "&quot;", $hobbies);
$loc = str_replace("\"", "&quot;", $loc);
$femail = str_replace("\"", "&quot;", $femail);
$homepage = str_replace("\"", "&quot;", $homepage);
$social1 = str_replace("\"", "&quot;", $social1);
$social2 = str_replace("\"", "&quot;", $social2);
$social3 = str_replace("\"", "&quot;", $social3);
$social4 = str_replace("\"", "&quot;", $social4);
$social5 = str_replace("\"", "&quot;", $social5);
$social6 = str_replace("\"", "&quot;", $social6);
$social7 = str_replace("\"", "&quot;", $social7);
$social8 = str_replace("\"", "&quot;", $social8);
$social9 = str_replace("\"", "&quot;", $social9);
$CUSTOM_FIELD_1 = str_replace("\"", "&quot;", $CUSTOM_FIELD_1);
$CUSTOM_FIELD_2 = str_replace("\"", "&quot;", $CUSTOM_FIELD_2);
$CUSTOM_FIELD_3 = str_replace("\"", "&quot;", $CUSTOM_FIELD_3);
$CUSTOM_FIELD_4 = str_replace("\"", "&quot;", $CUSTOM_FIELD_4);
$CUSTOM_FIELD_5 = str_replace("\"", "&quot;", $CUSTOM_FIELD_5);

// Location Lookup
$locurl = "";
if ($config['LOCINFO_URL'] && $loc) {
	$locurl = " <a href=\"{$config['LOCINFO_URL']}" . urlencode($loc) . "\" target=\"_blank\"><i class=\"fas fa-globe fa-fw\" aria-hidden=\"true\"></i></a>";
}

// Do they have a specified avatar?
$currentav = "";
if ($config['AVATAR_MAX_WIDTH']) {
	$picmaxpx = $config['AVATAR_MAX_WIDTH'] . "px";
} else {
	$picmaxpx = "120px";
}
if (($picture && $picture != "http://") || ($picture && $picture != "https://")) {
	$currentav = "<img src=\"$picture\" class=\"avatar\" style=\"margin-bottom:10px;width:$picmaxpx;\" alt=\"{$ubbt_lang['AVATAR']}\">";
	if (strpos($picture, "{$config['FULL_URL']}/images/avatars/") === 0) {
		$avatarstock_checked = "checked";
		$avatar_source = "{$ubbt_lang['AVATAR_STOCK']}";
	} else {
		$avatarurl_checked = "checked";
		$avatar_source = "{$ubbt_lang['AVATAR_UPLOADED']}";
		if (strpos($picture, "{$config['UPLOADED_AVATAR_URL']}") === false) {
			$avatar_source = "{$ubbt_lang['AVATAR_LINKED']}";
		}
	}
} else {
	$avatar_none_checked = "checked";
	$avatar_current = "invis";
}

// Birthday defaults
$bdaytext = $ubbt_lang['SHOW_BDAY'];
if (isset($config['BIRTHDAYS_IN_CALENDAR']) && $config['BIRTHDAYS_IN_CALENDAR']) {
	$bdaytext .= " {$ubbt_lang['SHOW_BDAY_1']}";
}
$showbday_checked = "";
if ($showbday) {
	$showbday_checked = "checked=\"checked\"";
}

if (($birthday = strtotime($birthday)) === false) {
	$birthday_date = "";
} else {
	$birthday_date = date('F j\, Y', $birthday);
}

$time_formats = "";
if (!$timeformat) {
	$timeformat = $config['TIME_FORMAT'];
}
foreach ($config['TIME_FORMATS'] as $k => $v) {
	$selected = "";
	if ($timeformat == $v) {
		$selected = "selected=\"selected\"";
	}
	$time_formats .= "<option value=\"$k\" $selected>" . strip_tags($html->convert_time(time(), 0, $v, 1)) . "</option>";
}

$style_checked = "";
if ($style == "0") {
	$style_checked = "checked=\"checked\"";
}

$flat = "";
$threaded = "";
if ($display == "flat") {
	$flat = "selected=\"selected\"";
}
if ($display == "threaded") {
	$threaded = "selected=\"selected\"";
}

if (!$TimeOffset || !in_array($TimeOffset, DateTimeZone::listIdentifiers())) {
	$TimeOffset = "UTC";
}
$tzlist = $html->generate_timezone_list();

// Default flat posts per page
if (!$flatposts) {
	$flatposts = $config['POSTS_PER_PAGE'];
}

// Default picture view
$SHOW_AVATARS_checked = "";
if (!$SHOW_AVATARS) {
	$SHOW_AVATARS = $config['SHOW_AVATARS'];
}
if ($SHOW_AVATARS == "1") {
	$SHOW_AVATARS_checked = "checked=\"checked\"";
}

// Default sig view
$signever == "";
$sigtonly == "";
$sigptonly == "";
$sigalways == "";
if ($showsigs == "no") {
	$signever = "selected=\"selected\"";
}
if ($showsigs == "to") {
	$sigtonly = "selected=\"selected\"";
}
if ($showsigs == "po") {
	$sigptonly = "selected=\"selected\"";
}
if ($showsigs == "yes") {
	$sigalways = "selected=\"selected\"";
}

// Who's Online defaults
$visible_checked = "";
if ($visible != "no") {
	$visible_checked = "checked=\"checked\"";
}

// Default accept Private Messages
$acceptpriv_checked = "";
if ($acceptpriv != "no") {
	$acceptpriv_checked = "checked=\"checked\"";
}

// Default email Private Message notifications
$notify_checked = "";
if ($notify == "yes") {
	$notify_checked = "checked=\"checked\"";
}

// Default email Watch List notifications
$watch_checked = "";
if ($watch == 1) {
	$watch_checked = "checked=\"checked\"";
}

// Accept admin emails
$acceptadmin_checked = "";
if ($acceptadmin != "Off") {
	$acceptadmin_checked = "checked=\"checked\"";
}

$tabs = array(
	"{$ubbt_lang['USER_INFO']}" => "",
	"{$ubbt_lang['PERMS']}" => "",
	"{$ubbt_lang['FIELDS']}" => "",
	"{$ubbt_lang['PREFS']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setReturnTab($returntab);
$admin->setParentTitle($ubbt_lang['MEM_MAN'], "membermanage.php");
$admin->setPageTitle($ubbt_lang['EDIT_PROF'] . " #$uid");
$admin->sendHeader();
$admin->createTopTabs($tabs, $returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE_USER']);

// Include the template
include("../templates/default/admin/showuser.tmpl");

if ($banned) {
	$loginas = "javascript:void(0)\" onclick=\"nobecomeban()\"";
} elseif ($config['COOKIE_PATH'] == "/") {
	$loginas = "{$config['BASE_URL']}/admin/loginas.php?uid=$uid";
} else {
	$loginas = "javascript:void(0)\" onclick=\"nobecome()\"";
}

if ($uid != $user['USER_ID']) {
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
		$bottomtabs = array(
			"{$ubbt_lang['DELETE_USER']}" => "{$config['BASE_URL']}/admin/deleteuser.php?uid=$uid",
			"{$ubbt_lang['BECOME_USER']}" => "$loginas",
			"{$ubbt_lang['SEND_PM']}" => make_ubb_url("ubb=sendprivate&User=$uid", "", false),
			"{$ubbt_lang['SEND_PASS']}" => "{$config['BASE_URL']}/admin/sendpassword.php?uid=$uid",
			"{$ubbt_lang['MERGE_USER']}" => "{$config['BASE_URL']}/admin/mergeuser.php?uid=$uid",
			"{$ubbt_lang['VIEW_PROFILE']}" => make_ubb_url("ubb=showprofile&User=$uid", $dname, false),
			"{$ubbt_lang['VIEW_POSTS']}" => make_ubb_url("ubb=userposts&id=$uid", "", false),
		);
	} else {
		$bottomtabs[$ubbt_lang['SEND_PASS']] = "{$config['BASE_URL']}/admin/sendpassword.php?uid=$uid";
	}
	$admin->createBottomTabs($bottomtabs, 0);
	$admin->createBottomTabs($bottomtabs, 1);
	$admin->createBottomTabs($bottomtabs, 2);
	$admin->createBottomTabs($bottomtabs, 3);
}

$admin->sendFooter();

?>