<?php
//	Script Version 7.7.4

// Require the library
require_once("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/dashboard.php");
require("../languages/{$config['LANGUAGE']}/admin/suhosin.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$html = new html;

$admin->doAuth(array("EDIT_USERS", "APPROVE_POSTS"));

// First thing. Get rid of any unverified email accounts that
// are over 24 hours old
$deldate = $html->get_date() - 86400;

// We store some info in an admin cookie so we don't have to requery for some stuff
$ubbt_admin = get_input("{$config['COOKIE_PREFIX']}ubbt_admin", "cookie");

// We only want to do some of these queries every 5 minutes (300) or 30 minutes (1800)
// so as not to slow things down if they keep hitting the login screen.
$rightnow = time();

if ($ubbt_admin) {
	$ubbt_admin = unserialize($ubbt_admin);
}

// ------------------
// Grab total members
$query = "
	SELECT count(*)
	FROM {$config['TABLE_PREFIX']}USERS
	where USER_ID > 1
	and USER_IS_APPROVED = 'yes'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($totalmembers) = $dbh->fetch_array($sth);

// -----------------
// Grab total forums
$query = "
	SELECT COUNT(*)
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_IS_ACTIVE = '1'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($totalforums) = $dbh->fetch_array($sth);


// -----------------
// Grab total topics
$query = "
	SELECT SUM(FORUM_TOPICS)
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_IS_ACTIVE='1'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($totaltopics) = $dbh->fetch_array($sth);

// -----------------
// Grab total forums
$query = "
	SELECT SUM(FORUM_POSTS)
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_IS_ACTIVE='1'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($totalposts) = $dbh->fetch_array($sth);

// -----------------
// Grab total attachments from the db
$query = "
	SELECT COUNT(*)
	FROM {$config['TABLE_PREFIX']}FILES
	WHERE FILE_DIR IS NULL AND
		POST_ID != '0'
	OR FILE_DIR = '' AND
		POST_ID != '0'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($totalattach) = $dbh->fetch_array($sth);

// Grab attachments size from the db
$query = "
	SELECT SUM(FILE_SIZE)
	FROM {$config['TABLE_PREFIX']}FILES
	WHERE FILE_DIR IS NULL AND
		POST_ID != '0'
	OR FILE_DIR = '' AND
		POST_ID != '0'
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($totalattachsize) = $dbh->fetch_array($sth);
$totalattachsize = file_size($totalattachsize);

// Grab total attachments and size from the directory
// Because this process can be disk intensive, this option
// is only displayed when debugging is enabled.
if ($config['ALLOW_DEBUGGING'] || $VERTYPE != "Release") {
	$i = 0;
	$size = 0;
	if (file_exists($config['ATTACHMENTS_PATH'])) {
		$dir = @opendir($config['ATTACHMENTS_PATH']);

		while ($file = readdir($dir)) {
			if ($file == "." || $file == ".." || (stristr($file, "test.file")) || (stristr($file, "index.html"))) {
				continue;
			}
			$size = $size + filesize("{$config['ATTACHMENTS_PATH']}/$file");
			$i++;
		}
	}
//	$Mult = Floor($size = Log($size+1) / Log(1024));
//	$printsize = Round(Pow(1024, $size - $Mult) * 100) / 100 . " " . SubStr(" KMGT", $Mult, Min(1, $Mult)) . "B";
	$printsize = file_size($size);

	$attach = "$i ($printsize)";

	$attachinfo .= <<<EOF
<div class="op5"><span>{$ubbt_lang['ATTACH_FOLDER']}</span> $attach</div>
EOF;
}

if ($config['BOARD_IS_CLOSED']) {
	$open = $ubbt_lang['IS_CLOSED'];
	$dotoggle = $ubbt_lang['OPEN_BOARD'];
} else {
	$open = $ubbt_lang['IS_OPEN'];
	$dotoggle = $ubbt_lang['CLOSE_BOARD'];
}

// Suhosin check
$max_vars = $totalforums * 30;

if (extension_loaded("suhosin")) {
	if ((ini_get("suhosin.request.max_vars") < 2048) || (ini_get("suhosin.post.max_vars") < 2048) || (ini_get("suhosin.request.max_vars") < $max_vars) || (ini_get("suhosin.post.max_vars") < $max_vars)) {
		$suhosin = 1;
	} else {
		$suhosin = 0;
	}
}

$max_input_vars = ini_get("max_input_vars");
if (($max_input_vars < 1000) || ($max_input_vars < $max_vars)) {
	$inputvars = 1;
} else {
	$inputvars = 0;
}
if ($max_vars > 2048) {
	$recommended = $max_vars;
} else {
	$recommended = 2048;
}
$input_vars_error = str_replace(array("%current%", "%recommend%"), array($max_input_vars, $recommended), $ubbt_lang['INPUTVARS']);

// Grab new members in time periods
if (!isset($ubbt_admin['newmembers1'])) {
	$query = "
		SELECT COUNT(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_REGISTERED_ON > (UNIX_TIMESTAMP() - (86400))
		AND USER_IS_APPROVED = 'yes'
	";
	$sth = $dbh->do_query($query);
	list($newmembers1) = $dbh->fetch_array($sth);
	$ubbt_admin['newmembers1'] = $newmembers1;

	$query = "
		SELECT COUNT(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_REGISTERED_ON > (UNIX_TIMESTAMP() - (86400 * 7))
		AND USER_IS_APPROVED = 'yes'
	";
	$sth = $dbh->do_query($query);
	list($newmembers7) = $dbh->fetch_array($sth);
	$ubbt_admin['newmembers7'] = $newmembers7;

	$query = "
		SELECT COUNT(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_REGISTERED_ON > (UNIX_TIMESTAMP() - (86400 * 31))
		AND USER_IS_APPROVED = 'yes'
	";
	$sth = $dbh->do_query($query);
	list($newmembers31) = $dbh->fetch_array($sth);
	$ubbt_admin['newmembers31'] = $newmembers31;
} else {
	$newmembers1 = $ubbt_admin['newmembers1'];
	$newmembers7 = $ubbt_admin['newmembers7'];
	$newmembers31 = $ubbt_admin['newmembers31'];
}


$loginfo = "";

$sqllog = $ubbt_lang['NOT_ENABLED'];
if ($config['LOG_SQL_ERRORS']) {
	//$sql_error = filectime();
	$i = 0;
	$size = 0;
	if (file_exists($config['SQL_LOG_PATH'])) {
		$dir = @opendir($config['SQL_LOG_PATH']);

		while ($file = readdir($dir)) {
			if ($file == "." || $file == ".." || (!stristr($file, "mysql.log"))) {
				continue;
			}
			$size = $size + filesize("{$config['SQL_LOG_PATH']}/$file");
			$i++;
		}
	}
//	$Mult = Floor($size = Log($size+1) / Log(1024));
//	$printsize = Round(Pow(1024, $size - $Mult) * 100) / 100 . " " . SubStr(" KMGT", $Mult, Min(1, $Mult)) . "B";
	$printsize = file_size($size);
	$sqllog = "$i ($printsize)";

	$loginfo .= <<<EOF
<div><a href="{$config['BASE_URL']}/admin/logs.php?returntab=0"><span>{$ubbt_lang['SQL_ERRORS']}</span> $sqllog</a></div>
EOF;
}


// Purge expired admin activity logs if necessary
// This task runs no less than 30 minutes since last accessing the dashboard by the same user
if ($ubbt_admin['timestamp'] < ($rightnow - 1800)) {
	if ((isset($config['LOG_ADMIN_ACTIVITY'])) && ($config['LOG_ADMIN_ACTIVITY'] > 1)) {
//		$config['LOG_ADMIN_ACTIVITY'] = 365; // Recommended Days

// 86400 = 1 day
// 604800 = 1 week
// 2592000 = 30 days
// 31536000 = 1 year
		$outdated = $html->get_date() - ($config['LOG_ADMIN_ACTIVITY'] * 86400);
		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}ADMIN_LOG
		WHERE LOG_DATE <= '$outdated'
	";
		$dbh->do_query($query, __LINE__, __FILE__);
	}
}


if ((!isset($config['LOG_ADMIN_ACTIVITY'])) || ($config['LOG_ADMIN_ACTIVITY'] > 1)) {
	$query = "
		SELECT COUNT(*)
		FROM {$config['TABLE_PREFIX']}ADMIN_LOG
	";
	$sth = $dbh->do_query($query);
	list($alogcount) = $dbh->fetch_array($sth);
	$ubbt_admin['alogcount'] = $alogcount;

	$loginfo .= <<<EOF
<div><a href="{$config['BASE_URL']}/admin/admin_log.php?returntab=1"><span>{$ubbt_lang['ADMIN_LOG']}</span> $alogcount</a></div>
EOF;
}


if ($config['LOG_REFERS']) {
	$query = "
		SELECT COUNT(*)
		FROM {$config['TABLE_PREFIX']}REFERER_LOG
	";
	$sth = $dbh->do_query($query);
	list($rlogcount) = $dbh->fetch_array($sth);
	$ubbt_admin['rlogcount'] = $rlogcount;

	$loginfo .= <<<EOF
<div><a href="{$config['BASE_URL']}/admin/referer_log.php?returntab=2"><span>{$ubbt_lang['REFERER_LOG']}</span> $rlogcount</a></div>
EOF;
}


// Any posts waiting for approval?
$pa_link = "";
$dc_link = "";
$modq_link = "";

$inlist = "";
if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
	$query = "
		SELECT FORUM_ID
		FROM {$config['TABLE_PREFIX']}MODERATORS
		WHERE USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	while (list($forum_id) = $dbh->fetch_array($sth)) {
		$inlist .= "$forum_id,";
	}
	$inlist = preg_replace("/,$/", "", $inlist);
	if ($inlist) {
		$inlist = "AND t2.FORUM_ID in ($inlist)";
	}
}

$query = "
	SELECT COUNT(t1.POST_ID)
	FROM {$config['TABLE_PREFIX']}POSTS as t1,
	{$config['TABLE_PREFIX']}TOPICS as t2
	WHERE t1.POST_IS_APPROVED = '0'
	and t1.TOPIC_ID = t2.TOPIC_ID
	$inlist
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($p) = $dbh->fetch_array($sth);
if ($p) {
//	$ubbt_lang['APP_POSTS'] = sprintf($ubbt_lang['APP_POSTS'],$p);
//	$pa_link = "<a href=\"{$config['BASE_URL']}/admin/approveposts.php\">{$ubbt_lang['APP_POSTS']}</a><br>";
}


// Any registration que users?
if (!isset($ubbt_admin['modq']) || ($ubbt_admin['timestamp'] < ($rightnow - 300))) {
	$query = "
		SELECT COUNT(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_IS_APPROVED <> 'yes'
		AND USER_ID <> '1'
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	list($modq) = $dbh->fetch_array($sth);
	$ubbt_admin['modq'] = $modq;
} else {
	$modq = $ubbt_admin['modq'];
}

if ($modq) {
//	$ubbt_lang['MODQ'] = sprintf($ubbt_lang['MODQ'],$modq);
//	$modq_link = "<a href=\"{$config['BASE_URL']}/admin/membermanage.php?returntab=1\">{$ubbt_lang['MODQ']}</a><br>";
}


// Any display name changes?
$query = "
	SELECT COUNT(*)
	FROM {$config['TABLE_PREFIX']}DISPLAY_NAMES
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($totaldc) = $dbh->fetch_array($sth);

if ($totaldc) {
//	$ubbt_lang['DISPLAY_CHANGES'] = sprintf($ubbt_lang['DISPLAY_CHANGES'],$totaldc);
//	$modq_link .= "<a href=\"{$config['BASE_URL']}/admin/membermanage.php?returntab=2\">{$ubbt_lang['DISPLAY_CHANGES']}</a><br>";
}


// Get Server Stats
$php_os = PHP_OS;								// Server OS
$php_version = phpversion();					// PHP Version
list($server_software, $junk) = preg_split("# #", $_SERVER['SERVER_SOFTWARE']);
$sth = $dbh->do_query("select VERSION()");
list($sql_version) = $dbh->fetch_array($sth);	// MySQL Version 


// Get database size
$dbsize = 0;
$sth = $dbh->do_query("SHOW TABLE STATUS LIKE '{$db->p}%'");
while ($row = $dbh->fetch_array($sth)) {
	$dbsize += $row['Data_length'] + $row['Index_length'];
}
$dbsize = file_size($dbsize);


// Can we get the System Load Average
$load = array();
if (!preg_match("#^win#i", PHP_OS)) {
	if (function_exists('sys_getloadavg')) {
		$load = sys_getloadavg();
	}
	if (file_exists("/proc/loadavg")) {
		$load = explode(chr(32), file_get_contents("/proc/loadavg"));
	}
}

if ($ubbt_admin['timestamp'] < ($rightnow - 1800)) {
	$ubbt_admin['timestamp'] = $rightnow;
}

function url_exists($str) {
	$headers = @get_headers($str);
	if ($headers[0] == "HTTP/1.1 404 Not Found") {
		$exists = false;
	} else {
		$exists = true;
	}

	return ($exists);
}

function load_feed($str, $total = 8) {
	if (url_exists($str) == 1) {
		$feed = "";
		$feedXml = simplexml_load_file($str);
		foreach ($feedXml->channel->item as $item) {
			$feed .= "<tr class=\"colored-row stdautorow alvt fw\" style=\"border-bottom:0;\">
	<td class=\"news_subject colored-row alvt\" style=\"width:90%;\"><a href=\"" . $item->link . "\" target=\"_blank\">" . $item->title . "</a></td>
	<td class=\"news_time colored-row alvt nw\" style=\"width:10%;\">" . date("m/d/Y \\a\\t h:i A", strtotime($item->pubDate)) . "</td>
	</tr>\n";
			if (++$count == $total) {
				break;
			}
		}
	} else {
		$feed = "<div style=\"font-weight:bold; text-align:center;\">Could not communicate with <a href=\"https://www.ubbcentral.com/\">UBB.Central</a>.</div>";
	}

	return ($feed);
}

$feed = load_feed("https://www.ubbcentral.com/forums/cache/rss1.xml");                    // Release
$feed .= "<tr class=\"colored-row stdautorow alvt fw\" style=\"border-bottom:0;\"><td class=\"news_subject nw\"  colspan=\"2\">&nbsp;</td></tr>\n";

if ($VERTYPE != "Release") {
	$feed .= "<tr class=\"colored-row stdautorow alvt fw\" style=\"border-bottom:0;\"><td class=\"autorow-header-1\" colspan=\"2\">Updates From The Developers At UBBDev</td></tr>\n";
	$feed .= load_feed("https://www.ubbdev.com/forums/cache/rss92.xml");                    // DEV/Preview
//	$feed .= load_feed("https://www.ubbdev.com/forums/ubbthreads.php?ubb=myfeeds&fp=92");	// DEV/Preview, Long URL
	$feed .= "<tr class=\"colored-row stdautorow alvt fw\" style=\"border-bottom:0;\"><td class=\"news_subject nw\"  colspan=\"2\">&nbsp;</td></tr>\n";
}

$ubbt_admin = serialize($ubbt_admin);
$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_admin", $ubbt_admin);

$tabs = array(
	"{$ubbt_lang['HOME']}" => "",
);

// Create the Page
$admin->setPageTitle("{$ubbt_lang['HOME']}");
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/dashboard.tmpl");

$admin->sendFooter();

?>