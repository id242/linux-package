<?php
//	Script Version 7.7.0

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/payment_settings.php");

// Get the input
$returntab = get_input("returntab", "both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['PAYMENT_SET']}" => "",
);

// Paypal
if ($config['ALLOW_PAYPAL']) {
	$allow_paypal = "checked='checked'";
}

// mail payment
$no_check_mo = "";
$check = "";
$mo = "";
$check_mo = "";
if ($config['ALLOW_MAIL'] == "check") {
	$check = "selected='selected'";
} elseif ($config['ALLOW_MAIL'] == "mo") {
	$mo = "selected='selected'";
} elseif ($config['ALLOW_MAIL'] == "check_mo") {
	$check_mo = "selected='selected'";
} else {
	$no_check_mo = "selected='selected'";
}

// Currency
if ($config['CURRENCY'] == "CAD") {
	$cad = "selected='selected'";
} elseif ($config['CURRENCY'] == "EUR") {
	$eur = "selected='selected'";
} elseif ($config['CURRENCY'] == "GBP") {
	$gbp = "selected='selected'";
} elseif ($config['CURRENCY'] == "JPY") {
	$jpy = "selected='selected'";
} else {
	$usd = "selected='selected'";
}

// Create the Page
$admin->setCurrentMenu($ubbt_lang['PAYMENT_SET']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['PAYMENT_SET']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/payment_settings.tmpl");

$admin->sendFooter();

?>