<?php
//	Script Version 7.7.3

// Require the library
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/doprunethreads.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = 0;
$total = get_input("total", "get");
$current = get_input("current", "get");
$excluded = get_input("excluded", "get");

// prune 100 topics per page
// Defining this in here instead of making an option since
// too many might result in the max_execution time being exceeded
// and that would be bad.
$prunecount = 100;

if (!$current) {
	$current = 0;
}
if (!$excluded) {
	$excluded = 0;
}

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

if ($current < $total) {

	// Retrieve query and removed results from database
	$query = "
		SELECT ADMIN_SEARCH_QUERY,ADMIN_SEARCH_REMOVED_RESULTS,ADMIN_SEARCH_RESULTS
		FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		WHERE ADMIN_SEARCH_TYPE='topicprune'
		AND USER_ID='{$user['USER_ID']}'
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	list ($savedquery, $removed, $results) = $dbh->fetch_array($sth);

	if ($removed) {
		$removed = unserialize($removed);
	} else {
		$removed = array();
	}

	// Execute the saved query if this is our first pass
	if (!$current) {
		$savedquery = preg_replace("/(\n|\r)/", "", $savedquery);
		$savedquery = preg_replace("/SELECT t1.TOPIC_ID,t1.TOPIC_SUBJECT,t1.FORUM_ID,t1.TOPIC_CREATED_TIME,t1.TOPIC_LAST_REPLY_TIME,t1.USER_ID,t1.TOPIC_LAST_POSTER_ID,t2.USER_DISPLAY_NAME,t1.TOPIC_LAST_POST_ID/", "select t1.TOPIC_ID", $savedquery);
		$savedquery .= " ORDER BY t1.TOPIC_ID";
		$sth = $dbh->do_query($savedquery, __LINE__, __FILE__);
		$results = array();
		while (list($bnum) = $dbh->fetch_array($sth)) {
			$results[] = $bnum;
		}
		$results_q = addslashes(serialize($results));
		$query = "
			UPDATE {$config['TABLE_PREFIX']}ADMIN_SEARCHES
			SET ADMIN_SEARCH_RESULTS = '$results_q'
			WHERE ADMIN_SEARCH_TYPE='topicprune'
			AND USER_ID='{$user['USER_ID']}'
		";
		$dbh->do_query($query, __LINE__, __FILE__);
		$inlist = "";
		for ($i = 0; $i < $prunecount; $i++) {
			if (isset($results[$i])) {
				$inlist .= "'$results[$i]',";
			}
		}
		$inlist = preg_replace("/,$/", "", $inlist);
		$query = "
			SELECT FORUM_ID,TOPIC_ID FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID IN ($inlist)
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
	} else {
		$inlist = "";
		$results = unserialize($results);
		for ($i = $current; $i < ($current + $prunecount); $i++) {
			if (isset($results[$i])) {
				$inlist .= "'$results[$i]',";
			}
		}
		$inlist = preg_replace("/,$/", "", $inlist);
		$query = "
			SELECT FORUM_ID,TOPIC_ID  FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID IN ($inlist)
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
	}
	$sources = array();
	$postnum = 0;

	while ($postrow = $dbh->fetch_array($sth)) {

		$current++;
		$postnum++;

		if (isset($removed[$postrow['TOPIC_ID']])) {
			$excluded++;
			if ($postnum == $prunecount) {
				$mess = sprintf($ubbt_lang['COUNTER'], $current, $total, $excluded);
				$admin->redirect($mess, "{$config['BASE_URL']}/admin/doprunethreads.php?total=$total&amp;current=$current&amp;excluded=$excluded", $ubbt_lang['F_LOC'], 2);
				exit;
			}
			continue;
		}

		$sources[] = $postrow['FORUM_ID'];

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
			WHERE  WATCH_ID = '{$postrow['TOPIC_ID']}'
			AND WATCH_TYPE = 't'
		";
		$dbh->do_query($query);

		// ---------------------------------------------------------------------
		// Find out if there are any files to delete and if the post is approved
		$query = "
			SELECT POST_ID
			FROM   {$config['TABLE_PREFIX']}POSTS
			WHERE  TOPIC_ID  = '{$postrow['TOPIC_ID']}'
		";
		$sta = $dbh->do_query($query, __LINE__, __FILE__);
		while (list($checkee) = $dbh->fetch_array($sta)) {

			$query = "
				select FILE_NAME
				from {$config['TABLE_PREFIX']}FILES
				where POST_ID = ?
			";
			$stx = $dbh->do_placeholder_query($query, array($checkee), __LINE__, __FILE__);
			while (list($filename) = $dbh->fetch_array($stx)) {
				@unlink("{$config['ATTACHMENTS_PATH']}/$filename");
			}

			$query = "
				delete from {$config['TABLE_PREFIX']}FILES
				where POST_ID = ?
			";
			$dbh->do_placeholder_query($query, array($checkee), __LINE__, __FILE__);

			$query = "
				select POLL_ID
				from {$config['TABLE_PREFIX']}POLL_DATA
				where POST_ID = ?
			";
			$stx = $dbh->do_placeholder_query($query, array($checkee), __LINE__, __FILE__);
			while (list($Poll) = $dbh->fetch_array($stx)) {

				$Poll = addslashes($Poll);
				$query = "
					DELETE FROM {$config['TABLE_PREFIX']}POLL_DATA
					WHERE  POLL_ID = '$Poll'
				";
				$dbh->do_query($query, __LINE__, __FILE__);
				$query = "
					DELETE FROM {$config['TABLE_PREFIX']}POLL_OPTIONS
					WHERE  POLL_ID = '$Poll'
				";
				$dbh->do_query($query, __LINE__, __FILE__);
				$query = "
					DELETE FROM {$config['TABLE_PREFIX']}POLL_VOTES
					WHERE  POLL_ID = '$Poll'
				";
				$dbh->do_query($query, __LINE__, __FILE__);
			}
		}

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POSTS
			WHERE TOPIC_ID = '{$postrow['TOPIC_ID']}'
		";
		$dbh->do_query($query, __LINE__, __FILE__);

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID = '{$postrow['TOPIC_ID']}'
		";
		$dbh->do_query($query, __LINE__, __FILE__);

		if ($postnum == $prunecount) {
			$mess = sprintf($ubbt_lang['COUNTER'], $current, $total, $excluded);
			$admin->redirect($mess, "{$config['BASE_URL']}/admin/doprunethreads.php?total=$total&amp;current=$current&amp;excluded=$excluded", $ubbt_lang['F_LOC'], 2);
			exit;
		}

	}
}


admin_log("PRUNE_THREADS", "");

// Fix all the source forums
for ($i = 0; $i < sizeof($sources); $i++) {
	$Keyword_q = addslashes($sources[$i]);
	$query = "
		SELECT TOPIC_LAST_POST_ID,TOPIC_LAST_REPLY_TIME,TOPIC_ID,TOPIC_LAST_POSTER_ID,TOPIC_LAST_POSTER_NAME
		FROM {$config['TABLE_PREFIX']}TOPICS
		WHERE FORUM_ID='$Keyword_q'
		ORDER BY TOPIC_LAST_REPLY_TIME DESC
		LIMIT 1
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	list($bnum, $blast, $blastnum, $blastposterid, $blastname) = $dbh->fetch_array($sth);

	$query = "
	select t1.TOPIC_ID,count(t2.POST_ID)
	from {$config['TABLE_PREFIX']}TOPICS as t1,
	{$config['TABLE_PREFIX']}POSTS as t2
	where t1.TOPIC_ID = t2.TOPIC_ID
	and   t1.FORUM_ID = '$Keyword_q'
	and   t2.POST_IS_APPROVED = '1'
	group by t1.TOPIC_ID
	";
	$stx = $dbh->do_query($query, __LINE__, __FILE__);
	$totalposts = 0;
	$totaltopics = 0;
	while (list($t, $c) = $dbh->fetch_array($stx)) {
		$totaltopics++;
		$totalposts = $totalposts + $c;
	}

	$query = "
		select POST_SUBJECT,POST_ICON
		from {$config['TABLE_PREFIX']}POSTS
		where POST_ID = '$bnum'
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	list($blastsubject, $blasticon) = $dbh->fetch_array($sth);
	$blastname = addslashes($blastname);
	$blastsubject = addslashes($blastsubject);
	$blasticon = addslashes($blasticon);

	if (!$bnum) $bnum = 0;
	if (!$blastnum) $blastnum = 0;
	if (!$blastposterid) $blastposterid = 0;
	if (!$blast) $blast = 0;

	$query = "
		UPDATE {$config['TABLE_PREFIX']}FORUMS
		SET FORUM_POSTS = $totalposts,
		FORUM_TOPICS = $totaltopics,
		FORUM_LAST_POST_ID = '$bnum',
		FORUM_LAST_TOPIC_ID = '$blastnum',
		FORUM_LAST_POSTER_ID = '$blastposterid',
		FORUM_LAST_POST_TIME = '$blast',
		FORUM_LAST_POSTER_NAME = '$blastname',
		FORUM_LAST_POST_SUBJECT = '$blastsubject',
		FORUM_LAST_POST_ICON = '$blasticon'
		WHERE FORUM_ID='$Keyword_q'
	";
	$dbh->do_query($query, __LINE__, __FILE__);
}

$admin->redirect($ubbt_lang['PRUNE_DONE'], "{$config['BASE_URL']}/admin/prunethreads.php", $ubbt_lang['F_LOC_MAIN']);

?>