Parental consent and approval is required for user registrations to persons under the age of 13.

For more information please see the <a href="https://www.ftc.gov/news-events/media-resources/protecting-consumer-privacy/kids-privacy-coppa">Federal Trade Commission's</a> COPPA (Children's Privacy) Policy Guidelines.
