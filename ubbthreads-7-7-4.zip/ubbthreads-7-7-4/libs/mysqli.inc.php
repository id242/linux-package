<?php
/*
  Version: 7.7.4
  Purpose: Database class for mysql functions
  Future:
*/

class sql {
	// #######################################################################
	// Connect to the database
	// #######################################################################
	//
	// @param string The database hostname.					$config['DATABASE_SERVER']
	// @param string The database username.					$config['DATABASE_USER']
	// @param string The database user's password.			$config['DATABASE_PASSWORD']
	// @param string The database name.						$config['DATABASE_NAME']
	// @return resource The database connection resource.
	//
	function connect() {
		global $config, $debug, $querycount;

		$querycount = 0;

		if (!isset($this->dbh)) {
			$this->debug_output = "";

			if (!isset($config['PERSISTENT_DB_CONNECTION']) || !$config['PERSISTENT_DB_CONNECTION']) {
				$this->dbh = mysqli_connect($config['DATABASE_SERVER'], $config['DATABASE_USER'], $config['DATABASE_PASSWORD'], $config['DATABASE_NAME']) or die("Problem occurred in connection");
			} else {
				$this->dbh = mysqli_connect("p:" . $config['DATABASE_SERVER'], $config['DATABASE_USER'], $config['DATABASE_PASSWORD'], $config['DATABASE_NAME']) or die("Problem occurred in connection");
			}
			if ($config['UTF8']) {
				mysqli_set_charset($this->dbh, "utf8mb4");
			}
		}

		if (!$this->dbh) {
//			$this->not_right("Unable to connect to the database!");
			$this->not_right("Unable to connect to the database (as " . $config['DATABASE_USER'] . " to " . $config['DATABASE_SERVER'] . ", database " . $config['DATABASE_NAME'] . ").");
		}

		if (!mysqli_select_db($this->dbh, $config['DATABASE_NAME'])) {
//			$this->not_right("Unable to select database!");
			$this->not_right("Unable to select database: " . $config['DATABASE_NAME']);
		}
	}

	// #######################################################################
	// Grab the error descriptor
	// #######################################################################
	function graberrordesc() {
		return mysqli_error($this->dbh);
	}

	// Determine if the parameter is an integer
	function is_int($x) {
		return preg_match("#^\d+$#", $x);
	}

	// #######################################################################
	// Grab the error number
	// #######################################################################
	function graberrornum() {
		return mysqli_errno($this->dbh);
	}

	// #######################################################################
	// Throw an error (Wrapper Function to reduce code)
	// #######################################################################
	function throw_error($errstr, $is_bare = false) {
		global $admin, $html;

		if (defined('IS_ADMIN')) {
			$admin->error($errstr);
		} else if (defined('IS_IMPORT') || defined('IS_UPGRADE')) {
			echo '<b>SQL Error:</b> ' . $errstr;
		} else {
			if (!is_object($html)) {
				$html = new html;
			}

			if (defined('NO_WRAPPERS')) $is_bare = true;

			($is_bare ? $html->not_right_bare($errstr) : $html->not_right($errstr));
		}
	}

	// #######################################################################
	// Do a placeholder query
	// #######################################################################
	function do_placeholder_query($query = "", $subst = array(), $line = "", $file = "") {

		if (!is_array($subst)) {
			$doom = debug_backtrace();
			$this->throw_error("BUG: do_placeholder_query was called without the replacement array. Caller: {$doom[0]['file']}:{$doom[0]['line']}");
		}

		$kaboom = explode("?", $query);
		$places = sizeof($kaboom) - 1;
		$replaces = sizeof($subst);
		if ($places > $replaces) {
			// Fewer places than replaces. Pad the replace array with blanks.
			$subst = array_pad($subst, $places, "");
			$this->throw_error("Tried to replace $places placeholders with $replaces replaces. That's bad. Here's the query: $query");
		} else if ($replaces > $places) {
			// More replaces than places? That's even worse. Fatal, in fact.
			// FIXME: Need to cover this up a bit better...
			$this->throw_error("Tried to replace $places placeholders with $replaces replaces. That's too many. Here's the query: $query");
		}

		// Good, we can actually run now.
		$query = "";
		for ($i = 0; $i < $places; $i++) {
			$query .= array_shift($kaboom);

			// Escape and add quotes to the string if we need to
			$string = array_shift($subst);

			if (is_array($string)) {
				// If this is an array, join it with commas after escaping
				// Primary use: IN(?) and INSERT INTO tablename(COL, COL, ...) VALUES(?)
				$new_ary = array();


				foreach ($string as $str) {
					$new_ary[] = $this->is_int($str) ? $str : "'" . mysqli_real_escape_string($this->dbh, $str) . "'";
				}

				$string = implode(", ", $new_ary);
			} else if (!$this->is_int($string) || $string[0] == '0') {
				// Escape the string only if it isn't a plain number or NULL
				$string = "'" . mysqli_real_escape_string($this->dbh, $string) . "'";
			}
			$query .= $string;
		}
		$query .= $kaboom[0]; // last piece after the last substitution
		return $this->do_query($query, $line, $file);
	}

	// #######################################################################
	// Calls MySQL's escape function to prepend backslashes where needed. Using
	// the data provider's escape function instead of addslashes() takes into
	// account the character set used by the current connection to the database
	// #######################################################################
	function escape_string($sth) {
		// Escape and add quotes to the string only if it isn't a plain number or NULL
		if (!$this->is_int($sth) || $sth[0] == '0') {
			$sth = "'" . mysqli_real_escape_string($this->dbh, $sth) . "'";
		}
		return $sth;
	}

	// #######################################################################
	// Do the query
	// #######################################################################
	function do_query($query, $line = "", $file = "") {
		global $querycount, $debug, $user, $mysqltime, $html, $admin;
		$querycount++;

		$status = array_get($user, 'USER_MEMBERSHIP_LEVEL', null);
		$explain = ($debug && ($status == null || $status == 'Administrator'));

		if ($explain) {
			// If we are in debug mode then we are going to EXPLAIN each
			// query but only to admins

			if (isset($this->debug) && !($this->debug = $debug)) {
				$this->debug_output = "";
			}

			$sth = mysqli_query($this->dbh, "EXPLAIN $query");
			$query2 = preg_replace('#,(\S)#', ', \1', trim($query));
			$query2 = ubbchars($query2);
			$numFields = "";
			if ($sth) {
				$numFields = $this->num_fields($sth);
			}

			$extra = "";
			if (!preg_match('#\s*SELECT#i', $query2)) {
				$extra = " <i class=\"e\">Non-Select Query</i>";
			}

			$this->debug_output .= "<table>\n<tr class=\"a\"><td colspan=\"$numFields\">Query $extra</td></tr>";
			$this->debug_output .= "\n<tr class=\"d\">\n\t<td colspan=\"$numFields\">\n\t\t<div class=\"tt\">{$query2}\n\t\t</div></td>\n</tr>\n";
			$this->debug_output .= "<tr class=\"b\">";

			for ($i = 0; $i < $numFields; $i++) {
				$this->debug_output .= "\n\t<td>" . $this->field_name($sth, $i) . "</td>";
			}

			$this->debug_output .= "\n</tr>";
			while ($results = $this->fetch_array($sth)) {
				$this->debug_output .= "\n<tr class=\"c\">";
				for ($i = 0; $i < $numFields; $i++) {
					if (!isset($results[$i])) {
						$results[$i] = "&nbsp;";
					}
					$results[$i] = preg_replace('#,(\S)#', ', \1', $results[$i]);
					$this->debug_output .= "\n\t<td>" . (isset($results[$i]) ? $results[$i] : "&nbsp;") . "</td>";
				}
				$this->debug_output .= "\n</tr>";
			}
		}

		$mytimea = getmicrotime();
// this line line grabs the query in to $sth
		$sth = mysqli_query($this->dbh, $query);
		$mytime = round(getmicrotime() - $mytimea, 4);
		$mysqltime = $mysqltime + $mytime;

		// If in debug mode we will also show the time needed to execute the query.
		if ($explain) {
			$this->debug_output .= "<tr class=\"a\">\n\t<td colspan=\"$numFields\">Query took a total of $mytime seconds.</td>\n</tr>\n</table><br>";
		}

		if (!$sth) {
			if (defined('IS_UPGRADE') || defined('IS_IMPORT')) {
				echo mysqli_error($this->dbh);
			} else {
				define('IS_SQL_ERROR', 1);
				$this->not_right($query, $line, $file);
			}
		}

		return $sth;
	}

	// #######################################################################
	// Fetch the next row in an array
	// #######################################################################
	function fetch_array($sth, $type = MYSQLI_BOTH) {
		if ($sth instanceof mysqli_result) {
			return mysqli_fetch_array($sth, $type);
		}
		return false;
	}

	// #######################################################################
	// Get a result row as an enumerated array
	// #######################################################################
	function mysqli_fetch_row($sth) {
		return mysqli_fetch_row($sth);
	}

	// #######################################################################
	// Finish the statement handler
	// #######################################################################
	function finish_sth($sth) {
		if (is_resource($sth)) {
			return mysqli_free_result($sth);
		}
	}

	// #######################################################################
	// Grab the total rows
	// #######################################################################
	function total_rows($sth) {
		return mysqli_num_rows($sth);
	}

	function affected_rows() {
		return mysqli_affected_rows($this->dbh);
	}

	function last_insert_id($line, $file) {
		$sth = $this->do_query("SELECT last_insert_id()", $line, $file);
		list($id) = $this->fetch_array($sth, MYSQLI_BOTH);
		return $id;
	}

	// #######################################################################
	// Grab the number of fields
	// #######################################################################
	function num_fields($sth) {
		return mysqli_num_fields($sth);
	}

	// #######################################################################
	// Grab the field name
	// #######################################################################
	function field_name($sth, $i) {
		return mysqli_fetch_field_direct($sth, $i)->name;
	}

	// #######################################################################
	// Die
	// #######################################################################
	function not_right($error, $line = "", $file = "") {
		global $user, $user_ip, $config, $html;

		// IF YOU SET THE VARIABLE BELOW TO 1 IT WILL SHOW THE SQL ERRORS TO ALL
		// USERS. USEFUL IF YOU CANNOT LOG IN AND NEED TO SEE THE SQL ERRORS
		$showerror = 0;
		if (defined('INSTALL')) {
			$showerror = 1;
		}

		$mysqli_error = mysqli_error($this->dbh);

		$now = time();
		$time = '';

		if ($config['LOG_SQL_ERRORS']) {
			$log_dir = array_get($config, 'SQL_LOG_PATH', false);
			if ($log_dir) {
				$date = date('Ymd', $now);              // example: '20021018'
				$time = date('D, M d Y H:i:s O', $now); // example: 'Fri Oct 18 21:50:13 2002 +0200'
				$log_file = "$log_dir/{$date}_mysql.log";
				$who = array_get($user, 'USER_DISPLAY_NAME', $user_ip);
				@error_log("[ERROR][$time] [$script_name] [$who] Script: $file - Line: $line $error - $mysqli_error\n", 3, $log_file);
			}
		}

		$connect_array = array(2001, 2002, 2003, 2004, 2005, 2006, 2013, 2016, 2017, 2018, 2019);

		if ($showerror || defined('SHOW_SQL_LOGS') || array_get($user, 'USER_MEMBERSHIP_LEVEL', 'User') == 'Administrator') {
			$show_error = "<b>Script:</b> $file\n";
			$show_error .= "<b>Line:</b> $line\n";
			if (in_array(mysqli_errno($this->dbh), $connect_array)) {
				$show_error .= "<b>SQL Error:</b> " . mysqli_error($this->dbh) . "\n<b>Please verify that your MySQL server is running</b>\n";
			} else {
				$show_error .= "<b>SQL Error:</b> " . mysqli_error($this->dbh) . "\n";
			}
			$show_error .= "<b>SQL Error:</b> " . mysqli_errno($this->dbh) . "\n";
			$show_error .= "\n<b>Query:</b><code>$error</code>";
		} else {
			if (in_array(mysqli_errno($this->dbh), $connect_array)) {
				$show_error = "Unable to connect to database server, please try again in a few minutes.";
			} else {
				$show_error = 'Database error only visible to forum administrators';
			}
		}
		$show_error = str_replace("\n", "<br>\n", $show_error);
		$this->throw_error($show_error, true);
	}
}

?>