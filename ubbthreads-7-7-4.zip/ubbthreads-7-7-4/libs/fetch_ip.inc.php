<?php
/*
  Version: 7.7.2
  Purpose: Fetch_ip function will retrieve the correct Client IP address from the set server globals instead
		   of relying on REMOTE_ADDR. This function is useful for sites that are behind a CDN or Firewall, or for
		   clients who are accessing the site behind a proxy.
  Author:  James Corthell, VNC Web Services (https://www.virtualnightclub.net/)
  Revised By Isaac DeCoursey to clean up any ports, lists, and IPv4/IPv6 validation & handling
*/

function fetch_ip() {
	if (isset($_SERVER["GD_PHP_HANDLER"])) {
		return ($_SERVER["GD_PHP_HANDLER"]);
	} elseif (isset($_SERVER["HTTP_AKAMAI_ORIGIN_HOP"])) {
		return ($_SERVER["HTTP_AKAMAI_ORIGIN_HOP"]);
	} elseif (isset($_SERVER["HTTP_X_SUCURI_CLIENTIP"])) {
		return ($_SERVER["HTTP_X_SUCURI_CLIENTIP"]);
	} elseif (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
		return ($_SERVER["HTTP_CF_CONNECTING_IP"]);
	} elseif (isset($_SERVER["HTTP_CLIENT_IP"])) {
		return ($_SERVER["HTTP_CLIENT_IP"]);
	} elseif (isset($_SERVER["HTTP_FASTLY_CLIENT_IP"])) {
		return ($_SERVER["HTTP_FASTLY_CLIENT_IP"]);
	} elseif (isset($_SERVER["HTTP_FORWARDED"])) {
		return ($_SERVER["HTTP_FORWARDED"]);
	} elseif (isset($_SERVER["HTTP_FORWARDED_FOR"])) {
		return ($_SERVER["HTTP_FORWARDED_FOR"]);
	} elseif (isset($_SERVER["HTTP_X_FORWARDED_FOR"]) && (($_SERVER["HTTP_X_FORWARDED_FOR"]) != ($_SERVER["SERVER_ADDR"]))) {
		return ($_SERVER["HTTP_X_FORWARDED_FOR"]);
	} elseif (isset($_SERVER["HTTP_INCAP_CLIENT_IP"])) {
		return ($_SERVER["HTTP_INCAP_CLIENT_IP"]);
	} elseif (isset($_SERVER["HTTP_TRUE_CLIENT_IP"])) {
		return ($_SERVER["HTTP_TRUE_CLIENT_IP"]);
	} elseif (isset($_SERVER["HTTP_X_CLIENTIP"])) {
		return ($_SERVER["HTTP_X_CLIENTIP"]);
	} elseif (isset($_SERVER["HTTP_X_CLUSTER_CLIENT_IP"])) {
		return ($_SERVER["HTTP_X_CLUSTER_CLIENT_IP"]);
	} elseif (isset($_SERVER["HTTP_X_FORWARDED"])) {
		return ($_SERVER["HTTP_X_FORWARDED"]);
	} elseif (isset($_SERVER["HTTP_X_IP_TRAIL"])) {
		return ($_SERVER["HTTP_X_IP_TRAIL"]);
	} elseif (isset($_SERVER["HTTP_X_REAL_IP"])) {
		return ($_SERVER["HTTP_X_REAL_IP"]);
	} elseif (isset($_SERVER["HTTP_X_VARNISH"])) {
		return ($_SERVER["HTTP_X_VARNISH"]);
	} else {
		return ($_SERVER["REMOTE_ADDR"]);
	}
}

$user_ip = fetch_ip();

// If multiple IPs are found, they will be presented as comma-separated list.
if (stristr($user_ip, ',')) {
	// Grab first IP address in list
	$user_ip = trim(reset((explode(',', $user_ip))));
}

// Remove remove port portion if applicable, sometimes found with ipv4 address
if (strpos($user_ip, '.') !== false && strpos($user_ip, ':') !== false) {
	$user_ip = preg_replace('/:\d+$/', '', $user_ip);
}

// Finally, we validate just in case
if (filter_var($user_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
	// Valid IPv4 address. Nothing further to do here.
} else if (filter_var($user_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
	// Valid IPv6 address. Nothing further to do here.
} else {
	// Invalid IP address. Provide some handling for this
	$user_ip = !empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
}
?>