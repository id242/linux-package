<?php
/*
  Version: 7.7.4
  Purpose: Current Version of UBB.threads
*/

$VERSION = "7.7.4";
$VERBUILD = "20200307";
$VERTYPE = "Release";	// Snapshot or Preview or Release. Build, Type, and Notes-URL are not shown in user footer for "Release" with Debugging off.
$VERNOTES = "https://www.ubbcentral.com/forums/directme.php?to=v774";

// Developer Notes for non-releases
if ($VERTYPE != "Release") {
	$VERNOTES = "https://www.ubbdev.com/forums/ubbthreads.php/ubb/postlist/Board/92/page/1/sort/start/order/desc.html";
}
?>