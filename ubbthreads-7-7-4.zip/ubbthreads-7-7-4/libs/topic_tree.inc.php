<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

$post_tree = array();
global $post_tree;

// If they are a normal user they can only see approved posts
$Viewable = "AND p.POST_IS_APPROVED = 1";
if ($userob->check_access("forum", "APPROVE_ANY", $topic_info['FORUM_ID'])) {
	$Viewable = "";
} else {
	$Viewable = preg_replace("/AND p/", "AND t1", $Viewable);
}

// --------------------------------------
// Grab all of the replies in this thread
$query = "
	SELECT t1.POST_ID,t1.POST_PARENT_ID,t1.POST_POSTED_TIME,t2.USER_DISPLAY_NAME,t1.POST_SUBJECT,t1.POST_IS_APPROVED,t1.POST_ICON,t3.USER_NAME_COLOR,t2.USER_MEMBERSHIP_LEVEL,t2.USER_ID,t3.USER_GROUP_IMAGES
	FROM  {$config['TABLE_PREFIX']}POSTS AS t1 USE INDEX (indx_2),
	{$config['TABLE_PREFIX']}USERS AS t2,
	{$config['TABLE_PREFIX']}USER_PROFILE AS t3
	WHERE t1.TOPIC_ID = ?
	$Viewable
	AND   t1.USER_ID = t2.USER_ID
	AND   t1.USER_ID = t3.USER_ID
	ORDER BY t1.POST_POSTED_TIME ASC
";
$sth = $dbh->do_placeholder_query($query, array($topic_id), __LINE__, __FILE__);
while (list($anumber, $aparent, $aposted, $ausername, $asubject, $aapproved, $aicon, $acolor, $austatus, $ausernumber, $aimages) = $dbh->fetch_array($sth)) {

	if ($aparent == "0") {
		//	continue;
	}
	$post_tree[$aparent][$anumber]['Posted'] = $aposted;
	$post_tree[$aparent][$anumber]['Username'] = $ausername;
	$post_tree[$aparent][$anumber]['Subject'] = $asubject;
	$post_tree[$aparent][$anumber]['Approved'] = $aapproved;
	$post_tree[$aparent][$anumber]['Open'] = $TopicOpen;
	$post_tree[$aparent][$anumber]['Icon'] = $aicon;
	$post_tree[$aparent][$anumber]['Color'] = $acolor;
	$post_tree[$aparent][$anumber]['Status'] = $austatus;
	$post_tree[$aparent][$anumber]['Number'] = $anumber;
	$post_tree[$aparent][$anumber]['UserNumber'] = $ausernumber;
	$post_tree[$aparent][$anumber]['images'] = $aimages;
	$istree = 1;
}


// Find out the number of replies to each parent
if (isset($istree)) {
	$parentkeys = array_keys($post_tree);
	$parentsize = sizeof($parentkeys);

	for ($i = 0; $i < $parentsize; $i++) {
		$childkeys = array_keys($post_tree[$parentkeys[$i]]);
		$childsize = sizeof($childkeys);
		$post_tree[$parentkeys[$i]]['children'] = $childsize;
	}
	$color = show_replies($Board, $first_post, $Number, $sb, $indent, $color, $newintopic, $Viewable, $toffset, $o, 0, $user['USER_TIME_FORMAT']);
}


// ---------------------
// SHOW REPLIES FUNCTION
function show_replies($Board = "", $current = "", $Number = "", $sb = "", $indent = "", $color = "", $newintopic = "", $Viewable = "", $offset = "", $o = "", $currentkey = "", $timeformat = "") {

	global $style_array, $post_tree, $config, $dbh, $ubbt_lang, $replycode, $z, $topic_tree, $modcheck, $html;
	$parentkeys = array_keys($post_tree[$currentkey]);


	$topicread = $_SESSION['topicread'];

	if (!$z) $z = 0;
	if (!$color) $color = "alt-1";

	$indent++;
	for ($x = 0; $x < $post_tree[$currentkey]['children']; $x++) {

		$PNumber = $post_tree[$currentkey][$parentkeys[$x]]['Number'];
		$Posted = $post_tree[$currentkey][$parentkeys[$x]]['Posted'];
		$Poster = $post_tree[$currentkey][$parentkeys[$x]]['Username'];
		$Subject = $post_tree[$currentkey][$parentkeys[$x]]['Subject'];
		$Open = $post_tree[$currentkey][$parentkeys[$x]]['Open'];
		$Approved = $post_tree[$currentkey][$parentkeys[$x]]['Approved'];
		$Icon = $post_tree[$currentkey][$parentkeys[$x]]['Icon'];
		$Color = $post_tree[$currentkey][$parentkeys[$x]]['Color'];
		$PostStatus = $post_tree[$currentkey][$parentkeys[$x]]['Status'];
		$UserNumber = $post_tree[$currentkey][$parentkeys[$x]]['UserNumber'];
		$gimages = $post_tree[$currentkey][$parentkeys[$x]]['images'];
		if (!$Icon) {
			$Icon = "blank.gif";
		}

		$indentsize = (15 * $indent) - 10;

		$time = $html->convert_time($Posted, $offset, $timeformat);
		$alt = ".";

		if (!in_array($PNumber, $_SESSION['topicread']['threaded_read']['track']) && $Posted > $newintopic) {
			$alt = "*";
			$folder = "newfolder.gif";
		} else {
			$alt = "*";
			$folder = "nonewfolder.gif";
		}
		if (($Open == "C") || ($Open == "M")) {
			$Icon = "lock.gif";
		}

		// ---------------------------------------
		// If it isn't approved we need to mark it
		if ($Approved == "0") {
			$Unapproved = "<i class=\"fas fa-exclamation-circle fa-fw\" title=\"{$ubbt_lang['NOT_APPROVED']}\"></i> ";
			$UnapprovedColor = "op5";
		} else {
			$Unapproved = "";
			$UnapprovedColor = "";
		}

		if ($Number != $PNumber) {
			$Subjectlinkstart = "<a href=\"" . make_ubb_url("ubb=showthreaded&Number=$PNumber", "", false) . "\">";
			$Subjectlinkstop = "</a>";
			$Current = "";
		} else {
			$Subjectlinkstart = "<span class=\"bold\">";
			$Subjectlinkstop = "</span>";
			$Current = "<span class=\"fr\"><i class=\"fas fa-angle-double-left fa-fw\"></i></span>";
		}

		$UserStatus = "";
		if ($UserNumber == "1") {
			$Username = $ubbt_lang['ANON_TEXT'];
		} else {
			$PPoster = $Poster;
			$PPoster = $html->user_color($PPoster, $Color, $PostStatus);
			$Username = "<a href=\"" . make_ubb_url("ubb=showprofile&User=$UserNumber", $Poster, false) . "\" rel=\"nofollow\">$PPoster</a>";
		}

		$topic_tree[$z]['color'] = $color;
		$topic_tree[$z]['indentsize'] = $indentsize;
		$topic_tree[$z]['icon'] = $Icon;
		$topic_tree[$z]['Unapproved'] = $Unapproved;
		$topic_tree[$z]['UnapprovedColor'] = $UnapprovedColor;
		$topic_tree[$z]['Subjectlinkstart'] = $Subjectlinkstart;
		$topic_tree[$z]['Subject'] = $Subject;
		$topic_tree[$z]['Subjectlinkstop'] = $Subjectlinkstop;
		$topic_tree[$z]['Current'] = $Current;
		$topic_tree[$z]['Username'] = $Username;
		$topic_tree[$z]['UserStatus'] = $UserStatus;
		$topic_tree[$z]['time'] = $time;
		$topic_tree[$z]['folder'] = $folder;
		$topic_tree[$z]['gimages'] = $html->user_status($UserNumber, $gimages, $modcheck);
		$z++;

		// --------------------
		// alternate the colors
		$color = $html->switch_colors($color);
		if (isset($post_tree[$PNumber]['children'])) {
			$color = show_replies($Board, $PNumber, $Number, $sb, $indent, $color, $newintopic, $Viewable, $offset, $o, $PNumber, $timeformat);
		}
	}

	$indent--;
	return $color;
}

?>