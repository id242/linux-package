<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function trigger_pointer_delete() {
	global $config, $dbh;

	$html = new html;

	// TRIGGER:
	// Delete pointers to moved topics that have expired
	$right_now = $html->get_date();
	$query = "
		select TOPIC_ID
		from {$config['TABLE_PREFIX']}POINTER_DELETE
		where DELETE_ON < ?
	";
	$sth = $dbh->do_placeholder_query($query, array($right_now), __LINE__, __FILE__);
	while (list($tid) = $dbh->fetch_array($sth)) {
		$query = "
			select FORUM_ID
			from {$config['TABLE_PREFIX']}TOPICS
			where TOPIC_ID = ?
		";
		$sti = $dbh->do_placeholder_query($query, array($tid), __LINE__, __FILE__);
		list ($fid) = $dbh->fetch_array($sti);

		$topic = 0;
		$post = 0;
		$query = "
			delete from {$config['TABLE_PREFIX']}TOPICS
			where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($tid), __LINE__, __FILE__);
		if ($dbh->affected_rows()) $topic = 1;

		$query = "
			delete from {$config['TABLE_PREFIX']}POSTS
			where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($tid), __LINE__, __FILE__);

		if ($dbh->affected_rows()) $post = 1;

		$query = "
			update {$config['TABLE_PREFIX']}FORUMS
			set FORUM_POSTS = FORUM_POSTS - $post,
			FORUM_TOPICS = FORUM_TOPICS - $topic
			where FORUM_ID = ?
		";
		$dbh->do_placeholder_query($query, array($fid), __LINE__, __FILE__);

		$query = "
			delete from {$config['TABLE_PREFIX']}POINTER_DELETE
			where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($tid), __LINE__, __FILE__);
	}
}

// Expire Bans
function trigger_ban_expiration() {
	global $config, $dbh;

	$html = new html;
	$rightnow = $html->get_date();

	$expired = array();

	$query = "
		select USER_ID
		from {$config['TABLE_PREFIX']}BANNED_USERS
		where BAN_EXPIRATION <> '0'
		and BAN_EXPIRATION < $rightnow
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	while (list($user_id) = $dbh->fetch_array($sth)) {
		$expired[$user_id] = 1;
		$query = "
			update {$config['TABLE_PREFIX']}USERS
			set USER_IS_BANNED='0'
			where USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($user_id), __LINE__, __FILE__);

		$query = "
			delete from {$config['TABLE_PREFIX']}BANNED_USERS
			where USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($user_id), __LINE__, __FILE__);
	}

	return $expired;
}

function trigger_birthday_notifications($sent, $rightnow, $today) {
	global $config, $dbh, $html, $user, $ubbt_lang;

	// If it's in pending mode, then make sure it isn't stuck
	// if it's not stuck, then we don't do anything
	if (preg_match("#PENDING#", $sent)) {
		$status = preg_replace("#PENDING-#", "", $sent);
		if (($rightnow - $status) < 3600) {
			return;
		}
	}
	$query = "
		update {$config['TABLE_PREFIX']}CACHE
		set CACHE_VALUE = ?
		where CACHE_FIELD = ?
		and CACHE_VALUE = ?
	";
	$dbh->do_placeholder_query($query, array("PENDING-$rightnow", 'birthdays', $sent), __LINE__, __FILE__);

	// If  the database didn't update, then it's already being processed
	if (!$dbh->affected_rows()) {
		return;
	}

	// What month/day are we querying
//		As of 760, we are no longer using SERVER_TIME_OFFSET. All server times are now based on UTC.
	$birthday = $html->convert_time($rightnow, $config['SERVER_TIME_OFFSET'], "n/j/", 1, 0);
//		$birthday = $html->convert_time($rightnow,0,"n/j/",1,0);

	$query = "
		SELECT t1.USER_DISPLAY_NAME,t2.USER_REAL_EMAIL,t2.USER_LANGUAGE
		FROM 	{$config['TABLE_PREFIX']}USER_PROFILE as t2,
					{$config['TABLE_PREFIX']}USERS as t1
		WHERE t1.USER_ID = t2.USER_ID
			AND t2.USER_BIRTHDAY like '$birthday%'
			AND t1.USER_IS_BANNED = 0
			AND t2.USER_ACCEPT_ADMIN_EMAILS = 'On'
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);

	$mailer = new mailer();
	while (list($bname, $b_email, $b_lang) = $dbh->fetch_array($sth)) {
		$mailer->set_language($b_lang);
		$mailer->set_subject('BDAY_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $bname));
		$mailer->add_content('BDAY_CONTENT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->ubbt_mail($b_email);
	}

	// Now set the birthday notices as sent
	$query = "
		update {$config['TABLE_PREFIX']}CACHE
		set CACHE_VALUE = ?
		where CACHE_FIELD = 'birthdays'
	";
	$dbh->do_placeholder_query($query, array($today), __LINE__, __FILE__);

}


function trigger_subscriptions() {
	global $config, $dbh, $html, $user, $ubbt_lang;

	// Find any subscriptions that are active, have a method other than
	// paypal, and also have an end date older than now
	$query = "
		select t1.USER_ID,t1.GROUP_ID,t2.SUBSCRIPTION_NAME
		from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA as t1,
		{$config['TABLE_PREFIX']}SUBSCRIPTIONS as t2
		where t1.SUBSCRIPTION_IS_ACTIVE='1'
		and t1.SUBSCRIPTION_PAYMENT <> 'paypal'
		and t1.SUBSCRIPTION_END_DATE < ?
		and t1.SUBSCRIPTION_END_DATE > 0
		and t1.GROUP_ID = t2.GROUP_ID
	";
	$dbh->do_placeholder_query($query, array($html->get_date()), __LINE__, __FILE__);
	while (list($userid, $groupid, $sub_name) = $dbh->fetch_array($sth)) {

		// Remove user from group
		$query = "
			delete from {$config['TABLE_PREFIX']}USER_GROUPS
			where USER_ID = ?
			and GROUP_ID = ?
		";
		$dbh->do_placeholder_query($query, array($userid, $groupid), __LINE__, __FILE__);

		// Remove Group Image from User
		$group_images = "";
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
			SET USER_GROUP_IMAGES = ?
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($group_images, $userid), __LINE__, __FILE__);

		// Send user a message
		$html->send_message($config['MAIN_ADMIN_ID'], $userid, $ubbt_lang['SUB_ENDED'], $html->substitute($ubbt_lang['SUB_ENDED_BODY'], array('GROUP' => $sub_name)));
	}

	// Clear any paypal subscriptions that are pending and over a day old
	// Clear any check subscriptions that are pending and over 1 month old
	$one_day = $html->get_date() - 86400;
	$one_month = $html->get_date() - (86400 * 30);
	$query = "
		delete from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		where (
			SUBSCRIPTION_PAYMENT='paypal'
			and SUBSCRIPTION_STATUS='PENDING'
			and SUBSCRIPTION_CREATED < ?
		)
		or (
			SUBSCRIPTION_PAYMENT='check'
			and SUBSCRIPTION_STATUS='PENDING'
			and SUBSCRIPTION_CREATED < ?
		)
	";
	$dbh->do_placeholder_query($query, array($one_day, $one_month), __LINE__, __FILE__);
}

?>