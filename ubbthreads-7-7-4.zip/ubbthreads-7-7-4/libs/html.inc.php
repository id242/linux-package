<?php
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

class html {

	var $badwords = array();
	var $replacewords = array();
	var $active_text = array();
	var $active_replace = array();
	var $island_cookies = array();
	var $graemlins = array();
	var $shoutbox_loaded = 0;
	var $colspan = 1;
	var $style_set = 0;
	var $group_images = array();

	function send_column($side = "", $force_column = 0) {
		global $smarty, $config, $userob, $user, $ubbt_lang, $dbh, $style_array, $wrappers;

		$wrapper_id = $style_array['wrappers'];
		$tbopen = $wrappers[$wrapper_id]['open'];
		$tbclose = $wrappers[$wrapper_id]['close'];
		$side_content = "{$side}_COLUMN_BOXES";
		$side_column = "{$side}_COLUMN";

		if (!$force_column) {
			if (($user['USER_HIDE_LEFT_COLUMN'] && $config['DISABLE_LEFT']) || $config['LEFT_COLUMN_PORTAL']) {
				$config['LEFT_COLUMN'] = 0;
			}
			if (($user['USER_HIDE_RIGHT_COLUMN'] && $config['DISABLE_RIGHT']) || $config['RIGHT_COLUMN_PORTAL']) {
				$config['RIGHT_COLUMN'] = 0;
			}
		}

		// Column widths should be defined within the Style (Styles > Left/Right Column Properties > .left_col/.right_col)
		if ($config['LEFT_COLUMN'] && !$config['RIGHT_COLUMN']) {
			$right_display = "invis";
			$this->colspan = 2;
		} elseif (!$config['LEFT_COLUMN'] && $config['RIGHT_COLUMN']) {
			$left_display = "invis";
			$this->colspan = 2;
		} elseif ($config['LEFT_COLUMN'] && $config['RIGHT_COLUMN']) {
			$this->colspan = 3;
		} else {
			$body_width = "fw";
			$left_display = "invis";
			$right_display = "invis";
		}

		$island = "";

		// Do they get a link to the Member List?
		if ($userob->check_access("site", "MEMBER_LIST")) {
			$smarty->assign("user_list", 1);
		} else {
			$smarty->assign("user_list", 0);
		}

		if ($config[$side_column]) {

			$smarty->assign("cp_link", 0);
			$smarty->assign("new_user_link", 0);
			$smarty->assign("myspace_link", 0);
			$smarty->assign("search_link", 0);


			// Need to grab calendar events if they are logged in
			if ($userob->is_logged_in && in_array("calendar", $config[$side_content]) && $config['CALENDAR']) {
				$smarty->assign("calendar", "private");

				// Get current date
				$current_date = date("j");
				$current_month = date("n");
				$current_year = date("Y");

				// Get date 30 days from now
				$month = time() + 2592000;
				$last_date = date("j", $month);
				$last_month = date("n", $month);
				$last_year = date("Y", $month);

				// Get any private events
				$query_vars = array($current_date, $current_month, $current_year, $user['USER_ID']);
				$query = "
					SELECT
						CALENDAR_EVENT_ID, CALENDAR_EVENT_DAY, CALENDAR_EVENT_MONTH, CALENDAR_EVENT_YEAR, CALENDAR_EVENT_SUBJECT
					FROM
						{$config['TABLE_PREFIX']}CALENDAR_EVENTS
					WHERE
						CALENDAR_EVENT_TYPE = 'private'
					AND	(CALENDAR_EVENT_DAY >= ?
						AND CALENDAR_EVENT_MONTH >= ?
						AND CALENDAR_EVENT_YEAR >= ? )
					AND USER_ID = ?
					ORDER BY
						CALENDAR_EVENT_YEAR, CALENDAR_EVENT_MONTH, CALENDAR_EVENT_DAY
					LIMIT 10
				";
				$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
				$events = array();
				$i = 0;
				while ($result = $dbh->fetch_array($sth)) {
					$events[$i]['id'] = $result['CALENDAR_EVENT_ID'];
					$events[$i]['day'] = $result['CALENDAR_EVENT_DAY'];
					$events[$i]['month'] = $result['CALENDAR_EVENT_MONTH'];
					$events[$i]['year'] = $result['CALENDAR_EVENT_YEAR'];
					$events[$i]['subject'] = $result['CALENDAR_EVENT_SUBJECT'];
					$i++;
				}

				$smarty->assign("events", $events);
				$smarty->assign("side", strtolower($side));
				$calendar_island = $smarty->fetch("island_calendar.tpl");
			} else {
				if (!in_array("calendar", $config["RIGHT_COLUMN_BOXES"]) && !in_array("calendar", $config['LEFT_COLUMN_BOXES']) && $config['CALENDAR']) {
					$smarty->assign("calendar", "public");
				}
			}

			$smarty->assign("side", strtolower($side));
			$style_side = strtolower($side);


			// grab all the islands
			foreach ($config[$side_content] as $k => $v) {
				if ($v == "public_calendar" && !$config['CALENDAR']) continue;
				if ($v == "calendar" && !$userob->is_logged_in) continue;
				if ($v == "search" && !$userob->check_access("site", "CAN_SEARCH")) continue;
				if ($v == "shoutbox") {
					if (!$userob->check_access("site", "CAN_SEE_SHOUTS")) continue;
					$this->shoutbox_loaded = 1;
				}
				if ($v == "calendar" && $config['CALENDAR']) {
					$island .= $calendar_island;
				} elseif ($v == "privates") {
					$island .= $privates_island;
				} else {
					ob_start();
					include_once("cache/{$v}.php");
					$island .= ob_get_contents();
					ob_end_clean();
				}
			}
		}

		$smarty_data = array(
			"island_data" => & $island,
			"side_column" => $side_column,
			"left_display" => $left_display,
			"right_display" => $right_display,
			"body_width" => $body_width,
		);

		return array(
			"template" => strtolower($side) . "_column",
			"data" => & $smarty_data,
		);

	}


	// Set the current style
	function set_style($force = 0) {
		global $config, $style_array, $user, $smarty, $userob;

		if (defined('INSTALL')) return;

		$mystyle = '';
		$this->style_set = 1;
		if ($force && $user['USER_STYLE'] == 0) {
			$mystyle = $force;
		} else {
			$mystyle = $user['USER_STYLE'];
		}
		if (!$mystyle || !file_exists("{$config['FULL_PATH']}/styles/{$mystyle}.php")) {
			$mystyle = $config['DEFAULT_STYLE'];
		}

		if (!$userob->is_logged_in && !$force) {
			$mystyle = $_SESSION['myprefs']['style'];
		}

		$check = @include_once("{$config['FULL_PATH']}/styles/{$mystyle}.php");
		if (!$check) {
			include_once("{$config['FULL_PATH']}/styles/{$config['DEFAULT_STYLE']}.php");
		}

		// 7.1 - Force mood setting if it's not set
		if (!array_key_exists('mood', $style_array) || !$style_array['mood']) {
			$style_array['mood'] = "moods/default";
		}

		table_wrapper();

		// Load the style array
		$smarty->assign('style_array', $style_array);

	}


	// ######################################################################
	// SEND_HEADER FUNCTION
	// Grab the title and send the header
	// ######################################################################

	function send_header($header) {
		global $style_array, $tree, $ubb, $config, $myinfo, $ubbt_lang, $dbh, $smarty, $PHPSESSID, $SID, $debug, $forumvisit, $user, $user_ip, $userob, $VERSION, $admin_closed_message, $closed_message;

		if (!defined('HEADER_SENT')) define('HEADER_SENT', 1);
		if (!$user['USER_LANGUAGE']) $user['USER_LANGUAGE'] = $config['LANGUAGE'];
		if (!$user_ip) $this->not_right_bare($ubbt_lang['INVALID_IP']);

		$inputTitle = array_get($header, 'title', '');
		$forumTitle = array_get($header, 'forum_title', '');
		$ogDescription = array_get($header, 'ogDescription', '');
		$ogUrl = array_get($header, 'ogUrl', '');
		$ogPagination = array_get($header, 'ogPagination', '');
		$shareHeader = array_get($header, 'shareHeader', 0);
		$refresh = array_get($header, 'refresh', '');
		$refresh = ($refresh === 0) ? '' : $refresh;
		$user = array_get($header, 'user', '');
		$Board = array_get($header, 'Board', '');
		$bypass = array_get($header, 'bypass', '');
		$onload = array_get($header, 'onload', '');
		$breadcrumb = array_get($header, 'breadcrumb', '');
		$javascript = array_get($header, 'javascript', array());
		$rss = array_get($header, 'rss', '');
		$rss_title = array_get($header, 'rss_title', '');
		$category = array_get($header, 'Category', '');
		$forum_parent = array_get($header, 'forum_parent', '');
		$fheader = array_get($header, 'custom_header_footer', '');
		$post_subject = array_get($header, 'post_subject', '');
		$post_id = array_get($header, 'post_id', '');
		$s_priv = $userob->check_access("site", "CAN_SHOUT");
		$sc_priv = $userob->check_access("site", "CAN_SEE_SHOUTS");

		// If board is set we need to do the breadcrumbs
		if ($Board) {
			if (!sizeof($tree)) {
				list($tree, $style_cache, $lang_cache) = build_forum_cache();
			}

			// Comment-out this line to have Category Titles hidden within the breadcrumbs.
			// This is in addition to the Forum Titles which are already displayed.
			$breadcrumb .= " <i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i> <a href=\"" . make_ubb_url("ubb=cfrm&c=$category", $tree['categories'][$category], false) . "\">{$tree['categories'][$category]}</a>";

			$width = 170;	// Truncate breadcrumb items to this many chars
			$wrap = 34;		// Allow a sequence of unbroken chars to be cut after this many chars
			$more = false;
			$strlen = strlen($config['COMMUNITY_TITLE'] . strip_tags($breadcrumb));

			if (isset($tree['tree'][$Board])) {
				foreach ($tree['tree'][$Board] as $key => $forum_id) {
					$more = true;
					$forum_title = preg_replace("/&nbsp;/", "", $tree[$category][$forum_id]);
					$forum_title = (strlen($forum_title) > $width) ? (substr($forum_title, 0, $width - 3) . '...') : $forum_title;
					$strlen = $strlen + strlen($forum_title);
					$breadcrumb .= " <i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i> <a href=\"" . make_ubb_url("ubb=postlist&Board=$forum_id", $forum_title, false) . "\" style=\"opacity:1.0!important;\">$forum_title</a>";
					if ($forum_id == $Board) {
						break;
					}
					if ($strlen > 100) {
						$more = false;
//						$breadcrumb .= "<br>";
						$strlen = 0;
					}
				}
			}
			$forum_title = preg_replace("/&nbsp;/", "", $tree[$category][$Board]);
			$forum_titletxt = (strlen($forum_title) > $width) ? (substr($forum_title, 0, $width - 3) . '...') : $forum_title;
			$forum_titletxt = wordwrap($forum_titletxt, $wrap, "\n", true);
			$inputTitletxt = (strlen($inputTitle) > $width) ? (substr($inputTitle, 0, $width - 3) . '...') : $inputTitle;
			$inputTitletxt = wordwrap($inputTitletxt, $wrap, "\n", true);
			if ($inputTitle == $forum_title) {
				$breadcrumb .= " <i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i> <a href=\"" . make_ubb_url("ubb=postlist&Board=$Board&page=1", $forum_title, false) . "\" style=\"opacity:1.0!important;\">$forum_titletxt</a>";
			} else {
				$breadcrumb .= " <i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i> <a href=\"" . make_ubb_url("ubb=postlist&Board=$Board&page=1", $forum_title, false) . "\">$forum_titletxt</a> <i class=\"fas fa-angle-right fa-fw\"></i> $inputTitletxt";
			}
			$inputTitle = preg_replace(array('/^\s\s+/', '/\s\s+$/', '/\s\s+/u'), array('', '', ' '), $inputTitle);
			$breadcrumb = preg_replace(array('/^\s\s+/', '/\s\s+$/', '/\s\s+/u'), array('', '', ' '), $breadcrumb);
		}

		$rss_feed = "";
		$rss_title = ubbchars($rss_title);
		if ($rss) {
			$rss_feed = "<link rel=\"alternate\" type=\"application/rss+xml\" title=\"$rss_title\" href=\"{$config['FULL_URL']}/cache/rss{$Board}.xml\">";
		}

		if (!$user) $user = array();
		if (isset($user['loggedout'])) $loggedout = $user['loggedout'];
		if (!$ubb) $ubb = "all_admin";
		$What = $ubb;

		// If we don't have a status then they we need to try and authenticate
		if (!isset($user['USER_MEMBERSHIP_LEVEL']) && !defined('IS_BANNED') && !defined('IS_SQL_ERROR') && !defined('ACCEPT_RULES')) {
			$userob = new user;
			$user = $userob->authenticate();
		}

		// -----------------------------
		// Grab any personal preferences
		$Privates = "";
		$Status = "";
		if (isset($user['USER_TOTAL_PM'])) $Privates = $user['USER_TOTAL_PM'];
		if (isset($user['USER_MEMBERSHIP_LEVEL'])) $Status = $user['USER_MEMBERSHIP_LEVEL'];

		header('Content-Type: text/html; charset=' . $ubbt_lang['CHARSET']);

		// Header Insert for Viewport (responsive layout on mobiles)
		if (!$config['DISABLE_VIEWPORT']) {
			$headerinsert = '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=3">' . "\n";
		}

		// Header Insert for All Pages
		$insert = @file_get_contents("{$config['FULL_PATH']}/includes/header-insert.php");
		$headerinsert .= ($insert === false) ? '' : $insert;

		// Header Insert for Shareaholic HTML Code Snippet
		if ($shareHeader) {
			$insert = @file_get_contents("{$config['FULL_PATH']}/includes/header-shareaholic.php");
			$shareinsert = ($insert === false) ? '' : $insert;
			$headerinsert .= $shareinsert;
		}

		// Header Insert for reCAPTCHA
		if ($config['RECAPTCHA_SITE']) {
			$headerinsert .= '<script src="https://www.google.com/recaptcha/api.js"></script>';
		}

		// Special Header Insert for diplaying topics
		if ($ubb == 'showflat') {
//			$inputTitle .= ' - ' . $forumTitle;
			$headerinsert .= '
<meta property="og:url" content="' . $ogUrl . '">
<meta property="og:type" content="article">
<meta property="og:title" content="' . $inputTitle . '">
<meta property="og:description" content="' . $ogDescription . '">
<meta property="article:section" content="' . $forumTitle . '">
<meta property="og:site_name" content="' . $config['COMMUNITY_TITLE'] . '">
' . $ogPagination;
		} else {
			$insert = @file_get_contents("{$config['FULL_PATH']}/includes/header-insert-descrip.php");
			$headerinsert .= ($insert === false) ? '' : $insert;
			$headerinsert .= '
<meta property="og:type" content="website">';
		}

		$cfrm_kludge = ($ubb == "cfrm" && $inputTitle == $config['COMMUNITY_TITLE']);

		if (!$user['USER_LANGUAGE']) $user['USER_LANGUAGE'] = $config['LANGUAGE'];

		if ($inputTitle == $config['COMMUNITY_TITLE']) {
			require_once("{$config['FULL_PATH']}/languages/{$user['USER_LANGUAGE']}/online.php");
			$inputTitle = array_get($ubbt_lang, $What, $ubbt_lang['all_admin']);
		}

		$powered = "";

		if ($ubb == "portal" || $cfrm_kludge) {
			$inputTitle = $config['COMMUNITY_TITLE'];
			$powered = $ubbt_lang['POWERED_BY'];
		}

		// how many columns
		$columns = 2;

		// Make sure there is a default mood
		if (!$user['USER_MOOD'] && !empty($user['USER_DISPLAY_NAME'])) {
			$user['USER_MOOD'] = "content.gif";
		}

		// If they aren't logged in, or just logged out, give them the proper message
		if ((empty($user['USER_DISPLAY_NAME']) || !$userob->is_logged_in) || ($bypass)) {
			$sfu = "";
			if ($config['SEARCH_FRIENDLY_URLS'] == "1") {
				$sfu = "?";
			} else {
				$sfu = "&";
			}
			$ocurl = urlencode(get_current_url());
			$welcome = "<a href=\"" . make_ubb_url("ubb=login", "", true) . "$sfu" . "ocu=$ocurl\" rel=\"nofollow\"><i class=\"fas fa-sign-in-alt fa-fw\" aria-hidden=\"true\"></i> {$ubbt_lang['BUTT_LOGIN']}</a>";
		} else {
			$welcome = "{$user['USER_DISPLAY_NAME']}";
		}

		// Update the online table
		if (!defined('IS_ERROR')) {
			if ((empty($user['USER_DISPLAY_NAME']) || $user['USER_ID'] == 1) || ($bypass)) {

				// Since we still want to see non logged in users on the online screen
				// we need to track this by IP
				$IP = $user_ip;
				$referer = substr(ubbchars(find_environmental("HTTP_REFERER")), 0, 255);
				$agent = substr(ubbchars(find_environmental("HTTP_USER_AGENT")), 0, 255);
				$Last = $this->get_date();

				// Try to update first.
				if (!$post_id) $post_id = 0;
				$query_vars = array($Last, $What, $Board, $post_id, $post_subject, "-ANON-$IP");
				$query = "
					UPDATE
						{$config['TABLE_PREFIX']}ONLINE
					SET
						ONLINE_LAST_ACTIVITY = ? ,
						ONLINE_SCRIPT_NAME = ? ,
						ONLINE_BROWSING_FORUM = ? ,
						ONLINE_POST_ID = ? ,
						ONLINE_POST_SUBJECT = ?
					WHERE
						ONLINE_DISPLAY_NAME = ?
				";
				$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

				// If no rows affected, this is a new visit
				if (!$dbh->affected_rows()) {

					if (!$post_id) $post_id = 0;
					$query_vars = array(1, "-ANON-$IP", $Last, $What, $Board, 'a', $IP, $referer, $agent, $post_id, $post_subject);
					$query = "
						REPLACE INTO
							{$config['TABLE_PREFIX']}ONLINE
							(USER_ID, ONLINE_DISPLAY_NAME, ONLINE_LAST_ACTIVITY, ONLINE_SCRIPT_NAME, ONLINE_BROWSING_FORUM, ONLINE_USER_TYPE, ONLINE_USER_IP, ONLINE_REFERER, ONLINE_AGENT, ONLINE_POST_ID, ONLINE_POST_SUBJECT)
						VALUES
							(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
					";
					$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__, 1);

					// If we have a referer, insert this into the referer_log table
					// But only if referer logging is enabled
					if ($referer && !preg_match("#({$config['REFERERS']})#", $referer) && ($config['LOG_REFERS'] == 1)) {
						$query_vars = array($Last, $referer);
						$query = "
						INSERT INTO
							{$config['TABLE_PREFIX']}REFERER_LOG
							(REFERER_DATE, REFERER_URL)
						VALUES
							(?, ?)
						";
						$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
					}
				}

			} else {

				// ------------------------------
				// Update the who's online screen
				$Last = $this->get_date();

				// we need to track this by IP
				$IP = $user_ip;
				$referer = substr(ubbchars(find_environmental("HTTP_REFERER")), 0, 255);
				$agent = substr(ubbchars(find_environmental("HTTP_USER_AGENT")), 0, 255);
				if (!$post_id) $post_id = 0;
				$query_vars = array($user['USER_DISPLAY_NAME'], $user['USER_ID'], $Last, $What, $Board, 'r', $IP, $referer, $agent, $post_id, $post_subject);

				$query = "
					REPLACE INTO
						{$config['TABLE_PREFIX']}ONLINE
						(ONLINE_DISPLAY_NAME, USER_ID, ONLINE_LAST_ACTIVITY, ONLINE_SCRIPT_NAME, ONLINE_BROWSING_FORUM, ONLINE_USER_TYPE, ONLINE_USER_IP, ONLINE_REFERER, ONLINE_AGENT, ONLINE_POST_ID, ONLINE_POST_SUBJECT)
					VALUES
						(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
				";
				$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

			}

		}

		// How many columns does the header need to span?
		if ($config['LEFT_COLUMN'] && $config['RIGHT_COLUMN']) {
			$colspan = 3;
		} elseif ($config['LEFT_COLUMN'] || $config['RIGHT_COLUMN']) {
			$colspan = 2;
		} else {
			$colspan = 1;
		}

		if ($fheader) {
			$file = "header_$Board.php";
		} else {
			$file = "header.php";
		}

		ob_start();
		include("{$config['FULL_PATH']}/includes/$file");
		$headerfile = ob_get_contents();
		ob_end_clean();

		if (!is_array($javascript)) {
			$javascript = array();
		}

		$javascript[] = "ubb_jslib.js";

		$javascript = array_reverse($javascript);

		if ($onload && !preg_match("/;$/", $onload)) {
			$onload = "{$onload};";
		}
		if ($config['BODY_ONLOAD']) {
			$onload = "{$onload}{$config['BODY_ONLOAD']}";
		}

		// Which links in the nav menu?
		$cp_link = 0;
		$myspace_link = 0;
		$search_link = 0;
		$new_flasher = "";
		$new_user_link = 0;
		if ($userob->is_logged_in) {
			// Registered Links
			if ($userob->check_access("cp")) {
				$cp_link = 1;
			}

			// Set this up for either a popup menu or left nav link
			$myspace_link = 1;
			if ($user['USER_SHOW_LEFT_MYSTUFF'] == 1) {
				$myspace_link = 2;
			}

			$search_link = 1;
			if ($user['USER_TOTAL_PM']) {
				$lang_string = sprintf($ubbt_lang['UNREAD_PM'], $user['USER_TOTAL_PM']);
				$new_flasher = "<a href=\"" . make_ubb_url("ubb=viewmessages", "", false) . "\"><img src= \"{$config['BASE_URL']}/images/{$style_array['general']}/newpm.gif\" alt=\"$lang_string\" title=\"$lang_string\"></a>";
			} else {
				$new_flasher = "<a href=\"" . make_ubb_url("ubb=viewmessages", "", false) . "\"><i class=\"far fa-envelope fa-fw\" title=\"{$ubbt_lang['MY_PRIVATES']}\"></i></a>";
			}
		} else {
			// Unregistered links
			$new_user_link = 1;
			if ($userob->check_access("site", "CAN_SEARCH")) {
				$search_link = 1;
			}

		}

		$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

		$now = $this->get_date();
		$today = $this->convert_time($now, $user['USER_TIME_OFFSET'], "j", 1, 0);
		$realtoday = $this->convert_time($now, 0, "d", 1, 0);
		// A messy little calendar hack. not even going to explain since hopefully it can be removed it someday ;)
		if ($today == 1 && $realtoday > 20) {
			$today = $realtoday;
		}

		$smarty_data = array(
			"onload" => $onload,
			"headerinsert" => & $headerinsert,
			"refresh" => $refresh,
			"stylesheet" => $stylesheet,
			"inputTitle" => $inputTitle,
			"colspan" => $columns,
			"welcome" => $welcome,
			"breadcrumb" => $breadcrumb,
			"colspan" => $colspan,
			"headerfile" => $headerfile,
			"javascript" => $javascript,
			"rss_feed" => $rss_feed,
			"myid" => $user['USER_ID'],
			"myname" => $user['USER_DISPLAY_NAME'],
			"mylocation" => $user['USER_LOCATION'],
			"myavatar" => $user['USER_AVATAR'],
			"mytotalpm" => $user['USER_TOTAL_PM'],
			"mytotalposts" => $user['USER_TOTAL_POSTS'],
			"cp_link" => $cp_link,
			"myspace_link" => $myspace_link,
			"search_link" => $search_link,
			"new_flasher" => $new_flasher,
			"new_user_link" => $new_user_link,
			"powered" => $powered,
			"today" => $today,
			"mood" => $user['USER_MOOD'],
			"version" => $VERSION,
			'referrer' => ubbchars(get_current_url()),
			's_priv' => $s_priv,
			'sc_priv' => $sc_priv,
			'admin_closed_message' => $admin_closed_message,
			'closed_message' => $closed_message,
		);

		return array(
			"template" => "header",
			"data" => & $smarty_data
		);
	}


	// #######################################################################
	// function send_redirect
	// #######################################################################
	function send_redirect($redirect) {

		global $user, $config, $smarty;

		$delay = 2;
		if (isset($redirect['delay'])) {
			$delay = $redirect['delay'];
		}

		if ($redirect['redirect']) {
			$meta = "\n<meta http-equiv=\"refresh\" content=\"{$delay}; url=" . make_ubb_url("ubb={$redirect['redirect']}", "{$redirect['Subject']}", false) . "\">";
		} else {
			$meta = "";
		}

		$smarty_data = array(
			"heading" => $redirect['heading'],
			"body" => $redirect['body'],
			"returnlink" => $redirect['returnlink'],
		);

		$data = array(
			"header" => array(
				"title" => array_get($redirect, 'heading', ''),
				"refresh" => $meta,
				"user" => $user,
				"Board" => array_get($redirect, 'Board', ''),
				"Category" => array_get($redirect, 'Category', ''),
				"forum_id" => array_get($redirect, 'forum_id', ''),
				"bypass" => 0,
				"onload" => "",
				"breadcrumb" => array_get($redirect, 'breadcrumb', ''),
			),
			"template" => "send_redirect",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => ""
		);

		smartyPrepare($data);
		exit;
	}


	// #############################################################
	// Give the user the board rules, they must accept
	// #############################################################
	function give_rules($view = "") {

		global $user, $ubbt_lang, $debug, $smarty, $config;

		define('ACCEPT_RULES', 1);

		if (!$this->style_set) {
			$this->set_style();
		}

		$ocurl = ubbchars(get_current_url());
		$rules = file_get_contents("{$config['FULL_PATH']}/includes/boardrules.php");

		$smarty_data = array(
			"ocurl" => "$ocurl",
			"rules" => "$rules",
			"view" => "$view",
		);

		$data = array(
			"header" => array(
				"title" => "{$ubbt_lang['BOARD_RULES']}",
				"refresh" => 0,
				"user" => $user,
				"Board" => "",
				"bypass" => 0,
				"onload" => "",
			),
			"template" => "boardrules",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
			"redirect" => "",
		);
		smartyPrepare($data);
		exit;
	}


	// #######################################################################
	// Not right - something went wrong - UHOH!
	// #######################################################################
	function not_right($error = "", $line = "", $file = "") {

		global $user, $userob, $ubbt_lang, $debug, $smarty;
		if (!is_array($ubbt_lang)) {
			@include_once("languages/{$user['USER_LANGUAGE']}/generic.php");
			$smarty->assignByRef('lang', $ubbt_lang);
		}
		if (!$this->style_set) {
			$this->set_style();
		}

		define('IS_ERROR', 1);
		$no_return = true;
		if (defined('NO_RETURN')) {
			$no_return = false;
		}

		@include_once("languages/{$user['USER_LANGUAGE']}/login.php");
		$smarty_data = array(
			"error" => & $error,
			"no_return" => $no_return,
			'not_logged_in' => !(is_object($userob) && $userob->is_logged_in),
			'referrer' => ubbchars(get_current_url()),
		);

		if (defined('INSTALL')) {
			echo "$error<br><br>";
			return;
		}

		if (!defined('HEADER_SENT')) {
			$data = array(
				"header" => array(
					"title" => "{$ubbt_lang['NO_PROCEED']}",
					"refresh" => 0,
					"user" => $user,
					"Board" => "",
					"bypass" => 0,
					"onload" => "",
				),
				"template" => "notright",
				"data" => & $smarty_data,
				"footer" => true,
				"location" => "",
				"redirect" => "",
			);
		} else {
			$data = array(
				"header" => array(),
				"template" => "notright",
				"data" => & $smarty_data,
				"footer" => true,
				"location" => "",
				"redirect" => "",
			);
		}

		smartyPrepare($data);
		exit;
	}

	// #########################################################
	// Basic not_right function used in popups
	// #########################################################
	function not_right_bare($error = "") {
		global $user, $config, $style_array, $smarty, $ubbt_lang;
		define('IS_ERROR', 1);

		@include_once("languages/{$user['USER_LANGUAGE']}/generic.php");
		if (!$this->style_set) {
			$this->set_style();
		}
		if (!$user['USER_LANGUAGE']) $user['USER_LANGUAGE'] = $config['LANGUAGE'];
		if (!is_array($ubbt_lang)) {
			@include_once("languages/{$user['USER_LANGUAGE']}/generic.php");
			$smarty->assignByRef('lang', $ubbt_lang);
		}
		$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";
		$smarty->assign("stylesheet", $stylesheet);
		$smarty->assign("error", $error);
		$smarty->assign("referrer", ubbchars(get_current_url()));
		echo $smarty->fetch("not_right_bare.tpl");
		exit;
	}


	// #######################################################################
	// Check_refer
	// #######################################################################
	function check_refer() {

		global $config, $ubbt_lang;
		$valid = 0;
		$referers = preg_split("#\|#", $config['REFERERS']);
		for ($i = 0; $i <= (sizeof($referers) - 1); $i++) {
			if (stristr(find_environmental('HTTP_REFERER'), $referers[$i])) {
				$valid++;
			}
		}
		if (!$valid) {
			$this->not_right($ubbt_lang['NOT_VALID']);
		}
	}


	// #####################################################################
	// ubbt_setcookie
	// #####################################################################
	function ubbt_setcookie($name, $value = "", $time = 0, $cookiepath = "") {

		global $config;
		if (!$cookiepath) {
			$cookiepath = $config['COOKIE_PATH'];
			if ($config['SEARCH_FRIENDLY_URLS'] && !$cookiepath) {
				$cookiepath = "/";
			}
		}

		setcookie("$name", "$value", $time, $cookiepath);

		if ($value) {
			$_SESSION[$name] = $value;
		} else {
			unset($_SESSION[$name]);
		}

	}


	// #######################################################################
	// Check for any badwords
	// #######################################################################
	function do_censor($text = "") {

		global $config, $dbh;

		$badwords = $this->badwords;
		$replacewords = $this->replacewords;
		if (!sizeof($badwords)) {
			$query = "
				SELECT
					CENSOR_WORD, CENSOR_REPLACE_WITH
				FROM
					{$config['TABLE_PREFIX']}CENSOR_LIST
			";
			$sth = $dbh->do_query($query);
			while ($result = $dbh->fetch_array($sth)) {
				$word = preg_quote($result['CENSOR_WORD'], "/");
				$word = str_replace("\(\.\*\?\)", "(.*?)", $word);
				$badwords[] = "/\b$word\b/i";

				if (!$result['CENSOR_REPLACE_WITH']) {
					$result['CENSOR_REPLACE_WITH'] = $config['REPLACE_WORD'];
				}
				$replacewords[] = $result['CENSOR_REPLACE_WITH'];
			}
			$this->badwords = $badwords;
			$this->replacewords = $replacewords;
		}


		if (is_array($badwords) && is_array($replacewords)) {
			return preg_replace($badwords, $replacewords, $text);
		} else {
			return $text;
		}

	}

	function get_graemlins() {
		global $dbh, $config;
		if (count($this->graemlins > 0)) {
			// Do smilies, since there are our only default
			$query = "
				SELECT
					GRAEMLIN_MARKUP_CODE, GRAEMLIN_SMILEY_CODE, GRAEMLIN_IMAGE, GRAEMLIN_HEIGHT, GRAEMLIN_WIDTH, GRAEMLIN_ORDER
				FROM
					{$config['TABLE_PREFIX']}GRAEMLINS
				WHERE
					GRAEMLIN_IS_ACTIVE='1'
				ORDER BY
					GRAEMLIN_ORDER ASC
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			while ($result = $dbh->fetch_array($sth)) {
				$this->graemlins[] = $result;
			}
		}
	}

	function active_text($text = "") {
		global $config, $dbh;

		$targets = $this->active_text;
		$replacements = $this->active_replace;
		if (!sizeof($targets)) {
			$targets = array();
			$replacements = array();
			foreach ($config['ACTIVE_TEXT_LIST'] as $target => $replace) {
				$target = preg_quote($target, "/");
				$targets[] = "/\b$target\b(?!([^\<\>]*\"\>|[^\<\>]*\" \/\>|[^\<]*\<\/[^\<\>]*\>))/iU";
				$replacements[] = "\\1$replace\\2\\3";
			}
		}

		if (is_array($targets) && is_array($replacements)) {
			return preg_replace($targets, $replacements, $text);
		} else {
			return $text;
		}

	}

	// #######################################################################
	// Markup a string
	// Thanks to Ian Spence for writing this function
	// #######################################################################
	function do_markup($body = "", $type = "", $convert = "") {
		global $config, $userob;

		if (!isset($this->bbcode_parser)) {
			$this->bbcode_parser = new bbcode();
		}

		$this->bbcode_parser->init_post($body, $type, $convert, $this, $config['IMAGE_LIMIT']);
		$this->bbcode_parser->set_fonts($config['MARKUP_FONTS']);
		$this->bbcode_parser->set_sizes($config['MARKUP_FONT_SIZES']);

		if ((($type == "signature" && !$userob->check_access("site", "SIGNATURE_IMAGES")) || (!$config['ALLOW_IMAGE_MARKUP'] && $type != "signature")) && !defined('IS_IMPORT')) {
			$this->bbcode_parser->disallow_tag("img");
		}
		if ($type == "signature") {
			$this->bbcode_parser->disallow_tag("custom");
		}

		//return $this->bbcode_parser->to_text();
		return $this->bbcode_parser->to_html();
	}


	// #######################################################################
	// Send the footer
	// #######################################################################
	function send_footer($header = array()) {

		global $user, $config, $VERSION, $ubbt_lang, $smarty, $timea, $querycount, $zlib, $Board, $mysqltime, $debugprint, $style_array, $wrappers, $style_cache, $lang_cache, $userob, $phpver, $dbtype;

		include("{$config['FULL_PATH']}/libs/ver.inc.php");
		$fheader = array_get($header, 'custom_header_footer', '');
		$Board = array_get($header, 'Board', '');

		$current_url = urlencode(get_current_url());

		if (!sizeof($style_cache)) {
			list($tree, $style_cache, $lang_cache) = build_forum_cache();
		}
		if (!sizeof($lang_cache)) {
			list($tree, $style_cache, $lang_cache) = build_forum_cache();
		}

		if ($userob->is_logged_in) {
			$current_style = $user['USER_STYLE'];
		} else {
			$current_style = $_SESSION['myprefs']['style'];
		}
		if (!$current_style) {
			$current_style = $config['DEFAULT_STYLE'];
		}

		if ($userob->is_logged_in) {
			$current_lang = $user['USER_LANGUAGE'];
		} else {
			$current_lang = $_SESSION['myprefs']['lang'];
		}
		if (!$current_lang) {
			$current_lang = $config['LANGUAGE'];
		}

		// Style Selector
		$style_select = "<select name=\"style\" onchange=\"changePrefs('style',this.form.style.value);\" class=\"form-input\">\n<optgroup label=\"{$ubbt_lang['STYLE_CHOOSER']}\">\n";
		$foundone = 0;
		$style_select .= "<option value=\"0\">{$ubbt_lang['STYLE_DEFAULT']}</option>\n";
		foreach ($style_cache as $k => $v) {
			$foundone++;
			$selected = "";
			$v = str_replace("_", " ", $v);
			if ($k == $current_style) {
				$style_select .= "<option selected=\"selected\" value=\"$k\">$v</option>\n";
			} else {
				$style_select .= "<option value=\"$k\">$v</option>\n";
			}
		}
		if ($foundone > 1) {
			$style_select .= "</optgroup>\n</select>";
		} else {
			$style_select = "";
		}

		// Language Selector
		$lang_select = "<select name=\"lang\" onchange=\"changePrefs('lang',this.form.lang.value);\" class=\"form-input\">\n<optgroup label=\"{$ubbt_lang['LANG_CHOOSER']}\">\n";
		$foundone = 0;
		foreach ($lang_cache as $k => $v) {
			$dir = $v['dir'];
			$name = $v['name'];
			$foundone++;
			$selected = "";
			if ($dir == $current_lang) {
				$lang_select .= "<option selected=\"selected\" value=\"$k\">$name</option>\n";
			} else {
				$lang_select .= "<option value=\"$k\">$name</option>\n";
			}
		}
		if ($foundone > 1) {
			$lang_select .= "</optgroup>\n</select>";
		} else {
			$lang_select = "";
		}

		if (isset($config['CONTACT_LINK_TYPE']) && $config['CONTACT_LINK_TYPE'] == "url") {
			$contactlink = "<a href=\"{$config['CONTACT_URL']}\">{$config['SITE_EMAIL_TITLE']}</a>";
		} else {
			$contactlink = "<a href=\"mailto:{$config['SITE_EMAIL']}\">{$config['SITE_EMAIL_TITLE']}</a>";
		}

		if ($config['PRIVACY_STATEMENT'] == "text") {
			$privacy_statement = "<a href=\"" . make_ubb_url("ubb=viewprivacy", "", false) . "\">{$ubbt_lang['PRIVACY']}</a>";
		} elseif ($config['PRIVACY_STATEMENT'] == "url") {
			$privacy_statement = "<a href=\"{$config['PRIVACY_URL']}\">{$ubbt_lang['PRIVACY']}</a>";
		} else {
			$privacy_statement = "";
		}

		$debug = "";

		if (array_get($config, 'ALLOW_DEBUGGING', false)) {
			$phpver = phpversion();
			$timeb = getmicrotime();
			$time = $timeb - $timea;
			$time = round($time, 3);
			$memoryUsage = number_format(memory_get_usage() / 1024 / 1024, 4);
			$memoryUsagePeak = number_format(memory_get_peak_usage() / 1024 / 1024, 4);
			$servertime = date('Y-m-d H:i:s e');
			$debug = sprintf($ubbt_lang['PAGE_DEBUG'], $phpver, $time, $querycount, $mysqltime, $memoryUsage, $memoryUsagePeak, $zlib, $servertime);
		}

		if ($fheader) {
			$file = "footer_$Board.php";
		} else {
			$file = "footer.php";
		}

		ob_start();
		include("{$config['FULL_PATH']}/includes/$file");
		$footerfile = ob_get_contents();
		ob_end_clean();

		$shoutbox = 0;
		if ($this->shoutbox_loaded === 1) {
			$shoutbox = 1;
		}

		$smarty_data = array(
			'contactlink' => $contactlink,
			'privacy_statement' => $privacy_statement,
			'VERSION' => $VERSION,
			'VERBUILD' => $VERBUILD,
			'VERTYPE' => $VERTYPE,
			'VERNOTES' => $VERNOTES,
			'debug' => $debug,
			'footerfile' => $footerfile,
			'shoutbox' => $shoutbox,
			'colspan' => $this->colspan,
			'styles' => $style_select,
			'langs' => $lang_select,
			'current_url' => $current_url,
		);

		return array(
			"template" => "footer",
			"data" => & $smarty_data,
		);

	}


	// #######################################################################
	// generate_timezone_list
	// #######################################################################
	function generate_timezone_list() {

		static $regions = array(
			DateTimeZone::ALL,
		);

		$timezones = array();
		foreach ($regions as $region) {
			$timezones = array_merge($timezones, DateTimeZone::listIdentifiers($region));
		}

		$timezone_offsets = array();
		foreach ($timezones as $timezone) {
			$tz = new DateTimeZone($timezone);
			$timezone_offsets[$timezone] = $tz->getOffset(new DateTime);
		}

		// Sort timezone by timezone offset
		asort($timezone_offsets);

		$timezone_list = array();
		foreach ($timezone_offsets as $timezone => $offset) {
			$offset_prefix = $offset < 0 ? '-' : '+';
			$offset_formatted = gmdate('H:i', abs($offset));

			$pretty_offset = "UTC${offset_prefix}${offset_formatted}";

			$t = new DateTimeZone($timezone);
			$c = new DateTime(null, $t);
			$current_time = $c->format('g:i A');

			$timezone_list[$timezone] = "${pretty_offset} - $timezone - $current_time";
		}
		return $timezone_list;
	}


	// #######################################################################
	// get_date
	// #######################################################################
	function get_date() {
		global $config;

		$currtime = time();
//		As of 760, we are no longer using SERVER_TIME_OFFSET. All server times are now based on UTC.
//759	$currtime = $currtime + ($config['SERVER_TIME_OFFSET']*3600);
		return $currtime;
	}

	function convert_time($time = "", $offset = "", $timeformat = "", $full = false, $tags = true) {
		global $config, $ubbt_lang, $user;

		if (!$timeformat) {
			$timeformat = $config['TIME_FORMAT'];
		}

		if ((!$user['USER_RELATIVE_TIME'] && !$config['RELATIVE_TIME']) || $user['USER_RELATIVE_TIME'] == '0') {
			$full = true;
		}

		$diff = $this->get_date() - $time;

		$offsetdif = "";
		if ($offset) {
			if (!in_array($offset, DateTimeZone::listIdentifiers())) {
				$offset = "UTC";
			}
			$offsetdiftz = new DateTimeZone($offset);
			$offsetdif = new DateTime('now', $offsetdiftz);
			$time = $time + ($offsetdif->getOffset());        // user's time in Epoch Timestamp format
			$gt = $offsetdiftz->getOffset($offsetdif);        // difference in seconds	ex. -28800
			$tzdif = ($gt / 3600);                            // difference in hours	ex. -8
		}
		$origtime = $time;

		if ($timeformat == "rss") {
			return @date("D, d M Y H:i:s O", $time);
		}

		// Grab the time portion of their prefs
		if (strpos($timeformat, "H") !== false) {
			$time_format = "H:i";
		} elseif (strpos($timeformat, "G") !== false) {
			$time_format = "G:i";
		} else {
			$time_format = "h:i A";
		}

		$parts = array();

//		As of 760, we are no longer using SERVER_TIME_OFFSET. All server times are now based on UTC.
//759	$adj_time = time() + (($config['SERVER_TIME_OFFSET'] + $offset) * 3600);
//		$adj_time = time() + ($offsetdif);
		$adj_time = time() + ($gt);

		$this_hour = date("H", $adj_time);
		$this_min = date("i", $adj_time);
		$this_sec = date("s", $adj_time);

		$midnight = $adj_time - ($this_hour * 3600) - ($this_min * 60) - ($this_sec);

		// Is it today or yesterday?
		if (!$full && ($origtime > ($midnight - 86400)) && $diff > -1) {
			if ($origtime > $midnight) {
				if ($diff < 3600) {
					$minutes = intval($diff / 60);
					$seconds = $diff - ($minutes * 60);
					if ($seconds == 1) {
						$seconds_print = $this->substitute($ubbt_lang['SECOND_AGO'], array('SEC' => $seconds));
					} else {
						$seconds_print = $this->substitute($ubbt_lang['SECONDS_AGO'], array('SECS' => $seconds));
					}
					$minutes_print = "";
					if ($minutes) {
						$seconds_print = "";
						if ($minutes == 1) {
							$minutes_print = $this->substitute($ubbt_lang['MINUTE_AGO'], array('MIN' => $minutes));
						} else {
							$minutes_print = $this->substitute($ubbt_lang['MINUTES_AGO'], array('MINS' => $minutes));
						}
					}
					$parts = array("{$minutes_print}{$seconds_print} {$ubbt_lang['AGO']}");
				} else {
					$hours = intval($diff / 3600);
					if ($hours == 1) {
						$hours_print = $this->substitute($ubbt_lang['HOUR_AGO'], array('HOUR' => $hours)) . " ";
					} else {
						$hours_print = $this->substitute($ubbt_lang['HOURS_AGO'], array('HOURS' => $hours)) . " ";
					}
					$parts = array("{$hours_print} {$ubbt_lang['AGO']}");
				}
			} else {
				$parts = array($ubbt_lang['YESTERDAY_AT'], date("$time_format", $time));
			}
		}

		if (count($parts) == 0) {
			$parts = explode('|', @date($timeformat, $time));
		}

		if (count($parts) > 1) {
			if ($tags) {
				return '<span class="date">' . trim($parts[0]) . '</span> <span class="time">' . trim($parts[1]) . '</span>';
			} else {
				return trim($parts[0]) . " " . trim($parts[1]);
			}
		} else {
			if ($tags) {
				return '<span class="date">' . trim($parts[0]) . '</span>';
			} else {
				return trim($parts[0]);
			}
		}
	}


	// #######################################################################
	// Switch_colors - This will switch colors between the 2 table colors
	// #######################################################################
	function switch_colors($color = "") {
		return ($color == "alt-1") ? "alt-2" : "alt-1";
	}

	function &paginate_logic($current, $total, $border) {
		$pages = array();

		if ($total <= 1) {
			return $pages;
		}

		if ($total < $border * 5) {
			for ($i = 1; $i <= $total; $i++) {
				$pages[] = array("$i", "$i");
			}

			return $pages;
		}

		for ($i = 1; $i <= $border; $i++) {
			$pages[] = array("$i", "$i");
		}

		$bottom = $current + $border;
		$top = $current + $border;

		if ($bottom < ($border + 1) || $top > $total) {
			$pages[] = array("&hellip;", round($total / 2));
		}

		if (($bottom > 1) || ($top < $total)) {
			$x = array();

			for ($i = ($border + 1); $i <= $total - $border; $i++) {
				if (abs($current - $i) <= $border) {
					$x[] = array("$i", "$i");
				}
			}

			$start = $x[0][0] + $border;
			$end = $x[count($x) - 1][0];

			if (($current >= (($border + 1) * 2)) && $pages[count($pages) - 1][0] != "&hellip;") {
				$pages[] = array("&hellip;", round($start / 2));
			}

			foreach ($x as $y) {
				$pages[] = $y;
			}

			if (($current < $total - (($border * 2) + 1)) && $pages[count($pages) - 1][0] != "&hellip;") {
				$pages[] = array("&hellip;", $end + round(($total - $end) / 2) - 1);
			}
		}

		for ($i = $total - ($border - 1); $i <= $total; $i++) {
			$pages[] = array("$i", "$i");
		}

		return $pages;
	}

	function paginate($current, $total, $url, $title = "") {
		global $ubbt_lang, $smarty;

		static $paginate_id = 0;

		if ($total <= 1) {
			return '';
		}

		$border = 2;

		if ($current > $total) {
			$current = $total;
		} else if ($current < 1) {
			$current = 1;
		}

		$page_html = $this->substitute($ubbt_lang['PAGE_TEXT'], array('CURRENT' => number_format($current), 'TOTAL' => number_format($total)));

		$pages =& $this->paginate_logic($current, $total, $border);

		if ($current > 1) {
			// Add prev link
			array_unshift($pages, array('<i class="fas fa-angle-left" aria-hidden="true"></i>', $current - 1));
		}

		if ($current < $total) {
			$pages[] = array('<i class="fas fa-angle-right" aria-hidden="true"></i>', ($current + 1));
		}

		$c = count($pages);

		for ($i = 0; $i < $c; $i++) {
			$tmp = $pages[$i];
			$pages[$i] = array($tmp[0], 'ubb=' . $url . $tmp[1], $title, $this->substitute($ubbt_lang['GO_TO_PAGE'], array('PAGE' => $tmp[1])));

			if ($tmp[1] == $current) {
				$pages[$i][1] = "";
			}
		}

		$smarty->assignByRef('pages', $pages);
		$smarty->assignByRef('page_html', $page_html);
		$smarty->assign('show_jump', $total > ($border * 5));
		$smarty->assign('url', $url);
		$smarty->assign('paginate_id', $paginate_id);

		$paginate_id++;

		// -------------------------------
		// require the pagination template
		return $smarty->fetch('pagination.tpl');
	}

	// #######################################################################
	// Modern Hop-To Menu
	// Generate a popup menu that allows single click jump to allowed forum(s)
	// #######################################################################
	function jump_box($Board = "") {
		global $config, $ubbt_lang, $tree, $userob, $style_cache, $lang_cache;

		// If not configured, show them the classic jump box
		if (!array_key_exists('HOPTO_WIDTH', $config) || !$config['HOPTO_WIDTH']) return $this->hop_to($Board);

		if (!sizeof($tree)) {
			list($tree, $style_cache, $lang_cache) = build_forum_cache();
		}

		$width = $config['HOPTO_WIDTH'];
		$popup = 1;
		$hopTo = '<table class="popup_menu">';
		foreach ($tree['categories'] as $cat => $cat_title) {
			$forums = 0;
			$cat_title = (strlen($cat_title) > $width) ? (substr($cat_title, 0, $width - 3) . '...') : $cat_title;
			$url = make_ubb_url("ubb=cfrm&c=$cat", "", false);
			$hopCat = "<tr><td class=\"popup_menu_content\"><a href=\"$url\">$cat_title</a></td></tr>";
			if (!isset($tree[$cat])) continue;
			foreach ($tree[$cat] as $forum_id => $forum_title) {
				if (!$userob->check_access("forum", "SEE_FORUM", $forum_id) || $tree['active'][$forum_id] != 1) {
					continue;
				}
				$level = substr_count($forum_title, "&nbsp;&nbsp;&nbsp;");
				$forum_title = str_replace("&nbsp;", "", $forum_title);
				$forum_title = (strlen($forum_title) > $width) ? (substr($forum_title, 0, $width - 3 - $level) . '...') : $forum_title;
				if ($level > 0) {
					$forum_title = str_repeat("&nbsp;", $level) . "<i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i>" . $forum_title;
				} else {
					$forum_title .= "<i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i>";
				}
				$url = make_ubb_url("ubb=postlist&Board=$forum_id&page=1", "", false);
				$hopCat .= "<tr><td class=\"popup_menu_content\"><a href=\"$url\">$forum_title</a></td></tr>";
				$forums++;
			}
			if ($forums) $hopTo .= $hopCat;
		}

		$hopTo .= '</table>';
		return array($hopTo, $popup);
	}

	// #######################################################################
	// Classic Jump Box
	// Generate a jump box to jump to other allowed forum(s)
	// #######################################################################
	function hop_to($Board = "") {

		global $userob, $smarty, $dbh, $config, $ubbt_lang, $debug, $tree;

		if (!sizeof($tree)) {
			list($tree, $style_cache, $lang_cache) = build_forum_cache();
		}

		$width = 35;	// The classic jump box gets a default max-character per item, making it mobile friendly.
		$choices = "";
		$category = "";
		$forums = 0;
		$popup = 0;
		foreach ($tree['categories'] as $cat => $cat_title) {
			$category = "";
			$forums = 0;
			$cat_title = (strlen($cat_title) > $width) ? (substr($cat_title, 0, $width - 3) . '...') : $cat_title;
			$category .= "<option value=\"c:$cat\">$cat_title ------</option>";
			if (!isset($tree[$cat])) continue;
			foreach ($tree[$cat] as $forum_id => $forum_title) {
				$selected = "";
				$level = substr_count($forum_title, "&nbsp;&nbsp;&nbsp;");
				if ($Board == $forum_id) $selected = "selected=\"selected\"";
				if (!$userob->check_access("forum", "SEE_FORUM", $forum_id) || $tree['active'][$forum_id] != 1) {
					continue;
				}
				$forum_title = str_replace("&nbsp;", "", $forum_title);
				$forum_title = (strlen($forum_title) > $width) ? (substr($forum_title, 0, $width - 3 - $level) . '...') : $forum_title;
				if ($level > 0) {
					$forum_title = str_repeat("&nbsp;&nbsp;", $level) . $forum_title;
				} else {
					$forum_title .= "&nbsp;&nbsp;";
				}
				$category .= "<option value=\"$forum_id\" $selected>$forum_title</option>";
				$forums++;
			}
			if ($forums) $choices .= $category;
		}

		$smarty->assign('choices', $choices);
		return array($smarty->fetch('jumper.tpl'), $popup);
	}

	// #######################################################################
	// Do login - Logs the user on
	// #######################################################################
	function do_login($Username = "", $Password = "", $rememberme = "", $from = "", $oncomplete = "") {

		global $userob, $smarty, $config, $dbh, $ubbt_lang, $forumvisit, $debug, $topicread, $myinfo, $user_ip;

		// -----------------------------------------
		// Connect to db and authenticate this user
		$query = "
			SELECT
				t1.USER_DISPLAY_NAME, t2.USER_REAL_EMAIL, t3.USER_LAST_VISIT_TIME, t1.USER_PASSWORD, t1.USER_ID, t2.USER_TEMPORARY_PASSWORD, t1.USER_IS_APPROVED, t1.USER_IS_BANNED, t1.USER_IS_UNDERAGE
			FROM
				{$config['TABLE_PREFIX']}USERS AS t1,
				{$config['TABLE_PREFIX']}USER_PROFILE AS t2,
				{$config['TABLE_PREFIX']}USER_DATA AS t3
			WHERE
				(t1.USER_LOGIN_NAME = ? OR t2.USER_REAL_EMAIL = ?)
			AND t1.USER_ID = t2.USER_ID
			AND t1.USER_ID = t3.USER_ID
		";
		$sth = $dbh->do_placeholder_query($query, array($Username, $Username), __LINE__, __FILE__);
		$user = $dbh->fetch_array($sth);

		list($CheckUser, $laston, $pass, $Uid, $temppass, $approved, $isbanned, $coppauser) = $user;
		$dbh->finish_sth($sth);

		$_SESSION['forumvisit']['lastonline'] = $user['USER_LAST_VISIT_TIME'];
		$_SESSION['forumvisit']['visit'] = array();


		if (!$user['USER_DISPLAY_NAME']) {
			$this->not_right($ubbt_lang['NO_AUTH']);
		}

		if ($user['USER_IS_APPROVED'] == "no") {
			if ($user['USER_IS_UNDERAGE']) {
				$this->not_right($this->substitute($ubbt_lang['PARENT_FORM'], array('COPPA_URL' => make_ubb_url("ubb=coppaform", "", true))));
			} else {
				$this->not_right($ubbt_lang['UNAPPROVED']);
			}
		} else if ($user['USER_IS_APPROVED'] != "yes") {
			$this->not_right($ubbt_lang['UNVERIFIED']);
		}

		// -------------------------------------------------------------
		// We allow them to login if they are using the correct password
		// of if they are using the temporary password
		$bad = "yes";

		if ((crypt($Password, $user['USER_PASSWORD']) != $user['USER_PASSWORD']) && (md5($Password) != $user['USER_PASSWORD'])) {
			$bad = "yes";
		} else {
			$bad = "no";
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
				SET USER_TEMPORARY_PASSWORD=''
				WHERE USER_ID = ?
			";
			$dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
		}
		if ($user['USER_TEMPORARY_PASSWORD']) {
			if (md5($Password) == $user['USER_TEMPORARY_PASSWORD']) {
				$bad = "no";
				$query = "
					UPDATE {$config['TABLE_PREFIX']}USERS
					SET USER_PASSWORD = ?
					WHERE USER_ID = ?
				";
				$dbh->do_placeholder_query($query, array($user['USER_TEMPORARY_PASSWORD'], $user['USER_ID']), __LINE__, __FILE__);
				$query = "
					UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
					SET USER_TEMPORARY_PASSWORD = ''
					WHERE USER_ID = ?
				";
				$dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
			}
		}
		if ($bad == "yes") {
			return array(
				"header" => array(
					"title" => $ubbt_lang['BAD_PASS'],
					"refresh" => "<meta http-equiv=\"refresh\" content=\"8; url=" . make_ubb_url("ubb=login", "", false) . "\">",
					"user" => "",
					"Board" => "",
					"bypass" => 0,
					"onload" => "",
				),
				"template" => "badlogin",
				"data" => array(),
				"footer" => true,
				"location" => "",
				"redirect" => "",
			);
		}

		// --------------------------------------
		// Set a cookie or register a session var
		srand((double)microtime() * 1000000);
		$newsessionid = md5(rand(0, 32767));
		$autolog = md5("^^{$config['BOARD_KEY']}^^{$user['USER_ID']}{$user['USER_PASSWORD']}");

		// Set a better default cookie expiration maximum. 30 days max; 7 days if no value is set.
		if (!isset($config['COOKIE_LIFETIME']) || empty($config['COOKIE_LIFETIME'])) $config['COOKIE_LIFETIME'] = 604800;
		if ($config['COOKIE_LIFETIME'] > 2592000) $config['COOKIE_LIFETIME'] = 2592000;

		// -------------------------------------------------------------------
		// If this is their first visit for this browser session, set a cookie
		if (!$laston) {
			$laston = $this->get_date();
		}

		if ($rememberme || get_input($config['COOKIE_PREFIX'] . "ubbt_hash", "cookie", null) != null) {
			$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_myid", "{$user['USER_ID']}", time() + $config['COOKIE_LIFETIME'], "{$config['COOKIE_PATH']}");
			$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_hash", "$autolog", time() + $config['COOKIE_LIFETIME'], "{$config['COOKIE_PATH']}");
		} else {
			$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_myid", "{$user['USER_ID']}", "0", "{$config['COOKIE_PATH']}");
			$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_hash", "$autolog", "0", "{$config['COOKIE_PATH']}");
		}

		$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_mysess", "$newsessionid", "0");
		$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_pass", "", time() - 3600);
		$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_dob", "", time() - 3600);

		// Check for multiple logins
		$myids = $myinfo['myids'];
		$multiple = false;
		if (empty($myids) && $Uid > 1) {
			$myids .= "-{$Uid}-";
		} elseif (!stristr($myids, "-{$Uid}-") && $Uid > 1) {
			$multiple = true;
			$myids .= "-{$Uid}-";
		}
		$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_x", $myids, time() + $config['COOKIE_LIFETIME']);

		if ($multiple) {
			$idarray = explode("-", $myids);
			$inlist = "";
			$double_check = 0;
			foreach ($idarray as $k => $v) {
				if (!is_numeric($v)) continue;
				$inlist .= "'$v',";
				$double_check++;
			}
			$inlist = preg_replace("/,$/", "", $inlist);

			// Make sure we have at least 2 identities
			if ($double_check > 1) {
				$profiles = "";
				$query = "
					SELECT USER_ID, USER_DISPLAY_NAME
					FROM {$config['TABLE_PREFIX']}USERS
					WHERE USER_ID IN ($inlist)
				";
				$sth = $dbh->do_query($query, __LINE__, __FILE__);
				$double_check = 0;
				while (list($muid, $mdisplay) = $dbh->fetch_array($sth)) {
					$double_check++;
					$profiles .= "<a href='" . make_ubb_url("ubb=showprofile&User=$muid", $mdisplay, true) . "'>$mdisplay</a>, ";
				}
				$profiles = preg_replace("/, $/", "", $profiles);

				if ($double_check > 1) {

					$body = $this->substitute($ubbt_lang['MULTI_LOGIN_BODY'], array('IP_ADDY' => $user_ip, 'ACCOUNTS' => $profiles));

					$query = "
						SELECT USER_ID
						FROM {$config['TABLE_PREFIX']}USER_PROFILE
						WHERE USER_NOTIFY_MULTI = '1'
					";
					$sth = $dbh->do_query($query, __LINE__, __FILE__);
					while (list($sendto) = $dbh->fetch_array($sth)) {
						$this->send_message($config['MAIN_ADMIN_ID'], $sendto, $ubbt_lang['MULTI_LOGINS'], $body);
					}
				}
			}
		}

		$topicread = "";

		$date = $this->get_date();
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USER_DATA
			SET USER_LAST_VISIT_TIME = ?
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($date, $user['USER_ID']), __LINE__, __FILE__);

		$query = "
			UPDATE {$config['TABLE_PREFIX']}USERS
			SET USER_SESSION_ID = ?
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($newsessionid, $user['USER_ID']), __LINE__, __FILE__);

		// ------------------------------------------
		// Get rid of their IP from the online table
		$ip = "-ANON-" . $user_ip;
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}ONLINE
			WHERE ONLINE_DISPLAY_NAME = ?
		";
		$dbh->do_placeholder_query($query, array($ip), __LINE__, __FILE__);

		$userob->build_permissions($user['USER_ID']);
		rebuild_pm_count($user['USER_ID']);
		$userob->cache_watch_lists($user['USER_ID']);

		rebuild_islands(0, array("online"));

		// Now send them to the start_page function
		return $this->start_page($user['USER_ID'], $newsessionid, "", 0, $from, $oncomplete);

	}

	// #######################################################################
	// Start_page - Sends the user to their start page
	// #######################################################################
	function start_page($myid = "", $mysess = "", $chosenlanguage = "", $myhome = "", $from = "", $oncomplete = "") {
		global $config, $dbh, $ubbt_lang, $myinfo, $debug, $smarty;

		// -----------------------------------------------------
		// Connect to db and get total posts and last logon, etc
		if ($mysess) {
			$myinfo['session'] = $mysess;
		}
		if ($myid) {
			$myinfo['id'] = $myid;
		}


		$userob = new user;
		$user = $userob->authenticate("USER_START_VIEW");
		list($start_view, $CheckUser, $pass, $sessionid, $status, $privates, $Uid) = $user;

		if ($config['BOARD_IS_CLOSED'] && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			$insert = @file("{$config['FULL_PATH']}/includes/closedforums.php");
			if (!is_array($insert)) {
				$insert = @file("{$config['BASE_URL']}/includes/closedforums.php");
			}

			if ($insert) {
				$closedforums = implode('', $insert);
				$smarty->assign("closedforums", $closedforums);
			}

			$this->not_right($closedforums);
		}

		// If we don't get a UID back then the authentication failed
		if (!$user['USER_ID']) {
			$this->not_right($ubbt_lang['NO_AUTH']);
		}

		if ($start_view == "lists") {
			$main = "myhome&type=lists";
		} else {
			$main = "cfrm";
		}

		if ($from == "cp") {
			$main = "admin/dashboard.php";
		}

		$redirect = "";
		if ($oncomplete && oncomplete_validate($oncomplete)) {
			$redirect = $oncomplete;
			$main = "";
		}

		if (strpos($from, "http") !== false) {
			header("Location: " . str_replace('&amp;', '&', $from));
			exit;
		}

		if ($from) {
			$redirect = $from;
			$main = "";
		}


		return array(
			"template" => "",
			"footer" => false,
			"location" => "$main",
			"login" => true,
			"redirect" => "",
			"http_redirect" => "$redirect",
		);
	}

	// #################################
	// Check if a user is still banned
	// ###############################
	function check_ban($uid = "", $timeoffset, $timeformat) {

		global $config, $dbh, $ubbt_lang, $smarty;
		require_once("{$config['FULL_PATH']}/libs/triggers.inc.php");
		$expires = trigger_ban_expiration();

		if (isset($expires[$uid])) {
			return;
		}

		$query = "
			SELECT
				t1.BAN_EXPIRATION, t1.BAN_REASON, t2.USER_LANGUAGE
			FROM
				{$config['TABLE_PREFIX']}BANNED_USERS AS t1,
				{$config['TABLE_PREFIX']}USER_PROFILE AS t2
			WHERE
				t1.USER_ID = ?
			AND t2.USER_ID = t1.USER_ID
		";
		$sth = $dbh->do_placeholder_query($query, array($uid), __LINE__, __FILE__);
		list ($expires, $reason, $language) = $dbh->fetch_array($sth);
		define('IS_BANNED', 1);
		if (!$language) $language = $config['LANGUAGE'];
		require_once("{$config['FULL_PATH']}/languages/{$language}/generic.php");
		$smarty->assignByRef('lang', $ubbt_lang);
		if (!$expires) {
			$extra_text = $ubbt_lang['BAN_PERM'];
		} else {
			$expires = $this->convert_time($expires, $timeoffset, $timeformat);
			$extra_text = $this->substitute($ubbt_lang['BAN_EXPIRES'], array('EXPIRES' => $expires));
		}
		if ($reason) $reason = "<br><br>$reason";
		$this->not_right("{$ubbt_lang['YOU_BANNED']} $extra_text{$reason}", 0);
	}


	// #######################################################################
	// Create the icon selection list
	// #######################################################################
	function icon_select($icon = "") {

		global $smarty, $ubbt_lang, $config, $debug, $style_array;

		if (!$icon) {
			$icon = "book.gif";
		}
		@list($selected, $extra) = @preg_split("#\.#", $icon);
		${$selected} = " checked=\"checked\"";
		$iconlist = "";

		// ------------------------------------------
		// We now load the entire directory of images
		$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['icons']}");
		$i = 0;
		while (($file = readdir($dir)) != false) {
			if (($file == ".") || ($file == "..") || ($file == "image.gif")) {
				continue;
			}
			if (!preg_match("/\.(?:gif|jpg|png)/", $file)) {
				continue;
			}
			$filename = preg_replace("/\.(.*?)$/", "", $file);
			if (!isset(${$filename})) {
				${$filename} = "";
			}
			if ($filename == "blank") {
				continue;
			}
			$iconlist .= "<span class=\"p10 nw\"><input type=\"radio\" name=\"Icon\" id=\"Icon-$file\" value=\"$file\" ${$filename}><label for=\"Icon-$file\"> <img src=\"{$config['BASE_URL']}/images/{$style_array['icons']}/$file\" alt=\"$filename\" title=\"$filename\"></label></span> ";
		}
		$selected = "";
		if ($icon == "blank.gif") {
			$selected = " checked=\"checked\"";
		}
		$iconlist .= "<span class=\"p6 nw\"><input type=\"radio\" name=\"Icon\" id=\"Icon-blank.gif\" value=\"blank.gif\" $selected><label for=\"Icon-blank.gif\"><span class=\"small\">{$ubbt_lang['NO_ICON']}</span></label></span>";

		$smarty->assign('iconlist', $iconlist);

		return $smarty->fetch('icon_select.tpl');
	}


	// #######################################################################
	//  Send_messages
	// #######################################################################
	function send_message($Sender = "", $To = "", $Subject = "", $Mess = "", $Group = "", $RawBody = "") {

		global $ubbt_lang, $dbh, $config;
		$date = $this->get_date();

		if (!$RawBody) $RawBody = $Mess;

		$mailer = new mailer();

		// Find out if we are sending to a group of users
		$admin_q = "Administrator";
		$mod_q = "%Moderator";
		$user_q = "User";
		$To_q = $To;

		if ($Group == "ADMIN_GROUP") {
			$selector = "AND t1.USER_MEMBERSHIP_LEVEL = '$admin_q'";
		} elseif ($Group == "MODERATOR_GROUP") {
			$selector = "AND t1.USER_MEMBERSHIP_LEVEL LIKE '$mod_q'";
		} elseif ($Group == "A_M_GROUP") {
			$selector = "AND (t1.USER_MEMBERSHIP_LEVEL = '$admin_q' OR t1.USER_MEMBERSHIP_LEVEL LIKE '$mod_q')";
		} elseif ($Group == "ALL_USERS") {
			$selector = "";
		} else {
			$selector = "AND t1.USER_ID = '$To_q'";
		}

		// ------------------------------------
		// Grab everyone we are sending this to
		$query = "
			SELECT DISTINCT
				t1.USER_DISPLAY_NAME, t1.USER_MEMBERSHIP_LEVEL, t1.USER_ID, t2.USER_NOTIFY_ON_PM, t2.USER_REAL_EMAIL, t2.USER_LANGUAGE
			FROM
				{$config['TABLE_PREFIX']}USERS AS t1,
				{$config['TABLE_PREFIX']}USER_PROFILE AS t2
			WHERE
				t1.USER_ID = t2.USER_ID
			$selector
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		while (list($To, $Status, $Number, $Notify, $Email, $Lang) = $dbh->fetch_array($sth)) {

			// Increment the recipients total number of unread pms
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
				SET USER_TOTAL_PM = USER_TOTAL_PM + 1
				WHERE USER_ID = ?
			";
			$dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

			$query_vars = array($date, 0, $Subject, $Sender, $date);
			$query = "
				INSERT INTO
					{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
					(TOPIC_TIME, TOPIC_REPLIES, TOPIC_SUBJECT, USER_ID, TOPIC_LAST_REPLY_TIME)
				VALUES
					(?, ?, ?, ?, ?)
			";
			$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
			$query = "
				SELECT last_insert_id()
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			list($message_id) = $dbh->fetch_array($sth);

			$query_vars = array($message_id, $Sender, $Mess, $date, $RawBody);
			$query = "
				INSERT INTO
					{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
					(TOPIC_ID, USER_ID, POST_BODY, POST_TIME, POST_DEFAULT_BODY)
				VALUES
					(? , ? , ? , ? , ?)
			";
			$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

			$query_vars = array($message_id, $Number, 0);
			$query = "
				INSERT INTO
					{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
					(TOPIC_ID, USER_ID, MESSAGE_LAST_READ)
				VALUES
					(? , ? , ?)
			";
			$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

			if ($Notify == "yes") {
				$mailer->set_language($Lang);
				$mailer->set_subject('PMN_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
				$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $To));
				$mailer->add_content('PMN_CONTENT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE'], 'FROMNAME' => $ubbt_lang['UBB_SYSTEM']));
				$mailer->add_content('PMN_CONTENT1', array('PM_URL' => make_ubb_url("ubb=viewmessage&message=$message_id&gonew=1", "", true, true)), true);
				$mailer->add_content('PMN_CONTENT2', array(), true);
				$mailer->add_post($ubbt_lang['UBB_SYSTEM'], $Subject, array(), $Mess, $RawBody);
				$mailer->ubbt_mail($Email);
			}
		}
		$dbh->finish_sth($sth);
	}

	function create_text_editor($name = "", $value = "", $tabindex = "", $allow_images = true, $allow_media = true) {
		global $config, $smarty, $ubbt_lang, $user, $user_ip, $dbh, $style_array, $bbcode_tags;

		// --------------------------------------------------
		// Grab all graemlins from the database

		if (count($this->graemlins) == 0) {
			$this->get_graemlins();
		}

		$i = 0;
		$graemlinlist = "";
		$altcode = "";
		$n = 0;
		$more_smilies = false;

// SCEDITOR BEGIN
		if ($config['EDITOR'] == "sceditor") {
			$graemlinlistmore = "";
			foreach ($this->graemlins as $graemlin) {
				$code = $graemlin['GRAEMLIN_MARKUP_CODE'];
				$smiley = $graemlin['GRAEMLIN_SMILEY_CODE'];
				$image = $graemlin['GRAEMLIN_IMAGE'];

				if (stristr("$code", "$")) {
					@eval("\$code = $code;");
				}
				$code = ":$code:";
				$altcode = "$code";
				if ($smiley) {
					$smiley = addslashes($smiley);
					$code = $smiley;
					$altcode .= "     $smiley";
				}

				if ($n < 20) {
					$graemlinlist .= <<<EOF
"$code": "{$config[FULL_URL]}/images/{$style_array['graemlins']}/$image",
EOF;
				}
				$n++;

				if ($n > 20) {
					$more_smilies = true;
					$graemlinlistmore .= <<<EOF
"$code": "{$config[FULL_URL]}/images/{$style_array['graemlins']}/$image",
EOF;
				}
			}
			$font_families = "";
			foreach ($config['MARKUP_FONTS'] as $k => $font) {
				$font_families .= <<<EOF
$font,
EOF;
			}
			$font_families = rtrim($font_families, ",");
		} else {


// STANDARD/BASIC EDITOR BEGIN
			foreach ($this->graemlins as $graemlin) {
				$code = $graemlin['GRAEMLIN_MARKUP_CODE'];
				$smiley = $graemlin['GRAEMLIN_SMILEY_CODE'];
				$image = $graemlin['GRAEMLIN_IMAGE'];

				if (stristr("$code", "$")) {
					@eval("\$code = $code;");
				}
				$code = ":$code:";
				$altcode = "$code";
				if ($smiley) {
					$smiley = addslashes($smiley);
					$code = $smiley;
					$altcode .= "     $smiley";
				}

				$graemlinlist .= <<<EOF
<a href="javascript:void(0)" onclick="insertAtCaret(document.replier.{$name}, ' $code'); showHideElement('smileys','hide'); document.replier.{$name}.focus();"><img src="{$config['BASE_URL']}/images/{$style_array['graemlins']}/$image" alt="$altcode" title="$altcode" class="p2"></a>\n
EOF;
				$n++;
				$i++;
				if ($i == 12) {
					$i = 0;
					$graemlinlist .= "<br>";
				}

				if ($config['SHOW_ALL_GRAEMLINS'] != '1' && $user['USER_SHOW_ALL_GRAEMLINS'] != '1') {
					if ($n == 18) {
						$more_smilies = true;
						break;
					}
				}
			}
			$font_families = "";
			foreach ($config['MARKUP_FONTS'] as $k => $font) {
				$font_families .= <<<EOF
<div id="font_$k" onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text" onmousedown="fontFamily('$font'); " style="cursor: pointer; font-family: $font;">$font</div>
EOF;
			}
		}


		$font_sizes = "";
		foreach ($config['MARKUP_FONT_SIZES'] as $k => $size) {
			$font_sizes .= <<<EOF
<div id="size_$k" onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text" onmousedown="formatText('[size:$size]','[/size]'); " style="cursor: pointer; font-size: $size;">$size</div>
EOF;
		}

		include("{$config['FULL_PATH']}/languages/{$user['USER_LANGUAGE']}/standard_text_editor.php");

		// Create the syntax highlighter dropdown
		//
		// Note: we will hardwire certain extensions regardless:
		//
		// css, php, text, html (html4strict), javascript, sql
		$fixed = array(
			'' => 'text',
			':css' => 'css',
			':html' => 'html4strict',
			':php' => 'php',
			':sql' => 'sql',
			':js' => 'javascript'
		);

		$se = "";
		foreach ($fixed as $alias => $ext) {
			$se_drop .= '<div onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text"
							onmousedown="formatText(\'[code' . $alias . ']\',\'[/code]\');">[code' . $alias . ']' . $ubbt_lang['CODE_MENU_CODE'] . '[/code]</div>';
		}

		// Now fill up the drop down with additional languages, if any
		$num = 0;
		foreach ($config['SYNTAX_ENGINES'] as $type) {
			if (!in_array($type, $fixed)) {
				if ($num == 0) {
					$se_drop .= '<div class="markup_panel_unselect_text"><hr></div>';
				}
				$se_drop .= '<div onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text"
							onmousedown="formatText(\'[code:' . $type . ']\',\'[/code]\');">[code:' . $type . ']' . $ubbt_lang['CODE_MENU_CODE'] . '[/code]</div>';
				$num++;
			}
		}

		// Do the Custom tag dance and only include those that have the 'show' set to 1
		if (sizeof($bbcode_tags) > 0 && $allow_media == true) {
			$bbcode_drop_nr = 0;
			$bbcode_drop = '<div id="bbcode-drop" class="markup_panel_popup nw" style="display:none;font-weight:normal;height:auto;overflow:hidden;width:auto;">';
			foreach ($bbcode_tags as $k => $type) {
				if ($type['show'] == 1) {
					$bbcode_drop .= <<<BLEH
<div id="bbcode_{$k}" onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text" onclick="DoPrompt('bbcode','{$type['prompt']}','{$type['open']}','{$type['close']}');" style="cursor: pointer;">{$type['descrip']}</div>
BLEH;
					$bbcode_drop_nr++;
				}
			}
			$bbcode_drop .= '</div>';
			if (!$bbcode_drop_nr) $bbcode_drop = '';
		} else {
			$bbcode_drop = '';
		}

		$smarty->assignByRef("font_families", $font_families);
		$smarty->assignByRef("font_sizes", $font_sizes);
		$smarty->assign("bbcode_drop", $bbcode_drop);
		$smarty->assign("name", $name);
		$smarty->assign("value", $value);
		$smarty->assign("tabindex", $tabindex);
		$smarty->assign("allow_images", $allow_images);
		$smarty->assign("more_smilies", $more_smilies);
		$smarty->assignByRef("smileys", $graemlinlist);
		$smarty->assign("code_drop", $se_drop);
		$smarty->assignByRef("lang", $ubbt_lang);
		if ($config['EDITOR'] == "sceditor") {
			$smarty->assignByRef("smileysmore", $graemlinlistmore);
			$text_editor = $smarty->fetch("standard_text_editorsce.tpl");
		} else if ($config['EDITOR'] == "tinymce") {
			$text_editor = $smarty->fetch("standard_text_editortiny.tpl");
		} else if ($config['EDITOR'] == "standard_fa") {
			$text_editor = $smarty->fetch("standard_text_editorfa.tpl");
		} else {
			$text_editor = $smarty->fetch("standard_text_editor.tpl");
		}
		return $text_editor;
	}


	// Language string replacement utility
	//
	// $html->substitute($ubbt_lang['LANG_IDENTITY'], array('EMAIL_ADDY' => $email, 'BOARD_ADDY' -> $board, etc));
	function substitute($string, $replacements) {
		// Probably not the fastest thing in the world
		$finds = array();
		foreach (array_keys($replacements) as $str) {
			$finds[] = "%%{$str}%%";
		}

		$string = str_replace($finds, array_values($replacements), $string);

		return $string;
	}

	// Takes a regular username and colorizes it, based upon whether they have a color
	// defined or they are one of the special ones with a group color
	function user_color($username, $usercolor = "", $userlevel) {
		$localname = $username;
		if ($usercolor) {
			$localname = "<span class='fwrap' style='color: $usercolor'>$username</span>";
		} else {
			switch ($userlevel) {
				case 'Administrator':
					$localname = "<span class='adminname'>$username</span>";
					break;
				case 'GlobalModerator':
					$localname = "<span class='globalmodname'>$username</span>";
					break;
				case 'Moderator':
					$localname = "<span class='modname'>$username</span>";
					break;
				case 'User':
					$localname = "<span class='username'>$username</span>";
					break;
			}
		}
		return $localname;
	}

	// Takes a user's status and returns their status indicator, if applicable
	function user_status($uid, $images = '', $modcheck) {
		global $config, $style_array, $ubbt_lang, $dbh;

		if (empty($this->group_images)) {
			$query = "
				SELECT GROUP_ID, GROUP_IMAGE, GROUP_NAME
				FROM {$config['TABLE_PREFIX']}GROUPS
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			while (list($gid, $gimage, $gname) = $dbh->fetch_array($sth)) {
				$this->group_images[$gid] = $gimage;
				$this->group_names[$gid] = $gname;
			}
		}
		$src = '';
		if ($images != '') {
			$image_array = unserialize($images);
			foreach ($image_array as $k => $v) {
				if ($v == 3 && !strstr($modcheck, ",{$uid},")) continue;
				$src .= "<img src='{$config['BASE_URL']}/images/groups/{$this->group_images[$v]}' class='rmar' alt='' title='{$this->group_names[$v]}'><wbr>";
			}
		}
		return $src;
	}

	// Cuts a string to the length of $length and replaces the last characters
	// with the ending if the text is longer than length.
	function truncate($text, $length = 200, $ending = ' (...)', $exact = false, $isHtml = true) {
		if ($isHtml) {
			// if the plain text is shorter than the maximum length, return the whole text
			if (strlen(preg_replace('/<.*?>/', '', $text)) <= $length) {
				return $text;
			}

			// splits all html-tags to scanable lines
			preg_match_all('/(<.+?>)?([^<>]*)/s', $text, $lines, PREG_SET_ORDER);

			$total_length = strlen($ending);
			$open_tags = array();
			$truncate = '';

			foreach ($lines as $line_matchings) {
				// if there is any html-tag in this line, handle it and add it (uncounted) to the output
				if (!empty($line_matchings[1])) {
					// if it's an "empty element" with or without xhtml-conform closing slash (f.e. <br/>)
					if (preg_match('/^<(\s*.+?\/\s*|\s*(img|br|input|hr|area|base|basefont|col|frame|isindex|link|meta|param)(\s.+?)?)>$/is', $line_matchings[1])) {
						// do nothing
						// if tag is a closing tag (f.e. </b>)
					} else if (preg_match('/^<\s*\/([^\s]+?)\s*>$/s', $line_matchings[1], $tag_matchings)) {
						// delete tag from $open_tags list
						$pos = array_search($tag_matchings[1], $open_tags);
						if ($pos !== false) {
							unset($open_tags[$pos]);
						}
						// if tag is an opening tag (f.e. <b>)
					} else if (preg_match('/^<\s*([^\s>!]+).*?>$/s', $line_matchings[1], $tag_matchings)) {
						// add tag to the beginning of $open_tags list
						array_unshift($open_tags, strtolower($tag_matchings[1]));
					}
					// add html-tag to $truncate'd text
					$truncate .= $line_matchings[1];
				}

				// calculate the length of the plain text part of the line; handle entities as one character
				$content_length = strlen(preg_replace('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|&#x[0-9a-f]{1,6};/i', ' ', $line_matchings[2]));
				if ($total_length + $content_length > $length) {
					// the number of characters which are left
					$left = $length - $total_length;
					$entities_length = 0;
					// search for html entities
					if (preg_match_all('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|&#x[0-9a-f]{1,6};/i', $line_matchings[2], $entities, PREG_OFFSET_CAPTURE)) {
						// calculate the real length of all entities in the legal range
						foreach ($entities[0] as $entity) {
							if ($entity[1] + 1 - $entities_length <= $left) {
								$left--;
								$entities_length += strlen($entity[0]);
							} else {
								// no more characters left
								break;
							}
						}
					}
					$truncate .= substr($line_matchings[2], 0, $left + $entities_length);
					// maximum length is reached, so get off the loop
					break;
				} else {
					$truncate .= $line_matchings[2];
					$total_length += $content_length;
				}

				// if the maximum length is reached, get out of loop
				if ($total_length >= $length) {
					break;
				}
			}
		} else {
			if (strlen($text) <= $length) {
				return $text;
			} else {
				$truncate = substr($text, 0, $length - strlen($ending));
			}
		}

		// Some words shouldn't be cut in the middle
		if (!$exact) {										// Search the last occurance of a space...
			$spacepos = strrpos($truncate, ' ');
			if (isset($spacepos)) {							// ...and cut the text in this position
				$truncate = substr($truncate, 0, $spacepos);
			}
		}

		// add the defined ending to the text
		$truncate .= $ending;

		if ($isHtml) {										// close all unclosed html-tags
			foreach ($open_tags as $tag) {
				$truncate .= '</' . $tag . '>';
			}
		}
		return $truncate;
	}

	// Generates the left Nav information for the 'My Account' option
	function mystuff() {
		global $config, $user, $dbh, $style_array, $ubbt_lang, $userob;

		// Only give them stuff, if their profile wants it
		if ($user['USER_SHOW_LEFT_MYSTUFF'] == 0) {
			$stuff = "";
		} else {
			$stuff = "<div class=\"category\">{$ubbt_lang['MY_SPACE']}</div>";

			// Do the Title/CustomTitle dance
			if ($user['USER_CUSTOM_TITLE'] && $config['ONLY_CUSTOM']) {
				$upTitle = $user['USER_CUSTOM_TITLE'];
			} else {
				$upTitle = $user['USER_TITLE'] . '<br>' . $user['USER_CUSTOM_TITLE'];
			}
			$uName = $this->user_color($user['USER_DISPLAY_NAME'], $user['USER_NAME_COLOR'], $user['USER_MEMBERSHIP_LEVEL']);
			if ($user['USER_AVATAR']) {
				$upAvatar = "<a href=\"" . make_ubb_url("ubb=showprofile&User={$user['USER_ID']}", "", false) . "\"><img src=\"{$user['USER_AVATAR']}\" style=\"max-width:150px;\" alt=\"\"/></a>";
			} else {
				$upAvatar = "<a href=\"" . make_ubb_url("ubb=showprofile&User={$user['USER_ID']}", "", false) . "\"><img src=\"" . $config['BASE_URL'] . "/images/" . $style_array['general'] . "/nopicture.gif\" style=\"width:150px\" alt=\"\"></a>";
			}

			$ulStyle = "style=\"list-style-type:none;line-height:140%;padding:6px 0 12px 12px;\" class=\"alvt alt-2\"";
			$stuff .= "<div class=\"acvt alt-2\">$upAvatar<div class=\"bold\">$uName</div><div class=\"small\">$upTitle</div><br></div>";

			$stuff .= "<div class=\"tdheader\" style=\"padding-bottom:0;padding-top:0;\">{$ubbt_lang['SETTINGS']}</div>";
			$stuff .= "<ul $ulStyle>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=editdisplay", "", false) . "\">{$ubbt_lang['EDIT_DISPLAY']}</a></li>";
			$stuff .= "</ul>";

			$stuff .= "<div class=\"tdheader\" style=\"padding-bottom:0;padding-top:0;\">{$ubbt_lang['YOUR_PROF']}</div>";
			$stuff .= "<ul $ulStyle>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=editbasic", "", false) . "\">{$ubbt_lang['EDIT_PROF']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=showprofile&User={$user['USER_ID']}", "", false) . "\">{$ubbt_lang['VIEW_PROF']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=userposts&id={$user['USER_ID']}", "", false) . "\">{$ubbt_lang['MY_POSTS']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=mybuddies", "", false) . "\">{$ubbt_lang['MY_BUDDIES']}</a></li>";
			$stuff .= "</ul>";

			$stuff .= "<div class=\"tdheader\" style=\"padding-bottom:0;padding-top:0;\">{$ubbt_lang['MESSAGES']}</div>";
			$stuff .= "<ul $ulStyle>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=viewmessages", "", false) . "\">{$ubbt_lang['MY_PRIVATES']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=sendprivate", "", false) . "\">{$ubbt_lang['NEW_MESSAGE']}</a></li>";
			$stuff .= "</ul>";

			$stuff .= "<div class=\"tdheader\" style=\"padding-bottom:0;padding-top:0;\">{$ubbt_lang['FOLLOWING']}</div>";
			$stuff .= "<ul $ulStyle>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=myhome&tab=forums", "", false) . "\">{$ubbt_lang['MY_WATCH_F']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=myhome&tab=topics", "", false) . "\">{$ubbt_lang['MY_WATCH_T']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=myhome&tab=users", "", false) . "\">{$ubbt_lang['MY_WATCH_U']}</a></li>";
			if ($config['MY_FEEDS']) {
				$stuff .= "<li><a href=\"" . make_ubb_url("ubb=myfeeds&show=1", "", false) . "\">{$ubbt_lang['MY_FEEDS']}</a></li></ul>";
			}
			$stuff .= "</ul>";

			$stuff .= "<div class=\"tdheader\" style=\"padding-bottom:0;padding-top:0;\">{$ubbt_lang['MEMBERSHIP']}</div>";
			$stuff .= "<ul $ulStyle>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=subscriptions", "", false) . "\">{$ubbt_lang['MY_SUBS']}</a></li>";
			$stuff .= "</ul>";

			$stuff .= "<div class=\"tdheader\" style=\"padding-bottom:0;padding-top:0;\">{$ubbt_lang['MISC']}</div>";
			$stuff .= "<ul $ulStyle>";
			if ($userob->check_access("site", "CAN_SEE_SHOUTS")) {
				$stuff .= "<li><a href=\"" . make_ubb_url("ubb=shoutchat", "", false) . "\">{$ubbt_lang['SHOUT_CHAT']}</a></li>";
			}
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=online", "", false) . "\">{$ubbt_lang['WHO_ON']}</a></li>";
			if ($userob->check_access("site", "MEMBER_LIST")) {
				$stuff .= "<li><a href=\"" . make_ubb_url("ubb=showmembers", "", false) . "\">{$ubbt_lang['USER_LIST']}</a></li>";
			}
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=mycookies", "", false) . "\">{$ubbt_lang['MYCOOKIES']}</a></li>";
			$stuff .= "</ul>";
		}
		return $stuff;
	}

	function utf8_wordwrap($str, $width, $break, $cut = false) {
		if (!$cut) {
			$regexp = '#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){' . $width . ',}\b#U';
		} else {
			$regexp = '#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){' . $width . '}#';
		}
		if (function_exists('mb_strlen')) {
			$str_len = mb_strlen($str, 'UTF-8');
		} else {
			$str_len = preg_match_all('/[\x00-\x7F\xC0-\xFD]/', $str, $var_empty);
		}
		$while_what = ceil($str_len / $width);
		$i = 1;
		$return = '';
		while ($i < $while_what) {
			preg_match($regexp, $str, $matches);
			$string = $matches[0];
			$return .= $string . $break;
			$str = substr($str, strlen($string));
			$i++;
		}
		return $return . $str;
	}
}

?>