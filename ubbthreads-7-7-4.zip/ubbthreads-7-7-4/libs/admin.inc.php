<?php
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

error_reporting(E_ERROR | E_PARSE);
ini_set("display_errors", true);

define('IS_ADMIN', 1);
define('UBB_MAIN_PROGRAM', 1);

// set the database type
if (function_exists('mysqli_connect')) {
	$dbtype = "MySQLi";
} else {
	print "<b>Fatal Error:</b> UBB.threads requires MySQLi.";
	exit;
}

// Setup the smarty class
require('../libs/smarty/Smarty.class.php');
$smarty = new Smarty();

$smarty->setTemplateDir('../templates/default');
$smarty->setCompileDir('../templates/compile');

// include all of the required libraries
require_once("../libs/phpmailer/PHPMailerAutoload.php");
require_once("../includes/config.inc.php");
require_once("../libs/" . strtolower($dbtype) . ".inc.php");
require_once("../languages/{$config['LANGUAGE']}/generic.php");
require_once("../libs/bbcode.inc.php");
require_once("../libs/html.inc.php");
require_once("../libs/mailer.inc.php");
require_once("../libs/user.inc.php");
require_once("../libs/ubbthreads.inc.php");
require_once("../libs/triggers.inc.php");
include("{$config['FULL_PATH']}/styles/{$config['DEFAULT_STYLE']}.php");

$html = new HTML;

explode_data();

// Force a mood default
if (!$style_array['mood']) {
	$style_array['mood'] = "moods/default";
}

$smarty->assignByRef('config', $config);


class Admin {
	var $pagetitle = "";
	var $redirect = "";
	var $redirect_time = "";
	var $returntab = "";
	var $submit = "";
	var $parent_title = "";
	var $current_menu = array();
	var $menucode = "";
	var $style = "";

	public function __construct() {
		global $ubbt_lang;
		$this->current_menu = array(
			$ubbt_lang['DB_P_URL'] => "",
			$ubbt_lang['REG_SET'] => "",
			$ubbt_lang['APPROVE_THREADS'] => "",
			$ubbt_lang['PRUNE_THREADS'] => "",
			$ubbt_lang['MOVE_THREADS'] => "",
			$ubbt_lang['MEM_MAN'] => "",
			$ubbt_lang['PRIMARY'] => "",
			$ubbt_lang['FEATURES'] => "",
			$ubbt_lang['GALLERY'] => "",
			$ubbt_lang['GENERAL'] => "",
			$ubbt_lang['LAYOUT'] => "",
			$ubbt_lang['CUSTOM_ISLANDS'] => "",
			$ubbt_lang['PORTAL_SETTINGS'] => "",
			$ubbt_lang['POST_ISLANDS'] => "",
			$ubbt_lang['GALLERY_ISLANDS'] => "",
			$ubbt_lang['IM_IC'] => "",
			$ubbt_lang['STYLES'] => "",
			$ubbt_lang['LANGS'] => "",
			$ubbt_lang['TEMPLATES'] => "",
			$ubbt_lang['FORUM_SET'] => "",
			$ubbt_lang['CAT_SET'] => "",
			$ubbt_lang['MOD_SET'] => "",
			$ubbt_lang['GROUP_SET'] => "",
			$ubbt_lang['DATABASE'] => "",
			$ubbt_lang['PHPINFO'] => "",
			$ubbt_lang['FILE_PERMS'] => "",
			$ubbt_lang['RSS_FEEDS'] => "",
			$ubbt_lang['CACHE'] => "",
			$ubbt_lang['PROF_SET'] => "",
			$ubbt_lang['LOGS'] => "",
			$ubbt_lang['FORUM_PERMS'] => "",
			$ubbt_lang['SITE_PERMS'] => "",
			$ubbt_lang['CP_PERMS'] => "",
			$ubbt_lang['PAYMENT_SET'] => "",
			$ubbt_lang['SUB_GROUPS'] => "",
			$ubbt_lang['VIEW_SUBS'] => "",
			$ubbt_lang['EMAIL_SEND'] => "",
		);
	}

	// #######################################################################
	// Set the current page title
	// #######################################################################
	function setPageTitle($title) {
		$this->pagetitle = $title;
	}

	function setStyle($style) {
		global $config;
		$this->style = "<link rel=\"stylesheet\" href=\"{$config['BASE_URL']}/styles/{$style}\" type=\"text/css\" />";
	}

	function setCurrentMenu($title) {
		$this->current_menu[$title] = "class=\"cpanel-menu-block-curpage\"";
	}

	function setParentTitle($title, $script) {
		global $config;
		$this->parent_title = "<i class=\"fas fa-angle-right fa-fw small\" aria-hidden=\"true\"></i> <a href=\"{$config['BASE_URL']}/admin/$script\">$title</a>";
	}

	function setReturnTab($returntab = 0) {
		$this->returntab = $returntab;
	}

	function setCommonSubmit($text) {
		$this->submit = $text;
	}

	// #######################################################################
	// Make sure they should be here
	// #######################################################################
	function doAuth($perm = array()) {
		global $user, $ubbt_lang, $userob;

		$auth = 0;

		$checks = array_merge(array("FULL_ACCESS"), $perm);

		foreach ($checks as $k => $v) {
			if ($userob->check_access("cp", $v)) {
				$auth = 1;
				break;
			}
		}

		if (!$auth) {
			$this->error($ubbt_lang['LOGIN_BODY'], 1);
		}

		// ALL _POST methods should contain the valid_post key
		if ($_SERVER['REQUEST_METHOD'] == "POST" && !isset($_POST['valid_post'])) {
			$this->error($ubbt_lang['BAD_FORM']);
		}
	}

	// #######################################################################
	// Generate the proper admin header
	// #######################################################################
	function sendHeader($charset = "") {
		global $ubbt_lang, $config, $user;

		if (!$charset) {
			$charset = $ubbt_lang['CHARSET'];
		}
		$returntab = $this->returntab;
		if (!$returntab) {
			$returntab = '0';
		}
		$pagetitle = $this->pagetitle;
		$parenttitle = $this->parent_title;
		$meta_refresh = "";

		if ($this->redirect) {
			$meta_refresh = "<meta http-equiv=\"refresh\" content=\"" . $this->redirect_time . ";URL=" . $this->redirect . "\" />";
		}
		if ($this->menucode) {
			$menucode = $this->menucode;
		} else {
			$menucode = $this->sendMenu();
		}
		$style = "";
		if ($this->style) {
			$style = $this->style;
		}
		if (!$config['COMMUNITY_TITLE']) {
			$config['COMMUNITY_TITLE'] = "<b>You have not set a title for the community.</b>";
		}
		include("../templates/default/admin/admin_header.tmpl");
	}

	// #######################################################################
	// Generate the proper admin footer
	// #######################################################################
	function sendFooter() {
		global $tabs, $VERSION_FRIENDLY;

		$returntab = $this->returntab;
		$commonsubmit = "";
		if ($this->submit) {
			$commonsubmit .= "<div class=\"paddingtop paddingbottom stdautorow acvt\"><input type=\"submit\" class=\"form-button\" name=\"" . $this->submit . "\" value=\"" . $this->submit . "\" /></form></div>";
		}

		if (!$returntab) {
			$returntab = '0';
		}
		$tabsize = sizeof($tabs);
		global $ubbt_lang, $config, $VERSION;
		include("../libs/ver.inc.php");
		include("../templates/default/admin/admin_footer.tmpl");
	}

	// #######################################################################
	// Generate the proper menu for the admin area
	// #######################################################################
	function sendMenu() {
		global $user, $config, $ubbt_lang, $userob;

		$current_menu = $this->current_menu;

		if ($userob->check_access("cp", "FULL_ACCESS")) {
			$code = include("../templates/default/admin/admin_adminmenu.tmpl");
			return $code;
		}
		if ($userob->check_access("cp", "EDIT_USERS") || $userob->check_access("cp", "APPROVE_POSTS")) {
			if ($userob->check_access("cp", "EDIT_USERS")) {
				$edit = 1;
			}
			if ($userob->check_access("cp", "APPROVE_POSTS")) {
				$approve = 1;
			}
			$code = include("../templates/default/admin/admin_modmenu.tmpl");
			return $code;
		}
	}

	// #######################################################################
	// Make the tabs for the top of each screen
	// #######################################################################
	function createTopTabs($tabs, $returntab = "") {
		$spacer = "";
		$i = 0;
		if (!$returntab) {
			$returntab = '0';
		}
		foreach ($tabs as $key => $value) {
			if ($i == $returntab) {
				$selected[$i] = "-selected";
			} else {
				$selected[$i] = "";
			}
			$text[$i] = $key;
			$target[$i] = "_self";
			if (!$value) {
				$link[$i] = "javascript:switch_tab($i);";
			} else {
				$link[$i] = "$value";
			}
			$i++;
		}

		$colspan = $i * 2;
		if (sizeof($tabs) == 1) {
			$spacer = "<td class=\"tab-grippysep\" style=\"width:45%;\">&nbsp;</td>";
			$colspan++;
		}
		$tabsize = sizeof($tabs);
		include("../templates/default/admin/top_tabs.tmpl");
	}

	function createBottomTabs($tabs = "", $div = "") {
		global $config;

		if (!$div) {
			$div = "0";
		}
		$spacer = "";
		$i = 0;
		foreach ($tabs as $key => $value) {
			$taburl[$i] = $value;
			$tabtitle[$i] = $key;
			$i++;
		}

		$colspan = $i * 2;
		if (sizeof($tabs) == 1) {
			$spacer = "<td class=\"tab-grippysep\" style=\"width:45%;\">&nbsp;</td>";
			$colspan++;
		}
		$tabsize = sizeof($tabs);
		include("../templates/default/admin/bottom_tabs.tmpl");
	}

	function error($error = "", $noaccess = "") {
		global $ubbt_lang, $user, $config;

		if (!$user['USER_DISPLAY_NAME']) {
			$ocurl = urlencode(get_current_url());
//			$this -> redirect($ubbt_lang['LOGIN_BODY'], make_ubb_url("", "", true) . "?ubb=login&ocu=$ocurl", $ubbt_lang['GO_LOGIN']);
			header('Location: ' . make_ubb_url("", "", true) . "?ubb=login&ocu=$ocurl");
			exit;
		}
		$this->setPageTitle($ubbt_lang['CP_MESS']);
		$tabs = array(
			"{$ubbt_lang['CP_MESS']}" => ""
		);
		if ($noaccess) {
			$this->menucode = include("../templates/default/admin/admin_nullmenu.tmpl");
		} else {
			$this->menucode = $this->sendMenu();
		}
		$this->sendHeader();
		$this->createTopTabs($tabs);
		$error .= "<br><br><b>&raquo; <a href=\"#\" onclick=\"window.history.back();return false;\">{$ubbt_lang['RETURN']}</a></b>";
		include("../templates/default/admin/error.tmpl");
		$this->sendFooter();
		exit;
	}

	function setRedirect($url) {
		$this->redirect = $url;
	}

	function setRedirectTime($time) {
		$this->redirect_time = $time;
	}

// This controls the delay between admin action pages, in seconds.
	function redirect($message = "", $redirect = "", $forward = "", $time = "") {
		global $ubbt_lang;

		$this->setPageTitle($ubbt_lang['CP_MESS']);
		$tabs = array(
			"{$ubbt_lang['CP_MESS']}" => ""
		);
		if (!is_numeric($time)) {
//						 // Slow servers should set $time to "5"
//			$time = "5"; // Default setting for 7.5.0 - 7.5.8
			$time = "2"; // Default setting for 7.5.9 and up
		}
		$this->redirect_time = $time;
		$this->redirect = $redirect;
		$this->sendHeader();
		$this->createTopTabs($tabs);
		include("../templates/default/admin/redirect.tmpl");
		$this->sendFooter();
		exit;
	}

	function get_config($key, $exists, $default = "") {
		if ($config[$key]) {
			return $exists;
		} else {
			return $default;
		}
	}
}

?>