<?php
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

class user {

	var $forum_access = array();
	var $site_access = array();
	var $cp_access = array();
	var $access_built = false;
	var $is_logged_in = false;

	// #######################################################################
	// Build the permission list for a userid
	// #######################################################################
	function build_permissions($Uid = "") {

		global $dbh, $config;

		if (!$Uid || $Uid == "deleted") $Uid = 1;

		// Get the list of perms
		$perm_list = array();
		$query = "
			SELECT PERMISSION_NAME, PERMISSION_IS_HIGH, PERMISSION_IS_LOW, PERMISSION_TYPE
			FROM {$config['TABLE_PREFIX']}PERMISSION_LIST
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		while (list($perm_name, $is_high, $is_low, $perm_type) = $dbh->fetch_array($sth)) {

			$value = "";
			if ($is_high == "1") {
				$value = "high";
			} else {
				$value = "low";
			}

			$perm_list[$perm_type][$perm_name] = $value;
		}

		// Build their permission list

		// First we grab all of their groups
		$query = "
			SELECT GROUP_ID
			FROM {$config['TABLE_PREFIX']}USER_GROUPS
			WHERE USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($Uid), __LINE__, __FILE__);

		$groups = array();
		while ($result = $dbh->fetch_array($sth)) {
			$groups[] = $result['GROUP_ID'];
		}

		$_SESSION['mygroups'] = serialize($groups);

		// If the user is in group 3, we need to grab all forums they moderate
		$mod_forums = array();
		if (in_array("3", $groups)) {
			$query = "
				SELECT FORUM_ID
				FROM {$config['TABLE_PREFIX']}MODERATORS
				WHERE USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($Uid), __LINE__, __FILE__);

			while ($result = $dbh->fetch_array($sth)) {
				$mod_forums[] = $result['FORUM_ID'];
			}
		}


		if (!sizeof($groups)) {
			$groups[] = "5";
		}

		// Now build their forum access list based on those groups
		$build_forum_access = array();
		$build_site_access = array();
		$build_cp_access = array();
		$forum_negatives = array();
		$forum_zeros = array();
		$site_negatives = array();
		$site_zeros = array();
		$cp_negatives = array();
		$cp_zeros = array();
		$approve_posts = 0;

		foreach ($groups as $k => $gid) {

			/**
			 * Build Forum Permissions
			 */

			$query = "
				SELECT *
				FROM {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
				WHERE GROUP_ID = ?
			";

			$sth = $dbh->do_placeholder_query($query, array($gid), __LINE__, __FILE__);
			while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
				$this_group = 0;
				foreach ($result as $k => $v) {
					if ($k == "GROUP_ID") {
						$this_group = $v;
						continue;
					}
					if ($k == "FORUM_ID") {
						$fid = $v;
						continue;
					}
					if ($fid == "New Forum Template") continue;

					// If they can approve posts, then we need to
					// set CP access to true.
					if ($k == "APPROVE_ANY" && ($v > 0)) {
						$approve_posts = 1;
					}

					// If this is the moderator group, only set permissions
					// if they actually moderate this forum.
					if ($this_group == 3) {
						if (!in_array($fid, $mod_forums)) continue;
					}

					// If it's zero, we add it to the list of perms with 0
					if ($v == 0) {
						$forum_zeros[$k][$fid] = 1;
					}

					// If this is a negative permission, they do not
					// get access to this permission at all
					if ($v == -1) {
						$forum_negatives[$fid][] = $k;
						continue;
					}

					// Set with a high or low value?
					$hilo = $perm_list['forum'][$k];
					if ($hilo == "high") {
						if ($v > $build_forum_access[$k][$fid] && $v != 0) {
							$build_forum_access[$k][$fid] = $v;
						}
					} else {
						if (!isset($build_forum_access[$k][$fid]) && !$forum_zeros[$k][$fid]) {
							$build_forum_access[$k][$fid] = $v;
						}
						if ($v < $build_forum_access[$k][$fid]) {
							$build_forum_access[$k][$fid] = $v;
						}
					}
				}
			}

			/**
			 * Build Site Permissions
			 */

			$query = "
				SELECT *
				FROM {$config['TABLE_PREFIX']}SITE_PERMISSIONS
				WHERE GROUP_ID = ?
			";

			$sth = $dbh->do_placeholder_query($query, array($gid), __LINE__, __FILE__);
			while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
				foreach ($result as $k => $v) {
					if ($k == "GROUP_ID") continue;

					// If it's zero, we add it to the list of perms with 0
					if ($v == 0) {
						$site_zeros[$k] = 1;
					}

					// If this is a negative permission, they do not
					// get access to this permission at all
					if ($v == -1) {
						$site_negatives[] = $k;
						continue;
					}

					// Set with a high or low value?
					$hilo = $perm_list['site'][$k];
					if ($hilo == "high") {
						if (($v > $build_site_access[$k]) && $v != 0) {
							$build_site_access[$k] = $v;
						}
					} else {
						if (!isset($build_site_access[$k]) && !$site_zeros[$k]) {
							$build_site_access[$k] = $v;
						}
						if ($v < $build_site_access[$k]) {
							$build_site_access[$k] = $v;
						}
					}
				}
			}


			/**
			 * Build CP Permissions
			 */

			if ($approve_posts) {
				$build_cp_access['APPROVE_POSTS'] = 1;
			}
			$query = "
				SELECT *
				FROM {$config['TABLE_PREFIX']}CP_PERMISSIONS
				WHERE GROUP_ID = ?
			";

			$sth = $dbh->do_placeholder_query($query, array($gid), __LINE__, __FILE__);
			while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
				foreach ($result as $k => $v) {
					if ($k == "GROUP_ID") continue;

					// If it's zero, we add it to the list of perms with 0
					if ($v == 0) {
						$cp_zeros[$k] = 1;
					}

					// If this is a negative permission, they do not
					// get access to this permission at all
					if ($v == -1) {
						$cp_negatives[] = $k;
						continue;
					}

					// Set with a high or low value?
					$hilo = $perm_list['cp'][$k];
					if ($hilo == "high") {
						if (($v > $build_cp_access[$k]) && $v != 0) {
							$build_cp_access[$k] = $v;
						}
					} else {
						if (!isset($build_cp_access[$k]) && !$cp_zeros[$k]) {
							$build_cp_access[$k] = $v;
						}
						if ($v < $build_cp_access[$k]) {
							$build_cp_access[$k] = $v;
						}
					}
				}
			}
		}

		// We need to unset any negative permissions
		foreach ($forum_negatives as $fid => $array) {
			foreach ($array as $k => $v) {
				unset($build_forum_access[$v][$fid]);
			}
		}

		// Unset any perms that are 0, we don't need em
		foreach ($forum_zeros as $pid => $array) {
			foreach ($array as $k => $v) {
				if ($build_forum_access[$pid][$k] == 0) {
					unset($build_forum_access[$pid][$k]);
				}
			}
		}

		foreach ($site_negatives as $k => $v) {
			unset($build_site_access[$v]);
		}

		// Unset any perms that are 0, we don't need em
		foreach ($site_zeros as $k => $v) {
			if ($build_site_access[$k] == 0) {
				unset($build_site_access[$k]);
			}
		}

		foreach ($cp_negatives as $k => $v) {
			unset($build_cp_access[$v]);
		}

		// Unset any perms that are 0, we don't need em
		foreach ($cp_zeros as $k => $v) {
			if ($build_cp_access[$k] == 0) {
				unset($build_cp_access[$k]);
			}
		}

		$this->forum_access = $build_forum_access;
		$this->site_access = $build_site_access;
		$this->cp_access = $build_cp_access;
		$this->access_built = true;

		$now = time();
		$stale = $now - ((60 * 60) * 4);

		// Get rid of any stale permissions (older than 4 hours)
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
			WHERE CACHED_TIMESTAMP < ?
		";
		$dbh->do_placeholder_query($query, array($stale), __LINE__, __FILE__);

		// Now populate the cached permissions table with the serialized results
		$query_vars = array($Uid, serialize($build_forum_access), serialize($build_site_access), serialize($build_cp_access), $now);
		$query = "
			REPLACE INTO
				{$config['TABLE_PREFIX']}CACHED_PERMISSIONS
				(USER_ID, FORUM_PERMISSIONS, SITE_PERMISSIONS, CP_PERMISSIONS, CACHED_TIMESTAMP)
			VALUES
				(?, ?, ?, ?, ?)
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}


	// ######################################################################
	// Grab a user's permission list
	// ######################################################################
	function get_permissions($Uid = "") {

		global $dbh, $config;

		if (!$Uid) $Uid = 1;
		// FIXME:  This causes problems during the install
		if (defined('INSTALL')) return;

		$query = "
			SELECT USER_ID, FORUM_PERMISSIONS, SITE_PERMISSIONS, CP_PERMISSIONS
			FROM {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
			WHERE USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($Uid), __LINE__, __FILE__);
		list($id, $forum_perms, $site_perms, $cp_perms) = $dbh->fetch_array($sth);

		if ($forum_perms) {
			$this->forum_access = unserialize($forum_perms);
		} else {
			$this->forum_access = array();
		}

		if ($site_perms) {
			$this->site_access = unserialize($site_perms);
		} else {
			$this->site_access = array();
		}

		if ($cp_perms) {
			$this->cp_access = unserialize($cp_perms);
		} else {
			$this->cp_access = array();
		}

		$this->access_built = true;

		// If we didn't find an entry, then we need to rebuild the permission
		/// list for this user.
		if (!$id) {
			$this->build_permissions($Uid);
		}
	}


	// ######################################################################
	// Get Watch lists
	// ######################################################################
	function cache_watch_lists($uid) {
		global $config, $dbh;

		$query = "
			SELECT WATCH_ID, WATCH_TYPE
			FROM {$config['TABLE_PREFIX']}WATCH_LISTS
			WHERE USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($uid), __LINE__, __FILE__);
		$watch_list = array();
		while (list($id, $type) = $dbh->fetch_array($sth)) {
			$watch_list[$type][$id] = $id;
		}
		$_SESSION['watch_lists'] = serialize($watch_list);
	}

	// ######################################################################
	// Check access to a permission
	// ######################################################################
	function check_access($type = "", $perm = "", $board = "") {

		$access = false;
		// Check forum access
		if ($type == "forum") {
			if (isset($this->forum_access[$perm][$board])) {
				$access = $this->forum_access[$perm][$board];
			}
			return $access;
		}

		// Check Site access
		if ($type == "site") {
			if (isset($this->site_access[$perm])) {
				$access = $this->site_access[$perm];
			}
			return $access;
		}

		// Check CP access
		if ($type == "cp") {
			if (!$perm) {
				return sizeof($this->cp_access);
			}
			if (isset($this->cp_access[$perm])) {
				$access = $this->cp_access[$perm];
			}
			return $access;
		}
	}


	// ######################################################################
	// AUTHENTICATE FUNCTION
	// Authenticate the user
	// ######################################################################
	function authenticate($Query = "") {
		global $dbh, $config, $myinfo, $ubbt_lang, $forumvisit, $html;

		// -----------------------------------------
		// There are some fields that we ALWAYS need
		if ($Query != "*") {
			if ($Query) {
				$Query .= ", ";
			}
			$Query .= "t1.USER_ID, t1.USER_DISPLAY_NAME, t1.USER_PASSWORD, t1.USER_SESSION_ID, t1.USER_MEMBERSHIP_LEVEL, t1.USER_IS_BANNED, t1.USER_RULES_ACCEPTED, t1.USER_IS_UNDERAGE, t2.USER_TOTAL_PM, t2.USER_TOTAL_POSTS, t2.USER_STYLE, t2.USER_HIDE_LEFT_COLUMN, t2.USER_HIDE_RIGHT_COLUMN, t2.USER_LANGUAGE, t2.USER_MOOD, t2.USER_RELATIVE_TIME, t2.USER_TIME_OFFSET, t2.USER_SHOW_ALL_GRAEMLINS, t2.USER_AVATAR, t2.USER_TITLE, t2.USER_CUSTOM_TITLE, t2.USER_NAME_COLOR, t2.USER_SHOW_LEFT_MYSTUFF, t2.USER_GROUP_IMAGES, t2.USER_TIME_FORMAT, t2.USER_LOCATION";
		}
		$Uid = intval($myinfo['id']);

		$query = "
			SELECT
				$Query
			FROM
				{$config['TABLE_PREFIX']}USERS AS t1,
				{$config['TABLE_PREFIX']}USER_PROFILE AS t2
			WHERE
				t1.USER_ID = ?
			AND	t1.USER_ID = t2.USER_ID
		";
		$sth = $dbh->do_placeholder_query($query, array($Uid), __LINE__, __FILE__);

		$thisuser = $dbh->fetch_array($sth);
		$dbh->finish_sth($sth);


		// Check if board is locked into flat or threaded
		if (isset($config['TOPIC_DISPLAY_OPTIONS']) && $config['TOPIC_DISPLAY_OPTIONS'] == "flat") {
			$thisuser['USER_TOPIC_VIEW_TYPE'] = "flat";
		}
		if (isset($config['TOPIC_DISPLAY_OPTIONS']) && $config['TOPIC_DISPLAY_OPTIONS'] == "threaded") {
			$thisuser['USER_TOPIC_VIEW_TYPE'] = "threaded";
		}

		// Assume they aren't logged in for starters
		$this->is_logged_in = false;

		if (($thisuser['USER_SESSION_ID']) && ($thisuser['USER_SESSION_ID'] == $myinfo['session'])) {
			$this->is_logged_in = true;
		} elseif ($myinfo['key']) {

			// See if the remember me key matches and log them in for this new session
			if ($myinfo['key'] == md5("^^{$config['BOARD_KEY']}^^{$thisuser['USER_ID']}{$thisuser['USER_PASSWORD']}")) {

				$this->is_logged_in = true;
				srand((double)microtime() * 1000000);
				$newsessionid = md5(rand(0, 32767));
				$date = $html->get_date();

				$query = "
					SELECT USER_LAST_VISIT_TIME
					FROM {$config['TABLE_PREFIX']}USER_DATA
					WHERE USER_ID = ?
				";
				$sth = $dbh->do_placeholder_query($query, array($Uid), __LINE__, __FILE__);
				list($laston) = $dbh->fetch_array($sth);

				$query = "
					UPDATE {$config['TABLE_PREFIX']}USERS
					SET USER_SESSION_ID = ?
					WHERE USER_ID = ?
				";
				$dbh->do_placeholder_query($query, array($newsessionid, $Uid), __LINE__, __FILE__);

				$query = "
					UPDATE {$config['TABLE_PREFIX']}USER_DATA
					SET USER_LAST_VISIT_TIME = ?
					WHERE USER_ID = ?
				";
				$dbh->do_placeholder_query($query, array($date, $Uid), __LINE__, __FILE__);
				$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_mysess", "$newsessionid", "0");
				$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_x", "-{$Uid}-", time() + $config['COOKIE_LIFETIME']);

				rebuild_pm_count($Uid);
				$this->cache_watch_lists($Uid);
				rebuild_islands(0, array("online"));
			}
		}

		if ($this->is_logged_in == false) {
			$myinfo['id'] = 0;
			$Uid = 1;
			$myinfo['key'] = "";
			$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_myid", "0");
			$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_hash", "", time() + $config['COOKIE_LIFETIME']);

			$thisuser = array();
			// ------------------------------------------------------------------
			// Authenticate failed so we need to return all of the array keys with
			// an empty value
			$keys = preg_split("#,#", $Query);
			for ($i = 0; $i < sizeof($keys); $i++) {
				$keys[$i] = str_replace(" ", "", $keys[$i]);
				$keys[$i] = str_replace("t1.", "", $keys[$i]);
				$keys[$i] = str_replace("t2.", "", $keys[$i]);
				$thisuser[$keys[$i]] = "";
			}
		}

		// ------------------------
		// Check if they are banned
		if ($thisuser['USER_IS_BANNED']) {
			$html->check_ban($Uid, $thisuser['USER_TIME_OFFSET'], $thisuser['USER_TIME_FORMAT']);
			$this->check_ban();
		}

		// Now grab their permission list if needed
		if (!$this->access_built) {
			$this->get_permissions($Uid);
		}

		return $thisuser;
	}


	// #######################################################################
	// Clear any cached permissions
	// #######################################################################
	// Get rid of any old cached permissions so they are rebuilt
	function clear_cached_perms($Uid = "") {
		global $config, $dbh;

		$clause = "";
		if ($Uid) {
			$Uid = addslashes($Uid);
			$clause = "where USER_ID = '$Uid'";
		}
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
			$clause
		";
		$dbh->do_query($query, __LINE__, __FILE__);
	}


	// #######################################################################
	// Check_ban
	// #######################################################################
	function check_ban() {
		global $ubbt_lang, $dbh, $config, $html, $user_ip, $smarty;
		$Hostname = $user_ip;

		$query = "
			SELECT BANNED_HOST
			FROM {$config['TABLE_PREFIX']}BANNED_HOSTS
			WHERE ? LIKE BANNED_HOST
		";
		$sth = $dbh->do_placeholder_query($query, array($Hostname), __LINE__, __FILE__);
		list ($Checkhost) = $dbh->fetch_array($sth);
		$dbh->finish_sth($sth);
		if ($Checkhost) {
			$html = new html;
			require_once("{$config['FULL_PATH']}/languages/{$config['LANGUAGE']}/generic.php");
			$smarty->assignByRef('lang', $ubbt_lang);
			$html->not_right("{$ubbt_lang['IP_BANNED']}");
		}
	}


	// #######################################################################
	// Check auto-join groups
	// #######################################################################
	function check_group_join($uid = "", $count = "") {
		global $config, $dbh;

		$mygroups = unserialize($_SESSION['mygroups']);
		$newgroup = 0;
		$query = "
			SELECT GROUP_ID, GROUP_POST_COUNT_JOIN
			FROM {$config['TABLE_PREFIX']}GROUPS
			WHERE GROUP_POST_COUNT_JOIN > 0
			ORDER BY GROUP_POST_COUNT_JOIN DESC
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		while (list($gid, $posts) = $dbh->fetch_array($sth)) {
			if ($count >= $posts && (!in_array($gid, $mygroups))) {
				$newgroup = 1;
				$query = "
					REPLACE INTO
						{$config['TABLE_PREFIX']}USER_GROUPS
						(USER_ID, GROUP_ID)
					VALUES
						(?, ?)
				";
				$dbh->do_placeholder_query($query, array($uid, $gid), __LINE__, __FILE__);
				// TODO:
				// Give some type of notice to the user?
			}
		}

		if ($newgroup) {
			$this->clear_cached_perms($uid);
		}
	}


	// #######################################################################
	// IPv4/IPv6 Detection
	// #######################################################################
	function check_ip($str) {
		if (filter_var($str, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
			return ("IPv4");
		} elseif (filter_var($str, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
			return ("IPv6");
		} else {
			return ("Unknown");
		}
	}


	// #######################################################################
	// Stop Forum Spam checks
	// #######################################################################
	// 0/Unlisted, 1/Listed, 2/IPv6
	function sfsCheck($email = "", $ip = "") {
		$retEmail = 0;
		$retIp = 0;
		$retStat = 0;


// If there is no data supplied, return.
		if ($email == "" && $ip == "") return array($retStat, $retEmail, $retIp);

		$sfsUrl = "http://www.stopforumspam.com/api?";
		$haveParam = 0;

// If supplied, add the EMail to the query.
		if ($email != "") {
			$haveParam = 1;
			$sfsUrl .= "email=" . urlencode(iconv("GBK", "UTF-8", $email));
		}

// If supplied, add the IP to the query if it is an IPv4 address.
		if ($ip != "") {
			$ip_check = $this->check_ip($ip);

			if ($ip_check == "IPv4") {
				if ($haveParam == 1) $sfsUrl .= "&";
				$sfsUrl .= "ip=" . urlencode(iconv("GBK", "UTF-8", $ip));
			}
		}

// Query the Stop Forum Spam API.
		$sfsUrl .= "&f=xmldom";
		$xml = @file_get_contents($sfsUrl);
		if ($xml != false) {
			$query = new SimpleXMLElement($xml);
			if ($query->email->appears == "1") {
				$retEmail = 1;
				admin_log("SFS_DETECTION", "BAD EMAIL: $email");
			}
			if ($query->ip->appears == "1") {
				$retIp = 1;
				admin_log("SFS_DETECTION", "BAD IP: $ip");
			}
			if ($query->success == "1") {
				$retStat = 0;
			}
		} else {
			$retStat = 1;
		}

		return array($retStat, $retEmail, $retIp);
	}
}

?>