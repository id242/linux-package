<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.3
  Purpose:
  Future:
*/

function resize_image($type, $sourcefile = "") {
	global $config;

	if (!$config['MAX_THUMB_W_H']) {
		$config['MAX_THUMB_W_H'] = "200";
	}
	if (!$config['MAX_MEDIUM_W_H']) {
		$config['MAX_MEDIUM_W_H'] = "480";
	}
	if (!$config['MAX_FULL_W_H']) {
		$config['MAX_FULL_W_H'] = "99999";
	}

	if ($type == "thumb") {
		$size = $config['MAX_THUMB_W_H'];
	} elseif ($type == "medium") {
		$size = $config['MAX_MEDIUM_W_H'];
	} elseif ($type == "full" || $type == "inline") {
		$size = $config['MAX_FULL_W_H'];
	} else {
	}

	// Get the extension
	$ext = explode('.', "{$config['FULL_PATH']}/tmp/$sourcefile");
	$ext = strtolower($ext[count($ext) - 1]);

	// Fix jpeg image orientation
	if (($ext == "jpg" || $ext == "jpeg") && (function_exists('exif_read_data'))) {
		$image = imagecreatefromjpeg("{$config['FULL_PATH']}/tmp/$sourcefile");
		$exif = @exif_read_data("{$config['FULL_PATH']}/tmp/$sourcefile");
		if (!empty($exif['Orientation'])) {
			switch ($exif['Orientation']) {
				case 3:
					$image = imagerotate($image, 180, 0);
					break;
				case 6:
					$image = imagerotate($image, -90, 0);
					break;
				case 8:
					$image = imagerotate($image, 90, 0);
					break;
			}
		}
		imagejpeg($image, "{$config['FULL_PATH']}/tmp/$sourcefile");
		imagedestroy($image);
	}

	$is = getimagesize("{$config['FULL_PATH']}/tmp/$sourcefile");

	$width = 0;
	$height = 0;
	if ($is[0] > $size || $is[1] > $size) {
		if (($is[0] - $size) >= ($is[1] - $size)) {
			$width = $size;
			$height = ($size / $is[0]) * $is[1];
		} else {
			$height = $size;
			$width = ($size / $is[1]) * $is[0];
		}
	} else {
		$width = $is[0];
		$height = $is[1];
	}

	$function = "resize_image_{$config['GRAPHICS_LIBRARY']}";
	$filename = $function ($type, $sourcefile, intval($width), intval($height), $is, $ext);

	return array($filename, $width, $height);
}

function resize_image_gd($type = "", $sourcefile = "", $width, $height, $original, $ext) {
	global $config;

	$img_dst = imagecreatetruecolor($width, $height);

	if ($ext == "jpg" || $ext == "jpeg") {
		$img_src = imagecreatefromjpeg("{$config['FULL_PATH']}/tmp/$sourcefile");
	} elseif ($ext == "png") {
		$img_src = imagecreatefrompng("{$config['FULL_PATH']}/tmp/$sourcefile");
		imagealphablending($img_dst, false);
		imagesavealpha($img_dst, true);
	} elseif ($ext == "gif") {
		$img_src = imagecreatefromgif("{$config['FULL_PATH']}/tmp/$sourcefile");
		$transparentIndex = imagecolortransparent($img_src);
		if ($transparentIndex >= 0) {
			// Image has transparency
			if (!(($width - $original[0]) || ($height - $original[1]))) {
				// Image isn't being resized, so make it transparent
				$trans_color = @imagecolorallocate($image, 255, 255, 255);
				@imagecolortransparent($img_dst, $trans_color);
			} else {
				// Image isn't being resized, so give it white background
				$trans_color = @imagecolorallocate($img_dst, 255, 255, 255);
				@imagefilledrectangle($img_dst, 0, 0, $width, $height, $trans_color);
			}
		}
	}

	imagecopyresampled($img_dst, $img_src, 0, 0, 0, 0, $width, $height, $original[0], $original[1]);

	if ($ext == "gif" && function_exists('imagegif')) {
		imagetruecolortopalette($img_dst, false, 255);
	}

	$sourcefile = preg_replace("/\.$ext$/i", "", $sourcefile);

	if ($type == "thumb") $quality = $config['THUMB_QUALITY'];
	if ($type == "medium") $quality = $config['MEDIUM_QUALITY'];
	if ($type == "full") $quality = $config['FULL_QUALITY'];
	if ($type == "inline") $quality = $config['FULL_QUALITY'];

	// If it's a jpg or if we can't handle gifs
	if (($ext == "jpg" || $ext == "jpeg") || (($ext == "gif") && !function_exists('imagegif'))) {
		imagejpeg($img_dst, "{$config['FULL_PATH']}/tmp/$sourcefile.jpg.$type", $quality);
		imagedestroy($img_dst);
		return "$sourcefile.jpg";
	} else if ($ext == "png") {
		imagepng($img_dst, "{$config['FULL_PATH']}/tmp/$sourcefile.png.$type");
		imagedestroy($img_dst);
		return "$sourcefile.png";
	} else if ($ext == "gif") {
		imagegif($img_dst, "{$config['FULL_PATH']}/tmp/$sourcefile.gif.$type");
		imagedestroy($img_dst);
		return "$sourcefile.gif";
	}
}

function resize_image_im($type = "", $sourcefile = "", $width, $height, $original = "", $ext = "") {
	global $config;

	if ($type == "thumb" || $type == "medium") {
		$thumb = " -thumbnail ";
	} else {
		$thumb = " -resize ";
	}

	if ($ext == "jpg" || $ext == "jpeg") {

		if ($type == "thumb") {
			$output = "JPG";
			$quality = " -quality {$config['THUMB_QUALITY']} ";
		} elseif ($type == "medium") {
			$output = "JPG";
			$quality = " -quality {$config['MEDIUM_QUALITY']} ";
		} else {
			$output = "JPG";
			$quality = " -quality {$config['FULL_QUALITY']} ";
		}
	}

	if ($ext == "png") {
		$output = "PNG";
		$quality = " -quality 95 ";
	}

	if ($ext == "gif") {
		$quality = "";
		$output = "GIF";
		$thumb = "";
	}

	$exec = "\"{$config['CONVERT_PATH']}\" {$config['FULL_PATH']}/tmp/$sourcefile $thumb {$width}x{$height} $quality -auto-orient {$output}:\"{$config['FULL_PATH']}/tmp/$sourcefile.$type\" 2>&1";

	exec($exec);

	return "$sourcefile";
}

?>