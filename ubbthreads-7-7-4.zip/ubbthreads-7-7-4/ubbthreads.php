<?php define('UBB_MAIN_PROGRAM', 1);
//	Script Version 7.7.4

// Error reporting default
error_reporting(E_ALL & ~E_NOTICE);
ini_set("display_errors", true);

// We need PHP 5.4 or higher
if (!version_compare(phpversion(), "5.4", ">=")) {
	print "<b>Fatal Error:</b> UBB requires PHP 5.4 or higher. Your PHP version: ";
	print phpversion();
	exit;
}

// Always work from the directory this script is in
chdir(dirname(__FILE__));

// Buffer everything
$config = array();
ob_start();

// set the database type
if (function_exists('mysqli_connect')) {
	$dbtype = "MySQLi";
} else {
	print "<b>Fatal Error:</b> UBB.threads requires MySQLi.";
	exit;
}

// Setup the smarty class
require('libs/smarty/Smarty.class.php');
$smarty = new Smarty();

//	Uncomment to enable the Smarty debugger
//	$smarty->debugging = true;

$smarty->setTemplateDir('templates/default');
$smarty->setCompileDir('templates/compile');

// include all of the required libraries
require_once("libs/fetch_ip.inc.php");
require_once("libs/phpmailer/PHPMailerAutoload.php");
require_once("includes/config.inc.php");
require_once("libs/" . strtolower($dbtype) . ".inc.php");
require_once("libs/bbcode.inc.php");
require_once("styles/wrappers.php");
require_once("libs/html.inc.php");
require_once("libs/mailer.inc.php");
require_once("libs/user.inc.php");
require_once("libs/ubbthreads.inc.php");

// Do we redirect them to the FULL_URL or retain the current URL?
$server_host = $_SERVER['HTTP_HOST'];
$protocol = "http";
if ((array_key_exists('HTTPS', $_SERVER) && $_SERVER['HTTPS'] == "on") || (array_key_exists('HTTP_X_FORWARDED_PROTO', $_SERVER) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == "https")) {
	$protocol = "https";
}

if ($config['MULTI_URL']) {
	$config['FULL_URL'] = preg_replace("#(http|https)://(.*?)/#", "$protocol://$server_host/", $config['FULL_URL']);
	$config['REFERERS'] .= "|{$protocol}://$server_host";
} else {
	if (!preg_match("#$protocol://$server_host#", $config['FULL_URL'])) {
		$hostparts = parse_url($config['FULL_URL']);
		header("Location: {$hostparts['scheme']}://{$hostparts['host']}" . $_SERVER['REQUEST_URI']);
	}
}

// If available and turned on, use zlib data compression
if (!defined('PREVIEW') && !defined('ALTER')) {
	if (isset($config['ZLIB_COMPRESSION']) && $config['ZLIB_COMPRESSION']) {
		if (extension_loaded("zlib") && !ini_get("zlib.output_compression") && !ini_get("output_handler") && !in_array("URL-Rewriter", ob_list_handlers())) {
			ob_start("ob_gzhandler");
			$zlib = "Zlib"; // Zlib enabled
		} else {
			ob_start();
			$zlib = "Unavailable"; // Zlib unavailable
		}
	} else {
		ob_start();
		$zlib = "Off"; // Zlib disabled
	}
}
if (ini_get("zlib.output_compression")) $zlib = "Zlib in php.ini"; // Zlib enabled in php.ini

if (!$config['DATABASE_SERVER']) {
	echo "It doesn't appear the forum has been setup yet.  Please visit the <a href='install/index.php'>install directory</a> to setup your forum.";
	exit;
}

// Minify the output?
if ($config['MINIFY']) {
	$smarty->loadFilter("output", "trimwhitespace");
}

$tree = array();
@include("cache/forum_cache.php");

$bbcode_tags = array();
@include("cache/custom_tag_cache.php");

// $config required in all templates
$smarty->assignByRef('config', $config);

$userob = new user;
$html = new html;

// Search engine friendly URLs
explode_data();

// ------------------------------
// Always grab the debug variable
$debug = get_input("debug", "get", "int");

// Can we handle the requested action?
if (!isset($_REQUEST['ubb'])) {
	if (isset($config['ENABLE_MAIN_PORTAL']) && $config['ENABLE_MAIN_PORTAL']) {
		$_REQUEST['ubb'] = "portal";
	} else {
		$_REQUEST['ubb'] = "cfrm";
	}
}
$ubb = preg_replace("/[^a-zA-Z0-9_-]/", "", $_REQUEST['ubb']);
if (!$ubb) $ubb = "cfrm";

// showflat, showthreaded and showgallery are handled by showflat
if ($ubb == "showthreaded") {
	$ubb = "showflat";
	$_GET['mode'] = "showthreaded";
}
if ($ubb == "showgallery") {
	$ubb = "showflat";
	$_GET['mode'] = "showgallery";
}

function style_preview($output, Smarty_Internal_Template $smarty) {
	return preg_replace("/<a href(.*?)=(.*?)\"(.*?)\">/", "<a href=\"javascript:void(0);\">", $output);
}

$force = 0;
if ($ubb == "previewskin") {
	$smarty->registerFilter("output", "style_preview");
	$force = get_input("skin", "get", "int");
	if ($force == "0") $force = $config['DEFAULT_STYLE'];
	$user['USER_STYLE'] = 0;
	$ubb = "cfrm";
}

// What file / functions are we going to use
$target_file = "scripts/" . $ubb . ".inc.php";
$preload_func = "page_" . $ubb . "_gpc";
$run_func = "page_" . $ubb . "_run";

$fatal_error = false;
$fatal_error_msg = "";
$pre_error = "";
$post_error = "";
$closed = false;

// Check for file and function
if (file_exists($target_file)) {

	include_once($target_file);

	// preload functions
	if (function_exists($preload_func)) {

		$init = call_user_func($preload_func);

		// If no_session is set, kill the current session
		// We don't want these on any AJAX scripts
		if (isset($init['no_session']) && $init['no_session'] == 1) {
			session_write_close();
		}

		// Authenticate the user
		$fields = "";
		if (isset($init['user_fields'])) {
			$fields = $init['user_fields'];
		}
		$user = $userob->authenticate($fields);
		$userob->check_ban();

		// Set a default language if user doesn't have one
		if (!$user['USER_LANGUAGE']) $user['USER_LANGUAGE'] = $config['LANGUAGE'];

		// Load the default language files
		$test = @include_once("languages/{$user['USER_LANGUAGE']}/generic.php");

		// If we didn't find the language file then give an error.
		if (!$test) {
			$dirs = $user['USER_LANGUAGE'];
			echo "<b>FATAL ERROR:</b> Unable to find the $dirs or {$config['LANGUAGE']} language directories. Please notify the administrator.";
			exit;
		}

		@include_once("languages/{$user['USER_LANGUAGE']}/portal_islands.php");

		// Load the wordlets
		if (isset($init['wordlets']) && is_array($init['wordlets'])) {
			foreach ($init['wordlets'] as $file) {
				if ($file && file_exists("languages/{$user['USER_LANGUAGE']}/{$file}.php")) {
					@include_once("languages/{$user['USER_LANGUAGE']}/{$file}.php");
				}
			}
		}

		$user['USER_STYLE'] = $force ? 0 : $user['USER_STYLE'];
		$html->set_style($force);

		// Closed?
		$admin_closed_message = false;
		if ($config['BOARD_IS_CLOSED'] && $ubb != "login" && $ubb != "start_page" && $ubb != "logout") {
			$closed_message = file_get_contents("{$config['FULL_PATH']}/includes/closedforums.php");
			if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
				$closed = true;
				$fatal_error = true;
				$fatal_error_message = $closed_message;
			} else {
				$admin_closed_message = true;
			}
		}

		// Does user have to be logged in?
		if (!isset($user['USER_ID']) || !$user['USER_ID']) {
			if (array_get($init, 'regonly', 0) == 1) {
				$fatal_error = true;
				$fatal_error_msg = "FATAL_NOT_LOGGED";
			}
		}

		// Does user have to be an admin
		if (array_get($init, 'admin_only', 0) == 1 && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			$fatal_error = true;
			$fatal_error_msg = "FATAL_ADMIN_ONLY";
		}

		// Does user have to be an admin or mod
		if (array_get($init, 'admin_or_mod', 0) == 1 && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !(preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL'])))) {
			$fatal_error = true;
			$fatal_error_msg = "FATAL_ADMIN_MOD_ONLY";
		}


		// Extract the requested variables
		$in = array();
		$init['input'] = array_get($init, 'input', array());
		if (is_array($init['input'])) {
			foreach ($init['input'] as $k => $v) {
				if (count($v) == 4) {
					$in[$k] = get_input($v['0'], $v['1'], $v['2'], $v['3']);
				} else {
					$in[$k] = get_input($v['0'], $v['1'], $v['2'], '');
				}
			}
		}

	} else {
		$fatal_error = true;
		$pre_error = $preload_func;
		$fatal_error_msg = "FATAL_NO_FUNCTION";
	}

	// Assign the language variables to smarty
	$smarty->assignByRef('lang', $ubbt_lang);

	// Does this user need to accept the board rules?
	if ((($user['USER_RULES_ACCEPTED'] < array_get($config, 'FORCE_RULES', 0)) && $ubb != "boardrules" & $ubb != "logout") && $user['USER_ID']) {
		$html->give_rules();
		exit;
	}


	// The meat and potatoes of the script
	if (function_exists($run_func)) {

		if ($fatal_error == false) {

			$results = call_user_func($run_func);

			// If the run function returns boolean false, we need to
			// bypass the Smarty output phase entirely.
			if ($results === false) {
				exit;
			}

			// Call our function that will process the returned data
			// We do this in a callable function, because this will
			// also be called directly from the error handler
			smartyPrepare($results);
			exit;
		}

	} else {

		// FIXME: more elegant error handling
		$fatal_error = true;
		$pre_error = $run_func;
		$fatal_error_msg = "FATAL_NO_FUNCTION";

	}


} else {
	// FIXME: more elegant error handling
	$fatal_error = true;
	$post_error = $target_file;
	$fatal_error_msg = "FATAL_NO_FILE";
}

if ($fatal_error) {
	if (!is_array($user)) {
		$user = $userob->authenticate($fields);
	}

	if (!$html->style_set) {
		$html->set_style();
	}

	// Set a default language if user doesn't have one
	if (!$user['USER_LANGUAGE']) $user['USER_LANGUAGE'] = $config['LANGUAGE'];

	// Include the generic language file
	$test = @include_once("languages/{$user['USER_LANGUAGE']}/generic.php");

	// Include the portal_islands language file
	@include_once("languages/{$user['USER_LANGUAGE']}/portal_islands.php");

	$smarty->assignByRef('lang', $ubbt_lang);
	if ($closed != true) {
		$fatal_error_message = $ubbt_lang[$fatal_error_msg];
	}

	if (defined('NO_WRAPPER')) {
		$html->not_right_bare("$pre_error $fatal_error_message $post_error");
	} else {
		$html->not_right("$pre_error $fatal_error_message $post_error");
	}
	exit;
} else {
	if (!is_array($user)) {
		$user = $userob->authenticate($fields);
	}

	if (!$html->style_set) {
		$html->set_style();
	}

	// Set a default language if user doesn't have one
	if (!$user['USER_LANGUAGE']) $user['USER_LANGUAGE'] = $config['LANGUAGE'];

	// Include the generic language file
	$test = @include_once("languages/{$user['USER_LANGUAGE']}/generic.php");
	$smarty->assignByRef('lang', $ubbt_lang);
	$html->not_right('You have reached an error thought to be impossible. Please report this bug at <a href="https://www.ubbcentral.com/forums">UBBCentral.com</a>. Please include the version, ' . $VERSION . ', with the report.');
	exit;
}


function smartyPrepare(&$results) {
	global $html, $config, $smarty, $dbh, $debug, $timea, $user;

	if ($debug && $dbh->debug_output) {
		global $zlib, $mysqltime, $querycount, $VERSION, $ubbt_lang, $phpver;

		echo <<<DEBUG
<html><head><title>MySQL Debug Information</title>
<style type="text/css"> .wrap{margin:10px;padding:15px;background:#FFF;border:1px solid #c6c6c6;} .small{font:9pt sas-serif;} body{color:#000;background:#d9d9d9;} table{border-collapse:collapse;width:100%;} td{border:1px solid #000;padding:3px;font:9pt sans-serif;} .tt{font:9pt monospace;} .a td{background:#DADADA;font-weight:bold;} .c td{width:10%;} .b td{background:#EAEAEA;font-weight:bold;} .c{background:#F0F0F0;} .d{background:#F0F0F0;} .e{color:red;font-style:italic;}</style></head><body>
<div class="wrap">
DEBUG;
		$phpver = phpversion();
		$timeb = getmicrotime();
		$time = $timeb - $timea;
		$time = round($time, 3);
		$memoryUsage = number_format(memory_get_usage() / 1024 / 1024, 4);
		$memoryUsagePeak = number_format(memory_get_peak_usage() / 1024 / 1024, 4);
		$servertime = date('Y-m-d H:i:s e');
		$debug = sprintf($ubbt_lang['PAGE_DEBUG'], $phpver, $time, $querycount, $mysqltime, $memoryUsage, $memoryUsagePeak, $zlib, $servertime);

		echo $dbh->debug_output;
		echo <<<DEBUG
			<div class="small" align="center">
				{$debug}
				<br><br>
				<a href="https://www.ubbcentral.com/" title="{$VERSION}" target="_blank">Powered by UBB.threads&#8482; PHP Forum Software {$VERSION}</a><br>
			</div>
	</div>
</body></html>
DEBUG;
		exit;
	}

	$login = make_ubb_url("ubb={$results['location']}", "", true);
	if (array_get($results, 'login', false) && (strpos($_SERVER["SERVER_SOFTWARE"], "Apache") === false)) {
		echo <<<SET_COOKIE_META_REFRESH_FOR_WINDOWS_SERVERS
			<html>
			<head>
			<meta http-equiv="refresh" content="0; url={$login}">
			</head>
			<body>
			</body>
			</html>
SET_COOKIE_META_REFRESH_FOR_WINDOWS_SERVERS;
		exit;
	}
	// If we were returned a location, then we send them directly to that page
	if ($results['location'] != "") {
		$login = str_replace('&amp;', '&', $login);
		header("Location: {$login}");
		exit;
	}

	if (isset($results['http_redirect']) && ($results['http_redirect'] != "")
		&& ($results['location'] == "") && ($results['template'] == "")
		&& (oncomplete_validate($results['http_redirect']))) {
		$results['http_redirect'] = str_replace('&amp;', '&', $results['http_redirect']);
		header("Location: {$results['http_redirect']}");
		exit;
	}

	if ($results['header'] != "" && !defined('NO_WRAPPER')) {
		$header_data = $html->send_header($results['header']);
	}

	if (!defined('NO_WRAPPER') && !defined('IS_ERROR')) {
		$left_column_data = $html->send_column("LEFT", array_get($results, 'force_columns', 0));
	}

	if ($results['template']) {
		$smarty_display['body']['template'] = $results['template'];
		$smarty_display['body']['data'] = $results['data'];
	}

	if (!defined('NO_WRAPPER') && !defined('IS_ERROR')) {
		$right_column_data = $html->send_column("RIGHT", array_get($results, 'force_columns', 0));
	}

	if ($results['footer'] == true && !defined('NO_WRAPPER')) {
		$footer_data = $html->send_footer($results['header']);
	}

	if (isset($header_data['template'])) {
		/*		if (defined('UBB_FULL_DEBUG')) {
					global $ubb_debug;
					$header_data['data']['DEBUG_MESSAGES'] = $ubb_debug;
				}
		*/
		smartyDisplay($header_data);
	}

	if (isset($left_column_data['template'])) {
		smartyDisplay($left_column_data);
	}

	if (isset($smarty_display['body'])) {
		// Need to set graemlin url based on the user's style
		$smarty->registerFilter("output", "graemlin_url");
		smartyDisplay($smarty_display['body']);
	}

	if (isset($right_column_data['template'])) {
		smartyDisplay($right_column_data);
	}

	if (isset($footer_data['template'])) {
		smartyDisplay($footer_data);
	}
}

function smartyDisplay(&$data) {
	global $smarty;
	foreach ($data['data'] as $k => $v) {
		$smarty->assign($k, $v);
	}
	$smarty->display("{$data['template']}.tpl");
}

?>