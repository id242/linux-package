/* Version: 7.7.3 */

var firstshout = 0;
var lastshout = 0;
var shoutTimer;
var shoutBox = 1;
var is_pending = 0;

function shoutit() {
	if (is_pending) return;
	is_pending = 1;
	obj = document.shoutbox;
	shouttext = obj.shoutbody.value;
	if (!shouttext) {
		is_pending = 0;
		return;
	}
	if (!s_priv) {
		alert(notLogged);
		return;
	}
	stopTimer();
	obj.shoutbody.value = "";
	shoutfield = get_object('shout_field');
	shoutfield.style.display = "none";
	sendingfield = get_object('sending_field');
	sendingfield.style.display = "";
	var url = script;
	var ajax = new ubbtAJAX(url, getShouts);
	ajax.sendData("POST", "ubb=shoutit&shout=" + encodeURIComponent(shouttext));
}

function getShouts() {
	stopTimer();
	var url = script;
	var ajax = new ubbtAJAX(url, updateShout, 'xml');
	ajax.sendData("POST", "ubb=getshouts&shout=" + lastshout);
	is_pending = 0;
}

function updateShout(responseXML) {
	var shoutData = responseXML;
	if (shoutData == null) return;
	var lastShout = shoutData.getElementsByTagName("lastshout");
	if (lastShout.length == 0) return;
	var shoutNode = lastShout[0];
	if (!shoutNode) return;
	if (shoutNode.childNodes[0]) {
		var shoutTextNode = shoutNode.childNodes[0];
		var last_shoutid = shoutTextNode.nodeValue;
		if (last_shoutid > 0) {
			lastshout = last_shoutid;
		}
	}
	var shoutNode = shoutData.getElementsByTagName("firstshout")[0];
	if (shoutNode.childNodes[0]) {
		var shoutTextNode = shoutNode.childNodes[0];
		var first_shoutid = shoutTextNode.nodeValue;
		if (!firstshout) {
			firstshout = first_shoutid;
		}
	}
	var shouts = shoutData.getElementsByTagName("shoutdata");
	if (shouts.length) {
		for (var i = 0; i < shouts.length; i++) {
			var nameNode = shoutData.getElementsByTagName("shoutdata")[i];
			var nameTextNode = nameNode.childNodes[0];
			var name = nameTextNode.nodeValue;
			obj = get_object('shout_content');
			obj.innerHTML += name;
		}
		for (x = firstshout - 1; x <= last_shoutid; x++) {
			if (x < (last_shoutid - 100)) {
				obj = get_object("shout" + x);
				if (obj) {
					obj.innerHTML = '';
					obj.style.display = "none";
				}
			}
		}
	}
	shoutfield = get_object('shout_field');
	shoutfield.style.display = "";
	sendingfield = get_object('sending_field');
	sendingfield.style.display = "none";
	startTimer();
	// IE has a problem with scrolling before the ShoutChat box is filled in. A 1 millisecond timer fixes this.
	if (shouts.length) {
		scrollTimer = setTimeout("scrollBottom()", 1);
	}
}

function scrollBottom() {
	var objDiv = get_object("shout_box");
	if (objDiv.scrollHeight) {
		objDiv.scrollTop = objDiv.scrollHeight;
	} else if (objDiv.offsetHeight) {
		objDiv.scrollTop = objDiv.offsetHeight;
	}
	return true;
}

function startTimer() {
	shoutTimer = setTimeout("getShouts()", 30000);
}

function stopTimer() {
	clearTimeout(shoutTimer);
}

function confirmDelete(id) {
	input_box = confirm(confirmText);
	if (input_box == true) {
		obj = get_object("shout" + id);
		obj.innerHTML = '';
		obj.style.display = "none";
		var url = script + "?ubb=shoutdelete&id=" + id;
		var ajax = new ubbtAJAX(url);
		ajax.sendData("GET");
	}
}