/* Version: 7.7.2 */

var listStart = false;

function hide_menus() {
	if (menus == null) return false;
	for (var i in menus) {
		var ob = get_object(menus[i]);
		if (ob != null) ob.style.display = 'none';
	}
}

function showHTML(id, html) {
	if (menus == null) return false;
	for (var i in menus) {
		if (menus[i] != html) {
			var ob = get_object(menus[i]);
			if (ob != null) ob.style.display = 'none';
		}
	}
	obj = get_object(id);
	pos = get_offset(obj);
	leftpx = pos['left'];
	toppx = pos['top'] + obj.offsetHeight - 3;
	element = get_object(html);
	element.style.position = 'absolute';
	element.style.zIndex = 50;
	element.style.left = leftpx + 'px';
	element.style.top = toppx + 'px';
	if (element.style.display == 'none') {
		element.style.display = '';
	} else {
		element.style.display = 'none';
	}
}

function showHideElement(element, showHide) {
	if (document.getElementById(element)) {
		element = document.getElementById(element);
	}
	if (showHide == "show") {
		element.style.display = "";
	} else if (showHide == "hide") {
		element.style.display = "none";
	}
}

function litSelection(e) {
	obj = get_object(e);
	if (obj) obj.className = "markup_panel_select_text";
}

function unlitSelection(e) {
	obj = get_object(e);
	if (obj) obj.className = "markup_panel_unselect_text";
}

function raiseButton(e) {
	obj = get_object(e);
	if (obj) obj.className = "markup_panel_hover_button";
}

function normalButton(e) {
	obj = get_object(e);
	if (obj) obj.className = "markup_panel_normal_button";
}

function lowerButton(e) {
	obj = get_object(e);
	if (obj) obj.className = "markup_panel_down_button";
}

function x() {
}

function storeCaret(textEl) {
	if (textEl.createTextRange)
		textEl.caretPos = document.selection.createRange().duplicate();
}

function insertAtCaret(textEl, text) {
	if (textEl.createTextRange && textEl.caretPos) { // IE
		var caretPos = textEl.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text + '' : text;
	} else if (textEl.selectionStart && textEl.setSelectionRange) { // Mozilla 1.3+
		var val = textEl.value;
		var cpos = textEl.selectionStart;
//	var fpos = cpos + text.length +1;
		var fpos = cpos + text.length;
		var before = val.substr(0, cpos);
		var after = val.substr(cpos, val.length);
		var aspace = after.charAt(0) == ' ' ? "" : "";
		var bspace = before.charAt(before.length) == ' ' ? "" : "";
		textEl.value = before + bspace + text + aspace + after;
		textEl.setSelectionRange(fpos, fpos); // set cursor pos to end of text
		textEl.focus();
	} else {
		textEl.value = textEl.value + text; // for non MSIE browsers just append it
	}
	return true;
}

function fontFamily(font) {
	hide_menus();
	formatText("[font:" + font + "]", "[/font]");
}

function formatText(tagstart, tagend, type) {
	hide_menus();
	if (goal == null) goal = get_object('texteditor');
	el = goal;
	if (el.setSelectionRange) {
		el.value = el.value.substring(0, el.selectionStart) + tagstart + el.value.substring(el.selectionStart, el.selectionEnd) + tagend + el.value.substring(el.selectionEnd, el.value.length)
	} else {
		selectedText = document.selection.createRange().text;
		if (selectedText) {
			newText = tagstart + selectedText + tagend;
			document.selection.createRange().text = newText;
		} else {
			insertAtCaret(document.replier.Body, ' ' + tagstart + ' ' + tagend + ' ');
		}
	}
	el.focus();
}

function DoPrompt(action, hint_text, open_tag, close_tag) {
	if (goal == null) goal = get_object('texteditor');
	var textarea = goal;
	var currentMessage = textarea.value;
	switch (action) {
		case "url":
			var thisURL = prompt(urlText, "http://");
			if (thisURL == null) {
				break;
			}
			var thisTitle = prompt(urlTitle, "");
			if (thisTitle == null) {
				break;
			}
			insertAtCaret(textarea, "[url=" + thisURL + "]" + thisTitle + "[/url]");
			textarea.focus();
			break;
		case "email":
			var thisEmail = prompt(enterEmail, "");
			if (thisEmail == null) {
				break;
			}
			insertAtCaret(textarea, "[email]" + thisEmail + "[/email]");
			textarea.focus();
			break;
		case "listitem":
			var thisItem = prompt(enterItem, "");
			if (thisItem == null) {
				break;
			}
			if (listStart == false) {
				insertAtCaret(textarea, "[list]\n[*]" + thisItem + '\n');
				listStart = true;
				textarea.focus();
				return;
			}
			if (thisItem == "") {
				listStart = false;
				insertAtCaret(textarea, "[/list]\n");
			} else {
				insertAtCaret(textarea, "[*]" + thisItem + '\n');
			}
			textarea.focus();
			break;
		case "image-left":
		case "image-non":
		case "image-right":
		case "image-center":
			var thisImage = prompt(enterImage, "http://");
			if (thisImage == null) {
				break;
			}
			if (action == "image-left") {
				insertAtCaret(textarea, "[img:left]" + thisImage + "[/img]");
			} else if (action == "image-right") {
				insertAtCaret(textarea, "[img:right]" + thisImage + "[/img]");
			} else if (action == "image-center") {
				insertAtCaret(textarea, "[img:center]" + thisImage + "[/img]");
			} else {
				insertAtCaret(textarea, "[img]" + thisImage + "[/img]");
			}
			textarea.focus();
			break;
		case "bbcode":
			var thisBBCode = prompt(enterBBCode + '\n' + hint_text, "");
			if (thisBBCode == null) {
				break;
			}
			insertAtCaret(textarea, open_tag + thisBBCode + close_tag);
			break;
	}
	hide_menus();
}

function InitColorPalette() {
	var cells = get_object("colors-table").getElementsByTagName("td");
	for (var i = 0; i < cells.length; i++) {
		var cell = cells[i];
		if (cell.id != "sample") {
			cell.onmouseover = function () {
				document.getElementById("sample").style.color = this.bgColor.toUpperCase();
				document.getElementById("sample").innerHTML = this.bgColor.toUpperCase();
			};
			cell.onmouseout = function () {
				document.getElementById("sample").style.color = "#000";
				document.getElementById("sample").innerHTML = noColor;
			};
			cell.onmousedown = function (e) {
				formatText('[color:' + this.bgColor.toUpperCase() + ']', '[/color]');
			}
		}
	}
	hide_menus();
}

var filemanager = null;

function filemanager_popup(url) {
	filemanager = window.open(url);
}

var smileys = null;

function smiley_popup(url) {
	smileys = window.open(url);
}