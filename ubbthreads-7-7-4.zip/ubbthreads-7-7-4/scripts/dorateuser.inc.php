<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_dorateuser_gpc() {
	return array(
		"input" => array(
			"Ratee" => array("Ratee", "post", "int"),
			"rating" => array("rating", "post", "int"),
		),
		"wordlets" => array("dorateuser"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_dorateuser_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// -------------------
	// Can't rate yourself
	if ($user['USER_ID'] == $Ratee) {
		$html->not_right($ubbt_lang['CANTRATE']);
	}

	// ---------------------------------------------------
	// Let's find out if they have rated this user already
	$query = "
	SELECT RATING_TARGET
	FROM   {$config['TABLE_PREFIX']}RATINGS
	WHERE  RATING_TARGET = ?
	AND    RATING_RATER    = ?
	AND    RATING_TYPE     = 'u'
	";
	$sth = $dbh->do_placeholder_query($query, array($Ratee, $user['USER_ID']), __LINE__, __FILE__);
	list($check) = $dbh->fetch_array($sth);

	if (!$check) {

		// ------------------------------
		// Grab the current rating/rates
		$query = "
			select sum(RATING_VALUE) as RATING_SUM, count(*) as RATING_COUNT
			from {$config['TABLE_PREFIX']}RATINGS
			where RATING_TARGET = ?
			and RATING_TYPE = 'u'
		";
		$sth = $dbh->do_placeholder_query($query, array($Ratee), __LINE__, __FILE__);
		list ($crating, $crates) = $dbh->fetch_array($sth);
		$crating = $crating + $rating;
		$crates = $crates + 1;
		$stars = $crating / $crates;
		$stars = intval($stars);

		// --------------------------------------
		// Make sure the rating is a valid number
		if (($rating < 1) || ($rating > 5) || (!is_numeric($rating))) {
			$html->not_right($ubbt_lang['INVALID_RATING']);
		}

		// ------------------------------------------------------
		// Insert the details into the database

		$query_vars = array($Ratee, $user['USER_ID'], $rating, 'u');
		$query = "
		INSERT INTO {$config['TABLE_PREFIX']}RATINGS
		(RATING_TARGET,RATING_RATER,RATING_VALUE,RATING_TYPE)
		VALUES ( ? , ? , ? , ? )
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
		$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
		SET    USER_RATING = ? ,
		USER_TOTAL_RATES = USER_TOTAL_RATES + 1
		WHERE  USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($stars, $Ratee), __LINE__, __FILE__);
	} else {
		// ---------------------
		// Already rated
		$html->not_right($ubbt_lang['NOMORERATE']);
	}

	// ------------------------------------------
	// Give confirmation and return to the thread
	$urluser = rawurlencode($Ratee);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "showprofile&User=$urluser",
			"heading" => $ubbt_lang['THANKS'],
			"body" => "{$ubbt_lang['RATED']} {$ubbt_lang['RET_PROFILE']}",
			"returnlink" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['THANKS']}
BREADCRUMB
		,
		)
	);
}

?>