<?php defined('UBB_MAIN_PROGRAM') or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_grabnext_gpc() {
	return array(
		"input" => array(
			"Board" => array("Board", "get", "alphanum"),
			"dir" => array("dir", "get", "alpha"),
			"posted" => array("posted", "get", "int"),
			"sb" => array("sb", "get", "int"),
			"o" => array("o", "get", "int"),
			"mode" => array("mode", "get", "alpha"),
			"sticky" => array("sticky", "get", "int"),
		),
		"wordlets" => array("grabnext"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_grabnext_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$number = "";

	// Check if this is a gallery forum and get sort order
	$query = "
		select FORUM_IS_GALLERY,FORUM_SORT_FIELD
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list($is_gallery, $sort) = $dbh->fetch_array($sth);

	if ($_SESSION['myprefs']['sort']) {
		$sort = $_SESSION['myprefs']['sort'];
	}

	if (!$sort) $sort = "last";


	// Figure out the sorting options
	switch ($sort) {
		case "subject":
			$sort_by = "t2.TOPIC_SUBJECT";
			break;
		case "starter":
			$sort_by = "t3.USER_DISPLAY_NAME";
			break;
		case "replies":
			$sort_by = "t2.TOPIC_REPLIES";
			break;
		case "views":
			$sort_by = "t2.TOPIC_VIEWS";
			break;
		case "start":
			$sort_by = "t2.TOPIC_CREATED_TIME";
			break;
		case "last":
			$sort_by = "t2.TOPIC_LAST_REPLY_TIME";
			break;
		default:
			$sort_by = "t2.TOPIC_LAST_REPLY_TIME";
	}

	$sort_by .= " $order";

	// --------------------
	// Grab the next newest
	if ($dir == "old") {
		$number = "";
		if (!$sticky) {

			$query = "
			SELECT t2.POST_ID,t2.TOPIC_IS_STICKY
			FROM {$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2,
			{$config['TABLE_PREFIX']}USERS as t3
			WHERE t2.FORUM_ID = ?
			AND t2.TOPIC_IS_STICKY='0'
			AND t2.TOPIC_LAST_REPLY_TIME > ?
			AND t1.TOPIC_ID = t2.TOPIC_ID
			AND t2.USER_ID = t3.USER_ID
			ORDER BY $sort_by
			LIMIT 1
			";
			$sth = $dbh->do_placeholder_query($query, array($Board, $posted), __LINE__, __FILE__);
			list($number, $newsticky) = $dbh->fetch_array($sth);
		}

		if (($sticky || !$number) && !$is_gallery) {
			$extra = "";

			$query_vars = array($Board);
			if ($sticky) {
				$extra = "AND t2.TOPIC_LAST_REPLY_TIME > ? ";
				array_push($query_vars, $posted);
			}
			$query = "
			SELECT t2.POST_ID,t2.TOPIC_IS_STICKY
			FROM {$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2,
			{$config['TABLE_PREFIX']}USERS as t3,
			{$config['TABLE_PREFIX']}FORUMS as t4
			WHERE ((t2.FORUM_ID = ? AND t2.TOPIC_IS_STICKY='1')
			OR (t2.TOPIC_IS_STICKY='2' AND t4.FORUM_IS_TEASER = '0'))
			$extra
			AND t1.TOPIC_ID = t2.TOPIC_ID
			AND t2.USER_ID = t3.USER_ID
			ORDER BY $sort_by
			LIMIT 1
			";
			$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
			list($number, $newsticky) = $dbh->fetch_array($sth);
		}

	}

	// --------------------
	// Grab the next oldest
	if ($dir == "new") {
		$number = "";
		if ($sticky && !$is_gallery) {
			$query = "
			SELECT t2.POST_ID,t2.TOPIC_IS_STICKY
			FROM {$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2,
			{$config['TABLE_PREFIX']}USERS as t3
			WHERE ((t2.FORUM_ID = ? AND t2.TOPIC_IS_STICKY='1')
			OR t2.TOPIC_IS_STICKY='2')
			AND t2.TOPIC_LAST_REPLY_TIME < ?
			AND t1.TOPIC_ID = t2.TOPIC_ID
			AND t2.USER_ID = t3.USER_ID
			ORDER BY $sort_by desc
			LIMIT 1
			";
			$sth = $dbh->do_placeholder_query($query, array($Board, $posted), __LINE__, __FILE__);
			list($number, $newsticky) = $dbh->fetch_array($sth);
		}

		if (!$number) {
			$extra = "";
			$query_vars = array($Board);
			if (!$sticky) {
				$extra = "AND t2.TOPIC_LAST_REPLY_TIME < ?";
				array_push($query_vars, $posted);
			}
			$query = "
			SELECT t2.POST_ID,t2.TOPIC_IS_STICKY
			FROM {$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2,
			{$config['TABLE_PREFIX']}USERS as t3
			WHERE t2.FORUM_ID = ?
			AND t2.TOPIC_IS_STICKY='0'
			$extra
			AND t1.TOPIC_ID = t2.TOPIC_ID
			AND t2.USER_ID = t3.USER_ID
			ORDER BY $sort_by desc
			LIMIT 1
			";
			$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
			list($number, $newsticky) = $dbh->fetch_array($sth);
		}
	}

	if (!$number) {
		$html = new html;
		$html->not_right($ubbt_lang['NOMORE']);
	}
	$an = "";
	if ($newsticky == 2) {
		$an = "&an=$Board";
	}

	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "$mode&Number=$number$an",
	);
}

?>