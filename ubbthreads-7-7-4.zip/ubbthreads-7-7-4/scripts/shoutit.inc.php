<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.3
  Purpose: Add a shout to the ShoutChat
  Future:
*/

define('NO_WRAPPER', 1);
function page_shoutit_gpc() {
	return array(
		"input" => array(
			"shout" => array("shout", "post", ""),
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
}

function page_shoutit_run() {
	global $smarty, $user, $user_ip, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;
	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$user_id = $user['USER_ID'];
	$display_name = $user['USER_DISPLAY_NAME'];
	$text = trim($shout);

	$text = ubbchars($text);
	$words = explode(" ", $text);
	foreach ($words as $i => $w) {
		if (strlen(html_entity_decode($words[$i])) > 20) {
			$words[$i] = $html->utf8_wordwrap($words[$i], 20, "<wbr>", 1);
		}
	}
	$text = implode(" ", $words);

	$time = $html->get_date();
	$ip = $user_ip;

	$text = $html->do_markup($text, "shoutbox", "markup");
	if ($config['DO_CENSOR']) {
		$text = $html->do_censor($text);
	}

	$query_vars = array($user_id, $display_name, $text, $time, $ip);

	if ($text && $user_id) {
		$query = "
			insert into {$config['TABLE_PREFIX']}SHOUT_BOX
			(USER_ID,SHOUT_DISPLAY_NAME,SHOUT_TEXT,SHOUT_TIME,USER_IP)
			values
			( ? , ? , ? , ? , ? )
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}

	return false;
}

?>