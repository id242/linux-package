<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_showprofile_gpc() {
	global $config;
	return array(
		"input" => array(
			"User" => array("User", "get", "int"),
			"page" => array("page", "get", "int"),
		),
		"wordlets" => array("showprofile", "social", "like"),
		"user_fields" => "t2.USER_SHOW_AVATARS,t2.USER_TIME_FORMAT,t2.USER_IGNORE_LIST,t2.USER_TOTAL_POSTS",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_showprofile_run() {

	global $style_array, $userob, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Enable Likes
	$show_likes = (isset($config['ENABLE_LIKES'])) ? $config['ENABLE_LIKES'] : 1;

	// -------------------------
	// Predefine a few variables
	$CUSTOM_FIELD_1 = "";
	$CUSTOM_FIELD_2 = "";
	$CUSTOM_FIELD_3 = "";
	$CUSTOM_FIELD_4 = "";
	$CUSTOM_FIELD_5 = "";
	$privlinkstart = "";
	$privlinkstop = "";
	$useredit = "";
	$addresslinks = "";
	$ignorelinkstart = "";
	$ignorelinkstop = "";
	$ignoretext = "";
	$addresslink = "";
	$picview = "";
	$toffset = $config['SERVER_TIME_OFFSET'];

	// Make sure User is numeric
	$User = intval($User);

	isset($user['USER_SHOW_AVATARS']) && $picview = $user['USER_SHOW_AVATARS'];
	if ($user['USER_TIME_OFFSET'] != "") {
		$toffset = $user['USER_TIME_OFFSET'];
	}
	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];
	!isset($user['USER_IGNORE_LIST']) && $user['USER_IGNORE_LIST'] = "";

	$Username = $user['USER_DISPLAY_NAME'];

	if (!$userob->check_access("site", "MEMBER_PROFILES") && ($user['USER_ID'] != $User)) {
		$html->not_right($ubbt_lang['NO_PROFILES']);
	}

	if ($User == 1) {
		$html->not_right($ubbt_lang['NO_LONGER']);
	}

	// Main Admin Uid
	$config['MAIN_ADMIN_ID'] = array_get($config, 'MAIN_ADMIN_ID', 2);

	// ------------------------------
	// Grab the profile for this user
	$query = "
		SELECT
			t1.USER_DISPLAY_NAME, t1.USER_IS_BANNED, t2.USER_DISPLAY_EMAIL, t2.USER_TOTAL_POSTS, t2.USER_HOMEPAGE, t2.USER_OCCUPATION, t2.USER_HOBBIES, t2.USER_LOCATION,
			t2.USER_EXTRA_FIELD_1, t2.USER_EXTRA_FIELD_2, t2.USER_EXTRA_FIELD_3, t2.USER_EXTRA_FIELD_4, t2.USER_EXTRA_FIELD_5, t1.USER_REGISTERED_ON,
			t2.USER_AVATAR, t2.USER_TITLE, t2.USER_CUSTOM_TITLE, t1.USER_MEMBERSHIP_LEVEL, t1.USER_ID, t2.USER_TOTAL_RATES,
			t2.USER_RATING, t2.USER_AVATAR_WIDTH, t2.USER_AVATAR_HEIGHT, t2.USER_BIRTHDAY, t2.USER_PUBLIC_BIRTHDAY,	t1.USER_IS_UNDERAGE,
			t2.USER_SOCIAL1, t2.USER_SOCIAL2, t2.USER_SOCIAL3, t2.USER_SOCIAL4, t2.USER_SOCIAL5, t2.USER_SOCIAL6, t2.USER_SOCIAL7, t2.USER_SOCIAL8, t2.USER_SOCIAL9,
			t2.USER_SIGNATURE, t2.USER_MOOD, t3.USER_LAST_VISIT_TIME, t2.USER_GROUP_IMAGES, t2.USER_LIKES
		FROM
			{$config['TABLE_PREFIX']}USERS AS t1,
			{$config['TABLE_PREFIX']}USER_PROFILE AS t2,
			{$config['TABLE_PREFIX']}USER_DATA AS t3
		WHERE
			t1.USER_ID = ?
		AND t1.USER_ID = t2.USER_ID
		AND t1.USER_ID = t3.USER_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($User), __LINE__, __FILE__);

	// ----------------
	// Assign the stuff
	list ($CheckUser, $Banned, $Fakeemail, $Totalposts, $Homepage, $Occupation, $Hobbies, $Location,
		$Extra1, $Extra2, $Extra3, $Extra4, $Extra5, $Registered,
		$Picture, $Title, $CustomTitle, $Userstatus, $UNumber,
		$Rates, $Rating, $width, $height, $Birthday, $showbday, $coppauser,
		$social1, $social2, $social3, $social4, $social5, $social6, $social7, $social8, $social9,
		$Signature, $mood, $lastvisit, $groupimages, $likes) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	$profileuser = $CheckUser;


	// ------------------------------------------------
	// If this is a coppa user, we can't show some info
	if ($coppauser) {
		$Fakeemail = "";
		$Homepage = "";
		$Occupation = "";
		$Hobbies = "";
		$Location = "";
		$social1 = "";
		$social2 = "";
		$social3 = "";
		$social4 = "";
		$social5 = "";
		$social6 = "";
		$social7 = "";
		$social8 = "";
		$social9 = "";
		$Extra1 = "";
		$Extra2 = "";
		$Extra3 = "";
		$Extra4 = "";
		$Extra5 = "";
		$Picture = "";
	}

	// ------------------------------------------------
	// Hide social contact fields for users who have not logged in since
	// UBB.threads 7.6.0 release date 2017-02-15 (1487116800)
	// This is the date when YAHOO/AIM/ICQ/MSN fields were repurposed and not disposed of.
	if ($lastvisit < 1487116800) {
		$social1 = "";
		$social2 = "";
		$social3 = "";
		$social4 = "";
		$social5 = "";
		$social6 = "";
		$social7 = "";
		$social8 = "";
		$social9 = "";
	}

	// Set a default mood
	if (!$mood || !$config['ENABLE_MOODS']) {
		$mood = "content.gif";
	}

	$extraquery = "";
	if (!$config['DISABLE_ONLINE_INVISIBLE'] && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
		$extraquery = "AND t2.USER_VISIBLE_ONLINE_STATUS = 'YES'";
	}
	$query = "
		SELECT
			count(t1.USER_ID)
		FROM
			{$config['TABLE_PREFIX']}ONLINE AS t1,
			{$config['TABLE_PREFIX']}USER_PROFILE AS t2
		WHERE
			t1.USER_ID = t2.USER_ID
		AND t1.USER_ID = ?
		$extraquery
	";
	$sth = $dbh->do_placeholder_query($query, array($User), __LINE__, __FILE__);
	list($isonline) = $dbh->fetch_array($sth);
	if (!$isonline) {
		$mood = "offline.gif";
		$mood_alt = "{$ubbt_lang['OFFLINE']}";
	} else {
		if (!$config['ENABLE_MOODS']) {
			$mood_alt = "{$ubbt_lang['ONLINE']}";
		} else {
			$mood_alt = "{$ubbt_lang['ONLINE']} - " . preg_replace("#.(gif|jpg|png)$#", "", $mood);
		}
	}

	$groupimages = $html->user_status($User, $groupimages, null);
//	$groupimages = str_replace("<wbr>", "<br>", $groupimages);

	// ----------------------------------
	// Posts Per Day
	$Postsperday = ($Totalposts / ((time() - $Registered) / 86400));
	$Postsperday = number_format((float)$Postsperday, 2, '.', '');

	// ----------------------------------
	// Figure out the number of stars they get
	$stars = $Rating;
	$Rating = "";
	if (isset($stars)) {
		for ($x = 1; $x <= $stars; $x++) {
			$Rating .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/star.gif\" title= \"$Rates {$ubbt_lang['T_RATES']}\" alt=\"*\" />";
		}
	}

	// ---------------------------
	// Are user ratings turned on?
	if (!$config['USER_RATINGS']) {
		$Rating = "";
	}

	// ----------------------------------------
	// Let's see if we already rated this user
	$query = "
		SELECT
			RATING_VALUE
		FROM
			{$config['TABLE_PREFIX']}RATINGS
		WHERE
			RATING_TARGET = ?
		AND RATING_RATER = ?
		AND RATING_TYPE = 'u'
	";
	$sti = $dbh->do_placeholder_query($query, array($UNumber, $user['USER_ID']), __LINE__, __FILE__);
	list($myrating) = $dbh->fetch_array($sti);

	// ----------------------------------
	// Figure out what we need to display
	$birthday = "";
	if ($showbday) {
		// Need to convert to a date that strtotime() can work with
		// on all servers
		$parts = preg_split("#/#", $Birthday);
		$birthday_stamp = strtotime("2006-{$parts[0]}-{$parts[1]} 00:00:00");
		$month = date("n", $birthday_stamp);
		$day = date("j", $birthday_stamp);
		$year = $parts['2'];
		if (!$config['AGE_WITH_BIRTHDAYS']) {
			$year = "";
		}
		$mstring = "MONTH$month";
		$month = $ubbt_lang[$mstring];
		$birthday = "$month $day $year";
	}

// Location
	if ($config['LOCINFO_URL'] && $Location) {
		$Location = "<a href=\"{$config['LOCINFO_URL']}" . urlencode($Location) . "\" rel=\"nofollow\" target=\"_blank\">$Location</a>";
	}

	// Only show rating options for logged in users
	$ratinghtml = "";
	if ($user['USER_DISPLAY_NAME'] && !$coppauser && $User != $user['USER_ID']) {
		if ($config['USER_RATINGS'] == "1") {
			if (!$myrating) {
				$script = make_ubb_url("", "", false);
				$ratinghtml = <<<EOF
				<form method="post" action="$script">
				<input type="hidden" name="ubb" value="dorateuser" />
				<input type="hidden" name="Ratee" value="$UNumber" />
				<label for="rating">{$ubbt_lang['RATE_USER']}</label>
				<select name="rating" id="rating" class="form-select">
				<option value="" selected="selected"></option>
				<option value="5">{$ubbt_lang['STAR5']}</option>
				<option value="4">{$ubbt_lang['STAR4']}</option>
				<option value="3">{$ubbt_lang['STAR3']}</option>
				<option value="2">{$ubbt_lang['STAR2']}</option>
				<option value="1">{$ubbt_lang['STAR1']}</option>
				</select>
				<input type="submit" name="dorate" value="{$ubbt_lang['DORATE']}" class="form-button" />
				</form>
EOF;
			} else {
				$ratinghtml = "{$ubbt_lang['YOURATED']} ";
				$UserRating = "";
				for ($x = 1; $x <= $myrating; $x++) {
					$UserRating .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/star.gif\" Title=\"$myrating Star\" alt=\"*\" />";
				}
			}
		}
	}

	// -----------------------
	// You can't rate yourself
	if ($User == $user['USER_ID']) {
		$ratinghtml = "";
	}

//	if ($CustomTitle && $config['ONLY_CUSTOM']) {
//		$Title = $CustomTitle;
//		$CustomTitle="";
//	}

	// -----------------------------
	// Show the profile if it exists
	$columns = 2;
	if ($CheckUser) {

		// Attempt to correct their homepage url
		if ($Homepage) {
			if (!parse_url($Homepage, PHP_URL_SCHEME)) {
				$Homepage = "http://" . $Homepage;
			}
			$Homepage = ubbchars($Homepage);
			$HomepageName = str_replace(array("http://", "https://"), "", $Homepage);

			if (substr($HomepageName, 0, strlen("www.")) == "www.") {
				$HomepageName = substr($HomepageName, strlen("www."));
			}
			if (filter_var($Homepage, FILTER_VALIDATE_URL) === false) {
				$Homepage = "";
				$HomepageName = "";
			}
		}

		if ($config['CUSTOM_FIELD_1']) {
			$CUSTOM_FIELD_1 = "{$config['CUSTOM_FIELD_1']}";
			$CUSTOM_EXTRA_1 = "$Extra1";
		}
		if ($config['CUSTOM_FIELD_2']) {
			$CUSTOM_FIELD_2 = "{$config['CUSTOM_FIELD_2']}";
			$CUSTOM_EXTRA_2 = "$Extra2";
		}
		if ($config['CUSTOM_FIELD_3']) {
			$CUSTOM_FIELD_3 = "{$config['CUSTOM_FIELD_3']}";
			$CUSTOM_EXTRA_3 = "$Extra3";
		}
		if ($config['CUSTOM_FIELD_4']) {
			$CUSTOM_FIELD_4 = "{$config['CUSTOM_FIELD_4']}";
			$CUSTOM_EXTRA_4 = "$Extra4";
		}
		if ($config['CUSTOM_FIELD_5']) {
			$CUSTOM_FIELD_5 = "{$config['CUSTOM_FIELD_5']}";
			$CUSTOM_EXTRA_5 = "$Extra5";
		}

		$date = $html->convert_time($Registered, $toffset, $user['USER_TIME_FORMAT']);
		$datelastvisit = $html->convert_time($lastvisit, $toffset, $user['USER_TIME_FORMAT']);

		// --------------------------------------------------------------
		// If this is an admin or moderator they get some special options
		$User = rawurlencode($User);
		$encoded = rawurlencode($User);
		if ($userob->check_access("cp", "EDIT_USERS")) {
			// Only the main admin can edit other admin
			if ($user['USER_ID'] == $config['MAIN_ADMIN_ID']) {
				$useredit .= "<a href=\"{$config['BASE_URL']}/admin/showuser.php?uid=$User\">{$ubbt_lang['EDIT_T_U']}</a>";
			} // Other admins can edit any users not in the admin group
			elseif (($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") && $Userstatus != "Administrator") {
				$useredit .= "<a href=\"{$config['BASE_URL']}/admin/showuser.php?uid=$User\">{$ubbt_lang['EDIT_T_U']}</a>";
			} // If they aren't an admin, they can only edit regular users
			elseif (($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && $Userstatus == "User") {
				$useredit .= "<a href=\"{$config['BASE_URL']}/admin/showuser.php?uid=$User\">{$ubbt_lang['EDIT_T_U']}</a>";
			} // They can edit themselves
			elseif ($user['USER_ID'] == $User) {
				$useredit .= "<a href=\"{$config['BASE_URL']}/admin/showuser.php?uid=$User\">{$ubbt_lang['EDIT_T_U']}</a>";
			}
		}
		if ($useredit && $Banned) {
			$viewbanned = 1;
		}

		// ---------------------------------------------------
		// Only show the address book link for logged in users
		if ($user['USER_DISPLAY_NAME'] && !$coppauser && $User != $user['USER_ID']) {
			$query = "
				SELECT COUNT(USER_ID) AS COUNT
				FROM {$config['TABLE_PREFIX']}ADDRESS_BOOK
				WHERE USER_ID = ?
				  AND ADDRESS_ENTRY_USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $User), __LINE__, __FILE__);
			$result = $dbh->fetch_array($sth, MYSQLI_ASSOC);
			$count = array_get($result, 'COUNT', 0);

			if ($count > 0) {
				$addresslink = "<a href=\"" . make_ubb_url("ubb=removeaddress&User=$User", "", false) . "\">{$ubbt_lang['REMOVE_BOOK']}</a>";
			} else {
				$addresslink = "<a href=\"" . make_ubb_url("ubb=addaddress&User=$User", "", false) . "\">{$ubbt_lang['ADD_BOOK']}</a>";
			}
		}

		$fav_user_link = "";
		if ($user['USER_DISPLAY_NAME'] && !$coppauser && $User != $user['USER_ID']) {

			// Let's see if this is a favorite user
			$query = "
				SELECT USER_ID
				FROM {$config['TABLE_PREFIX']}WATCH_LISTS
				WHERE USER_ID = ?
				  AND WATCH_ID = ?
				  AND WATCH_TYPE = 'u'
			";
			$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $User), __LINE__, __FILE__);
			list($fav_check) = $dbh->fetch_array($sth);

			if (!$fav_check) {
				$fav_user_link = "<a href=\"" . make_ubb_url("ubb=addfavuser&User=$User", "", false) . "\">{$ubbt_lang['ADD_FAV_USER']}</a>";
			} else {
				$fav_user_link = "<a href=\"" . make_ubb_url("ubb=addfavuser&User=$User", "", false) . "\">{$ubbt_lang['REM_FAV_USER']}</a>";
			}
		}

		if (($user['USER_DISPLAY_NAME']) && !$coppauser) {
			$privlinkstart = "<a href=\"" . make_ubb_url("ubb=sendprivate&User=$User", "", false) . "\">";
			$privlinkstop = "</a>";
		}

		// ---------------------------------------------------
		// Only logged in users can ignore / unignore people
		if ($user['USER_DISPLAY_NAME']) {
			if ($Userstatus != "Administrator" && !preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']) && $user['USER_ID'] != $User) {
				$ignorelinkstart = "<a href=\"" . make_ubb_url("ubb=toggleignore&User=$User", "", false) . "\">";
				$ignorelinkstop = "</a>";
				if (preg_match("/-$User-/", $user['USER_IGNORE_LIST'])) {
					$ignoretext = $ubbt_lang['UNIGNORE'];
				} else {
					$ignoretext = $ubbt_lang['IGNORE'];
				}
			}
		}

		// ----------------
		// They don't exist
	} else {
		$html->not_right($ubbt_lang['NO_LONGER']);
	}

	$stockPicture = "{$config['FULL_URL']}/images/{$style_array['general']}/nopicture.gif";
	$imagehw = getimagesize($stockPicture);
	$stockWidth = $imagehw[0];
	$stockHeight = $imagehw[1];

	if (!$Picture) {
//		$Picture = $stockPicture;
		$Picture = "";
		$width = $stockWidth;
		$height = $stockHeight;
	}

	// Get the list of buddies
	$query = "
		SELECT
			t2.USER_AVATAR, t2.USER_AVATAR_WIDTH, t2.USER_AVATAR_HEIGHT, t3.USER_DISPLAY_NAME, t3.USER_ID, t4.ONLINE_LAST_ACTIVITY, t2.USER_MOOD
		FROM
			{$config['TABLE_PREFIX']}ADDRESS_BOOK AS t1
				LEFT JOIN {$config['TABLE_PREFIX']}ONLINE AS t4 ON t4.USER_ID = t1.USER_ID,
			{$config['TABLE_PREFIX']}USER_PROFILE AS t2,
			{$config['TABLE_PREFIX']}USERS AS t3
		WHERE
			t1.ADDRESS_ENTRY_USER_ID = ?
		AND t1.USER_ID = t2.USER_ID
		AND t2.USER_ID = t3.USER_ID
		ORDER BY
			t3.USER_DISPLAY_NAME
	";
	$sth = $dbh->do_placeholder_query($query, array($User), __LINE__, __FILE__);
	$buddies = array();
	$listed = array();
	while (list($b_avatar, $b_width, $b_height, $b_display, $b_id, $b_online, $b_mood) = $dbh->fetch_array($sth)) {
		if (in_array($b_id, $listed)) continue;
		$listed[] = $b_uid;
		if (!$b_avatar) {
			$b_avatar = $stockPicture;
			$b_width = $stockWidth;
			$b_height = $stockHeight;
		}
		$buddies[] = array(
			"avatar" => $b_avatar,
			"width" => $b_width,
			"height" => $b_height,
			"name" => $b_display,
			"id" => $b_id,
			"online" => $b_online,
			"mood" => $b_mood,
		);
	}

	// Get the texteditor
	$text_editor = $html->create_text_editor("Body", "", 2, 0, 0);

	// MD5 for duplicate posts
	$md5_stamp = md5($user['USER_DISPLAY_NAME'] . time());

	$pages = "";
	if ($config['COMMENTS']) {

		if (!$page) $page = 1;

		// Grab total comments
		$query = "
			SELECT count(*)
			FROM {$config['TABLE_PREFIX']}PROFILE_COMMENTS
			WHERE PROFILE_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($User), __LINE__, __FILE__);
		list ($total) = $dbh->fetch_array($sth);
		if ($total > 10) {
			$pages = $html->paginate($page, ceil($total / 10), "showprofile&User=$User&page=");
		}

		// Grab any profile comments for this user
		if ($page == 1) {
			$limit = "10";
		} else {
			$limit = ($page - 1) * 10 . ",10";
		}

		$comments = array();
		$query = "
			SELECT
				t1.COMMENT_ID, t1.USER_ID, t1.COMMENT_BODY, t1.COMMENT_TIME, t2.USER_DISPLAY_NAME, t2.USER_IS_BANNED, t3.USER_AVATAR, t3.USER_AVATAR_WIDTH, t3.USER_AVATAR_HEIGHT
			FROM
				{$config['TABLE_PREFIX']}PROFILE_COMMENTS AS t1,
				{$config['TABLE_PREFIX']}USERS AS t2,
				{$config['TABLE_PREFIX']}USER_PROFILE AS t3
			WHERE
				t1.PROFILE_ID = ?
			AND t1.USER_ID = t2.USER_ID
			AND t1.USER_ID = t3.USER_ID
			ORDER BY
				COMMENT_ID DESC
			limit $limit
		";
		$sth = $dbh->do_placeholder_query($query, array($User), __LINE__, __FILE__);
		while (list($c_id, $c_uid, $c_body, $c_time, $c_dname, $c_banned, $c_avatar, $c_width, $c_height) = $dbh->fetch_array($sth)) {

			if (!$c_avatar) {
//				$c_avatar = $stockPicture;
				$c_avatar = "";
				$c_width = $stockWidth;
				$c_height = $stockHeight;
			}
			if ($width && $height) {
				$picsize = "width=\"$c_width\" height=\"$c_height\"";
			} else {
				$picsize = "width=\"{$config['AVATAR_MAX_WIDTH']}\" height=\"{$config['AVATAR_MAX_HEIGHT']}\"";
			}

			$edit = 0;
			if ($c_uid == $user['USER_ID'] || $user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
				$edit = 1;
			}
			$delete = 0;
			if ($User == $user['USER_ID']) {
				$delete = 1;
			}

			$comments[] = array(
				"id" => $c_id,
				"uid" => $c_uid,
				"banned" => $c_banned,
				"body" => $c_body,
				"delete" => $delete,
				"edit" => $edit,
				"time" => $html->convert_time($c_time, $toffset, $user['USER_TIME_FORMAT']),
				"username" => $c_dname,
				"avatar" => $c_avatar,
				"picsize" => $picsize,
			);
		}
	}

	// Can they leave comments
	$post_comment = false;
//	if ($userob->is_logged_in && $user['USER_ID'] != $User && $user['USER_TOTAL_POSTS'] >= $config['COMMENTS_MIN_POST']) {
	if ($userob->is_logged_in && $user['USER_TOTAL_POSTS'] >= $config['COMMENTS_MIN_POST']) {
		$post_comment = true;
	}

	$smarty_data = array(
		"groupimages" => $groupimages,
		"profileuser" => $profileuser,
		"comments" => $comments,
		"md5" => $md5_stamp,
		"Fakeemail" => $Fakeemail,
		"Picture" => $Picture,
		"width" => $width,
		"height" => $height,
		"User" => $User,
		"Title" => $Title,
		"CustomTitle" => $CustomTitle,
		"Totalposts" => $Totalposts,
		"Postsperday" => $Postsperday,
		"Rating" => $Rating,
		"UserRating" => $UserRating,
		"birthday" => $birthday,
		"Homepage" => $Homepage,
		"HomepageName" => $HomepageName,
		"Occupation" => $Occupation,
		"Hobbies" => $Hobbies,
		"Location" => $Location,
		"social1" => $social1,
		"social2" => $social2,
		"social3" => $social3,
		"social4" => $social4,
		"social5" => $social5,
		"social6" => $social6,
		"social7" => $social7,
		"social8" => $social8,
		"social9" => $social9,
		"CUSTOM_FIELD_1" => $CUSTOM_FIELD_1,
		"CUSTOM_FIELD_2" => $CUSTOM_FIELD_2,
		"CUSTOM_FIELD_3" => $CUSTOM_FIELD_3,
		"CUSTOM_FIELD_4" => $CUSTOM_FIELD_4,
		"CUSTOM_FIELD_5" => $CUSTOM_FIELD_5,
		"CUSTOM_EXTRA_1" => $CUSTOM_EXTRA_1,
		"CUSTOM_EXTRA_2" => $CUSTOM_EXTRA_2,
		"CUSTOM_EXTRA_3" => $CUSTOM_EXTRA_3,
		"CUSTOM_EXTRA_4" => $CUSTOM_EXTRA_4,
		"CUSTOM_EXTRA_5" => $CUSTOM_EXTRA_5,
		"date" => $date,
		"datelastvisit" => $datelastvisit,
		"show_likes" => $show_likes,
		"likes" => $likes,
		"ratinghtml" => $ratinghtml,
		"privlinkstart" => $privlinkstart,
		"privlinkstop" => $privlinkstop,
		"useredit" => $useredit,
		"addresslink" => $addresslink,
		"ignorelinkstart" => $ignorelinkstart,
		"ignoretext" => $ignoretext,
		"ignorelinkstop" => $ignorelinkstop,
		"fav_user_link" => $fav_user_link,
		"signature" => $Signature,
		"sig_title" => $html->substitute($ubbt_lang['SIGNATURE'], array('USERNAME' => $profileuser)),
		"mood" => $mood,
		"mood_alt" => $mood_alt,
		"buddies" => $buddies,
		"text_editor" => $text_editor,
		"post_comment" => $post_comment,
		"pages" => $pages,
		"banned" => $Banned,
		"viewbanned" => $viewbanned,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['PROF_FOR']} $profileuser",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['PROF_FOR']} $profileuser
BREADCRUMB
		,
			"javascript" => array(
				0 => "standard_text_editor.js",
				1 => "image.js",
			),
		),
		"template" => "showprofile",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>