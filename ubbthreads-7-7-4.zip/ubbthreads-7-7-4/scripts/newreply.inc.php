<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_newreply_gpc() {
	return array(
		"input" => array(
			"Number" => array("Number", "both", "int"),
			"Parent" => array("Parent", "both", "int"),
			"what" => array("what", "both", "alpha"),
			"fpart" => array("fpart", "both", "alphanum"),
			"q" => array("q", "both", "int"),
			"CurrentBody" => array("Body", "post", ""),
		),
		"wordlets" => array("newreply"),
		"user_fields" => "t2.USER_FLOOD_CONTROL_OVERRIDE,USER_TEXT_EDITOR",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_newreply_run() {

	global $html, $smarty, $userob, $user, $in, $myinfo, $ubbt_lang, $config, $forumvisit, $visit, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------
	// Predefine some variables
	$choosename = "";
	$Pselected = "";
	$canattach = "";

	// Are we coming from the quick reply screen?
	if ($Parent) $Number = $Parent;
	$name_choice = "";

	$Username = $user['USER_DISPLAY_NAME'];

	// -----------------
	// Get the post info
	$query = "
		SELECT
			t2.USER_DISPLAY_NAME, t1.TOPIC_ID, t1.POST_SUBJECT, t1.POST_BODY, t1.POST_IS_APPROVED, t2.USER_ID, t3.FORUM_ID,	t1.POST_DEFAULT_BODY, t1.POST_POSTER_NAME
		FROM
			{$config['TABLE_PREFIX']}POSTS AS t1,
			{$config['TABLE_PREFIX']}USERS AS t2,
			{$config['TABLE_PREFIX']}TOPICS AS t3
		WHERE
			t1.POST_ID = ?
		AND t2.USER_ID = t1.USER_ID
		AND t1.TOPIC_ID = t3.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

	// ---------------
	// Assign the stuff
	list($ResUsername, $Main, $Subject, $Body, $Approved, $ParentUser, $Board, $RawBody, $anon) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);
	// FIXME: better error handling
	if (!$Subject && $Subject != "0") {
		exit;
	}

	$query = "
		SELECT USER_LAST_POST_TIME
		FROM {$config['TABLE_PREFIX']}USER_DATA
		WHERE USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	list($user['USER_LAST_POST_TIME']) = $dbh->fetch_array($sth);

	// Flood control settings
	if ($user['USER_FLOOD_CONTROL_OVERRIDE'] == "-1") {
		$floodcontrol = $userob->check_access("forum", "POST_THROTTLE", $Board);
	} else {
		$floodcontrol = $user['USER_FLOOD_CONTROL_OVERRIDE'];
	}

	// ----------------------------------------------
	// Let's get the groups and default flood control
	if (!$userob->is_logged_in) {
		$floodcontrol = $userob->check_access("forum", "POST_THROTTLE", $Board);
		$lastposttime = get_input("lastposttime", "cookie");
		$name_choice = 1;
	} else {
		$lastposttime = $user['USER_LAST_POST_TIME'];
	}


	// Check if they can make a post yet
	if (($html->get_date() - $lastposttime) < $floodcontrol) {
		$html->not_right($html->substitute($ubbt_lang['FLOODCONTROL'], array('SO_OFTEN' => $floodcontrol)));
	}

	$TEXT_AREA_COLUMNS = $config['TEXT_AREA_COLUMNS'];
	$TEXT_AREA_ROWS = $config['TEXT_AREA_ROWS'];


	// ----------------------------------------------------------
	// Find out if they are supposed to be replying on this board
	if (!$userob->check_access("forum", "CREATE_REPLIES", $Board)) {
		$html->not_right($ubbt_lang['READ_PERM']);
	}

	// Check to see if they can reply to this thread
	$query = "
		SELECT TOPIC_IS_STICKY, TOPIC_STATUS
		FROM {$config['TABLE_PREFIX']}TOPICS
		WHERE TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Main), __LINE__, __FILE__);
	list($issticky, $bstatus) = $dbh->fetch_array($sth);
	if ($issticky == "2" && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator")) {
		$html->not_right($ubbt_lang['NO_R_ANNOUNCE']);
	}

	// ---------------------------------------------------------------------------
	// If this thread is locked and they are not a admin or mod they can't proceed
	if (($bstatus != "O" && $bstatus != "") && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && (!$userob->check_access("forum", "LOCK_ANY", $Board))) {
		$html->not_right($ubbt_lang['LOCKED']);
	}


	if ($ResUsername == "**DONOTDELETE**") {
		if ($anon) {
			$ResUsername = $anon;
		} else {
			$ResUsername = $ubbt_lang['ANON_TEXT'];
		}
	}

	// -----------------------------------------------------
	// Make sure we only put one Re: in front of the subject
	if (!preg_match("/^Re:/", $Subject)) {
		$Subject = "Re: " . $Subject;
	}

	// ---------------------------------------------------------------
	// If we are quoting then we need to wrap the body in quote markup
	$QuoteBody = "";
	if ($q == 1) {
		$QuoteBody = "[quote=$ResUsername]$RawBody [/quote]";
	}

	// ----------------------
	// Convert "'s to &quot;
	$Subject = str_replace("\"", "&quot;", $Subject);
	$Body = str_replace("\"", "&quot;", $Body);


	// ------------------
	// Get the board info
	$query = "
		SELECT FORUM_TITLE, FORUM_CUSTOM_HEADER, FORUM_STYLE, FORUM_PARENT, CATEGORY_ID, FORUM_IS_RSS, FORUM_RSS_TITLE, FORUM_IS_GALLERY
		FROM {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_ID = ?
		  AND FORUM_IS_ACTIVE = '1'
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);

	// ----------------
	// Assign the stuff
	list($Title, $fheader, $fstyle, $forum_parent, $cat_id, $is_rss, $rss_title, $is_gallery) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	$guest_captcha = $userob->check_access("forum", "CAPTCHA", $Board);

	// -------------------------------------------------
	// Here we need to figure out what stylesheet to use
	if ($fstyle) {
		$html->set_style($fstyle);
	}

	if (isset(${$config['COOKIE_PREFIX'] . "ubbt_pass"})) {
		if (${$config['COOKIE_PREFIX'] . "ubbt_pass"} == "invalid") {
			if (!$config['ALLOW_UNDER_13']) {
				$html->not_right($html->substitute($ubbt_lang['UNDERAGE'], array('MINIMUM_AGE' => $config['MINIMUM_AGE'])));
			} else {
				$html->not_right($html->substitute($ubbt_lang['NO_COPPA'], array('COPPA_URL' => make_ubb_url("ubb=coppaform", "", true))));
			}
		}
	}

	// ------------------------------------------------------
	// IF This post isn't approved yet, you can't reply to it
	if ($Approved == "0") {
		$html->not_right($ubbt_lang['NOT_APP']);
	}

	// -------------------------------
	// Check if HTML is enabled or not
	if ($userob->check_access("forum", "USE_HTML", $Board)) {
		$htmlstatus = " {$ubbt_lang['YES_HTML']}";
	} else {
		$htmlstatus = " {$ubbt_lang['NO_HTML']}";
	}

	// --------------------------------------------
	// Markup is disabled, so we better let them know
	if ($userob->check_access("forum", "USE_MARKUP", $Board)) {
		$markupstatus = " {$ubbt_lang['YES_MARKUP']}";
	} else {
		$markupstatus = " {$ubbt_lang['NO_MARKUP']}";
	}

	// ----------------------------------------------------------------------
	// If The Guest group can post here then we set the Username to Anonymous
	// and we set the reged flag to "0";
	$Reged = '1';
	if (!$Username) {
		$postername = $ubbt_lang['ANON_TEXT'];
		$Reged = '0';
	} else {
		$postername = $user['USER_DISPLAY_NAME'];
	}

	// ---------------------
	// Can they post a poll?
	if ($userob->check_access("forum", "POLLS_IN_REPLIES", $Board)) {
		$makepoll = 1;
	}

	$addtofav = "";
	if ($postername != $ubbt_lang['ANON_TEXT']) {
		$addtofav = "
			<input type=\"checkbox\" id=\"dofav\" name=\"dofav\" value=\"1\" checked=\"checked\" class=\"form-checkbox\" />
			<label for=\"dofav\">{$ubbt_lang['ADDTOFAV']}</label>
		";


	}


	$postname = "<b>$postername</b>";
	$postname .= "<input type=\"hidden\" name=\"postername\" value=\"$postername\" />";

	$iconselect = $html->icon_select();

	// If we are coming from the quickreply screen, quotebody gets
	// set to CurrentBody
	if ($CurrentBody) $QuoteBody = $CurrentBody;

	$QuoteBody = ubbchars($QuoteBody);

	$text_editor = $html->create_text_editor("Body", "$QuoteBody", 2, !$is_gallery);

	// -------------------------------------
	// What options do they have for posting
	$markupselect = "";
	$markupshow = "1";
	if (($config['MARKUP_HTML_TOGGLE'] == 1) || ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") || (preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
		$markupselect .= "<select name=\"convert\" id=\"convert\" class=\"form-select\">";
		if ($userob->check_access("forum", "USE_MARKUP", $Board)) {
			$markupselect .= "<option value=\"markup\" selected=\"selected\">{$ubbt_lang['USE_MARKUP']}</option>";
		}
		if ($userob->check_access("forum", "USE_HTML", $Board)) {
			$markupselect .= "<option value=\"html\">{$ubbt_lang['USE_HTML']}</option>";
		}
		if (($userob->check_access("forum", "USE_HTML", $Board)) && ($userob->check_access("forum", "USE_MARKUP", $Board))) {
			$markupselect .= "<option value=\"both\">{$ubbt_lang['USE_BOTH']}</option>";
		}
		if ((!$userob->check_access("forum", "USE_HTML", $Board)) && (!$userob->check_access("forum", "USE_MARKUP", $Board))) {
			$markupselect .= "<option value=\"none\">{$ubbt_lang['USE_NONE']}</option>";
			$markupshow = "";
		}
		$markupselect .= "</select>";
	}

	// ------------------------------------
	// No options, we use the board default
	else {
		$markupselect = "";
	}

	$onsubmit = "";
	if ($user['USER_TEXT_EDITOR'] == "richtext") {
		$onsubmit = "onsubmit='return submitForm();'";
	}

	$canattach = 0;
	if ((!$is_gallery) && ($userob->check_access("forum", "FILE_TOTAL", $Board)) && ($Reged == "1") && (ini_get('file_uploads'))) {
		$canattach = 1;
	}

	$Body = str_replace("&quot;", "\"", $Body);

	// -----------
	// Sig option?
	$addsig = "";
	if ($Reged == "1") {
		$addsig = "<input type=\"checkbox\" name=\"addsig\" value=\"1\" id=\"addsig\" checked=\"checked\" class=\"form-checkbox\" /> <label for=\"addsig\">{$ubbt_lang['ADDSIG']}</label>";
	}

	// Create an md5 for polls and files
	$md5_stamp = md5($user['USER_DISPLAY_NAME'] . time());

	// Allow them to reply and lock in one fell swoop
	$closetopic = ($userob->check_access("forum", "LOCK_ANY", $Board)) ? 1 : 0;

	$smarty_data = array(
		"md5_stamp" => $md5_stamp,
		"Title" => $Title,
		"htmlstatus" => $htmlstatus,
		"markupstatus" => $markupstatus,
		"choosename" => $choosename,
		"postname" => $postname,
		"Board" => $Board,
		"Reged" => $Reged,
		"Main" => $Main,
		"Parent" => $Number,
		"what" => $what,
		"fpart" => $fpart,
		"ResUsername" => $ResUsername,
		"Subject" => $Subject,
		"iconselect" => & $iconselect,
		"markupselect" => & $markupselect,
		"markupshow" => & $markupshow,
		"text_editor" => & $text_editor,
		"makepoll" => $makepoll,
		"addtofav" => $addtofav,
		"addsig" => $addsig,
		"canattach" => $canattach,
		"Body" => $Body,
		"guest_captcha" => $guest_captcha,
		"name_choice" => $name_choice,
		"is_gallery" => $is_gallery,
		"closetopic" => $closetopic,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['REPLY_TEXT']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $forum_parent,
			"post_subject" => $Subject,
			"post_id" => $Number,
			"custom_header_footer" => $fheader,
			"bypass" => 0,
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"onload" => "document.replier.Body.focus()",
			"onunload" => "clearSubmit()",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
			"javascript" => array(
				0 => "standard_text_editor.js",
				1 => "image.js",
			),
		),
		"template" => "newreply",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>