<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_doedittopics_gpc() {
	return array(
		"input" => array(
			"topic" => array("topic", "post", "int"),
			"email" => array("email", "post", "alpha"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 1,
	);
}

function page_doedittopics_run() {

	global $in, $user, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$watch_lists = unserialize($_SESSION['watch_lists']);

	foreach ($topic as $topic_id => $value) {
		$query = "
			delete from	{$config['TABLE_PREFIX']}WATCH_LISTS
			where	USER_ID = ?
			and	WATCH_ID = ?
			and	WATCH_TYPE = 't'
		";
		$dbh->do_placeholder_query($query, array($user['USER_ID'], $topic_id), __LINE__, __FILE__);
		unset($watch_lists['t'][$topic_id]);

	}

	$_SESSION['watch_lists'] = serialize($watch_lists);

	foreach ($email as $topic_id => $value) {

		$immediate = 0;
		if ($value == "yes") {
			$immediate = 1;
		}

		$query_vars = array($immediate, $user['USER_ID'], $topic_id);
		$query = "
			update 	{$config['TABLE_PREFIX']}WATCH_LISTS
			set	WATCH_NOTIFY_IMMEDIATE = ?
			where	USER_ID = ?
			and	WATCH_ID = ?
			and	WATCH_TYPE = 't'
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}


	// ---------------------
	// Return to the profile
	return array(
		"data" => $data,
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "myhome&tab=topics",
	);
}

?>