<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);
function page_viewpoll_gpc() {
	return array(
		"input" => array(
			"Poll" => array("Poll", "get", "int"),
		),
		"wordlets" => array("viewpoll"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_viewpoll_run() {

	global $style_array, $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select POST_ID
		from {$config['TABLE_PREFIX']}POLL_DATA
		where POLL_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Poll), __LINE__, __FILE__);
	list($post) = $dbh->fetch_array($sth);


	$query = "
	select	t1.FORUM_ID
	from		{$config['TABLE_PREFIX']}TOPICS as t1,
					{$config['TABLE_PREFIX']}POSTS as t2
	where		t2.POST_ID = ?
	and			t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($post), __LINE__, __FILE__);
	list($board) = $dbh->fetch_array($sth);


	if (!$userob->check_access("forum", "SEE_FORUM", $board)) {
		$html->not_right_bare($ubbt_lang['BAD_GROUP']);
	}

	$view_results = 1;
	include("libs/includepoll.inc.php");

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	$smarty_data['showpoll'] = $showpoll;
	$smarty_data['stylesheet'] = $stylesheet;
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['POLL_RES'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['POLL_RES']}
BREADCRUMB
		,
		),
		"template" => "viewpoll_popup",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>