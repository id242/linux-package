<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_searchusers_gpc() {
	return array(
		"input" => array(
			"searchvalue" => array("searchvalue", "post", "alphanum"),
		),
		"wordlets" => array("searchusers"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_searchusers_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (strlen($searchvalue) < 3) {
		$html->not_right($ubbt_lang['MORE_LETTERS']);
	}

	// Grab our current favorites
	$query = "
		select 	WATCH_ID
		from		{$config['TABLE_PREFIX']}WATCH_LISTS
		where		USER_ID = ?
		and			WATCH_TYPE = 'u'
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	$in_list = "";
	while (list($uid) = $dbh->fetch_array($sth)) {
		$in_list .= "'$uid',";
	}
	$in_list = preg_replace("/,$/", "", $in_list);

	if ($in_list) {
		$in_list = "and USER_ID not in ($in_list)";
	}

	$query = "
		select	USER_ID,USER_DISPLAY_NAME
		from		{$config['TABLE_PREFIX']}USERS
		where		USER_DISPLAY_NAME like ?
		and			USER_ID <> '1'
		and			USER_ID <> ?
		$in_list
		order by	lower(USER_DISPLAY_NAME) asc
	";
	$sth = $dbh->do_placeholder_query($query, array("%$searchvalue%", $user['USER_ID']), __LINE__, __FILE__);
	$results = $dbh->total_rows($sth);

	if (!$results) {
		$html->not_right($ubbt_lang['NO_RESULTS'] . $searchvalue);
	}
	if ($results > 400) {
		$html->not_right($ubbt_lang['TOO_MANY'] . $searchvalue);
	}

	$row = 0;
	$user_array = array();
	while (list($user_id, $display_name) = $dbh->fetch_array($sth)) {
		$user_array[$row] = array(
			"id" => $user_id,
			"display_name" => $display_name,
		);
		$row++;
	}

	$smarty_data = array(
		"user_array" => $user_array,
		"mystuff" => $html->mystuff(),
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['HEADER']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['HEADER']}
BREADCRUMB
		,
		),
		"template" => "searchusers",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>