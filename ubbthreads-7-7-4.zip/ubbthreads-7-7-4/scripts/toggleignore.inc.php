<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_toggleignore_gpc() {
	return array(
		"input" => array(
			"User" => array("User", "get", "int"),
		),
		"wordlets" => array("toggleignore"),
		"user_fields" => "t2.USER_IGNORE_LIST",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_toggleignore_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!isset($user['USER_IGNORE_LIST']) || !$user['USER_IGNORE_LIST']) {
		$user['USER_IGNORE_LIST'] = "-";
	}

	// ----------------------------------------------------
	// Make sure they aren't ignoring an admin or moderator
	$query = "
	SELECT USER_ID,USER_MEMBERSHIP_LEVEL
	FROM   {$config['TABLE_PREFIX']}USERS
	WHERE  USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($User), __LINE__, __FILE__);
	list($unum, $ustat) = $dbh->fetch_array($sth);
	if ($ustat == "Administrator" || preg_match("/Moderator/", $ustat)) {
		$html->not_right("{$ubbt_lang['NOIGNORE']}");
	}
	if ($unum == $user['USER_ID']) {
		$html->not_right("{$ubbt_lang['CRAZY']}");
	}

	// ---------------------------------
	// Are they currently being ignored?
	if (preg_match("/-$User-/", $user['USER_IGNORE_LIST'])) {
		$head = $ubbt_lang['UNIGNORED'];
		$body = $ubbt_lang['UNIGNORED_BODY'];
		$newignore = preg_replace("/-$User-/", "-", $user['USER_IGNORE_LIST']);
	} else {
		$head = $ubbt_lang['IGNORED'];
		$body = $ubbt_lang['IGNORED_BODY'];
		$newignore = "{$user['USER_IGNORE_LIST']}$User-";
	}
	$query = "
	UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
	SET    USER_IGNORE_LIST = ?
	WHERE  USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($newignore, $user['USER_ID']), __LINE__, __FILE__);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "showprofile&User=$User",
			"heading" => $head,
			"body" => $body,
			"returnlink" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> $head
BREADCRUMB
		,
		)
	);
}

?>