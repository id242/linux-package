<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_printthread_gpc() {
	return array(
		"input" => array(
			"Board" => array("Board", "get", "alphanum"),
			"main" => array("main", "get", "int"),
			"type" => array("type", "get", "alpha"),
			"page" => array("page", "get", "int"),
			"fpart" => array("fpart", "get", "alphanum"),
		),
		"wordlets" => array("showflat"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE,t2.USER_TOPICS_PER_PAGE,t2.USER_SHOW_AVATARS,t2.USER_POSTS_PER_TOPIC",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_printthread_run() {
	global $html, $style_array, $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars
	define('NO_WRAPPER', 1);
	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];
	$query = "
		SELECT FORUM_ID
		FROM {$config['TABLE_PREFIX']}TOPICS
		WHERE TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($main), __LINE__, __FILE__);
	list($Board) = $dbh->fetch_array($sth);

	if (!$userob->check_access("forum", "SEE_FORUM", $Board)) {
		$html->not_right($ubbt_lang['BAD_GROUP']);
	}

	// Reassign $main to $Number
	$Number = $main;
	$folder = "icons";

	// If we didn't get a board or number then we give them an error
	if (!$Board) {
		$html->not_right($ubbt_lang['NO_B_INFO']);
	}

	// Set the default of viewing pictures with posts
	$AVATARS_WITH_POSTS = $user['USER_SHOW_AVATARS'];
	if (!$AVATARS_WITH_POSTS) {
		$AVATARS_WITH_POSTS = $config['SHOW_AVATARS'];
	}

	// Let's find out if they should be here or not
	$query = "
		SELECT FORUM_TITLE, CATEGORY_ID
		FROM {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_ID = ?
		  AND FORUM_IS_ACTIVE = '1'
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list($title, $CatNumber) = $dbh->fetch_array($sth);


	// If they are a normal user they can only see approved posts
	$ismod = "no";
	$P_Viewable = "AND POST_IS_APPROVED = 1";
	$T_Viewable = "AND TOPIC_IS_APPROVED = 1";
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
		$P_Viewable = "";
		$T_Viewable = "";
	}
	if ($user['USER_MEMBERSHIP_LEVEL'] == "GlobalModerator") {
		$P_Viewable = "";
		$T_Viewable = "";
	}
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
		// ---------------------------------
		// Check if they moderate this board
		$Board_q = addslashes($Board);
		$query = "
			SELECT FORUM_ID
			FROM {$config['TABLE_PREFIX']}MODERATORS
			WHERE USER_ID = ?
			  AND FORUM_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $Board), __LINE__, __FILE__);
		list($check) = $dbh->fetch_array($sth);
		if ($check) {
			$P_Viewable = "";
			$T_Viewable = "";
			$ismod = "yes";
		}
	}

	// If we don't have a post number then we can't view it
	if (!$Number) {
		header("X-Robots-Tag: noindex, nofollow");
		header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found");
		header("Status: 404 Not Found");
		$html->not_right($ubbt_lang['POST_PROB']);
	}

	$current = 0;
	$posted = 0;

	// Grab the main post number for this thread
	if ($type == "post") {
		$query = "
			SELECT TOPIC_ID, POST_POSTED_TIME
			FROM {$config['TABLE_PREFIX']}POSTS
			WHERE POST_ID = ?
			  $P_Viewable
		";
		$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
		list($current, $posted) = $dbh->fetch_array($sth);
	} else {
		$query = "
			SELECT TOPIC_ID
			FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID = ?
			  $T_Viewable
		";
		$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
		list($current) = $dbh->fetch_array($sth);
	}
	// If we didn't find the main post, then this post doesn't exist
	if (!$current) {
		$html->not_right("The post you are looking for could not be found");
	}
	$extra = "";
	if ($type == "thread") {
		$query_vars = array($current);
		$extra = "AND TOPIC_ID = ? ";
	} else {
		$query_vars = array($Number);
		$extra = "AND POST_ID = ? ";
	}

	// Now cycle through all the posts
	$query = "
		SELECT
			t1.POST_ID, t1.POST_POSTED_TIME, t2.USER_DISPLAY_NAME, t1.POST_POSTER_IP, t1.POST_SUBJECT, t1.POST_BODY,
			t1.POST_IS_APPROVED, t1.POST_HAS_FILE, t3.USER_AVATAR, t3.USER_TITLE, t3.USER_NAME_COLOR, t1.POST_ICON,
			t1.POST_PARENT_ID, t2.USER_MEMBERSHIP_LEVEL, t1.USER_ID, t3.USER_AVATAR_WIDTH, t3.USER_AVATAR_HEIGHT,
			t3.USER_GROUP_IMAGES
		FROM
			{$config['TABLE_PREFIX']}POSTS AS t1,
			{$config['TABLE_PREFIX']}USERS AS t2,
			{$config['TABLE_PREFIX']}USER_PROFILE AS t3
		WHERE
			t1.USER_ID = t2.USER_ID
		AND t1.USER_ID = t3.USER_ID
		$P_Viewable
		$extra
		ORDER BY POST_ID
	";
	$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	$totalthread = $dbh->total_rows($sth);
	$tsubject = "";
	for ($i = 0; $i < $totalthread; $i++) {

		list ($Number, $Posted, $Username, $IP, $Subject, $Body, $Approved, $Files, $Picture, $Title, $Color, $Icon, $Parent, $PostStatus, $Posterid, $picwidth, $picheight, $groupimages) = $dbh->fetch_array($sth);

		$time = $html->convert_time($Posted, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT'], true);

		$EUsername = $Posterid;
		$PUsername = $html->user_color($Username, $Color, $PostStatus);


		// We need to know if this was made by an admin or moderator
		$UserStatus = $html->user_status($Posterid, $groupimages, ",$Posterid,");

		// Mark it if it isn't approved
		if ($Approved == "0") {
			$Unapproved = "({$ubbt_lang['NOT_APPROVED']}) ";
		} else {
			$Unapproved = "";
		}

		$Subjectlinkstart = "<a href=\"" . make_ubb_url("ubb=showflat&Number=$Number#Post$Number", $Subject, false) . "\">";
		$Subjectlinkstop = "</a>";

		$folder = "icons";

		$showicon = "";
		if (!$Icon) {
			$Icon = "blank.gif";
		}

		// If its an anonymous post, dont give a link to the profile
		if ($Posterid == "1") {
			$Username = $ubbt_lang['ANON_TEXT'];
			$Title = $ubbt_lang['UNREGED_USER'];

		} else {
			$Username = "<a href=\"" . make_ubb_url("ubb=showprofile&User=$EUsername", $Username, false) . "\">$PUsername</a>";
		}

		if (!$userob->check_access("site", "EXT_INFO")) $IP = "";

		$picture = "";
		if (($Picture) && ($Picture != "http://") && (($AVATARS_WITH_POSTS) || ($AVATARS_WITH_POSTS == 'on'))) {
			$picsize = "";
			if ($picwidth && $picheight) {
				$picsize = "width=\"$picwidth\" height=\"$picheight\"";
			} else {
				$picsize = "width=\"{$config['AVATAR_MAX_WIDTH']}\" height=\"{$config['AVATAR_MAX_HEIGHT']}\"";
			}
			$picture = "<img src=\"$Picture\" alt=\"\" $picsize />";
		}

		// If there is an image attachment, we need to display it inline.
		$postrow[$i]['filelink'] = "";
		$postrow[$i]['thumbs'] = array();
		$filecount = 0;
		if ($Files) {
			$query = "
				SELECT
					FILE_ID, FILE_NAME, FILE_ORIGINAL_NAME, FILE_DOWNLOADS, FILE_SIZE, FILE_TYPE,
					FILE_DESCRIPTION, FILE_DIR, FILE_WIDTH, FILE_HEIGHT
				FROM
					{$config['TABLE_PREFIX']}FILES
				WHERE
					POST_ID = ?
				ORDER BY FILE_ID ASC
			";
			$stx = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
			$img_array = array("gif", "png", "jpg", "jpeg");
			while (list($file_id, $file_name, $filename_orig, $downloads, $size, $ext, $file_desc, $file_dir, $file_width, $file_height) = $dbh->fetch_array($stx)) {

				$filecount++;
				// If this is a gallery forum, grab the medium image.
				if (!$postrow[$i]['gallery_pic'] && $forum_info['FORUM_IS_GALLERY']) {
					if (!$file_desc) {
						$img_link = "$filename_orig";
					} else {
						$img_link = preg_replace("/ +/", "_", $file_desc) . ".$ext";
					}
					$postrow[$i]['gallery_pic'] = "<img id=\"mediumpic\" style=\"cursor: pointer;\" onclick=\"showFullSize($file_width,$file_height,$file_id)\" src=\"{$config['FULL_URL']}/gallery/$file_dir/medium/$file_id.$ext\" alt=\"{$img_link}\" title=\"{$ubbt_lang['SHOW_FULL']}\" />";
					$postrow[$i]['gallery_desc'] = $file_desc;
					$postrow[$i]['thumb'] = "[img]{$config['FULL_URL']}/gallery/{$file_dir}/thumbs/{$file_id}.{$ext}[/img]";
					$postrow[$i]['medium'] = "[img]{$config['FULL_URL']}/gallery/{$file_dir}/medium/{$file_id}.{$ext}[/img]";
					$postrow[$i]['full'] = "[img]{$config['FULL_URL']}/gallery/{$file_dir}/full/{$file_id}.{$ext}[/img]";
					$postrow[$i]['width'] = $file_width;
					$postrow[$i]['height'] = $file_height;
					$postrow[$i]['size'] = file_size($size);
				}

				// If this isn't a gallery, we're just displaying attachments
				if (!$forum_info['FORUM_IS_GALLERY']) {
					if (!$downloads) {
						$downloads = "0";
					}
					if ($file_desc) {
						$postrow[$i]['filelink'] .= "<br><div style=\"width:98%;margin:0 1em;padding:3px;\">{$ubbt_lang['FILE_DESC']} $file_desc</div>";
					}
					if (($size < $config['INLINE_IMAGE'] && in_array($ext, $img_array)) || (!$size && preg_match("/\.(gif|jpg|jpeg|png)$/i", $filename_orig))) {
						if (!$size) {
							// USE THIS LINE IF: You upgraded from UBB.threads 6.x and kept the same attachments directory for UBB.threads 7.x
							$postrow[$i]['filelink'] .= "<img src=\"{$config['ATTACHMENTS_URL']}/$filename_orig\" alt=\"Attached picture {$filename_orig}\" title=\"{$filename_orig}\" class=\"post-image\" /><br>";
							// USE THIS LINE IF: You upgraded from UBB.threads 6 and used a new attachments directory for UBB.threads 7. Edit the path if needed.
//							$postrow[$i]['filelink'] .= "<img src=\"/ubbthreads/attach/$filename_orig\" alt=\"Attached picture {$filename_orig}\" title=\"{$filename_orig}\" class=\"post-image\" /><br>";
						} else {
							$postrow[$i]['filelink'] .= "<img src=\"" . preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", false)) . "\" alt=\"Attached picture {$filename_orig}\" title=\"{$filename_orig}\" class=\"post-image\" /><br>";
						}
					} else {
						$postrow[$i]['filelink'] .= "<!-- attachment --><div style=\"padding:6px\"><fieldset class=\"fieldset\"><legend>Attached File</legend><div style=\"padding:3px\"> <img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/file.gif\" alt=\"\" /> $file_attach_type <a href=\"" . preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", false)) . "\"><b>$filename_orig</b></a>&nbsp;&nbsp;<span class=\"small\">($downloads {$ubbt_lang['DOWNLOADS']})</span></div></fieldset></div><!-- / attachment -->";
					}
				} else {
					$postrow[$i]['thumbs'][] = array(
						"id" => $file_id,
						"src" => "{$config['FULL_URL']}/gallery/$file_dir/thumbs/$file_id.$ext",
						"url" => "{$config['FULL_URL']}/gallery/$file_dir/full/$file_id.ext",
						"desc" => ubbchars($file_desc, ENT_QUOTES),
					);
				}
			}
		}

	// If there is a poll in this post, we need to include includepoll.php
	// or includepollresults.php depending on if they voted or not
	// ...this needs to be written.

//		$postrow[$i]['showpoll'] = "";					// Not Written
		$postrow[$i]['Username'] = $Username;
//		$postrow[$i]['UserStatus'] = $UserStatus;		// Not Used - User Group Image
//		$postrow[$i]['Title'] = $Title;					// Not Used - User Title
		$postrow[$i]['time'] = $time;
//		$postrow[$i]['IP'] = $IP;						// Uncomment To Enable - User IP Address
		$postrow[$i]['fileurl'] = '';
//		$postrow[$i]['picture'] = $picture;				// Not Used - User Avatar
//		$postrow[$i]['folder'] = $folder;				// Not Used - Path for Post Icons
//		$postrow[$i]['Icon'] = $Icon;					// Not Used	- Post Icons
		$postrow[$i]['Unapproved'] = $Unapproved;
		$postrow[$i]['Subjectlinkstart'] = $Subjectlinkstart;
		$postrow[$i]['Subject'] = $Subject;
		$postrow[$i]['Subjectlinkstop'] = $Subjectlinkstop;
		$postrow[$i]['Body'] = $Body;
	}

	$postrowsize = sizeof($postrow);

	$smarty_data = array(
		"tsubject" => $tsubject,
		"postrow" => $postrow,
	);

	return array(
		"header" => "",
		"template" => "printthread",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>