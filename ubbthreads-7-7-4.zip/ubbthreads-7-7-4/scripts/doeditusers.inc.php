<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_doeditusers_gpc() {
	return array(
		"input" => array(
			"user_array" => array("user", "post", "int", 0),
			"email" => array("email", "post", array("immediate", "none", "newtopic"), "none"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 1,
	);
}

function page_doeditusers_run() {

	global $in, $user, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$watch_lists = unserialize($_SESSION['watch_lists']);

	foreach ($user_array as $user_id => $value) {
		$query = "
			delete from	{$config['TABLE_PREFIX']}WATCH_LISTS
			where	USER_ID = ?
			and	WATCH_ID = ?
			and	WATCH_TYPE = 'u'
		";
		$dbh->do_placeholder_query($query, array($user['USER_ID'], $user_id), __LINE__, __FILE__);

		unset($watch_lists['u'][$user_id]);

	}

	$_SESSION['watch_lists'] = serialize($watch_lists);

	foreach ($email as $user_id => $value) {
		$immediate = 0;
		switch ($value) {
			case "immediate":
				$immediate = 1;
				break;
			case "newtopic":
				$immediate = 2;
				break;
			default:
				$immediate = 0;
				break;
		}

		$query_vars = array($immediate, $user['USER_ID'], $user_id);
		$query = "
			update 	{$config['TABLE_PREFIX']}WATCH_LISTS
			set	WATCH_NOTIFY_IMMEDIATE = ?
			where	USER_ID = ?
			and	WATCH_ID = ?
			and	WATCH_TYPE = 'u'
		";

		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}

	// ---------------------
	// Return to the profile
	return array(
		"data" => $data,
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "myhome&tab=users",
	);
}

?>