<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_coppaform_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("coppaform"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_coppaform_run() {

	global $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$date = date("M/d/Y");

	// Grab the coppainsert file
	$insert = @file("{$config['FULL_PATH']}/includes/coppainsert.php");
	if (!is_array($insert)) {
		$insert = @file("{$config['BASE_URL']}/includes/coppainsert.php");
	}
	$coppainsert = "";
	if ($insert) {
		foreach ($insert as $linenum => $line) {
			$coppainsert .= "$line";
		}
	}

	// --------------------------------
	// Grab their info, if there is any
	$coppaid = "";
	if (isset(${$config['COOKIE_PREFIX'] . "ubbt_coppaid"})) {
		$coppaid = ${$config['COOKIE_PREFIX'] . "ubbt_coppaid"};
	}
	$query = "
	SELECT t1.USER_DISPLAY_NAME,t2.USER_REAL_EMAIL,t2.USER_BIRTHDAY
	FROM   {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2
	WHERE  t1.USER_ID = ?
	AND    t1.USER_ID = t2.USER_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($coppaid), __LINE__, __FILE__);
	list($loginname, $emailaddress, $birthdate) = $dbh->fetch_array($sth);

	$smarty_data = array(
		"loginname" => $loginname,
		"emailaddress" => $emailaddress,
		"birthdate" => $birthdate,
		"coppainsert" => $coppainsert,
	);

	return array(
		"header" => array(
			"title" => $config['COMMUNITY_TITLE'],
			"refresh" => 0,
			"user" => array(),
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
		),
		"template" => "coppaform",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>