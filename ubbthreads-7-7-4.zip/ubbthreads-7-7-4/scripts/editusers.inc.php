<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_editusers_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("editusers"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_editusers_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$user_array = array();

	$is_checked = ' selected="selected" ';
	$is_not_checked = '';

	$query = "
		select 	fav.WATCH_ID,u.USER_DISPLAY_NAME,fav.WATCH_NOTIFY_IMMEDIATE
		from		{$config['TABLE_PREFIX']}WATCH_LISTS as fav,
						{$config['TABLE_PREFIX']}USERS as u
		where		fav.USER_ID = ?
		and			fav.WATCH_ID = u.USER_ID
		and			fav.WATCH_TYPE = 'u'
		order by	lower(USER_DISPLAY_NAME) asc
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	while (list($id, $name, $immediate) = $dbh->fetch_array($sth)) {
		$email_new_topic = ($immediate == 2) ? $is_checked : $is_not_checked;
		$email_immediate = ($immediate == 1) ? $is_checked : $is_not_checked;
		$email_none = ($email_new_topic || $email_immediate) ? $is_not_checked : $is_checked;

		$user_array[] = array(
			"id" => $id,
			"name" => $name,
			"none" => $email_none,
			"immediate" => $email_immediate,
			"newtopic" => $email_new_topic,
		);
	}

	$smarty_data = array(
		"user_array" => $user_array,
		"mystuff" => $html->mystuff(),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$home = make_ubb_url("ubb=myhome", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['EDIT_FAV_USERS']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"javascript" => array('inline_moderation.js'),
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 <a href="{$home}">{$ubbt_lang['VIEW_WATCH']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 {$ubbt_lang['EDIT_FAV_USERS']}
BREADCRUMB
		,
		),
		"template" => "editusers",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>