<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_editnotify_gpc() {
	return array(
		"input" => array(
			"type" => array("type", "get", "alpha"),
			"f" => array("f", "get", "int"),
			"t" => array("t", "get", "int"),
			"do" => array("do", "get", "alpha"),
		),
		"wordlets" => array("editnotify"),
		"user_fields" => "",
		"regonly" => 1,
	);
}

function page_editnotify_run() {
	global $in, $user, $ubbt_lang, $config, $dbh, $html, $userob;

	$mode = "";
	$id = 0;

	if ($in['f'] != 0) {
		$mode = "f";
		$id = $in['f'];
	} else if ($in['t'] != 0) {
		$mode = "t";
		$id = $in['t'];
	} else {
		$html->not_right($ubbt_lang['TYPE_NOT_SPECIFIED']);
	}

	$response = "";

	$title = "";

	$watch_lists = unserialize($_SESSION['watch_lists']);

	foreach ($topic as $topic_id => $value) {
		$query = "
			delete from	{$config['TABLE_PREFIX']}WATCH_LISTS
			where	USER_ID = ?
			and	WATCH_ID = ?
			and	WATCH_TYPE = 't'
		";
		$dbh->do_placeholder_query($query, array($user['USER_ID'], $topic_id), __LINE__, __FILE__);
		unset($watch_lists['t'][$topic_id]);

	}

	if ($mode == "f") {
		if (!$userob->check_access("forum", "SEE_FORUM", $id)) {
			$html->not_right($ubbt_lang['INVALID_FORUM_ID']);
		}

		$query = "
			SELECT	FORUM_TITLE
			FROM	{$config['TABLE_PREFIX']}FORUMS
			WHERE	FORUM_ID = ?
		";

		$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
		$result = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$dbh->finish_sth($sth);
		if (($title = array_get($result, 'FORUM_TITLE', null)) === null) {
			$html->not_right($ubbt_lang['INVALID_FORUM_ID']);
		}
	} else if ($mode == "t") {
		$query = "
			SELECT	FORUM_ID, TOPIC_SUBJECT
			FROM	{$config['TABLE_PREFIX']}TOPICS
			WHERE	TOPIC_ID = ?
		";

		$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
		list($fid, $title) = $dbh->fetch_array($sth);
		if (!$title) {
			$html->not_right($ubbt_lang['INVALID_TOPIC_ID']);
		}

		if (!$userob->check_access("forum", "SEE_FORUM", $fid)) {
			$html->not_right($ubbt_lang['INVALID_TOPIC_ID']);
		}

		$query = "
			select FORUM_TITLE
			from {$config['TABLE_PREFIX']}FORUMS
			where FORUM_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($fid), __LINE, __FILE__);
		list($forum_title) = $dbh->fetch_array($sth);

	} else if ($mode == "u") {
		$query = "
			SELECT	USER_DISPLAY_NAME
			FROM	{$config['TABLE_PREFIX']}USERS
			WHERE	USER_ID = ?
		";

		$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
		$result = $dbh->fetch_array($sth, MYSQLI_ASSOC);
		$dbh->finish_sth($sth);
		if (($title = array_get($result, 'USER_DISPLAY_NAME', null)) === null) {
			$html->not_right($ubbt_lang['INVALID_USER_ID']);
		}

	}

	if ($in['do'] == "remove") {
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
			WHERE	USER_ID = ? AND WATCH_TYPE = ? AND WATCH_ID = ?
		";

		$dbh->do_placeholder_query($query, array($user['USER_ID'], $mode, $id), __LINE__, __FILE__);

		unset($watch_lists[$mode][$id]);

		$response = $ubbt_lang['REMOVED_WATCH'];
	} else if ($in['do'] == "immediate_notify" || $in['do'] == "no_notify" || $in['do'] == "new_topic_notify") {
		$notify_int = 0;
		switch ($in['do']) {
			case "immediate_notify":
				$notify_int = 1;
				break;
			case "new_topic_notify":
				$notify_int = 2;
				break;
		}

		$watch_lists[$mode][$id] = 1;

		$query = "
			UPDATE {$config['TABLE_PREFIX']}WATCH_LISTS
			SET WATCH_NOTIFY_IMMEDIATE = ?
			WHERE USER_ID = ? AND WATCH_TYPE = ? AND WATCH_ID = ?
		";

		$dbh->do_placeholder_query($query, array($notify_int, $user['USER_ID'], $mode, $id), __LINE__, __FILE__);
	}

	$_SESSION['watch_lists'] = serialize($watch_lists);

	$redirect_text = $html->substitute($ubbt_lang[strtoupper($in['do']) . '_' . strtoupper($mode)], array('NAME' => $title));

	$heading = $ubbt_lang['ACTION_COMPLETED'];
	$redirect = $in['type'] . (($in['type'] == "postlist") ? "&Board=$fid" : "");
	$return_text = $html->substitute($ubbt_lang['PLEASE_WAIT_' . strtoupper($in['type'])], array('NAME' => $forum_title));

	$cfrm = make_ubb_url("", "", false);
	$html->send_redirect(
		array(
			"redirect" => $redirect,
			"heading" => $heading,
			"body" => $redirect_text,
			"delay" => 5,
			"returnlink" => "<a href=\"" . make_ubb_url("ubb=$redirect", "", false) . "\">$return_text</a>",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		)
	);
}

?>