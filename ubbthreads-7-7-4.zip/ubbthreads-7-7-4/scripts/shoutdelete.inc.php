<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.3
  Purpose: Delete a shout from the ShoutChat
  Future:
*/

define('NO_WRAPPER', 1);
function page_shoutdelete_gpc() {
	return array(
		"input" => array(
			"id" => array("id", "get", "int"),
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
}

function page_shoutdelete_run() {
	global $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;
	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select USER_ID, SHOUT_DISPLAY_NAME, SHOUT_TEXT
		from	{$config['TABLE_PREFIX']}SHOUT_BOX
		where SHOUT_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	list($user_id, $shout_user, $shout_text) = $dbh->fetch_array($sth);

	if ($user_id == $user['USER_ID'] || $user['USER_MEMBERSHIP_LEVEL'] == "Administrator" || preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL'])) {
		// Delete it
		$query = "
			delete from {$config['TABLE_PREFIX']}SHOUT_BOX
			where SHOUT_ID = ?
		";
		$dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	}

	// Log it
	admin_log("DELETE_SHOUT", "$id: $shout_user ($user_id): $shout_text");

	return false;
}

?>