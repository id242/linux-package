<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_portal_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("portal"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_portal_run() {
	global $style_array, $myinfo, $userob, $smarty, $in, $ubbt_lang, $config, $visit, $dbh, $html, $user;
	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!isset($config['NEWS_ITEMS']) || !$config['NEWS_ITEMS']) {
		$config['NEWS_ITEMS'] = 5;
	}

	if (!$config['PORTAL_NEWS_FORUMS']) {
		$config['PORTAL_NEWS_FORUMS'] = "''";
	}

	// Grab the latest news items
	$query = "
		SELECT
			t1.TOPIC_SUBJECT, t2.USER_ID, t2.USER_DISPLAY_NAME,
			t1.TOPIC_CREATED_TIME, t3.POST_BODY, t1.POST_ID,
			t3.POST_HAS_FILE,
			t1.TOPIC_VIEWS, t1.TOPIC_REPLIES, t1.TOPIC_NEWS_ICON
		FROM
			{$config['TABLE_PREFIX']}TOPICS AS t1,
			{$config['TABLE_PREFIX']}USERS AS t2,
			{$config['TABLE_PREFIX']}POSTS AS t3
		WHERE
			(t1.FORUM_ID IN ({$config['PORTAL_NEWS_FORUMS']})
			OR (t1.TOPIC_NEWS_ICON IS NOT NULL
			AND t1.TOPIC_NEWS_ICON != ''))
		AND t1.USER_ID = t2.USER_ID
		AND t1.POST_ID = t3.POST_ID
		AND t1.TOPIC_IS_APPROVED = '1'
		AND t3.POST_IS_APPROVED = '1'
		AND t1.TOPIC_STATUS <> 'M'
		ORDER BY
			TOPIC_CREATED_TIME DESC
		LIMIT {$config['NEWS_ITEMS']}
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	$news = array();
	while (list($subject, $user_id, $poster, $time, $body, $topic_id, $files, $views, $replies, $newsicon) = $dbh->fetch_array($sth)) {
		if ($user_id == 1) {
			$poster = $ubbt_lang['ANON_TEXT'];
		}

		$old_len = strlen($body);
		$body = preg_replace('#\[end_news_blurb\].+$#', '', $body);

		$bodyIMG = "";
		$bodyTXT = "";
		if ($config['NEWS_BODYIMAGE']) {
			if (preg_match('/<img [^>]*src=["|\']([^"|\']+)/i', $body, $match)) {
				$bodyIMG = $match[1];
			}
			if ($bodyIMG) {
				list($BIwidth, $BIheight, $BItype, $BIattr) = getimagesize("$bodyIMG");
				if ($BIwidth < 240 && $BIheight < 240) {
					$bodyIMG = "";
				}
			}
			$bodyTXT = str_replace('<br>', ' ', $body);
//			$bodyTXT = strip_tags($bodyTXT, "<a>");		// All HTML is stripped. Links are allowed, which may break things when they get snipped.
			$bodyTXT = ubbchars(strip_tags($bodyTXT));	// All HTML is stripped
		}

		$news[] = array(
			"subject" => $subject,
			"user_id" => $user_id,
			"poster" => $poster,
			"time" => $html->convert_time($time, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']),
			"body" => $body,
			"bodyIMG" => $bodyIMG,
			"bodyTXT" => $bodyTXT,
			"topic_id" => $topic_id,
			"files" => $files,
			"views" => $views,
			"replies" => $replies,
			"newsicon" => $newsicon,
			"truncated" => (strlen($body) < $old_len),
		);
	}

	if (is_numeric($config['SHAREAHOLIC']) && $config['SHAREAHOLIC'] > 0) {
		$shareaholic = '<div class="shareaholic-canvas" data-app="share_buttons" data-app-id="' . $config['SHAREAHOLIC'] . '"></div>';
		$shareHeader = 1;
	}

	$smarty_data = array(
		"news" => $news,
		"shareaholic" => $shareaholic,
		"newsslice" => $config['NEWS_SLICE'],
	);
	return array(
		"header" => array(
			"title" => $config['COMMUNITY_TITLE'],
			"refresh" => 0,
			"shareHeader" => $shareHeader,
			"user" => $user,
			"Board" => "",
			"bypass" => "",
			"onload" => "",
			"javascript" => array('assets/jquery.expander.min.js'),
			"breadcrumb" => "",
			"force_columns" => 1,
		),
		"template" => "portal",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
		"force_columns" => 1,
	);
}

?>