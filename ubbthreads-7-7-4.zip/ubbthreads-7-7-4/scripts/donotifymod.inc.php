<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_donotifymod_gpc() {
	return array(
		"input" => array(
			"Board" => array("Board", "post", "int"),
			"what" => array("what", "post", "alpha"),
			"Number" => array("Number", "post", "int"),
			"fpart" => array("fpart", "post", "alphanum"),
			"reason" => array("reason", "post"),
		),
		"wordlets" => array("donotifymod"),
		"user_fields" => "t2.USER_REAL_EMAIL",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_donotifymod_run() {

	global $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// -------------------------------------------------------------
	// If we didn't get a board or number then we give them an error
	if (!$Board) {
		$html->not_right($ubbt_lang['POST_PROB']);
	}

	if (!$userob->check_access("forum", "SEE_FORUM", $Board)) {
		$html->not_right($ubbt_lang['BAD_GROUP']);
	}

	// --------------------------------------------
	// Let's find out if they should be here or not
	$query = "
		select t1.FORUM_ID
		from {$config['TABLE_PREFIX']}TOPICS as t1,
		{$config['TABLE_PREFIX']}POSTS as t2
		where t2.POST_ID = ?
		and t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($Board) = $dbh->fetch_array($sth);

	$query = "
		SELECT FORUM_TITLE,CATEGORY_ID,FORUM_PARENT
		FROM   {$config['TABLE_PREFIX']}FORUMS
		WHERE  FORUM_ID = ?
		AND FORUM_IS_ACTIVE='1'
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list($title, $CatNumber, $parent_id) = $dbh->fetch_array($sth);

	if (!$Board) {
		$html->not_right($ubbt_lang['POST_PROB']);
	}

	// ----------------------------------
	// Grab the main subject for this post
	$query = "
		SELECT p.POST_SUBJECT, p.POST_DEFAULT_BODY, p.POST_BODY, u.USER_DISPLAY_NAME
			FROM {$config['TABLE_PREFIX']}POSTS p,
					 {$config['TABLE_PREFIX']}USERS u
		WHERE  POST_ID = ?
			AND	p.USER_ID = u.USER_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($tsubject, $tbody, $hbody, $postername) = $dbh->fetch_array($sth);

	// --------------------------------------
	// Setup a variable to hold the mail body
	$echoname = $user['USER_DISPLAY_NAME'];

	// -----------------------------
	// Grab the moderators to notify
	$query = "
		SELECT USER_ID
		FROM   {$config['TABLE_PREFIX']}MODERATORS
		WHERE  FORUM_ID = ?
	";
	$ismod = 0;
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);

	$notify_array = array();
	while (list($Mod) = $dbh->fetch_array($sth)) {
		$notify_array[] = $Mod;
	}

	// Grab any admins that want notification
	$query = "
		select t1.USER_ID
		from {$config['TABLE_PREFIX']}USER_PROFILE as t1,
			{$config['TABLE_PREFIX']}USERS as t2
		where t1.USER_ID = t2.USER_ID
		and t1.USER_REPORT_POST_NOTIFY = 1
		and t2.USER_MEMBERSHIP_LEVEL <> 'User'
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	while (list($admin) = $dbh->fetch_array($sth)) {
		if (!in_array($admin, $notify_array)) {
			$notify_array[] = $admin;
		}
	}

	// If notify_array is empty, send to the main site admin
	if (!sizeof($notify_array)) {
		$notify_array[] = $config['MAIN_ADMIN_ID'];
	}

	// --------------------------------------------------------
	// Loop through the moderators and inform them at most once
	$mailer = new mailer();
	$already_sent = array();
	foreach ($notify_array as $k => $v) {

		// --------------------------------------------------------------------
		// Grab the email address, language and display name for this moderator
		$query = "
			SELECT up.USER_REAL_EMAIL, up.USER_LANGUAGE, u.USER_DISPLAY_NAME
				FROM {$config['TABLE_PREFIX']}USER_PROFILE up,
						 {$config['TABLE_PREFIX']}USERS u
			WHERE	up.USER_ID = ?
				AND	up.USER_ID = u.USER_ID
		";
		$sti = $dbh->do_placeholder_query($query, array($v), __LINE__, __FILE__);
		list($Email, $Lang, $Username) = $dbh->fetch_array($sti);

		// Don't dupe to same email
		if (in_array($Email, $already_sent)) continue;
		$already_sent[] = $Email;

		$mailer->set_language($Lang);
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $Username));
		$mailer->set_subject('DNM_SUBJECT', array('FORUM_TITLE' => $title, 'POST_SUBJECT' => $tsubject));
		$mailer->add_content('DNM_CONTENT', array('USERNAME' => $echoname, 'POST_SUBJECT' => $tsubject));
		$mailer->add_content('DNM_CONTENT1', array('REASON' => $reason));
		$mailer->add_content('DNM_CONTENT2', array('POST_URL' => make_ubb_url("ubb=showflat&Number=$Number#Post$Number", $tsubject, true, true)), true);
		$mailer->add_post($postername, $tsubject, array(), $hbody, $tbody);
		$mailer->ubbt_mail($Email);
	}

	// -------------------------------------------------------------------
	// Update the table so we know the moderator has already been notified
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}MODERATOR_NOTIFICATIONS
		(POST_ID)
		VALUES
		( ? )
	";
	$dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

	// --------------------------------------
	// Give confirmation and return to thread

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "$what&Number=$Number&fpart=$fpart",
			"heading" => $ubbt_lang['NOTIFY_SENT'],
			"body" => "{$ubbt_lang['NOTIFY_SENT']} {$ubbt_lang['RET_FORUM']}",
			"returnlink" => "<a href=\"" . make_ubb_url("ubb=$what&Number=$Number&fpart=$fpart", $tsubject, false) . "\">{$ubbt_lang['FORUM_RETURN']}</a>",
			"Board" => $Board,
			"Category" => $CatNumber,
			"parent_forum" => $parent_id,
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		)
	);
}

?>