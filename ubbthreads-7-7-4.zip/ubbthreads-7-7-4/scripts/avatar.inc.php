<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);
function page_avatar_gpc() {
	return array(
		"input" => array(
			"startat" => array("startat", "get", "int"),
			"form" => array("form", "get", "alphanum"),
		),
		"wordlets" => array("avatar"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_avatar_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	if (!$startat) {
		$startat = "0";
	}

	$html = new html;

	// --------------------------------
	// Let's grab all the avatar images
	$avatarlist = "";
	$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['avatars']}");
	$i = 0;
	$currentwidth = 0;
	$prevpage = "";
	$nextpage = "";
	if ($startat > 0) {
		$start = $startat - 10;
		$prevpage = "<span class=\"post-buttons\"><a href=\"" . make_ubb_url("ubb=avatar&startat=$start&form=$form", "", false) . "\"><i class=\"fas fa-angle-double-left fa-fw fa-2x\" aria-hidden=\"true\"></i> {$ubbt_lang['PREV_ICON']}</a></span>";
	}

	while (($file = readdir($dir)) != false) {
		if (($file == ".") || ($file == "..") || ($file == "index.html")) {
			continue;
		}
		if ($i < $startat) {
			$i++;
			continue;
		}
		$imagehw = @GetImageSize("{$config['FULL_PATH']}/images/{$style_array['avatars']}/$file");
		$iw = $imagehw[0];
		$ih = $imagehw[1];
		if (!$iw) {
			$iw = "48";
		}
		if (!$ih) {
			$ih = "48";
		}

		$currentwidth = $currentwidth + $iw;
		if ($currentwidth > 250) {
			$currentwidth = $iw;
		}
		if ($i == $startat + 10) {
			$start = $startat + 10;
			$nextpage = "<span class=\"post-buttons\"><a href=\"" . make_ubb_url("ubb=avatar&startat=$start&form=$form", "", false) . "\">{$ubbt_lang['NEXT_ICON']} <i class=\"fas fa-angle-double-right fa-fw fa-2x\" aria-hidden=\"true\"></i></a></span>";
			$prevpage = "&nbsp;$prevpage";
			break;
		}

		$avatarlist .= "<a href=\"javascript:void(0);\" onclick=\"javascript:preview('$file','$iw','$ih');\"><img src=\"{$config['BASE_URL']}/images/{$style_array['avatars']}/$file\" alt=\"\" class=\"p6\" /></a> ";
		$i++;
	}

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	$smarty_data = array(
		"stylesheet" => $stylesheet,
		"avatarlist" => & $avatarlist,
		"prevpage" => $prevpage,
		"nextpage" => $nextpage,
		"form" => $form,
	);

	return array(
		"header" => array(
			"title" => $ubbt_lang['AVATAR'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "avatar",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>