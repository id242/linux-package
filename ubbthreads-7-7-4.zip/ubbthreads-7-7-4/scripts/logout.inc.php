<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_logout_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("login"),
		"user_fields" => "USER_TOPIC_VIEW_TYPE",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_logout_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// --------------------------------------------------------
	// Delete their cookie and remove them from the online page
	clear_online();

	$date = $html->get_date();
	$query = "
	UPDATE {$config['TABLE_PREFIX']}USERS
	SET    USER_SESSION_ID = '0'
	WHERE  USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);

	$query = "
	UPDATE {$config['TABLE_PREFIX']}USER_DATA
	SET    USER_LAST_VISIT_TIME = ?
	WHERE  USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($date, $user['USER_ID']), __LINE__, __FILE__);

	$query = "
    delete from {$config['TABLE_PREFIX']}ONLINE
    where USER_ID = ?
  ";
	$dbh->do_placeholder_query($query, array($user['USER_ID']));


	// ----------------------------------
	// get rid of their session or cookie
	$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_myid", "0", time() - 31968000);
	$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_mysess", "0", time() - 31968000);
	$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_hash", "0", time() - 31968000);

	$userob->is_logged_in = false;
	$_SESSION['forumvisit'] = array();
	$_SESSION['topicread'] = array();
	$_SESSION['watch_lists'] = array();

	rebuild_islands(0, array("online"));

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(array(
		"heading" => $ubbt_lang['LOGOUT_HEADER'],
		"body" => $ubbt_lang['LOGOUT_BODY'],
		"returnlink" => "",
		"redirect" => "cfrm",
		"delay" => 0,
		"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['LOGOUT_HEADER']}
BREADCRUMB
	,
	));
}

?>