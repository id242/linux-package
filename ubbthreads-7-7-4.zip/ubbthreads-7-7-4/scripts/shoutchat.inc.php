<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose: View ShoutChat in page
  Future:
*/

function page_shoutchat_gpc() {
	return array(
		"input" => array(""),
		"wordlets" => array("portal_islands"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_shoutchat_run() {
	global $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob;
	extract($in, EXTR_OVERWRITE | EXTR_REFS);

	if (!$userob->check_access("site", "CAN_SEE_SHOUTS")) {
		$html->not_right($ubbt_lang['SHOUT_ERR']);
	}

	$smarty_data = array(
		"style_side" => "",
		"shoutchat" => 1,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['SHOUT_BOX'],
			"refresh" => 0,
			"user" => "",
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['SHOUT_CHAT']}
BREADCRUMB
		,
		),
		"template" => "shoutchat",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>