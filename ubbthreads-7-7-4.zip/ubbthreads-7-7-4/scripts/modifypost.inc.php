<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_modifypost_gpc() {
	return array(
		"input" => array(
			"deleteattach" => array("deleteattach", "both", "int"),
			"Username" => array("Username", "both", ""),
			"Number" => array("Number", "both", "int"),
			"Board" => array("Board", "both", "alphanum"),
			"what" => array("what", "both", "alpha"),
			"fpart" => array("fpart", "both", "int"),
			"Approved" => array("Approved", "both", "alpha"),
			"convert" => array("convert", "both", "alpha"),
			"Subject" => array("Subject", "both", ""),
			"Body" => array("Body", "both", ""),
			"peditchange" => array("peditchange", "both", ""),
			"peditdelete" => array("peditdelete", "both", ""),
			"markedit" => array("markedit", "both", "int"),
			"editreason" => array("editreason", "both"),
			"peditapprove" => array("peditapprove", "both", ""),
			"peditunapprove" => array("peditunapprove", "both", ""),
			"Icon" => array("Icon", "both", ""),
			"option" => array("option", "both", ""),
			"Main" => array("Main", "both", "int"),
			"addevent" => array("addevent", "both", "int"),
			"calday" => array("calday", "both", "int"),
			"calmonth" => array("calmonth", "both", "int"),
			"calyear" => array("calyear", "both", "int"),
			"addsig" => array("addsig", "both", "int"),
			"md5_stamp" => array("md5_stamp", "both", "alphanum"),
			"news_image" => array("news_image", "both"),
		),
		"wordlets" => array("modifypost"),
		"user_fields" => "USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_modifypost_run() {

	global $style_array, $html, $smarty, $user, $in, $myinfo, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!$Main) {
		$Main = "$Number";
	}

	// ------------------------
	// Predefine some variables
	$extra = "";
	$extra_var = "";

	$Subject = trim($Subject);
	$Body = trim($Body);
	$DefaultBody = $Body;

	$Username = $user['USER_DISPLAY_NAME'];
	$query = "
		SELECT
			t1.FORUM_ID, t1.TOPIC_REPLIES, t2.POST_IS_TOPIC, POST_POSTED_TIME
		FROM
			{$config['TABLE_PREFIX']}TOPICS AS t1,
			{$config['TABLE_PREFIX']}POSTS AS t2
		WHERE
			t2.POST_ID = ?
		AND t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($Board, $replies, $is_topic, $posted_on) = $dbh->fetch_array($sth);

	if (!$Board) {
		$query = "
			SELECT FORUM_ID
			FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
		list($Board, $first_post) = $dbh->fetch_array($sth);
	}
	$hasfile = 0;
	$query = "
		SELECT count(*)
		FROM {$config['TABLE_PREFIX']}FILES
		WHERE FILE_MD5 = ?
		   OR POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($md5_stamp, $Number), __LINE__, __FILE__);
	list($hasfile) = $dbh->fetch_array($sth);

	// --------------------------
	// Grab the board information
	$query = "
		SELECT FORUM_CUSTOM_HEADER, FORUM_STYLE, FORUM_TITLE, CATEGORY_ID, FORUM_PARENT, FORUM_IS_RSS, FORUM_RSS_TITLE, FORUM_IS_GALLERY
		FROM {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list($fheader, $fstyle, $Title, $cat_id, $parent_id, $is_rss, $rss_title, $is_gallery) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	// -------------------------------------------------
	// Here we need to figure out what stylesheet to use
	if ($fstyle) {
		$html->set_style($fstyle);
	}

	// Smarty variables needed by a variety of templates
	$smarty_data = array(
		"Board" => $Board,
		"what" => $what,
		"Number" => $Number,
		"Approved" => $Approved,
		"Username" => $Username,
		"Main" => $Main,
		"md5_stamp" => $md5_stamp,
	);

	// Deleting post
	if ($peditdelete) {

		$right_now = $html->get_date();
		$del_expired = false;
		$delete_timer = $userob->check_access("forum", "DELETE_POSTS", $Board);

		if (($right_now - $posted_on) > ($delete_timer * 60)) {
			$del_expired = true;
		}
		if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']) && $del_expired) {
			$html->not_right($ubbt_lang['DELETE_TIMER']);
		}
		if ($is_topic && $replies) {
			$html->not_right($ubbt_lang['NO_DELETE_FIRST']);
			exit;
		}
		if (!$user['USER_DISPLAY_NAME']) {
			$html->not_right($ubbt_lang['NO_AUTH']);
		}
		$cfrm = make_ubb_url("ubb=cfrm", "", false);
		return array(
			"header" => array(
				"title" => $ubbt_lang['PEDIT_DELETE'],
				"refresh" => 0,
				"user" => $user,
				"Board" => $Board,
				"Category" => $cat_id,
				"forum_parent" => $parent_id,
				"bypass" => 0,
				"onload" => "",
				"custom_header_footer" => $fheader,
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			),
			"template" => "modifypost_delete",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
		);
	}

	// -------------------------------------------------
	// Otherwise we are deleting the thread so do this sub
	elseif ($deletethread) {

		if (!$user['USER_DISPLAY_NAME']) {
			$html->not_right($ubbt_lang['NO_AUTH']);
		}
		$cfrm = make_ubb_url("ubb=cfrm", "", false);
		return array(
			"header" => array(
				"title" => $ubbt_lang['PEDIT_DELETE'],
				"refresh" => 0,
				"user" => $user,
				"Board" => $Board,
				"Category" => $cat_id,
				"forum_parent" => $parent_id,
				"custom_header_footer" => $fheader,
				"bypass" => 0,
				"onload" => "",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			),
			"template" => "modifypost_expire",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
		);
	}

	// -------------------------------------------------
	// Otherwise we are approving the post so do this sub
	elseif ($peditapprove) {


		if (!$user['USER_DISPLAY_NAME']) {
			$html->not_right($ubbt_lang['NO_AUTH']);
		}

		$cfrm = make_ubb_url("ubb=cfrm", "", false);

		return array(
			"header" => array(
				"title" => $ubbt_lang['PEDIT_APPROVE'],
				"refresh" => 0,
				"user" => $user,
				"Board" => $Board,
				"Category" => $cat_id,
				"forum_parent" => $parent_id,
				"bypass" => 0,
				"onload" => "",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			),
			"template" => "modifypost_approve",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
		);

	}

	// -------------------------------------------------
	// Otherwise we are unapproving the post so do this sub
	elseif ($peditunapprove) {


		if (!$user['USER_DISPLAY_NAME']) {
			$html->not_right($ubbt_lang['NO_AUTH']);
		}

		$cfrm = make_ubb_url("ubb=cfrm", "", false);

		return array(
			"header" => array(
				"title" => $ubbt_lang['PEDIT_UNAPPROVE'],
				"refresh" => 0,
				"user" => $user,
				"Board" => $Board,
				"Category" => $cat_id,
				"forum_parent" => $parent_id,
				"bypass" => 0,
				"onload" => "",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			),
			"template" => "modifypost_unapprove",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
		);

	}

	// ---------------------------------------------------------------------------
	// For security purposes we need to verify that this is user made this post or
	// if they are an admin or a moderator for this board.
	$Status = $user['USER_MEMBERSHIP_LEVEL'];

	// ------------------------------------------------
	// Make the sure the edittime value has not expired
	$expired = $userob->check_access("forum", "EDIT_POSTS", $Board) * 60;
	$current = $html->get_date();
	if (($current - $posted_on > $expired) && ($Status != "Administrator") && (!preg_match("/Moderator/", $Status))) {
		$html->not_right($ubbt_lang['EDITTIME']);
	}


	// ----------------------------------------------------------------------
	// Get the post info from the database and also check if this is the first
	// topic in the post
	$query = "
		SELECT
			t1.USER_ID, t1.POST_IS_TOPIC, t1.TOPIC_ID
		FROM
			{$config['TABLE_PREFIX']}POSTS AS t1,
			{$config['TABLE_PREFIX']}TOPICS AS t2
		WHERE
			t1.POST_ID = ?
		AND t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

	// -------------------------
	// Assign the retrieved data
	list($Postedby, $post_is_topic, $topic_id) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);


	// ---------------------------------
	// Check if they moderate this board
	$query = "
		SELECT FORUM_ID
		FROM {$config['TABLE_PREFIX']}MODERATORS
		WHERE USER_ID = ?
		  AND FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $Board), __LINE__, __FILE__);
	list($check) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	if (($user['USER_ID'] != $Postedby) && ($Status != "Administrator") && ($Status != "GlobalModerator") && (!$check)) {
		$html->not_right($ubbt_lang['NO_EDIT']);
	}

	// -------------------------------------
	// Make sure there is a subject and body
	if ((preg_match("/^\s*$/", $Subject)) || ($Body == "")) {
		$html->not_right($ubbt_lang['ALL_FIELDS']);
	}

	// ---------------------
	// Check maximum quote level
	unset($total);
	$max = $config['NESTED_QUOTES'] + 1;
	preg_match_all('%(\[quote=.+?\]|\[quote\]|\[/quote\])%', $Body, $result, PREG_PATTERN_ORDER);
	for ($i = 0; $i < count($result[0]); $i++) {
		$total .= $result[0][$i];
	}
	if (preg_match("%(\[/quote\]){{$max},}%", $total)) {
		$html->not_right($html->substitute($ubbt_lang['MAX_QUOTE'], array('QUOTE' => $config['NESTED_QUOTES'])));
	}


	if ($fstyle) {
		$html->set_style($fstyle);
	}

	// FIXME - FILTER THIS
	if (!$ParentUser) $ParentUser = 0;
	$extract = substr($Body, 0, 254);


	// --------------------------------------
	// Get rid of <, >, &, and " in the subject because we don't want them using
	// these character types in the subject line
	$Subject = ubbchars($Subject);
	if (!$userob->check_access("forum", "USE_MARKUP", $Board)) {
		$convert = "none";
	}

	$Body = $html->do_markup($Body, "post", $convert);


	// -----------------------------
	// Are we marking this as edited
	$editdate = 0;
	if ($markedit) {
		$editdate = $html->get_date();
	}

	// -----------------------
	// Run the censor filter
	if ($config['DO_CENSOR']) {
		$Body = $html->do_censor($Body);
		$Subject = $html->do_censor($Subject);
		$editreason = $html->do_censor($editreason);
	}

	// --------------------------------------
	// Update the calendar event if necessary
	if (!$addevent) {
		$calday = "";
		$calmonth = "";
		$calyear = "";
	}

	// -------------------
	// Gallery posts get the image icon
	if ($is_gallery) {
		$Icon = "image.gif";
	}
	$Icon = preg_replace("/('|\")/", "", $Icon);

	if (!$addsig) {
		$addsig = "0";
	}

	// -------------------
	// Sanitize editreason
	$editreason = ubbchars($editreason);


	// -------------------
	// Update the database
	$query_vars = array($Subject, $Body, $DefaultBody, $Icon, $editdate, $editreason, $user['USER_DISPLAY_NAME'], $addsig, $hasfile, $convert);
	if ($extra_var) {
		array_push($query_vars, $extra_var);
	}
	array_push($query_vars, $Number);

	$query = "
		UPDATE
			{$config['TABLE_PREFIX']}POSTS
		SET
			POST_SUBJECT = ? ,
			POST_BODY = ? ,
			POST_DEFAULT_BODY = ? ,
			POST_ICON = ? ,
			POST_LAST_EDITED_TIME = ? ,
			POST_LAST_EDIT_REASON = ? ,
			POST_LAST_EDITED_BY = ? ,
			POST_ADD_SIGNATURE = ? ,
			POST_HAS_FILE = ? ,
			POST_MARKUP_TYPE = ?
		$extra
		WHERE
			POST_ID = ?
	";
	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

	if ($post_is_topic == true) {

		// News image?
		$news_array = preg_split("#,#", $config['PORTAL_NEWS_FORUMS']);

		if (in_array($Board, $news_array) || $userob->check_access("forum", "CREATE_NEWS", $Board)) {
			$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['news']}");
			$found = 0;
			while (($file = readdir($dir)) != false) {
				$file = trim($file);
				if (($file == ".") || ($file == "..") || ($file == "index.html") || (!preg_match("/(gif|jpg|png)$/", $file))) {
					continue;
				}
				if ($file == $news_image) {
					$found = 1;
				}
			}
			if (!$found) {
				$news_image = "";
			}
		} else {
			$news_image = "";
		}

		if (!$calday) $calday = 0;
		if (!$calmonth) $calmonth = 0;
		if (!$calyear) $calyear = 0;
		if (!$addevent) $addevent = 0;

		$query_vars = array($Subject, $hasfile, $news_image, $addevent, $Icon, $topic_id);
		$query = "
			UPDATE
				{$config['TABLE_PREFIX']}TOPICS
			SET
				TOPIC_SUBJECT = ? ,
				TOPIC_HAS_FILE = ? ,
				TOPIC_NEWS_ICON = ? ,
				TOPIC_IS_EVENT = ? ,
				TOPIC_ICON = ?
			WHERE
				TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($topic_id), __LINE__, __FILE__);

		if ($addevent && $calday) {
			$query_vars = array($user['USER_ID'], $topic_id, $calday, $calmonth, $calyear, $Subject, "public");
			$query = "
				INSERT INTO
					{$config['TABLE_PREFIX']}CALENDAR_EVENTS
					(USER_ID, TOPIC_ID, CALENDAR_EVENT_DAY, CALENDAR_EVENT_MONTH, CALENDAR_EVENT_YEAR, CALENDAR_EVENT_SUBJECT, CALENDAR_EVENT_TYPE)
				VALUES
					(?, ?, ?, ?, ?, ?, ?)
			";
			$dbh->do_placeholder_query($query, $query_vars);
		}

	}

	if ($hasfile) {

		$filedir = "";
		if ($is_gallery) {
			if (ini_get('safe_mode')) {
				$filedir = "default";

			} else {
				$filedir = $Board;
			}
		}


		// Update the files
		$topic_thumbnail = "";
		$query = "
			SELECT FILE_NAME, FILE_ADD_TIME
			FROM {$config['TABLE_PREFIX']}FILES
			WHERE FILE_MD5 = ?
			ORDER BY FILE_ADD_TIME ASC
		";
		$sth = $dbh->do_placeholder_query($query, array($md5_stamp), __LINE__, __FILE__);
		while (list($filename) = $dbh->fetch_array($sth)) {
			if ($is_gallery) {
				if (!$topic_thumbnail) {
					$query = "
						UPDATE {$config['TABLE_PREFIX']}TOPICS
						SET TOPIC_THUMBNAIL = ?
						WHERE TOPIC_ID = ?
					";
					$dbh->do_placeholder_query($query, array("$filedir/thumbs/$filename", $topic_id), __LINE__, __FILE__);
					$topic_thumbnail = 1;
				}
				@rename("{$config['FULL_PATH']}/tmp/$filename.thumb", "{$config['FULL_PATH']}/gallery/$filedir/thumbs/$filename");
				chmod("{$config['FULL_PATH']}/gallery/$filedir/thumbs/$filename", 0666);
				@rename("{$config['FULL_PATH']}/tmp/$filename.medium", "{$config['FULL_PATH']}/gallery/$filedir/medium/$filename");
				chmod("{$config['FULL_PATH']}/gallery/$filedir/medium/$filename", 0666);
				@rename("{$config['FULL_PATH']}/tmp/$filename.full", "{$config['FULL_PATH']}/gallery/$filedir/full/$filename");
				chmod("{$config['FULL_PATH']}/gallery/$filedir/full/$filename", 0666);
			} else {
				@rename("{$config['FULL_PATH']}/tmp/$filename", "{$config['ATTACHMENTS_PATH']}/$filename");
				chmod("{$config['ATTACHMENTS_PATH']}/$filename", 0666);
			}
		}


		$query = "
			UPDATE {$config['TABLE_PREFIX']}FILES
			SET POST_ID = ? ,
				FILE_DIR = ?
			WHERE FILE_MD5 = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($Number, $filedir, $md5_stamp), __LINE__, __FILE__);
	}

	// ----------------------------------------------
	// Make sure they get refreshed to the proper page
	$redirect = "";
	if (($what == "showthreaded") || ($what == "showflat") || ($what == "showgallery")) {
		$redirect = "$what&Number=$Number#Post$Number";
	} else {
		$redirect = "postlist&Board=$Board";
	}

	$extra_bread = "";
	if ($parent_id) {
		$link = make_ubb_url("ubb=postlist&Board=$parent_id", $parent_title, false);
		$extra_bread = <<<EOF
 <a href="{$link}">{$parent_title}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
EOF;
	}

	// Rebuild the forum data
	rebuild_forum_data($Board);

	// Log it
	admin_log("EDIT_POST", "<a href='" . make_ubb_url("ubb=showflat&Number=$Number#Post$Number", $Subject, false) . "' target='_blank'>$Subject</a>");


	$flink = make_ubb_url("ubb=postlist&Board=$Board", $Title, false);
	$plink = make_ubb_url("ubb=$what&Number=$Number#Post$Number", $Subject, false);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => $redirect,
			"heading" => $ubbt_lang['MODIF_HEAD'],
			"body" => "{$ubbt_lang['MODIF_HEAD']} {$ubbt_lang['RET_FORUM']}",
			"Subject" => $Subject,
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $parent_id,
			"custom_header_footer" => $fheader,
			"returnlink" => "<a href=\"{$flink}\">{$ubbt_lang['FORUM_RETURN']}</a> | <a href=\"{$plink}\">{$ubbt_lang['VIEW_POST']}</a>",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		)
	);
}

?>