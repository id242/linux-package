<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_deletepost_gpc() {
	return array(
		"input" => array(
			"Username" => array("Username", "post", ""),
			"Board" => array("Board", "post", "alphanum"),
			"what" => array("what", "post", "alpha"),
			"Number" => array("Number", "post", "int"),
			"Approved" => array("Approved", "post", "alpha"),
		),
		"wordlets" => array("deletepost"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_deletepost_run() {
	global $html, $userob, $user, $in, $ubbt_lang, $config, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$Username = $user['USER_DISPLAY_NAME'];

	// Get the board this is on
	$query = "
		SELECT
			t1.FORUM_ID
		FROM
			{$config['TABLE_PREFIX']}TOPICS AS t1,
			{$config['TABLE_PREFIX']}POSTS AS t2
		WHERE
			t2.POST_ID = ?
		AND	t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($Board) = $dbh->fetch_array($sth);

	// ------------------
	// Get the forum info
	$query = "
		SELECT FORUM_CUSTOM_HEADER, FORUM_STYLE, FORUM_LAST_POST_ID, CATEGORY_ID, FORUM_TITLE, FORUM_PARENT, FORUM_IS_RSS, FORUM_RSS_TITLE
		FROM {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list ($fheader, $fstyle, $lastnumber, $cat_id, $Title, $parent_id, $is_rss, $rss_title) = $dbh->fetch_array($sth);

	if (!$is_rss) $rss_title = "";

	// -------------------------------------------------
	// Here we need to figure out what stylesheet to use
	if ($fstyle) {
		$html->set_style($fstyle);
	}

	// -----------------------------------
	// Get the post info from the database
	$query = "
		SELECT
			t1.USER_ID, t1.POST_SUBJECT, t1.POST_BODY, t1.POST_IS_APPROVED, t1.TOPIC_ID, t1.POST_IS_TOPIC, t1.POST_PARENT_ID, t1.POST_POSTED_TIME
		FROM
			{$config['TABLE_PREFIX']}POSTS AS t1,
			{$config['TABLE_PREFIX']}TOPICS AS t2
		WHERE
			t1.POST_ID = ?
		AND t1.TOPIC_ID = t2.TOPIC_ID
		AND t2.FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Number, $Board), __LINE__, __FILE__);

	// -------------------------
	// Assign the retrieved data
	list($Postedby, $Subject, $Body, $Approved, $topic_id, $post_is_topic, $parent_post, $posted_on) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	// ----------------------------------------------------------------------------
	// Check if they moderate this board or they are an admin or they made the post
	if ($user['USER_MEMBERSHIP_LEVEL'] == "GlobalModerator") {
		$modcheck = true;
	}

	if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
		$query = "
			SELECT USER_ID
			FROM {$config['TABLE_PREFIX']}MODERATORS
			WHERE FORUM_ID = ?
			  AND USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($Board, $user['USER_ID']), __LINE__, __FILE__);
		list($modcheck) = $dbh->fetch_array($sth);
	}

	if (($user['USER_ID'] != $Postedby) && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && (!$modcheck)) {
		$html->not_right($ubbt_lang['NO_EDIT']);
	}

	$right_now = $html->get_date();
	$del_expired = false;

	if (($right_now - $posted_on) > ($userob->check_access("forum", "DELETE_POSTS", $Board) * 60)) {
		$del_expired = true;
	}

	if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !$modcheck && $del_expired) {
		$html->not_right($ubbt_lang['DELETE_EXPIRED']);
	}

	$query = "
		SELECT FILE_NAME, FILE_DIR
		FROM {$config['TABLE_PREFIX']}FILES
		WHERE POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	while (list($File, $dir) = $dbh->fetch_array($sth)) {
		if (!$dir) {
			unlink("{$config['ATTACHMENTS_PATH']}/$File");
		} else {
			unlink("{$config['FULL_PATH']}/gallery/$dir/full/$File");
			unlink("{$config['FULL_PATH']}/gallery/$dir/medium/$File");
			unlink("{$config['FULL_PATH']}/gallery/$dir/thumbs/$File");
		}
	}

	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}FILES
		WHERE POST_ID = ?
	";
	$dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

	$query = "
	DELETE FROM {$config['TABLE_PREFIX']}POSTS
	WHERE POST_ID = ?
	";
	$dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

	// Update all replies so their parent is set to this
	// post's parent
	$query = "
		UPDATE {$config['TABLE_PREFIX']}POSTS
		SET POST_PARENT_ID = ?
		WHERE TOPIC_ID = ?
		  AND POST_PARENT_ID = ?
	";
	$dbh->do_placeholder_query($query, array($parent_post, $topic_id, $Number), __LINE__, __FILE__);


	// ----------------------------------------------------------
	// If this post is approved then we bump the number down by 1
	if ($Approved == "1") {

		$query = "
			SELECT count(*)
			FROM {$config['TABLE_PREFIX']}POSTS
			WHERE TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($topic_id), __LINE__, __FILE__);
		list ($postcount) = $dbh->fetch_array($sth);
		if (!$postcount) {
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}TOPICS
				WHERE TOPIC_ID = ?
			";
			$dbh->do_placeholder_query($query, array($topic_id), __LINE__, __FILE__);
		} else {
			rebuild_topic_data($topic_id);
		}
		rebuild_forum_data($Board);
	} else {
		rebuild_topic_data($topic_id);
	}


	if ($post_is_topic) {

		// -------------------------------
		// Delete from the favorites table
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
			WHERE WATCH_ID = ?
			  AND WATCH_TYPE = 't'
		";
		$dbh->do_placeholder_query($query, array($topic_id), __LINE__, __FILE__);

		// Delete from announcements table
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}ANNOUNCEMENTS
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($topic_id), __LINE__, __FILE__);
	}

	$query = "
		SELECT POLL_ID
		FROM {$config['TABLE_PREFIX']}POLL_DATA
		WHERE POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	while (list($Poll) = $dbh->fetch_array($sth)) {

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POLL_DATA
			WHERE POLL_ID = ?
		";
		$dbh->do_placeholder_query($query, array($Poll), __LINE__, __FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POLL_OPTIONS
			WHERE POLL_ID = ?
		";
		$dbh->do_placeholder_query($query, array($Poll), __LINE__, __FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POLL_VOTES
			WHERE POLL_ID = ?
		";
		$dbh->do_placeholder_query($query, array($Poll), __LINE__, __FILE__);
	}

	// Rebuild the islands
	rebuild_islands(1);

	// Log this action
	admin_log("DELETE_POST", "<a href='" . make_ubb_url("ubb=postlist&Board=$Board", $Title, false) . "' target='_blank'>$Title</a>: $Subject");

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "postlist&Board=$Board",
			"heading" => $ubbt_lang['NO_PROCEED'],
			"body" => "{$ubbt_lang['POST_DEL']} {$ubbt_lang['RET_FORUM']}",
			"returnlink" => "",
			"Board" => $Board,
			"Category" => $cat_id,
			"parent_forum" => $parent_id,
			"custom_header_footer" => $fheader,
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		)
	);
}

?>