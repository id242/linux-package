<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_edittopics_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("edittopics"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_edittopics_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$topic_array = array();

	$query = "
		select 	fav.WATCH_ID,t.TOPIC_SUBJECT,t.POST_ID,fav.WATCH_NOTIFY_IMMEDIATE
		from	{$config['TABLE_PREFIX']}WATCH_LISTS as fav,
			{$config['TABLE_PREFIX']}TOPICS as t
		where	fav.USER_ID = ?
		and	fav.WATCH_ID = t.TOPIC_ID
		and	fav.WATCH_TYPE = 't'
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	while (list($id, $title, $pid, $immediate) = $dbh->fetch_array($sth)) {

		$email_none = "checked=\"checked\"";
		$email_immediate = "";

		if ($immediate) {
			$email_immediate = "checked=\"checked\"";
		}

		$topic_array[] = array(
			"id" => $id,
			"title" => $title,
			"pid" => $pid,
			"none" => $email_none,
			"immediate" => $email_immediate,
		);
	}

	$smarty_data = array(
		"topic_array" => $topic_array,
		"user" => $user,
		"mystuff" => $html->mystuff(),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$home = make_ubb_url("ubb=myhome", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['EDIT_FAV_TOPICS']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"javascript" => array('inline_moderation.js'),
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 <a href="{$home}">{$ubbt_lang['VIEW_WATCH']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 {$ubbt_lang['EDIT_FAV_TOPICS']}
BREADCRUMB
		,
		),
		"template" => "edittopics",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>