<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_doeditforums_gpc() {
	return array(
		"input" => array(
			"forum" => array("forum", "post", "int"),
			"email" => array("email", "post", array("immediate", "none", "newtopic"), "none"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 1,
	);
}

function page_doeditforums_run() {

	global $in, $user, $ubbt_lang, $config, $forumvisit, $visit, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	foreach ($forum as $forum_id => $value) {

		$forum_id = addslashes($forum_id);
		if ($value == 0) {
			$query = "
				delete from	{$config['TABLE_PREFIX']}WATCH_LISTS
				where	USER_ID = ?
				and	WATCH_ID = ?
				and	WATCH_TYPE = 'f'
			";
			$dbh->do_placeholder_query($query, array($user['USER_ID'], $forum_id), __LINE__, __FILE__);

		} else {
			$watch_lists['f'][$forum_id] = $forum_id;
			$query = "
				select 	count(*)
				from	{$config['TABLE_PREFIX']}WATCH_LISTS
				where	USER_ID = ?
				and	WATCH_ID = ?
				and	WATCH_TYPE = 'f'
			";
			$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $forum_id), __LINE__, __FILE__);
			list($check) = $dbh->fetch_array($sth);

			if (!$check) {
				$query = "
					insert into {$config['TABLE_PREFIX']}WATCH_LISTS
					(USER_ID,WATCH_ID,WATCH_TYPE)
					values
					( ? , ? , 'f')
				";
				$dbh->do_placeholder_query($query, array($user['USER_ID'], $forum_id), __LINE__, __FILE__);
			}

		}
	}

	foreach ($email as $forum_id => $value) {

		$immediate = 0;
		switch ($value) {
			case "immediate":
				$immediate = 1;
				break;
			case "newtopic":
				$immediate = 2;
				break;
			default:
				$immediate = 0;
				break;
		}

		$query_vars = array($immediate, $user['USER_ID'], $forum_id);
		$query = "
			update 	{$config['TABLE_PREFIX']}WATCH_LISTS
			set			WATCH_NOTIFY_IMMEDIATE = ?
			where		USER_ID = ?
			and			WATCH_ID = ?
			and			WATCH_TYPE = 'f'
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}

	$_SESSION['watch_lists'] = serialize($watch_lists);

	// ---------------------
	// Return to the profile
	return array(
		"data" => $data,
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "myhome&tab=forums",
	);
}

?>