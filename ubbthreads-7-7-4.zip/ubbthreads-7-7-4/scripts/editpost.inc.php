<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_editpost_gpc() {
	return array(
		"input" => array(
			"Board" => array("Board", "get", "int"),
			"Number" => array("Number", "get", "int"),
			"what" => array("what", "get", "alpha"),
		),
		"wordlets" => array("editpost"),
		"user_fields" => "USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_editpost_run() {

	global $style_array, $html, $userob, $myinfo, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------
	// Predefine some variables
	$fpart = "";
	$addevent = "";
	$selectmonth = "";
	$selectday = "";
	$selectyear = "";

	$Username = $user['USER_DISPLAY_NAME'];

	$TEXT_AREA_COLUMNS = $config['TEXT_AREA_COLUMNS'];
	$TEXT_AREA_ROWS = $config['TEXT_AREA_ROWS'];

	// ---------------------------------------------------------------------------
	// For security purposes we need to verify that this is user made this post or
	// if they are an admin or a moderator for this board.
	$Status = $user['USER_MEMBERSHIP_LEVEL'];

	// -----------------------------------
	// Get the post info from the database
	$query = "
		select	t1.USER_ID,t1.POST_SUBJECT,t1.POST_DEFAULT_BODY,t1.POST_IS_APPROVED,t2.POST_ID,t2.TOPIC_STATUS,t1.TOPIC_ID,t2.TOPIC_IS_STICKY,t1.POST_POSTED_TIME,t1.POST_ICON,t1.POST_MARKUP_TYPE,t1.POST_ADD_SIGNATURE,t2.FORUM_ID,t2.TOPIC_IS_EVENT,t2.TOPIC_NEWS_ICON,t1.POST_IS_TOPIC,t1.POST_LAST_EDIT_REASON
		from	{$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2
		where	t1.POST_ID = ? and t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

	// -------------------------
	// Assign the retrieved data
	list($Postedby, $Subject, $Body, $Approved, $Topic_Post, $TStatus, $Main, $Sticky, $Posted, $Icon, $Convert, $addsig, $Board, $event, $newsicon, $is_topic, $editreason) = $dbh->fetch_array($sth);


	$istopic = 0;
	if ($Topic_Post == $Number) {
		$istopic = 1;
	}

	$news_array = preg_split("#,#", $config['PORTAL_NEWS_FORUMS']);

	$is_news = 0;
	$imagelist = array();
	if ((in_array($Board, $news_array) && $istopic) || ($userob->check_access("forum", "CREATE_NEWS", $Board) && $istopic)) {
		$is_news = 1;
		$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['news']}");
		while (($file = readdir($dir)) != false) {
			if (($file == ".") || ($file == "..") || ($file == "index.html") || (!preg_match("/(gif|jpg|png)$/", $file))) {
				continue;
			}
			$imagelist[] .= $file;
		}
		sort($imagelist);
	}

	// -------------------------------
	// Check if HTML is enabled or not
	if ($userob->check_access("forum", "USE_HTML", $Board)) {
		$htmlstatus = " {$ubbt_lang['YES_HTML']}";
	} else {
		$htmlstatus = " {$ubbt_lang['NO_HTML']}";
	}

	// --------------------------------------------
	// Markup is disabled, so we better let them know
	if ($userob->check_access("forum", "USE_MARKUP", $Board)) {
		$markupstatus = " {$ubbt_lang['YES_MARKUP']}";
	} else {
		$markupstatus = " {$ubbt_lang['NO_MARKUP']}";
	}

	// Calendar event?
	if ($event) {
		$query = "
			select CALENDAR_EVENT_DAY,CALENDAR_EVENT_MONTH,CALENDAR_EVENT_YEAR
			from {$config['TABLE_PREFIX']}CALENDAR_EVENTS
			where TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($Main), __LINE__, __FILE__);
		list($calday, $calmonth, $calyear) = $dbh->fetch_array($sth);
	}

	// ---------------------------------
	// Grab some info about this board
	$query = "
	SELECT FORUM_CUSTOM_HEADER,FORUM_STYLE,FORUM_TITLE,CATEGORY_ID,FORUM_PARENT,FORUM_IS_RSS,FORUM_RSS_TITLE,FORUM_IS_GALLERY
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE  FORUM_ID    = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list($fheader, $fstyle, $Title, $cat_id, $parent_id, $is_rss, $rss_title, $is_gallery) = $dbh->fetch_array($sth);

	if ($fstyle) {
		$html->set_style($fstyle);
	}

	if ((!$userob->check_access("forum", "EDIT_ANY", $Board)) && ($user['USER_ID'] != $Postedby)) {
		$html->not_right($ubbt_lang['NO_EDIT']);
	}

	// ---------------------------------------------------------------------------
	// If this thread is locked and they are not a admin or mod they can't proceed
	if (($TStatus == "C" || $TStatus == "M") && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && (!preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
		$html->not_right($ubbt_lang['LOCKED']);
	}

	// ------------------------------------------------
	// Make the sure the edittime value has not expired
	$expired = $userob->check_access("forum", "EDIT_POSTS", $Board) * 60;
	$current = $html->get_date();
	if (($current - $Posted > $expired) && (!$userob->check_access("forum", "EDIT_ANY", $Board))) {
		$html->not_right($ubbt_lang['EDITTIME']);
	}

	// -------------------------------------------------------------------------
	// Well everything checked out, doesn't look like a hacker so let's let them
	// edit the post.


	// -----------------
	// Change " to &quot;
	$Subject = str_replace("\"", "&quot;", $Subject);

	// -----------------------------
	// Signature added to this post?
	$addsigcheck = "";
	if ($addsig) {
		$addsigcheck = "checked = \"checked\"";
	}
	$iconselect = $html->icon_select($Icon);

	if ($userob->check_access("forum", "APPROVE_ANY", $Board) && ($Approved == "0")) {
		$approvebutton = "<input tabindex=\"6\" type=\"submit\" name=\"peditapprove\" value=\"{$ubbt_lang['PEDIT_APPROVE']}\" class=\"form-button\">";
	} else {
		$approvebutton = "";
	}

	if ($userob->check_access("forum", "APPROVE_ANY", $Board) && ($Approved == "1")) {
		$unapprovebutton = "<input tabindex=\"6\" type=\"submit\" name=\"peditunapprove\" value=\"{$ubbt_lang['PEDIT_UNAPPROVE']}\" class=\"form-button\">";
	} else {
		$unapprovebutton = "";
	}

	$changebutton = "<input tabindex=\"3\" type=\"submit\" name=\"peditchange\" value=\"{$ubbt_lang['PEDIT_CHANGE']}\" class=\"form-button major-button\">";
	if ((!$userob->check_access("forum", "EDIT_ANY", $Board)) && ($user['USER_ID'] != $Postedby)) {
		$changebutton = "&nbsp;";
	}
	$deletebutton = "<input tabindex=\"5\" type=\"submit\" name=\"peditdelete\" value=\"{$ubbt_lang['PEDIT_DELETE']}\" class=\"form-button\">";
	if ((!$userob->check_access("forum", "DELETE_ANY", $Board)) && ($user['USER_ID'] != $Postedby)) {
		$deletebutton = "&nbsp;";
	}

	// ------------------------------------------------------------------------------
	// If this is a main topic they might be able to add/edit a public calendar event
	if ($istopic) {
		if ($userob->check_access("site", "CALENDAR_EVENTS") && $config['CALENDAR']) {
			$checked = "";
			if ($calday && $calmonth && $calyear) {
				$checked = "checked=\"checked\"";
			}
			$addevent = "
			<input type=\"checkbox\" $checked name=\"addevent\" id=\"addevent\" value=\"1\" class=\"form-checkbox\">
			<label for=\"addevent\">{$ubbt_lang['ADDEVENT']}</label>
			";

			$selectmonth = "
			<select name=\"calmonth\" class=\"form-select\">
			";

			$temp = getdate();
			$year = $temp["year"];
			$day = $temp["mday"];
			$month = $temp["mon"];
			if ($calday) {
				$day = $calday;
			}
			if ($calmonth) {
				$month = $calmonth;
			}
			if ($calyear) {
				$year = $calyear;
			}

			for ($i = 1; $i <= 12; $i++) {
				$mname = "MONTH$i";
				$mname = $ubbt_lang[$mname];
				$selected = "";
				if ($month == $i) {
					$selected = "selected=\"selected\"";
				}
				$selectmonth .= "<option value=\"$i\" $selected>$mname</option>";
			}
			$selectmonth .= "</select>";

			$selectday = "<select name=\"calday\" class=\"form-select\">";
			for ($i = 1; $i <= 31; $i++) {
				$selected = "";
				if ($day == $i) {
					$selected = "selected=\"selected\"";
				}
				$selectday .= "<option $selected>$i</option>";
			}
			$selectday .= "</select>";

			$selectyear = "<select name=\"calyear\" class=\"form-select\">";
			$temp = getdate();
			$thisyear = $temp["year"];
			for ($i = $thisyear; $i <= $thisyear + 10; $i++) {
				$selected = "";
				if ($year == $i) {
					$selected = "selected=\"selected\"";
				}
				$selectyear .= "<option $selected>$i</option>";
			}
			$selectyear .= "</select><br>";
		}
	}

	//$Body = str_replace("<br>","\n",$Body);
	$Body = ubbchars($Body);

	$text_editor = $html->create_text_editor("Body", "$Body", 2);

	$managepost = 0;
	if ($userob->check_access("forum", "MOVE_ANY", $Board)) {
		if ($Number != $Main) {
			$managepost = 1;
		}
	}

	$totalfiles = 0;
	$query = "
		select count(*)
		from {$config['TABLE_PREFIX']}FILES
		where POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($totalfiles) = $dbh->fetch_array($sth);

	$filemanage = 0;
	// Can they add/edit a file attachment (EDIT POST TOPIC/REPLY or GALLERY TOPIC)
	if ((($is_gallery && $is_topic) || ($userob->check_access("forum", "FILE_TOTAL", $Board))) && (ini_get('file_uploads'))) {
		$filemanage = 1;
	}
	// No file attachments for gallery replies. Though, if attachments already exist, display a link
	if (($is_gallery && !$is_topic) && ($is_gallery && !$totalfiles)) {
		$filemanage = 0;
	}

	$md5_stamp = md5($user['USER_DISPLAY_NAME'] . time());

	// -------------------------------------
	// What options do they have for posting
	if (($config['MARKUP_HTML_TOGGLE'] == 1) || ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") || (preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
		$markupselect .= "<select name=\"convert\" id=\"convert\" class=\"form-select\">";
		if ($userob->check_access("forum", "USE_MARKUP", $Board)) {
			$markupselect .= "<option value=\"markup\">{$ubbt_lang['USE_MARKUP']}</option>";
		}
		if ($userob->check_access("forum", "USE_HTML", $Board)) {
			$markupselect .= "<option value=\"html\">{$ubbt_lang['USE_HTML']}</option>";
		}
		if (($userob->check_access("forum", "USE_HTML", $Board)) && ($userob->check_access("forum", "USE_MARKUP", $Board))) {
			$markupselect .= "<option value=\"both\">{$ubbt_lang['USE_BOTH']}</option>";
		}
		if ((!$userob->check_access("forum", "USE_HTML", $Board)) && (!$userob->check_access("forum", "USE_MARKUP", $Board))) {
			$markupselect .= "<option value=\"none\">{$ubbt_lang['USE_NONE']}</option>";
		}
		$markupselect .= "</select>";

		$find = '#("' . $Convert . '")#';
		$markupselect = preg_replace($find, '\1 selected="selected"', $markupselect);
	}
	// No options, we use the forum default
	else {
		$markupselect = sprintf('<input type="hidden" name="convert" value="%s">', $Convert);
	}

	$smarty_data = array(
		"totalfiles" => $totalfiles,
		"md5_stamp" => $md5_stamp,
		"filemanage" => $filemanage,
		"managepost" => $managepost,
		"editreason" => $editreason,
		"Username" => $Username,
		"Number" => $Number,
		"Board" => $Board,
		"what" => $what,
		"fpart" => $fpart,
		"Approved" => $Approved,
		"Convert" => $Convert,
		"Subject" => $Subject,
		"iconselect" => & $iconselect,
		"addevent" => $addevent,
		"selectmonth" => $selectmonth,
		"selectday" => $selectday,
		"selectyear" => $selectyear,
		"addsigcheck" => $addsigcheck,
		"changebutton" => $changebutton,
		"deletebutton" => $deletebutton,
		"approvebutton" => $approvebutton,
		"unapprovebutton" => $unapprovebutton,
		"text_editor" => & $text_editor,
		"onsubmit" => $onsubmit,
		"is_news" => $is_news,
		"imagelist" => $imagelist,
		"newsicon" => $newsicon,
		"is_gallery" => $is_gallery,
		"markupselect" => $markupselect,
		"htmlstatus" => $htmlstatus,
		"markupstatus" => $markupstatus,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['PEDIT_HEAD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $parent_id,
			"custom_header_footer" => $fheader,
			"bypass" => 0,
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
			"javascript" => array(
				0 => "standard_text_editor.js",
			),
		),
		"template" => "editpost",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>