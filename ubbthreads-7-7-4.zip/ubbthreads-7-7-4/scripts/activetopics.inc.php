<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.2
  Purpose:
  Future:
*/

function page_activetopics_gpc() {
	return array(
		"input" => array(
			"range" => array("range", "get", "int"),
			"page" => array("page", "get", "int"),
			"type" => array("type", "get", "alpha"),
		),
		"wordlets" => array("activetopics"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE, t2.USER_TIME_FORMAT, t2.USER_TOPICS_PER_PAGE",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_activetopics_run() {
	global $tree, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $style_array;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Set up page size based upon user preference or board config
	$PostsPer = array_get($user, 'USER_TOPICS_PER_PAGE', $config['TOPICS_PER_PAGE']);
	if (!$page || $page < 1) $page = 1;
	if (!$PostsPer) $PostsPer = 25;

	// First check what timestamp we use to check new posts against
	if ($userob->is_logged_in) {
		if (!isset($_SESSION['forumvisit']['visit']) || !is_array($_SESSION['forumvisit']['visit'])) {
			$_SESSION['forumvisit']['lastonline'] = $user['USER_LAST_VISIT_TIME'];
			$query = "
				select LAST_VISIT_TIME,FORUM_ID
				from {$config['TABLE_PREFIX']}FORUM_LAST_VISIT
				where USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
			while (list($last_visit, $board_id) = $dbh->fetch_array($sth)) {
				$_SESSION['forumvisit']['visit'][$board_id] = $last_visit;
			}
		}
	}

	$timeline = $html->get_date();
	if ($range == 1) {
		$header = $ubbt_lang['ACTIVE_24'];
		$timeline = $timeline - 86400;
	} elseif ($range == 2) {
		$header = $ubbt_lang['ACTIVE_48'];
		$timeline = $timeline - (86400 * 2);
	} elseif ($range == 7) {
		$header = $ubbt_lang['ACTIVE_7'];
		$timeline = $timeline - (86400 * 7);
	} elseif ($range == 30) {
		$header = "";
		$timeline = $timeline - (86400 * 30);
	} else {
		$header = $ubbt_lang['ACTIVE_24'];
		$timeline = $timeline - 86400;
	}

	// Based upon user's permissions, build a list of allowable forums
	$boards = array();
	foreach ($tree['active'] as $k => $v) {
		if ($userob->check_access("forum", "READ_TOPICS", $k)) {
			$boards[] = $k;
		}
	}
	$board_in = join(",", $boards);
	if (!$board_in) $board_in = '0';

	// How many active topics?
	$total_topics = 0;
	if ($type == "p") {
		$query = "
			select	count(t1.POST_ID)
			from	{$config['TABLE_PREFIX']}POSTS as t1,
				{$config['TABLE_PREFIX']}TOPICS as t2,
				{$config['TABLE_PREFIX']}FORUMS as t3
			where	t1.POST_POSTED_TIME > ?
				and t1.TOPIC_ID = t2.TOPIC_ID
				and t3.FORUM_ACTIVE_POSTS = 1
				and t2.FORUM_ID in ($board_in)
				and t2.FORUM_ID = t3.FORUM_ID
				and t1.POST_IS_APPROVED = 1
				and t2.TOPIC_STATUS <> 'M'
		";
	} else if ($type == "u") {
		$query = "
			select	count(t1.TOPIC_ID)
			from	{$config['TABLE_PREFIX']}TOPICS as t1,
				{$config['TABLE_PREFIX']}FORUMS as t2
			where	t1.TOPIC_LAST_REPLY_TIME > ?
				and t1.FORUM_ID in ($board_in)
				and t1.FORUM_ID = t2.FORUM_ID
				and t2.FORUM_ACTIVE_POSTS = 1
				and t1.TOPIC_REPLIES = 0
				and t1.TOPIC_IS_APPROVED = 1
				and t1.TOPIC_STATUS <> 'M'
		";
	} else {
		$query = "
			select	count(t1.TOPIC_ID)
			from	{$config['TABLE_PREFIX']}TOPICS as t1,
				{$config['TABLE_PREFIX']}FORUMS as t2
			where	t1.TOPIC_LAST_REPLY_TIME > ?
				and t1.FORUM_ID in ($board_in)
				and t1.FORUM_ID = t2.FORUM_ID
				and t2.FORUM_ACTIVE_POSTS = 1
				and t1.TOPIC_IS_APPROVED = 1
				and t1.TOPIC_STATUS <> 'M'
		";
	}
	$sth = $dbh->do_placeholder_query($query, array($timeline), __LINE__, __FILE__);
	list($total_topics) = $dbh->fetch_array($sth);

	// What is our limit clause?
	if ($page == 1) {
		$limit = "limit $PostsPer";
	} else {
		$limit = "limit " . (($page - 1) * $PostsPer) . ", $PostsPer";
	}

	$extra = "and t2.TOPIC_LAST_POST_ID = t3.POST_ID and t2.TOPIC_LAST_REPLY_TIME > ? and t2.TOPIC_LAST_POSTER_ID = t4.USER_ID";
	$poster_field = "t2.TOPIC_LAST_POSTER_NAME";
	$time_field = "t2.TOPIC_LAST_REPLY_TIME";
	if ($type == "p") {
		$extra = "and t2.TOPIC_ID = t3.TOPIC_ID and t3.POST_POSTED_TIME > ? and t3.USER_ID = t4.USER_ID AND t3.POST_IS_APPROVED = 1";
		$poster_field = "t4.USER_DISPLAY_NAME";
		$time_field = "t3.POST_POSTED_TIME";
	} else if ($type == "u") {
		$extra = "and t2.TOPIC_REPLIES = 0 and t2.TOPIC_LAST_POST_ID = t3.POST_ID and t2.TOPIC_LAST_REPLY_TIME > ? and t2.TOPIC_LAST_POSTER_ID = t4.USER_ID AND t3.POST_IS_APPROVED = 1";
	}
	$topics = array();
	$query = "
		SELECT t1.FORUM_ID, t1.FORUM_TITLE, t3.POST_SUBJECT, t3.POST_ICON, t3.POST_POSTED_TIME, $poster_field, t3.POST_BODY,
					 t2.TOPIC_ID, t3.POST_ID, t1.FORUM_IS_GALLERY, t2.TOPIC_VIEWS, t2.TOPIC_REPLIES, t2.TOPIC_CREATED_TIME, t4.USER_MEMBERSHIP_LEVEL,
					 t4.USER_ID,t5.USER_NAME_COLOR
			FROM {$config['TABLE_PREFIX']}FORUMS as t1,
					 {$config['TABLE_PREFIX']}TOPICS as t2,
					 {$config['TABLE_PREFIX']}POSTS as t3,
					 {$config['TABLE_PREFIX']}USERS as t4,
					 {$config['TABLE_PREFIX']}USER_PROFILE as t5
		WHERE t1.FORUM_ID IN ($board_in)
			AND t1.FORUM_ACTIVE_POSTS = 1
			$extra
			AND t2.FORUM_ID = t1.FORUM_ID
			AND t2.TOPIC_STATUS <> 'M'
			AND t2.TOPIC_IS_APPROVED = 1
			AND t4.USER_ID = t5.USER_ID
		ORDER BY $time_field DESC
		$limit
	";
	$sth = $dbh->do_placeholder_query($query, array($timeline), __LINE__, __FILE__);
	$i = 0;
	while (list($forum_id, $forum_title, $post_subject, $post_icon, $post_time, $poster_name, $post_body, $topic_id, $post_id, $is_gallery, $topic_views, $topic_replies, $topic_time, $level, $user_id, $color) = $dbh->fetch_array($sth)) {

		if ($user_id == 1) {
			$poster_name = $ubbt_lang['ANON_TEXT'];
		}
		if ($is_gallery) $post_icon = "image.gif";
		if (!$post_icon) $post_icon = "blank.gif";
		// Check for unread posts
		if (isset($_SESSION['topicread'][$topic_id])) {
			$checkread = $_SESSION['topicread'][$topic_id];
		} else {
			$checkread = $_SESSION['forumvisit']['visit'][$forum_id];
		}

		$topics[$i]['gonew'] = 0;
		if ($post_time > $checkread) {
			$topics[$i]['gonew'] = 1;
		}
		// Prepare the body preview (tooltip) and also clean up the inline one on the page
		//
		// Gotta clean out the [ and ], as they are keys to the .js parser. Also need to fix graemlin links
		$topics[$i]['tooltip'] = "";
		if ($config['TOOLTIP_LENGTH'] && $config['TOOLTIP_LENGTH'] > 0) {
			$tooltip = str_replace("]", "&rbr;", str_replace("[", "&lbr;", $post_body));
			$tooltip = str_replace("<<GRAEMLIN_URL>>", "{$config['BASE_URL']}/images/{$style_array['graemlins']}", $tooltip);
			$tooltip = ubbchars($html->truncate($tooltip, $config['TOOLTIP_LENGTH']));
			$topics[$i]['tool_tip'] = "title=\"header=[{$ubbt_lang['TOOLTIP_HEADER']}] body=[{$tooltip}]\"";
		}
		// Now clean up the body itself
		$post_body = preg_replace('/<div style="padding-left:10px;"><div class="ubbcode-headerZZ">(.*?)<\/div><div class="post_inner"><div style="display:none;">(.*?)<\/div><\/div><\/div>/si', "{$ubbt_lang['SPOILER_CONTENT']}", $post_body);
//		$post_body = preg_replace("/\<br\s*\/?\>/i", " ", $post_body);
//		$topics[$i]['post_body'] = substr(strip_tags($post_body),0,1080);
		$topics[$i]['post_body'] = $post_body;

		$topics[$i]['forum_id'] = $forum_id;
		$topics[$i]['forum_title'] = $forum_title;
		$topics[$i]['post_subject'] = $post_subject;
		$topics[$i]['post_icon'] = $post_icon;
		$topics[$i]['post_time'] = $html->convert_time($post_time, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
		$topics[$i]['poster_name'] = $html->user_color($poster_name, $color, $level);
		$topics[$i]['user_id'] = $user_id;

		$topics[$i]['post_id'] = $post_id;
		$topics[$i]['topic_id'] = $topic_id;
		$topics[$i]['start_time'] = $html->convert_time($topic_time, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
//		$topics[$i]['color'] = ($i & 1) ? "alt-topicsubject" : "topicsubject";
		$topics[$i]['row'] = $i;

		$topics[$i]['topic_views'] = $topic_views;
		$topics[$i]['topic_replies'] = $topic_replies;
		$i++;
	}

	$pages = ceil($total_topics / $PostsPer);
	$pages = $html->paginate($page, $pages, "activetopics&range=$range&type={$type}&page=");

	if (!$user['USER_TOPIC_VIEW_TYPE']) {
		$mode = $config['TOPIC_DISPLAY_STYLE'];
	} else {
		$mode = $user['USER_TOPIC_VIEW_TYPE'];
	}

	$link_1 = "<a href='" . make_ubb_url("ubb=activetopics&range=1&type={$type}", "", false) . "'>{$ubbt_lang['ACTIVE_24']}</a>";
	$link_2 = "<a href='" . make_ubb_url("ubb=activetopics&range=2&type={$type}", "", false) . "'>{$ubbt_lang['ACTIVE_48']}</a>";
	$link_7 = "<a href='" . make_ubb_url("ubb=activetopics&range=7&type={$type}", "", false) . "'>{$ubbt_lang['ACTIVE_7']}</a>";

	if ($range == 1) {
		$link_1 = $ubbt_lang['ACTIVE_24'];
	} elseif ($range == 2) {
		$link_2 = $ubbt_lang['ACTIVE_48'];
	} elseif ($range == 7) {
		$link_7 = $ubbt_lang['ACTIVE_7'];
	}

	if ($type == "t") {
		$t_link = "{$ubbt_lang['ACTIVE_TOPICS']}";
		$p_link = "<a href='" . make_ubb_url("ubb=activetopics&range={$range}&type=p", "", false) . "'>{$ubbt_lang['ACTIVE_POSTS']}</a>";
		$u_link = "<a href='" . make_ubb_url("ubb=activetopics&range={$range}&type=u", "", false) . "'>{$ubbt_lang['ACTIVE_NO_ANSWERS']}</a>";
	} else if ($type == "u") {
		$u_link = "{$ubbt_lang['ACTIVE_NO_ANSWERS']}";
		$p_link = "<a href='" . make_ubb_url("ubb=activetopics&range={$range}&type=p", "", false) . "'>{$ubbt_lang['ACTIVE_POSTS']}</a>";
		$t_link = "<a href='" . make_ubb_url("ubb=activetopics&range={$range}&type=t", "", false) . "'>{$ubbt_lang['ACTIVE_TOPICS']}</a>";
	} else {
		$p_link = "{$ubbt_lang['ACTIVE_POSTS']}";
		$t_link = "<a href='" . make_ubb_url("ubb=activetopics&range={$range}&type=t", "", false) . "'>{$ubbt_lang['ACTIVE_TOPICS']}</a>";
		$u_link = "<a href='" . make_ubb_url("ubb=activetopics&range={$range}&type=u", "", false) . "'>{$ubbt_lang['ACTIVE_NO_ANSWERS']}</a>";
	}

	if (is_numeric($config['SHAREAHOLIC']) && $config['SHAREAHOLIC'] > 0) {
		$shareaholic = '<div class="shareaholic-canvas" data-app="share_buttons" data-app-id="' . $config['SHAREAHOLIC'] . '"></div>';
		$shareHeader = 1;
	}

	$smarty_data = array(
		"topics" => & $topics,
		"display" => $mode,
		"pages" => $pages,
		"shareaholic" => $shareaholic,
		"link_1" => $link_1,
		"link_2" => $link_2,
		"link_7" => $link_7,
		"t_link" => $t_link,
		"p_link" => $p_link,
		"u_link" => $u_link
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['ACTIVE_TOPICS']} $header",
			"refresh" => 0,
			"shareHeader" => $shareHeader,
			"user" => $user,
			"Board" => "",
			"javascript" => array('boxover.js', 'assets/jquery.expander.min.js'),
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => " <a href=\"{$cfrm}\">{$ubbt_lang['FORUM_TEXT']}</a> <i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i> {$ubbt_lang['ACTIVE_TOPICS']} $header",
		),
		"template" => "activetopics",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>