<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Title: UBB.Likes
  Author: James Corthell, VNC Web Services - https://www.virtualnightclub.net
  Purpose: Allows a user to like and remove their like from posts. Also has a summary of post likes and user likes, and increases a field in the user profile for how many likes they have recieved.
  Future: Dont allow likes on locked topics
*/

function page_like_gpc() {
	return array(
		"input" => array(
			"process" => array("process", "post", "int"),
			"target" => array("target", "both", "int"),
			"task" => array("task", "both", "alpha"),
			"type" => array("type", "both", "alpha"),
		),
		"wordlets" => array("like"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_like_run() {
	global $style_array, $html, $userob, $myinfo, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh;
	extract($in, EXTR_OVERWRITE | EXTR_REFS);

// Is this user a guest?
	if ($userob->is_logged_in) {
		$guest = 0;
	} else {
		$guest = 1;
	}
	$smarty->assign("guest", $guest);

// Allowed to like their own content?
	$self_like = (isset($config['LIKE_SELF'])) ? $config['LIKE_SELF'] : 0;

// Require active (non-banned/only approved) members on the summary?
	$require_active = (isset($config['LIKES_REQUIRE_ACTIVE'])) ? $config['LIKES_REQUIRE_ACTIVE'] : 1;

// Maximum number of Likes a member can give per 24 hour period ("" = Unlimited)
	$likes_per_day = (isset($config['LIKES_PER_DAY_MAX'])) ? $config['LIKES_PER_DAY_MAX'] : "20";

// If no mode has been set, define as showflat
	$mode = (!$mode) ? "showflat" : $mode;

// Define the redirect delay
	$delay = 2;

// We put this here as we define the redirect and smarty code in each section versus an all inclusive one at the bottom of the page
	$cfrm = make_ubb_url("ubb=cfrm", "", false);

// Fetch the User's Time Offset
	$useroffset = 0;
	isset($user["USER_TIME_OFFSET"]) && $useroffset = $user["USER_TIME_OFFSET"];
	!isset($user["USER_TIME_FORMAT"]) && $user["USER_TIME_FORMAT"] = $config["TIME_FORMAT"];

// Lets see how many likes the user has made in the last 24 hours
	$likes_today = 0;
	$days = 1;
	$date_range = date("U") - (60 * 60 * 24 * $days);
	$query = "
		SELECT count(*)
		FROM {$config['TABLE_PREFIX']}LIKES
		WHERE TIMESTAMP >= ?
		AND USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($date_range, $user["USER_ID"]), __LINE__, __FILE__);
	list($likes_today) = $dbh->fetch_array($sth);
	$smarty->assign("likes_today", $likes_today);

	if ($likes_per_day == null) {
		$smarty->assign("too_many", "");
	} elseif ($likes_per_day <= $likes_today) {
		$smarty->assign("too_many", str_replace("%limit%", $likes_per_day, $ubbt_lang["TOO_MANY_LIKES"]));
	} else {
		$smarty->assign("too_many", "");
	}

	if ($type == "post") {
		$template = "like_post";
// Fetch the Post Information
		if ($process != 1) {
// Lets see if they've liked this before
			$previous = 0;
			$query = "
				SELECT count(*)
				FROM {$config['TABLE_PREFIX']}LIKES
				WHERE TYPE = ?
				  AND POST_ID = ?
				  AND USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array("p", $target, $user["USER_ID"]), __LINE__, __FILE__);
			list($previous) = $dbh->fetch_array($sth);

			if ($previous == 1) {
				$task = "down";
			} else {
				$task = "up";
			}

// User is not processing a like/unlike request
			if ($task == "up") {
// User is liking a post, fetch post data.
				$type_title = $ubbt_lang["BUTTON_LIKE"] . " " . $ubbt_lang["POST_TEXT"];
				$like_button = $ubbt_lang["BUTTON_LIKE"];
				$like_unlike = "<input type=\"hidden\" name=\"task\" value=\"up\">\n";

				$query = "
					SELECT
						t1.POST_SUBJECT, t1.POST_BODY, t1.POST_ID, t1.POST_POSTED_TIME, t1.POST_ICON, t1.TOPIC_ID, t1.POST_IS_TOPIC,
						t2.FORUM_ID, t2.TOPIC_IS_EVENT,
						u.USER_ID, u.USER_DISPLAY_NAME, USER_NAME_COLOR, USER_MEMBERSHIP_LEVEL,
						up.USER_AVATAR
					FROM
						{$config['TABLE_PREFIX']}POSTS AS t1,
						{$config['TABLE_PREFIX']}TOPICS AS t2,
						{$config['TABLE_PREFIX']}USERS AS u,
						{$config['TABLE_PREFIX']}USER_PROFILE AS up
					WHERE
						t1.POST_ID = ?
					AND t1.TOPIC_ID = t2.TOPIC_ID
					AND t1.USER_ID = u.USER_ID
					AND u.USER_ID = up.USER_ID
				";
				$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
				list($post_subject, $post_body, $post_id, $post_time, $post_icon, $topic_id, $forum_id, $is_event, $is_topic, $user_id, $user_name, $user_color, $user_level, $user_avatar) = $dbh->fetch_array($sth);

				if ($user_id == $user["USER_ID"]) {
					$own_post = 1;
				} else {
					$own_post = 0;
				}

				$like_uid = "";
				$like_type = "";
				$like_target = "";
				$like_timestamp = "";

				$user_color = $html->user_color($user_name, $user_color, $user_level);
				$user_link = "<a href=\"" . make_ubb_url("ubb=showprofile&User=$user_id", $user_name, false) . "\" rel=\"nofollow\">" . $user_color . "</a>";
			} else {
// User is removing their like, fetch the like data and post data
				$type_title = $ubbt_lang["BUTTON_UNLIKE"] . " " . $ubbt_lang["POST_TEXT"];
				$like_button = $ubbt_lang["BUTTON_UNLIKE"];
				$like_unlike = "<input type=\"hidden\" name=\"task\" value=\"down\">\n" . $ubbt_lang["POST_UNLIKE_MESSAGE"] . "<br><br>";

				$query = "
					SELECT
						t1.USER_ID, t1.TYPE, t1.POST_ID, t1.TIMESTAMP,
						t2.POST_SUBJECT, t2.POST_BODY, t2.POST_ID, t2.POST_POSTED_TIME, t2.POST_ICON, t2.TOPIC_ID, t2.POST_IS_TOPIC,
						t3.FORUM_ID, t3.TOPIC_IS_EVENT,
						u.USER_ID, u.USER_DISPLAY_NAME, p.USER_NAME_COLOR, u.USER_MEMBERSHIP_LEVEL,
						p.USER_AVATAR
					FROM
						{$config['TABLE_PREFIX']}LIKES AS t1,
						{$config['TABLE_PREFIX']}POSTS AS t2,
						{$config['TABLE_PREFIX']}TOPICS AS t3,
						{$config['TABLE_PREFIX']}USERS AS u,
						{$config['TABLE_PREFIX']}USER_PROFILE AS p
					WHERE
						t1.POST_ID = ?
					AND t1.POST_ID = t2.POST_ID
					AND t2.TOPIC_ID = t3.TOPIC_ID
					AND t2.USER_ID = u.USER_ID
					AND u.USER_ID = p.USER_ID
				";
				$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
				list($like_uid, $like_type, $like_target, $like_timestamp, $post_subject, $post_body, $post_id, $post_time, $post_icon, $topic_id, $forum_id, $is_event, $is_topic, $user_id, $user_name, $user_color, $memberlevel, $user_avatar) = $dbh->fetch_array($sth);

				if ($user_id == $user["USER_ID"]) {
					$own_post = 1;
				} else {
					$own_post = 0;
				}

				if ($userob->is_logged_in) {
					$like_timestamp = $html->convert_time($like_timestamp, $useroffset, $user["USER_TIME_FORMAT"]);
//					$like_timestamp = $html->convert_time($like_timestamp, $useroffset, "m/d/Y g:i A");
				} else {
					$like_timestamp = $html->convert_time($like_timestamp, $useroffset, "m/d/Y g:i A");
				}

				$user_color = $html->user_color($user_name, $user_color, $memberlevel);
				$user_link = "<a href=\"" . make_ubb_url("ubb=showprofile&User=$user_id", $user_name, false) . "\" rel=\"nofollow\">" . $user_color . "</a>";
			}
			$post_body = $html->active_text($post_body);
			$post_subject = str_replace("\"", "&quot;", $post_subject);
			if ($userob->is_logged_in) {
				$post_time = $html->convert_time($post_time, $useroffset, $user["USER_TIME_FORMAT"]);
//				$post_time = $html->convert_time($post_time, $useroffset, "M jS \a\t h:i A");
			} else {
				$post_time = $html->convert_time($post_time, $useroffset, "M jS \a\t h:i A");
			}

			$like_count = 0;
			$query = "
				SELECT count(*)
				FROM {$config['TABLE_PREFIX']}LIKES
				WHERE TYPE = ?
				  AND POST_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array("p", $target), __LINE__, __FILE__);
			list($like_count) = $dbh->fetch_array($sth);

// Fetch users who've liked this post.
			$query = "
				SELECT
					u.USER_DISPLAY_NAME, u.USER_ID, u.USER_MEMBERSHIP_LEVEL, p.USER_NAME_COLOR, l.TIMESTAMP
				FROM
					{$config['TABLE_PREFIX']}LIKES AS l,
					{$config['TABLE_PREFIX']}USERS AS u,
					{$config['TABLE_PREFIX']}USER_PROFILE AS p
				WHERE
					l.TYPE = 'p'
				AND l.POST_ID = '" . $target . "'
				AND l.USER_ID = u.USER_ID
				AND u.USER_ID = p.USER_ID
				ORDER BY
					l.TIMESTAMP DESC
			";
			$sth = $dbh->do_query($query);

			$users = array();
			$i = 0;
			while (list($uname, $uid, $level, $color, $timestamp) = $dbh->fetch_array($sth)) {
				$users[$i]["name"] = $html->user_color($uname, $color, $level);
				$users[$i]["uid"] = $uid;
				$users[$i]["timestamp"] = $html->convert_time($timestamp, $useroffset, "M jS Y", 1, 0);
				$i++;
			}

			$smarty_data = array(
				"type" => $type,
				"target" => $target,
				"task" => $task,
				"mode" => $mode,
				"own_post" => $own_post,
				"self_like" => $self_like,
				"type_title" => $type_title,
				"like_button" => $like_button,
				"like_unlike" => $like_unlike,
				"like_count" => $like_count,
				"like_uid" => $like_uid,
				"like_type" => $like_type,
				"like_target" => $like_target,
				"like_timestamp" => $like_timestamp,
				"post_id" => $post_id,
				"post_time" => $post_time,
				"post_icon" => $post_icon,
				"post_subject" => $post_subject,
				"post_body" => $post_body,
				"process" => $process,
				"topic_id" => $topic_id,
				"forum_id" => $forum_id,
				"is_event" => $is_event,
				"is_topic" => & $is_topic,
				"user_id" => & $user_id,
				"user_link" => & $user_link,
				"user_name" => & $user_name,
				"user_avatar" => & $user_avatar,
				"users" => & $users,
			);
		} else {
// Fetch the user who created this post and their like count
			$query = "
				SELECT
					p.USER_ID, p.TOPIC_ID, up.USER_LIKES
				FROM
					{$config['TABLE_PREFIX']}POSTS AS p,
					{$config['TABLE_PREFIX']}USER_PROFILE AS up
				WHERE
					p.POST_ID = ?
				AND p.USER_ID = up.USER_ID
			";
			$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
			list($puid, $topic_id, $ulikes) = $dbh->fetch_array($sth);

			if ($puid == $user["USER_ID"]) {
				$own_post = 1;
			} else {
				$own_post = 0;
			}

// User is sending a like/unlike request
			if ($task == "up") {
// Insert a like for this post
				$query = "
					INSERT INTO
						{$config['TABLE_PREFIX']}LIKES
						(USER_ID, TYPE, TOPIC_ID, POST_ID, POSTER_ID, TIMESTAMP)
					VALUES
						(?, ?, ?, ?, ?, ?)
				";
				$sth = $dbh->do_placeholder_query($query, array($user["USER_ID"], "p", $topic_id, $target, $puid, date("U")), __LINE__, __FILE__);

// Increase the users like counter
				$ulikes = $ulikes + 1;
				$query = "
					UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
					SET USER_LIKES = ?
					WHERE USER_ID = ?
				";
				$sth = $dbh->do_placeholder_query($query, array($ulikes, $puid), __LINE__, __FILE__);
			} else {
// Remove the users like of a post
				$query = "
					DELETE FROM {$config['TABLE_PREFIX']}LIKES
					WHERE USER_ID = ?
					  AND TYPE = ?
					  AND POST_ID = ?
				";
				$sth = $dbh->do_placeholder_query($query, array($user["USER_ID"], "p", $target), __LINE__, __FILE__);

// Decrease the users like counter
				$ulikes = $ulikes - 1;
// If the users like counter is now negative, set it to zero
				$ulikes = max($ulikes, 0);

				$query = "
					UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
					SET USER_LIKES = ?
					WHERE USER_ID = ?
				";
				$sth = $dbh->do_placeholder_query($query, array($ulikes, $puid), __LINE__, __FILE__);
			}

// Fetch the post subject for the auto-redirect
			$query = "
				SELECT POST_SUBJECT
				FROM {$config['TABLE_PREFIX']}POSTS
				WHERE POST_ID = " . $target . "
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			list($Subject) = $dbh->fetch_array($sth);

			$html->send_redirect(
				array(
					"redirect" => $mode . "&Number=" . $target . "#Post" . $target,
					"Subject" => $Subject,
					"heading" => $ubbt_lang["POST_RECORDED"],
					"body" => $ubbt_lang["RET_TOPIC"],
					"returnlink" => "",
					"delay" => $delay,
					"breadcrumb" => " <a href=\"" . $cfrm . "\">" . $ubbt_lang["FORUM_TEXT"] . "</a> <i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i> " . $ubbt_lang["POST_RECORDED"],
				)
			);
		}
	} elseif ($type == "thread") {
		$template = "like_thread_summary";
// Fetch the Topic Information
		$topic = array();
		$query = "
			SELECT
				t.FORUM_ID, t.TOPIC_ID, t.POST_ID, t.TOPIC_SUBJECT, t.TOPIC_REPLIES, t.TOPIC_CREATED_TIME, t.TOPIC_ICON,
				p.POST_BODY,
				count(l.TOPIC_ID) AS LIKES,
				u.USER_ID, u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
			FROM
				{$config['TABLE_PREFIX']}LIKES AS l,
				{$config['TABLE_PREFIX']}TOPICS AS t,
				{$config['TABLE_PREFIX']}POSTS AS p,
				{$config['TABLE_PREFIX']}USERS AS u, 
				{$config['TABLE_PREFIX']}USER_PROFILE AS up
			WHERE
				t.TOPIC_ID = ?
			AND t.TOPIC_IS_APPROVED = '1'
			AND l.TOPIC_ID = t.TOPIC_ID
			AND l.TYPE = 'p'
			AND p.POST_ID = t.POST_ID
			AND t.USER_ID = u.USER_ID
			AND up.USER_ID = u.USER_ID
			GROUP BY
				t.POST_ID, t.TOPIC_ID, t.FORUM_ID, t.TOPIC_SUBJECT, t.TOPIC_REPLIES, t.TOPIC_CREATED_TIME, t.TOPIC_ICON,
				p.POST_BODY,
				u.USER_ID, u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
		";
		$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
		while (list($fid, $tid, $pid, $subject, $replies, $timestamp, $icon, $body, $likes, $uid, $name, $memberlevel, $namecolor) = $dbh->fetch_array($sth)) {
			$topic["body"] = $body;
			$topic["fid"] = $fid;
			$topic["icon"] = $icon;
			$topic["likes"] = $likes;
			$topic["name"] = $name;
			$topic["namecolor"] = $html->user_color($name, $namecolor, $memberlevel);
			$topic["pid"] = $pid;
			$topic["replies"] = $replies;
			$topic["subject"] = $subject;
			$topic["tid"] = $tid;
			$topic["uid"] = $uid;

			if ($userob->is_logged_in) {
				$topic["timestamp"] = $html->convert_time($timestamp, $useroffset, $user["USER_TIME_FORMAT"]);
//				$topic["timestamp"] = $html->convert_time($timestamp, $useroffset, "m/d/Y g:i A");
			} else {
				$topic["timestamp"] = $html->convert_time($timestamp, $useroffset, "m/d/Y g:i A");
			}

			$type_title = str_replace("%%title%%", $topic["subject"], $ubbt_lang["TITLE_THREAD_SUMMARY"]);
		}

		if (!$topic["fid"]) {
			$html->not_right($ubbt_lang['LIKES_NONE']);
		}

// Fetch the thread participants
		$i = 0;
		$query = "
			SELECT
				l.USER_ID, u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
			FROM
				{$config['TABLE_PREFIX']}LIKES AS l,
				{$config['TABLE_PREFIX']}POSTS AS p,
				{$config['TABLE_PREFIX']}USERS AS u, 
				{$config['TABLE_PREFIX']}USER_PROFILE AS up
			WHERE
				l.TYPE = 'p'
			AND l.TOPIC_ID = ?
			AND l.USER_ID = u.USER_ID
			AND up.USER_ID = u.USER_ID
			GROUP BY
				l.USER_ID,
				u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
			ORDER BY
				u.USER_DISPLAY_NAME ASC
		";
		$users = array();
		$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
		while (list($uid, $name, $memberlevel, $namecolor) = $dbh->fetch_array($sth)) {
			$users[$i]["uid"] = $uid;
			$users[$i]["name"] = $name;
			$users[$i]["namecolor"] = $html->user_color($name, $namecolor, $memberlevel);
			$i++;
		}


// Fetch the liked posts for this topic
		$i = 0;
		$query = "
			SELECT
				p.TOPIC_ID, p.POST_ID, count(p.POST_ID) AS LIKES, p.POST_SUBJECT, p.POST_POSTED_TIME, p.POST_ICON, p.POST_BODY,
				u.USER_ID, u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
			FROM
				{$config['TABLE_PREFIX']}LIKES AS l,
				{$config['TABLE_PREFIX']}POSTS AS p,
				{$config['TABLE_PREFIX']}USERS AS u, 
				{$config['TABLE_PREFIX']}USER_PROFILE AS up
			WHERE
				l.TYPE = 'p'
			AND l.TOPIC_ID = ?
			AND p.POST_ID = l.POST_ID
			AND p.POST_IS_APPROVED = '1'
			AND p.POST_IS_TOPIC = '0'
			AND p.USER_ID = u.USER_ID
			AND up.USER_ID = u.USER_ID
			GROUP BY
				p.POST_ID,
				p.TOPIC_ID, p.POST_SUBJECT, p.POST_POSTED_TIME, p.POST_ICON, p.POST_BODY,
				u.USER_ID, u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
			ORDER BY
				LIKES DESC
		";
		$posts = array();
		$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
		while (list($tid, $pid, $likes, $subject, $timestamp, $icon, $body, $uid, $name, $memberlevel, $namecolor) = $dbh->fetch_array($sth)) {
			$posts[$i]["body"] = $body;
			$posts[$i]["fid"] = $fid;
			$posts[$i]["icon"] = $icon;
			$posts[$i]["likes"] = $likes;
			$posts[$i]["name"] = $name;
			$posts[$i]["namecolor"] = $html->user_color($name, $namecolor, $memberlevel);
			$posts[$i]["pid"] = $pid;
			$posts[$i]["replies"] = $replies;
			$posts[$i]["subject"] = $subject;
			$posts[$i]["tid"] = $tid;
			$posts[$i]["uid"] = $uid;

			if ($userob->is_logged_in) {
				$posts[$i]["timestamp"] = $html->convert_time($timestamp, $useroffset, $user["USER_TIME_FORMAT"]);
//				$posts[$i]["timestamp"] = $html->convert_time($timestamp, $useroffset, "M jS \a\t h:i A");
			} else {
				$posts[$i]["timestamp"] = $html->convert_time($timestamp, $useroffset, "M jS \a\t h:i A");
			}

			if ($posts[$i]["likes"] == 1) {
				$posts[$i]["liked"] = $ubbt_lang["LIKED1"];
			} else {
				$posts[$i]["liked"] = $ubbt_lang["LIKED"];
			}

			$i++;
		}


		if (!$userob->check_access("forum", "READ_TOPICS", $topic["fid"])) {
			$html->not_right($ubbt_lang["ERROR_PERMS"]);
		}


		$smarty_data = array(
			"mode" => $mode,
			"posts" => $posts,
			"type" => $type,
			"target" => $target,
			"topic" => $topic,
			"type_title" => $type_title,
			"users" => $users,
		);
	} elseif ($type == "user") {
// Fetch the User Information
		$template = "like_user_summary";

		$likes_total = 0;
		$query = "
			SELECT USER_DISPLAY_NAME
			FROM {$config['TABLE_PREFIX']}USERS
			WHERE USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
		list($pdn) = $dbh->fetch_array($sth);

		$type_title = str_replace("%%name%%", $pdn, $ubbt_lang["TITLE_USER_SUMMARY"]);


// Lets see how many likes the user has made in the last 24 hours
		$likes_today = 0;
		$days = 1;
		$date_range = date("U") - (60 * 60 * 24 * $days);

		$query = "
			SELECT count(*)
			FROM {$config['TABLE_PREFIX']}LIKES
			WHERE TIMESTAMP >= ?
			AND USER_ID = ?
	";
		$sth = $dbh->do_placeholder_query($query, array($date_range, $target), __LINE__, __FILE__);
		list($likes_today) = $dbh->fetch_array($sth);
//	die($likes_today);


// How many likes has this user made?
		$likes_total = 0;
		$query = "
			SELECT count(*)
			FROM {$config['TABLE_PREFIX']}LIKES
			WHERE TYPE = 'p'
			AND USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
		list($likes_total) = $dbh->fetch_array($sth);


// How many likes has the user received?
		$likes_received = 0;
		$query = "
			SELECT count(*)
			FROM {$config['TABLE_PREFIX']}LIKES
			WHERE POSTER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
		list($likes_received) = $dbh->fetch_array($sth);


// What are the users most liked posts?
		$i = 0;
		$liked_posts = array();
		$query = "
			SELECT
				l.POST_ID, count(l.POSTER_ID) AS LIKES, l.POSTER_ID,
				u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR,
				t.FORUM_ID,
				p.POST_SUBJECT, p.TOPIC_ID
			FROM
				{$config['TABLE_PREFIX']}FORUMS AS f,
				{$config['TABLE_PREFIX']}LIKES AS l,
				{$config['TABLE_PREFIX']}POSTS AS p,
				{$config['TABLE_PREFIX']}TOPICS AS t,
				{$config['TABLE_PREFIX']}USERS AS u, 
				{$config['TABLE_PREFIX']}USER_PROFILE AS up
			WHERE
				l.TYPE = 'p'
			AND l.POSTER_ID = u.USER_ID
			AND l.POSTER_ID = up.USER_ID
			AND p.POST_ID = l.POST_ID
			AND t.TOPIC_ID = p.TOPIC_ID
			AND t.TOPIC_IS_APPROVED = 1
			AND t.FORUM_ID = f.FORUM_ID
			AND l.POSTER_ID = ?
			GROUP BY
				p.TOPIC_ID,
				l.POST_ID, l.POSTER_ID,
				u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR,
				t.FORUM_ID,
				p.POST_SUBJECT
			ORDER BY
				LIKES DESC, p.TOPIC_ID DESC, p.POST_ID ASC
			LIMIT 30
		";
		$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
		while (list($pid, $likes, $uid, $name, $memberlevel, $namecolor, $fid, $subject, $tid) = $dbh->fetch_array($sth)) {
			if ($userob->check_access("forum", "READ_TOPICS", $fid)) {
				$liked_posts[$i]["pid"] = $pid;
				$liked_posts[$i]["likes"] = $likes;
				$liked_posts[$i]["uid"] = $uid;
				$liked_posts[$i]["name"] = $name;
				$liked_posts[$i]["namecolor"] = $html->user_color($name, $namecolor, $memberlevel);
				$liked_posts[$i]["fid"] = $fid;
				$liked_posts[$i]["subject"] = $subject;
				$liked_posts[$i]["tid"] = $tid;
				$i++;
			}
		}


		$smarty_data = array(
			"liked_posts" => $liked_posts,
			"likes_received" => $likes_received,
			"likes_today" => $likes_today,
			"likes_total" => $likes_total,
			"target" => $target,
			"type" => $type,
			"type_title" => $type_title,
			"timeframe" => $days,
		);
	} else {
// Build a Summary
		$template = "like_summary";

		$days = 30;
		$date_range = date("U") - (60 * 60 * 24 * $days);
		$likes_month = 0;
		$type_title = str_replace("%%num%%", $days, $ubbt_lang["TITLE_SUMMARY"]);

// Lets gather the amount of likes in the last 30 Days
		$likes_total = 0;
		$query = "
			SELECT count(*)
			FROM {$config['TABLE_PREFIX']}LIKES
			WHERE TYPE = 'p'
			AND `TIMESTAMP` >= ?
		";
		$sth = $dbh->do_placeholder_query($query, array($target), __LINE__, __FILE__);
		list($likes_total) = $dbh->fetch_array($sth);

// Lets gather the list of posts that've been liked in the last 30 days.
		$i = 0;
		$liked_posts = array();
		$query = "
			SELECT
				l.POST_ID, count(l.POSTER_ID) AS LIKES, l.POSTER_ID,
				u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR,
				t.FORUM_ID,
				p.POST_SUBJECT
			FROM
				{$config['TABLE_PREFIX']}FORUMS AS f,
				{$config['TABLE_PREFIX']}LIKES AS l,
				{$config['TABLE_PREFIX']}POSTS AS p,
				{$config['TABLE_PREFIX']}TOPICS AS t,
				{$config['TABLE_PREFIX']}USERS AS u, 
				{$config['TABLE_PREFIX']}USER_PROFILE AS up
			WHERE
				l.TYPE = 'p'
			AND l.POSTER_ID = u.USER_ID
			AND l.POSTER_ID = up.USER_ID
			AND p.POST_ID = l.POST_ID
			AND t.TOPIC_ID = p.TOPIC_ID
			AND t.TOPIC_IS_APPROVED = 1
			AND t.FORUM_ID = f.FORUM_ID
			AND l.TIMESTAMP >= ?
			GROUP BY
				p.POST_SUBJECT,
				l.POST_ID, l.POSTER_ID,
				u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR,
				t.FORUM_ID
			ORDER BY
				LIKES DESC, p.POST_SUBJECT ASC
		";
		$sth = $dbh->do_placeholder_query($query, array($date_range), __LINE__, __FILE__);
		while (list($pid, $likes, $uid, $name, $memberlevel, $namecolor, $fid, $subject) = $dbh->fetch_array($sth)) {
			if ($userob->check_access("forum", "READ_TOPICS", $fid)) {
				$liked_posts[$i]["fid"] = $fid;
				$liked_posts[$i]["likes"] = $likes;
				$liked_posts[$i]["namecolor"] = $html->user_color($name, $namecolor, $memberlevel);
				$liked_posts[$i]["name"] = $name;
				$liked_posts[$i]["pid"] = $pid;
				$liked_posts[$i]["subject"] = $subject;
				$liked_posts[$i]["uid"] = $uid;
				$i++;
			}
		}

// Lets gather the most liked users in the last 30 days.
		if ($require_active == 1) {
			$active = "AND u.USER_IS_APPROVED = 'yes' AND u.USER_IS_BANNED != '1'";
		} else {
			$active = "";
		}

		$i = 0;
		$liked_users = array();
		$query = "
			SELECT
				l.POSTER_ID, count(l.POSTER_ID) AS LIKES,
				u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
			FROM
				{$config['TABLE_PREFIX']}LIKES AS l,
				{$config['TABLE_PREFIX']}USERS AS u, 
				{$config['TABLE_PREFIX']}USER_PROFILE AS up
			WHERE
				l.TYPE = 'p'
			AND l.POSTER_ID = u.USER_ID
			AND l.POSTER_ID = up.USER_ID
			" . $active . "
			AND l.TIMESTAMP >= ?
			GROUP BY
				l.POSTER_ID,
				u.USER_DISPLAY_NAME,
				u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
			ORDER BY
				LIKES DESC, u.USER_DISPLAY_NAME ASC
		";
		$sth = $dbh->do_placeholder_query($query, array($date_range), __LINE__, __FILE__);
		while (list($uid, $likes, $name, $memberlevel, $namecolor) = $dbh->fetch_array($sth)) {
			$liked_users[$i]["namecolor"] = $html->user_color($name, $namecolor, $memberlevel);
			$liked_users[$i]["name"] = $name;
			$liked_users[$i]["likes"] = $likes;
			$liked_users[$i]["uid"] = $uid;
			$i++;
		}

// Lets gather the most active users in the last 30 days.
		if ($require_active == 1) {
			$active = "AND u.USER_IS_APPROVED = 'yes' AND u.USER_IS_BANNED != '1'";
		} else {
			$active = "";
		}

		$i = 0;
		$active_users = array();
		$query = "
			SELECT
				l.USER_ID, count(l.USER_ID) AS LIKES,
				u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
			FROM
				{$config['TABLE_PREFIX']}LIKES AS l,
				{$config['TABLE_PREFIX']}USERS AS u, 
				{$config['TABLE_PREFIX']}USER_PROFILE AS up
			WHERE
				l.TYPE = 'p'
			AND l.USER_ID = u.USER_ID
			AND l.USER_ID = up.USER_ID
			" . $active . "
			AND l.TIMESTAMP >= ?
			GROUP BY
				l.USER_ID,
				u.USER_DISPLAY_NAME,
				u.USER_MEMBERSHIP_LEVEL,
				up.USER_NAME_COLOR
			ORDER BY
				LIKES DESC, u.USER_DISPLAY_NAME ASC
		";
		$sth = $dbh->do_placeholder_query($query, array($date_range), __LINE__, __FILE__);
		while (list($uid, $likes, $name, $memberlevel, $namecolor) = $dbh->fetch_array($sth)) {
			$active_users[$i]["namecolor"] = $html->user_color($name, $namecolor, $memberlevel);
			$active_users[$i]["name"] = $name;
			$active_users[$i]["likes"] = number_format($likes);
			$active_users[$i]["uid"] = $uid;
			$i++;
		}

		$smarty_data = array(
			"active_users" => $active_users,
			"liked_posts" => $liked_posts,
			"liked_users" => $liked_users,
			"likes_month" => $likes_month,
			"likes_total" => $likes_total,
			"type" => $type,
			"target" => $target,
			"timeframe" => $days,
//			"test_string" => $date_range,
			"type_title" => $type_title,
		);
	}

	return array(
		"header" => array(
			"title" => $type_title,
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang["FORUM_TEXT"]}</a>
 <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 {$type_title}
BREADCRUMB
		,
		),
		"template" => $template,
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>