<?php defined('UBB_MAIN_PROGRAM') or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);
function page_list_address_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("list_address"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_list_address_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	// ----------------------------------------------------
	// Grab all entries from the address book for this user

	$query = "
	SELECT t2.USER_DISPLAY_NAME
	FROM  {$config['TABLE_PREFIX']}ADDRESS_BOOK AS t1,
	{$config['TABLE_PREFIX']}USERS AS t2
	WHERE t1.USER_ID = ?
	AND   t1.ADDRESS_ENTRY_USER_ID = t2.USER_ID
	ORDER BY t2.USER_DISPLAY_NAME
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);

	// Lets give the start of the page

	// ----------------------------------------------------------------
	// Cycle through the users
	$color = "alt-1";
	$userrow = array();
	while ($result = $dbh->fetch_array($sth)) {
		$userrow[] = array(
			'Member' => $result['USER_DISPLAY_NAME']
		);
	}


	$smarty_data = array(
		"userrow" => $userrow,
		"stylesheet" => $stylesheet,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['MY_ADDRESS'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['MY_ADDRESS']}
BREADCRUMB
		,
		),
		"template" => "list_address",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>