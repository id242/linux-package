<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_sendprivate_gpc() {
	return array(
		"input" => array(
			"User" => array("User", "both", "int"),
			"Username" => array("Username", "post", ""),
			"recips" => array("recips", "post", ""),
			"Subject" => array("Subject", "post", ""),
			"CurrentBody" => array("Body", "post", ""),
			"checked" => array("check-inline", "post", "int"),
			"pmcheck" => array("pmcheck", "post", ""),
		),
		"wordlets" => array("sendprivate"),
		"user_fields" => "t2.USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_sendprivate_run() {

	global $smarty, $user, $in, $ubbt_lang, $config, $dbh, $html, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$Subject = trim($Subject);
	$CurrentBody = trim($Body);

	// ------------------------
	// Predefine some variables
	$options = "<option value=\"\"></option>";
	$Pselected = "";

	if ($recips) {
		$recip_array = unserialize($recips);
	} else {
		$recip_array = array();
	}


	if ($user['USER_IS_UNDERAGE'] || !$userob->check_access("site", "PM_TOTAL")) {
		$html->not_right($ubbt_lang['NOPRIVS']);
	}

	$TEXT_AREA_COLUMNS = $config['TEXT_AREA_COLUMNS'];
	$TEXT_AREA_ROWS = $config['TEXT_AREA_ROWS'];

	// Check if we were told to send a PM to multiple users
	$sendtoname = "";
	if ($pmcheck) {
		$in_array = array();
		foreach ($checked as $id) {
			if (is_numeric($id)) $in_array[] = intval($id);
		}
		if (sizeof($in_array) > 0) {
			$sendtoname = "*";
			$where_in = 'WHERE USER_ID IN (' . implode(',', $in_array) . ')';
			$query = "
				SELECT USER_ID, USER_ACCEPT_PM, USER_IGNORE_LIST
				FROM  {$config['TABLE_PREFIX']}USER_PROFILE
				$where_in
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);

			// Just skip bad guys. No need to error on each one
			while (list($user_id, $AcceptPriv, $Ignored) = $dbh->fetch_array($sth)) {
				if (($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && ($AcceptPriv == "no")) {
					continue;
				}
				if (preg_match("/-{$user['USER_ID']}-/", $Ignored)) {
					continue;
				}
				if (!$user_id) {
					continue;
				}

				$recip_array[] = $user_id;
			}
		}
	} else {
		// Find out if this user is taking private messages
		// or if they are over their limit
		if ($User || $Username) {

			if ($User) {
				$clause = "u.USER_ID = ?";
				$query_val = $User;
			} else {
				$clause = "u.USER_DISPLAY_NAME = ?";
				$query_val = $Username;
			}

			$query = "
				SELECT up.USER_ID, up.USER_ACCEPT_PM, u.USER_DISPLAY_NAME, up.USER_IGNORE_LIST,u.USER_IS_UNDERAGE
				FROM  {$config['TABLE_PREFIX']}USER_PROFILE up,
							{$config['TABLE_PREFIX']}USERS u
				WHERE  $clause
					AND up.USER_ID = u.USER_ID
			";
			$sth = $dbh->do_placeholder_query($query, array($query_val), __LINE__, __FILE__);
			list($user_id, $AcceptPriv, $sendtoname, $Ignored, $underage) = $dbh->fetch_array($sth);
			$dbh->finish_sth($sth);

			if (!$user_id) {
				$html->not_right($ubbt_lang['NOTFOUND']);
			}

			// How many PMs can they have?
			$query = "
				select max(t1.PM_TOTAL)
				from {$config['TABLE_PREFIX']}SITE_PERMISSIONS as t1,
				{$config['TABLE_PREFIX']}USER_GROUPS as t2
				where t1.GROUP_ID = t2.GROUP_ID
				and t2.USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($user_id), __LINE__, __FILE__);
			list($pm_limit) = $dbh->fetch_array($sth);

			$query = "
				select count(*)
				from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
        {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t2
				where t1.USER_ID = ?
        and t1.TOPIC_ID = t2.TOPIC_ID
			";
			$sth = $dbh->do_placeholder_query($query, array($user_id), __LINE__, __FILE__);
			list($total) = $dbh->fetch_array($sth);

			if (($total >= $pm_limit) && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator")) {
				$html->not_right($html->substitute($ubbt_lang['OVERLIMIT'], array("USER" => $sendtoname)));
			}

			if (($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && ($AcceptPriv == "no") || $underage) {
				$html->not_right($ubbt_lang['NO_PRIVATE']);
			}
			if (preg_match("/-{$user['USER_ID']}-/", $Ignored)) {
				$html->not_right($ubbt_lang['IGNORING_YOU']);
			}
			if (!$user_id) {
				$html->not_right("{$ubbt_lang['NOT_FOUND']} $Username");
			}
			$recip_array[] = $user_id;
		}
	}

	// Grab the usernames of all the recipients
	if (sizeof($recip_array)) {
		$in_list = "";
		foreach ($recip_array as $k => $v) {
			$v = intval($v);
			$in_list .= "'{$v}',";
		}
		$in_list = preg_replace("/,$/", "", $in_list);

		$query = "
			SELECT USER_DISPLAY_NAME
				FROM {$config['TABLE_PREFIX']}USERS
			WHERE  USER_ID IN ($in_list)
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		while (list($names) = $dbh->fetch_array($sth)) {
			$allnames .= "$names, ";
		}
		$allnames = preg_replace("/, $/", "", $allnames);

		$new_recip_array = preg_replace('#"#', '&quot;', serialize($recip_array));
	}

	// -----------------------------
	// List the address book members
	$Username_q = addslashes($user['USER_DISPLAY_NAME']);
	$query = "
		SELECT t2.USER_ID,t2.USER_DISPLAY_NAME
			FROM {$config['TABLE_PREFIX']}ADDRESS_BOOK AS t1,
				 	 {$config['TABLE_PREFIX']}USERS AS t2
		WHERE  t1.USER_ID = ?
			AND  t1.ADDRESS_ENTRY_USER_ID = t2.USER_ID
	ORDER BY t2.USER_DISPLAY_NAME
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);

	while (list ($Item, $addname) = $dbh->fetch_array($sth)) {
		$options .= "<option value=\"$Item\">$addname</option>";
	}

	$CurrentBody = str_replace("&", "&amp;", $CurrentBody);
	$CurrentBody = str_replace("\"", "&quot;", $CurrentBody);
	$CurrentBody = str_replace("<", "&lt;", $CurrentBody);
	$CurrentBody = str_replace(">", "&gt;", $CurrentBody);

	$Subject = str_replace("\"", "&quot;", $Subject);
	$Subject = str_replace("<", "&lt;", $Subject);

	$text_editor = $html->create_text_editor("Body", "$CurrentBody", 4);

	$instructions = $html->substitute($ubbt_lang['PRIV_BODY2'], array('MAX_IN_PM' => $userob->check_access("site", "PM_INVITES")));

	$smarty_data = array(
		"sendtoname" => $sendtoname,
		"options" => $options,
		"text_editor" => & $text_editor,
		"Pselected" => $Pselected,
		"instructions" => $instructions,
		"recips" => $new_recip_array,
		"recipnames" => $allnames,
		"Subject" => $Subject,
		"fromname" => $user['USER_DISPLAY_NAME'],
		"mystuff" => $html->mystuff(),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['PRIV_HEAD']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['PRIV_HEAD']}
BREADCRUMB
		,
			"javascript" => array('standard_text_editor.js', 'pt.js'),
		),
		"template" => "sendprivate",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>