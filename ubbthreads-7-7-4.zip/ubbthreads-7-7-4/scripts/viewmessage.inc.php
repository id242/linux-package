<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_viewmessage_gpc() {
	return array(
		"input" => array(
			"message" => array("message", "get", "int"),
			"page" => array("page", "get", "int"),
			"gonew" => array("gonew", "get", "int"),
			"jump" => array("jump", "get", "int"),
		),
		"wordlets" => array("viewmessage"),
		"user_fields" => "t2.USER_TIME_FORMAT, t2.USER_IGNORE_LIST, t2.USER_TOPICS_PER_PAGE, t2.USER_POSTS_PER_TOPIC, t2.USER_SHOW_SIGNATURES, t2.USER_SHOW_AVATARS, t2.USER_POST_LAYOUT",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_viewmessage_run() {

	global $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $style_array, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$limit = array_get($user, 'USER_POSTS_PER_TOPIC', $config['POSTS_PER_PAGE']);
	if (!$limit) $limit = 40;

	$post_layout = $user['USER_POST_LAYOUT'];
	if (!$post_layout) $post_layout = $config['POST_LAYOUT'];

	$toffset = $config['SERVER_TIME_OFFSET'];
	if ($user['USER_TIME_OFFSET'] != "") {
		$toffset = $user['USER_TIME_OFFSET'];
	}

	// Show Avatars with Posts?
	$AVATARS_WITH_POSTS = $config['SHOW_AVATARS'];
	if ($userob->is_logged_in) {
		$AVATARS_WITH_POSTS = $user['USER_SHOW_AVATARS'];
	}

	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];

	// Make sure they are in this topic
	$query = "
		SELECT
			t1.USER_ID, t1.MESSAGE_LAST_READ, t2.USER_DISPLAY_NAME
		FROM
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS AS t1,
			{$config['TABLE_PREFIX']}USERS AS t2
		WHERE
			t1.TOPIC_ID = ?
		AND	t1.USER_ID = t2.USER_ID
		ORDER BY
			lower(t2.USER_DISPLAY_NAME) ASC
	";
	$sth = $dbh->do_placeholder_query($query, array($message), __LINE__, __FILE__);
	$participants = array();
	$last_visit = 0;
	$participant_list = array();
	$found = false;
	while (list($user_id, $last_read, $uname) = $dbh->fetch_array($sth)) {
		if ($user_id == $user['USER_ID']) {
			$mylastread = $last_read;
			$found = true;
		}
		$participant_list[] = array(
			"name" => $uname,
			"id" => $user_id,
		);
		$participants[$last_read][] = $uname;
		if ($user_id == $user['USER_ID']) {
			$last_visit = $last_read;
		}
	}

	if ($found == false) {
		$html->not_right("{$ubbt_lang['NO_PT']}");
	}

	if (!$page) {
		$page = 1;
	}

	// If jump is set then we need to figure out what page to send them to
	if ($jump) {
		$query = "
			SELECT count(*)
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			WHERE TOPIC_ID = ?
			  AND POST_ID < ?
		";
		$sth = $dbh->do_placeholder_query($query, array($message, $jump), __LINE__, __FILE__);
		list($previous) = $dbh->fetch_array($sth);
		$page = intval($previous / $limit) + 1;
	}

	// If gonew is set we need to figure out what page to send them to
	if ($gonew) {
		$query = "
			SELECT count(*)
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			WHERE TOPIC_ID = ?
			  AND POST_TIME < ?
		";
		$sth = $dbh->do_placeholder_query($query, array($message, $mylastread), __LINE__, __FILE__);
		list($previous) = $dbh->fetch_array($sth);
		$page = intval(($previous - 1) / $limit) + 1;
	}

	$query = "
		SELECT count(*)
		FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		WHERE TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($message), __LINE__, __FILE__);
	list($total) = $dbh->fetch_array($sth);

	// What's the PM length limit?
	$mytotal = $userob->check_access("site", "PM_LENGTH");

	$toolong = 0;
	if ($total >= $mytotal) {
		$toolong = $html->substitute($ubbt_lang['TOO_LONG'], array('TOTAL' => $mytotal));
	}


	$pages1 = $html->paginate($page ? $page : 1, ceil($total / $limit), "viewmessage&message=$message&page=");
	$pages2 = preg_replace('#pagination_\d+#', '', $page1);

	if ($page > 0) {
		$new_page = ($page - 1) * $limit;
	} else {
		$new_page = 0;
	}

	$watch_lists = @unserialize($_SESSION['watch_lists']);
	if (!is_array($watch_lists['u'])) $watch_lists['u'] = array();
	if (!is_array($watch_lists['t'])) $watch_lists['t'] = array();

	// -------------------------------------------------
	// Get the message(s) in this post from the database
	$query = "
		SELECT
			p.POST_ID, t.TOPIC_SUBJECT, p.USER_ID, p.POST_BODY, p.POST_TIME, u.USER_DISPLAY_NAME,
			up.USER_TITLE, up.USER_RATING, up.USER_AVATAR, up.USER_AVATAR_WIDTH, up.USER_AVATAR_HEIGHT,
			u.USER_REGISTERED_ON, up.USER_TOTAL_POSTS, up.USER_LOCATION, up.USER_SIGNATURE,
			up.USER_CUSTOM_TITLE, up.USER_ACCEPT_PM, up.USER_HOMEPAGE, up.USER_VISIBLE_ONLINE_STATUS,
			up.USER_MOOD, up.USER_NAME_COLOR, u.USER_MEMBERSHIP_LEVEL, up.USER_GROUP_IMAGES, u.USER_IS_BANNED
		FROM
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS AS p,
			{$config['TABLE_PREFIX']}USERS AS u,
			{$config['TABLE_PREFIX']}USER_PROFILE AS up,
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS AS t
		WHERE
			p.TOPIC_ID = ?
		AND p.TOPIC_ID = t.TOPIC_ID
		AND p.USER_ID = u.USER_ID
		AND u.USER_ID = up.USER_ID
		ORDER BY
			p.POST_TIME
		LIMIT $new_page, $limit
	";
	$sth = $dbh->do_placeholder_query($query, array($message), __LINE__, __FILE__);

	$postrow = array();
	$i = 0;
	$last_post = 0;

	// Keep track of all users on this page
	$users_in_topic = array();
	$popups = "";

	while (list($post_id, $post_subject, $user_id, $post_body, $post_time, $user_name, $user_title, $stars, $Picture,
		$picwidth, $picheight, $Registered, $TotalPosts, $Location, $Signature, $CustomTitle, $accept_pm, $homepage,
		$visible, $mood, $namecolor, $userlevel, $gimages, $Banned) = $dbh->fetch_array($sth)) {

		// Track this for quick reply;
		$last_post = $post_id;

		$plist = "";
		foreach ($participants as $pvisit => $pdata) {
			if ($pvisit < $post_time) {
				foreach ($pdata as $k => $pname) {
					$plist .= "$pname, ";
				}
			}
		}
		$plist = preg_replace("/, $/", "", $plist);

		$postrow[$i]['plist'] = $plist;
		$postrow[$i]['userid'] = $user_id;

		// Set the mood
		if (!$mood) $mood = "content.gif";
		$mood_alt = preg_replace("#.(gif|jpg|png)$#", "", $mood);

		if (!$config['ENABLE_MOODS']) $mood_alt = "";

		$postrow[$i]['mood'] = $mood;
		$postrow[$i]['mood_alt'] = $mood_alt;

		$watch_text = "";
		if ($user_id == 1) {
			$postrow[$i]['Username'] = $ubbt_lang['DELETED'];
		} else {
			// Colorize username (if it applies)
			$PUsername = $html->user_color($user_name, $namecolor, $userlevel);
			$postrow[$i]['UsernameTOP'] = $PUsername;
			$postrow[$i]['GROUP_IMAGES'] = $html->user_status($user_id, $gimages, null);

			$postrow[$i]['Username'] = "<span id=\"menu_control_$post_id\"><a href=\"javascript:void(0);\" onclick=\"showHideMenu('menu_control_$post_id','profile_popup_$post_id');\">$PUsername</a></span>";
			$postrow[$i]['printuser'] = $user_name;
			if (is_array($watch_lists['u']) && in_array($user_id, $watch_lists['u'])) {
				$watch_text = $ubbt_lang['REMOVE_WATCH'];
				$watch_fa = "fas";
			} else {
				$watch_text = $ubbt_lang['ADD_WATCH'];
				$watch_fa = "far";
			}
		}

		if ($user_id == $user['USER_ID']) {
			if ($i == 0) {
				$postrow[$i]['editlink'] = make_ubb_url("ubb=editprivate&message=$post_id&subj=1", "", false);
			} else {
				$postrow[$i]['editlink'] = make_ubb_url("ubb=editprivate&message=$post_id", "", false);
			}
		} else {
			$postrow[$i]['editlink'] = "";
		}

		$postrow[$i]['replylink'] = make_ubb_url("ubb=mess_handler&replymess=1&Number=$message&id=$post_id", "", false);
		$postrow[$i]['quotelink'] = make_ubb_url("ubb=mess_handler&replymess=1&Number=$message&q=1&id=$post_id", "", false);

		$postrow[$i]['mailpostlink'] = "";
		if ($config['MAIL_POST']) {
			$postrow[$i]['mailpostlink'] = make_ubb_url("ubb=domailthread&PM=1&Number=$message", "", false);
		}

//		$picsize = "";
//		if ($picwidth && $picheight) {
//			$picsize = "style=\"max-width:$picwidth"."px; max-height:$picheight"."px;\"";
//		}
//		elseif ($config['AVATAR_MAX_WIDTH'] && $config['AVATAR_MAX_HEIGHT']) {
//			$picsize = "style=\"max-width:{$config['AVATAR_MAX_WIDTH']}"."px; max-height:{$config['AVATAR_MAX_HEIGHT']}"."px;\"";
//		}
		if ($Picture) {
//			$postrow[$i]['Picture'] = "<img src=\"$Picture\" alt=\"\" $picsize />";
// IE11 and older will display the avatar at full size due to their lack of support for css3
// the css3 "object-fit:contain" became available as of edge16,ios8.1,android4.3
			$postrow[$i]['Picture'] = "$Picture";

		} else {
			$postrow[$i]['Picture'] = "";
		}

		$postrow[$i]['time'] = $html->convert_time($post_time, $toffset, $user['USER_TIME_FORMAT']);
		if ($i) $post_subject = "Re: $post_subject";
		$postrow[$i]['Subject'] = $post_subject;
		$postrow[$i]['new_marker'] = "";
		$postrow[$i]['Number'] = $post_id;

		// Handle Title vs Custom and how the board is configured
		if ($CustomTitle && $config['ONLY_CUSTOM']) {
			$postrow[$i]['Title'] = $CustomTitle;
			$CustomTitle = "";
		} else {
			$postrow[$i]['Title'] = $user_title;
			$postrow[$i]['CustomTitle'] = $CustomTitle;
		}

		$postrow[$i]['identicon'] = "";
		if (($config['IDENTICONS_REGD']) && ($usernum != 1)) {
			$postrow[$i]['identicon'] = md5("{$config['BOARD_KEY']}.{$postrow[$i]['userid']}");
		}
		if (($config['IDENTICONS_ANON']) && ($usernum == 1)) {
			$postrow[$i]['identicon'] = md5("{$config['BOARD_KEY']}.{$results[$i]['POST_POSTER_IP']}");
		}

		$postrow[$i]['TotalPosts'] = "{$ubbt_lang['TOTAL_POSTS']} " . number_format($TotalPosts);
		$postrow[$i]['Signature'] = $Signature;
		if (isset($Registered)) {
			$Registered = $html->convert_time($Registered, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT'], 1);
			preg_match("/<span class=\"date\">(.*?)<\/span>/", $Registered, $matches);
			$Registered = trim($matches['1']);

			$postrow[$i]['Registered'] = "{$ubbt_lang['REGED_ON']} $Registered";
		}
		if ($Location) {
			if (strlen($Location) > 30) {
				$TitleText = $Location;
				$Location = substr($Location, 0, 30);
				$Location = "<span title=\"$TitleText\">$Location... </span>";
			}
			$postrow[$i]['Location'] = "{$ubbt_lang['USER_LOC']} $Location";
		}

		if ($user['USER_SHOW_SIGNATURES'] == "no" || $user['USER_SHOW_SIGNATURES'] == "to" || $Banned) {
			$postrow[$i][Signature] = "";
		}

		$rateimage = "";
		if (($stars) && ($config['USER_RATINGS'] == "1")) {
			for ($x = 1; $x <= $stars; $x++) {
				$rateimage .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/star.gif\" alt=\"*\" />";
			}
			$postrow[$i]['Rating'] = $rateimage;
		}

		if ($post_time > $last_visit) {
			$postrow[$i]['unread'] = "<a name=\"UNREAD\"></a>";
			$postrow[$i]['newimage'] = "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/new.gif\" alt=\"\" />";
		} else {
			$postrow[$i]['newimage'] = "";
			$postrow[$i]['unread'] = "";
		}

		// --------------------------
		// Are we ignoring this user?
		if (stristr($user['USER_IGNORE_LIST'], "-$user_id-")) {
			$postrow[$i]['Body'] = <<<NO_PEEKING
<div align="center">
{$ubbt_lang['IGNORING']}<br>
<a href="javascript:void(0);" onclick="toggleIgnore('body$i');">{$ubbt_lang['IGNORING_TOGGLE']}</a>
</div>
<br>
<div id="body$i" style="display:none">$post_body</div>
NO_PEEKING;
		} else {
			$postrow[$i]['Body'] = "<div id=\"body$i\">$post_body</div>";
		}


		$popups .= "<div id=\"profile_popup_$post_id\" style=\"display:none;\"><table class=\"popup_menu\">";
		$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=showprofile&User=$user_id", $user_name, false) . "\" class=\"nd\" rel=\"nofollow\"><i class=\"far fa-user fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['VIEW_PROFILE']}</a></td></tr>";
		if ($userob->check_access("cp", "EDIT_USERS")) {
			if ($userlevel == "User") {
				$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"{$config['BASE_URL']}/admin/showuser.php?uid=$user_id\" class=\"nd\" rel=\"nofollow\"><i class=\"fas fa-wrench fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['EDIT_USER']}</a></td></tr>";
			}
		}
		if (($user['USER_MEMBERSHIP_LEVEL'] == 'Administrator') && ($user['USER_ID'] != $user_id)) {
			$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"{$config['BASE_URL']}/admin/loginas.php?uid={$usernum}\" class=\"nd\" rel=\"nofollow\"><i class=\"far fa-meh fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['BECOME_USER']}</a></td></tr>";
		}
		if ($accept_pm) {
			$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=sendprivate&User=$user_id", "", false) . "\" class=\"nd\" rel=\"nofollow\"><i class=\"far fa-envelope fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['SEND_PM']}</a></td></tr>";
		}
		if ($homepage) {
			$homepage = "http://$homepage";
			$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"$homepage\" class=\"nd\" target=\"_blank\"><i class=\"fas fa-globe fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['VIEW_HOME']}</a></td></tr>";
		}
		if ($user['USER_ID'] != $user_id) {
			$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=addfavuser&User=$user_id&n=$post_id&p=$page", "", false) . "\" class=\"nd\" rel=\"nofollow\"><i class=\"$watch_fa fa-bookmark fa-fw menu-item\" aria-hidden=\"true\"></i> $watch_text</a></td></tr>";
		}
		$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=userposts&id=$user_id", "", false) . "\" class=\"nd\" rel=\"nofollow\"><i class=\"far fa-comment fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['VIEW_POSTS']}</a></td></tr>";
		$popups .= "</table></div>";
		$popups .= "<script>registerPopup(\"profile_popup_$post_id\");</script>";

		if (!isset($users_in_topic[$user_id])) {
			$users_in_topic[$user_id] = $visible;
		}


		$i++;

	}


	// Now let's figure out who's online and who isn't
	$inlist = "";
	$online_status = array();
	foreach ($users_in_topic as $o_uid => $o_vis) {
		$online_status[$o_uid] = 0;
		if (!$config['DISABLE_ONLINE_INVISIBLE'] && $o_vis == "no" && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && (!preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL'])))) {
			continue;
		}
		$inlist .= "'$o_uid',";
	}
	$inlist = preg_replace("#,$#", "", $inlist);

	if (!$inlist) $inlist = "''";
	$query = "
		SELECT USER_ID
		FROM {$config['TABLE_PREFIX']}ONLINE
		WHERE USER_ID IN ($inlist)
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	while (list($o_uid) = $dbh->fetch_array($sth)) {
		$online_status[$o_uid] = 1;
	}


	// Get the subject for this topic
	$query = "
		SELECT TOPIC_SUBJECT
		FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
		WHERE TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($message), __LINE__, __FILE__);
	list($topic_subject) = $dbh->fetch_array($sth);

	// Update the last visit to this pt
	$date = $html->get_date();
	$query = "
		UPDATE {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		SET MESSAGE_LAST_READ = ?
		WHERE USER_ID = ?
		  AND TOPIC_ID = ?
	";
	$dbh->do_placeholder_query($query, array($date, $user['USER_ID'], $message), __LINE__, __FILE__);

	// Check and see if there are any more unread PMs
	$query = "
		SELECT count(*)
		FROM
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS AS t1,
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS AS t2
		WHERE
			t1.TOPIC_ID = t2.TOPIC_ID
		AND	t2.TOPIC_LAST_REPLY_TIME > t1.MESSAGE_LAST_READ
		AND	t1.USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	list($total_unread) = $dbh->fetch_array($sth);

	$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
		SET USER_TOTAL_PM = ?
		WHERE USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($total_unread, $user['USER_ID']), __LINE__, __FILE__);

	$user['USER_TOTAL_PM'] = $total_unread;

	$smarty_data = array(
		"pages1" => &$pages1,
		"pages2" => &$pages2,
		"title" => $topic_subject,
		"postrow" => & $postrow,
		"message" => $message,
		"participant_list" => $participant_list,
		"id" => $last_post,
		"quickreply" => 1,
		"popups" => $popups,
		"post_layout" => $post_layout,
		"online_status" => $online_status,
		"mystuff" => $html->mystuff(),
		"toolong" => $toolong,
		"show_avatars" => $AVATARS_WITH_POSTS,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$viewmessages = make_ubb_url("ubb=viewmessages", "", false);
	return array(
		"header" => array(
			"title" => $topic_subject,
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"javascript" => array(
				0 => "quickquote.js",
			),
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 <a href="{$viewmessages}">{$ubbt_lang['MY_PRIVATES']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> $topic_subject
BREADCRUMB
		,
		),
		"template" => "viewmessage",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>