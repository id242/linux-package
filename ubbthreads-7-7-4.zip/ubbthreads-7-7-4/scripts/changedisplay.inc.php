<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_changedisplay_gpc() {
	return array(
		"input" => array(
			"start_view" => array("start_view", "post", "alpha"),
			"default_tab" => array("default_tab", "post", "alpha"),
			"default_sort" => array("default_sort", "post", "alpha"),
			"PostsPer" => array("PostsPer", "post", "int"),
			"FlatPosts" => array("FlatPosts", "post", "int"),
			"display" => array("display", "post", "alpha"),
			"SHOW_AVATARS" => array("SHOW_AVATARS", "post", "int"),
			"Notify" => array("Notify", "post", "alpha"),
			"AcceptPriv" => array("AcceptPriv", "post", "alpha"),
			"timeoffset" => array("timeoffset", "post", ""),
			"timeformat" => array("timeformat", "post", "alphanum"),
			"profilehash" => array("profilehash", "post", ""),
			"hide" => array("hide", "post", "alpha"),
			"ShowSigs" => array("ShowSigs", "post", "alpha"),
			"adminemails" => array("adminemails", "post", "alpha"),
			"style" => array("style", "post", "int"),
			"unapproved" => array("unapproved", "post", "int"),
			"email_watch" => array("email_watch", "post", "int"),
			"language" => array("language", "post", ""),
			"HIDE_LEFT" => array("HIDE_LEFT", "post", "int"),
			"HIDE_RIGHT" => array("HIDE_RIGHT", "post", "int"),
			"admin_notify" => array("admin_notify", "post", "int"),
			"relative" => array("relative", "post", "int"),
			"newuser_notify" => array("newuser_notify", "post", "int"),
			"post_layout" => array("post_layout", "post", "alpha"),
			"show_all_graemlins" => array("show_all_graemlins", "post", "int"),
			"mystuff_left" => array("mystuff_left", "post", "int"),
			"notify_multi" => array("notify_multi", "post", "int"),
		),
		"wordlets" => array("changedisplay"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_changedisplay_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!$unapproved) $unapproved = 0;

	$query = "
		select USER_PROFILE_KEY
		from	{$config['TABLE_PREFIX']}USER_DATA
		where USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	list($user['USER_PROFILE_KEY']) = $dbh->fetch_array($sth);

	// Make sure this is a legit submission
	if ($profilehash != $user['USER_PROFILE_KEY']) {
		$html->not_right($ubbt_lang['PHASH']);
	}

	// --------------------------------------------------------------
	// If Posts per is less than 1 or greater than 99, can't proceed
	if (($PostsPer < 1) || ($PostsPer > 99)) {
		$html->not_right($ubbt_lang['POSTS_PER']);
	}

	// -------------------------------------------------------------
	// If FlatPosts is less than 1 or greater than 99, can't proceed
	if (($FlatPosts < 1) || ($FlatPosts > 99)) {
		$html->not_right($ubbt_lang['FLAT_BAD']);
	}

	// Make sure they have chosen an option for receiving admin emails
	if (!$adminemails) {
		$html->not_right($ubbt_lang['ADMIN_EMAIL']);
	}

	if (isset($config['TOPIC_DISPLAY_OPTIONS']) && $config['TOPIC_DISPLAY_OPTIONS'] != "both") {
		$display = $config['TOPIC_DISPLAY_OPTIONS'];
	}

	$timeformat = $config['TIME_FORMATS'][$timeformat];

	if (!$HIDE_LEFT) $HIDE_LEFT = 0;
	if (!$HIDE_RIGHT) $HIDE_RIGHT = 0;
	if (!$mystuff_left) $mystuff_left = 0;

	if (!$admin_notify) $admin_notify = '0';
	if (!$newuser_notify) $newuser_notify = '0';
	if (!$notify_multi) $notify_multi = '0';

	$query_vars = array($start_view, $default_tab, $default_sort, $display, $SHOW_AVATARS, $Notify, $FlatPosts, $PostsPer, $AcceptPriv, $timeformat, $timeoffset, $hide, $ShowSigs, $adminemails, $style, $unapproved, $HIDE_LEFT, $HIDE_RIGHT, $email_watch, $language, $admin_notify, $relative, $newuser_notify, $post_layout, $show_all_graemlins, $mystuff_left, $notify_multi, $user['USER_ID']);

	// --------------------------
	// Update the User's profile
	$date = $html->get_date();
	$query = "
	UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
	SET
	USER_START_VIEW = ?,
	USER_FAVORITES_TAB = ?,
	USER_FAVORITES_SORT = ?,
	USER_TOPIC_VIEW_TYPE = ?,
	USER_SHOW_AVATARS = ?,
	USER_NOTIFY_ON_PM = ?,
	USER_POSTS_PER_TOPIC = ?,
	USER_TOPICS_PER_PAGE = ?,
	USER_ACCEPT_PM = ?,
	USER_TIME_FORMAT = ?,
	USER_TIME_OFFSET = ?,
	USER_VISIBLE_ONLINE_STATUS = ?,
	USER_SHOW_SIGNATURES = ?,
	USER_ACCEPT_ADMIN_EMAILS = ? ,
	USER_STYLE = ?,
	USER_UNAPPROVED_POST_NOTIFY = ? ,
	USER_HIDE_LEFT_COLUMN = ? ,
	USER_HIDE_RIGHT_COLUMN = ? ,
	USER_EMAIL_WATCHLISTS = ? ,
	USER_LANGUAGE = ? ,
	USER_REPORT_POST_NOTIFY = ? ,
	USER_RELATIVE_TIME = ? ,
	USER_NOTIFY_NEW_USER = ?  ,
	USER_POST_LAYOUT = ?,
	USER_SHOW_ALL_GRAEMLINS = ?,
	USER_SHOW_LEFT_MYSTUFF = ?,
	USER_NOTIFY_MULTI = ?
	WHERE USER_ID = ?
	";
	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

	$query = "
	UPDATE {$config['TABLE_PREFIX']}USER_DATA
	SET
	USER_LAST_VISIT_TIME = ?
	WHERE USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($date, $user['USER_ID']), __LINE__, __FILE__);

	// Force thier navigation cookie to be read on next load
	$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_mynav_show", "", time() - 3600);

	rebuild_islands();

	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "editdisplay&u=1",
	);
}

?>