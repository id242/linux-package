<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);
function page_showpic_gpc() {
	return array(
		"input" => array(
			"id" => array("id", "get", "int"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_showpic_run() {

	global $html, $style_array, $smarty, $userob, $user, $in, $myinfo, $ubbt_lang, $config, $forumvisit, $visit, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select FILE_NAME,FILE_ORIGINAL_NAME,FILE_DIR,FILE_WIDTH,FILE_HEIGHT,FILE_TYPE,FILE_DESCRIPTION
		from {$config['TABLE_PREFIX']}FILES
		where FILE_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	list($filename, $filename_orig, $filedir, $width, $height, $type, $desc) = $dbh->fetch_array($sth);

	if ($desc) {
		$filename = preg_replace("/ +/", "_", $desc) . ".$type";
	} else {
		$filename = $filename_orig;
	}

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	$smarty_data = array(
		"stylesheet" => $stylesheet,
		"filename" => $filename,
		"img" => "{$config['FULL_URL']}/gallery/$filedir/full/$id.$type",
		"id" => $id,
		"width" => $width,
		"height" => $height,
		"dir" => $filedir,
		"ext" => $type,
	);

	return array(
		"header" => array(
			"title" => "",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => 0,
			"breadcrumb" => "",
		),
		"template" => "showpic",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>