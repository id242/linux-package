<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_myhome_gpc() {
	return array(
		"input" => array(
			"tab" => array("tab", "get", "alpha"),
			"sort" => array("sort", "get", "alpha"),
			"page" => array("page", "get", "int"),
			"filter" => array("filter", "get", "int"),
			"type" => array("type", "get", "int"),
			"n" => array("n", "get", "int"),
		),
		"wordlets" => array("myhome"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE, t2.USER_TIME_FORMAT, t2.USER_FAVORITES_TAB, t2.USER_FAVORITES_SORT, t2.USER_TOPICS_PER_PAGE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_myhome_run() {

	global $smarty, $myinfo, $user, $in, $ubbt_lang, $config, $visit, $dbh, $html, $userob, $style_array;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!$filter) $filter = 0;
	$filter_links = "";

	// Make sure we have a set topics per page
	if (!$user['USER_TOPICS_PER_PAGE']) {
		$config['TOPICS_PER_PAGE'];
	}

	// Make sure we have their last visit time to each forum
	if (!isset($_SESSION['forumvisit']['visit']) || !is_array($_SESSION['forumvisit']['visit'])) {

		$query = "
			select 	USER_LAST_VISIT_TIME
			from	{$config['TABLE_PREFIX']}USER_DATA
			where	USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
		list($user['USER_LAST_VISIT_TIME']) = $dbh->fetch_array($sth);

		$_SESSION['forumvisit']['lastonline'] = $user['USER_LAST_VISIT_TIME'];
		if ($user['USER_ID']) {
			$query = "
			SELECT LAST_VISIT_TIME,FORUM_ID
			FROM {$config['TABLE_PREFIX']}FORUM_LAST_VISIT
			WHERE USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
			while (list($l_last, $l_board) = $dbh->fetch_array($sth)) {
				$_SESSION['forumvisit']['visit'][$l_board] = $l_last;
			}
		}
	}

	// If $n and $tab aren't set then we're returning here from looking at a topic
	// Let's grab the session data to return to the right page.
	if ((!$n && !$tab) && isset($_SESSION['favorites']['tab'])) {
		$sort = $_SESSION['favorites']['sort'];
		$tab = $_SESSION['favorites']['tab'];
		$page = $_SESSION['favorites']['page'];
	}

	// If tab isn't set, lets see if we are changing type
	if (!$tab && isset($_SESSION['favorites']['tab'])) {
		$tab = $_SESSION['favorites']['tab'];
	}

	if (!$tab) {
		if (isset($user['USER_FAVORITES_TAB'])) {
			$tab = $user['USER_FAVORITES_TAB'];
		} else {
			$tab = "forums";
		}
	}

	if (!$sort) {
		if (isset($user['USER_FAVORITES_SORT'])) {
			$sort = $user['USER_FAVORITES_SORT'];
		} else {
			$sort = "reply";
		}
	}

	if (!$page) {
		$page = 1;
	}

	// What's our real sort key?
	$field_sort = "";
	if ($sort == "creation") {
		$field_sort = "t.TOPIC_CREATED_TIME DESC";
	} elseif ($sort == "title") {
		$field_sort = "t.TOPIC_SUBJECT ASC";
	} elseif ($sort == "author") {
		$field_sort = "u.USER_DISPLAY_NAME ASC";
	} else {
		$field_sort = "t.TOPIC_LAST_REPLY_TIME desc";
	}

	// User tab is a bit different
	if ($tab == "users" && $sort == "reply") {
		$field_sort = "p.POST_POSTED_TIME DESC";
	}

	// Setup the sort links
	$reply_link = "<a href='" . make_ubb_url("ubb=myhome&tab=$tab&sort=reply", "", false) . "'>{$ubbt_lang['REPLY']}</a>";
	$creation_link = "<a href='" . make_ubb_url("ubb=myhome&tab=$tab&sort=creation", "", false) . "'>{$ubbt_lang['CREATION']}</a>";
	$title_link = "<a href='" . make_ubb_url("ubb=myhome&tab=$tab&sort=title", "", false) . "'>{$ubbt_lang['TOPIC_TITLE']}</a>";
	$author_link = "<a href='" . make_ubb_url("ubb=myhome&tab=$tab&sort=author", "", false) . "'>{$ubbt_lang['TOPIC_AUTHOR']}</a>";

	if ($sort == 'reply') $reply_link = $ubbt_lang['REPLY'];
	if ($sort == 'creation') $creation_link = $ubbt_lang['CREATION'];
	if ($sort == 'title') $title_link = $ubbt_lang['TOPIC_TITLE'];
	if ($sort == 'author') $author_link = $ubbt_lang['TOPIC_AUTHOR'];


	// Which template are we loading?
	$template = "tab_{$tab}";

	// Include the proper script
	define('INCLUDE_TAB', 1);

	// Populate smarty data for the tab_contents
	$smarty->assign("tab", $tab);
	$smarty->assign("reply_link", $reply_link);
	$smarty->assign("creation_link", $creation_link);
	$smarty->assign("title_link", $title_link);
	$smarty->assign("author_link", $author_link);

	include_once("{$config['FULL_PATH']}/scripts/tab_{$tab}.inc.php");

	// Process the tab_contents template
	$contents = $smarty->fetch("tab_contents.tpl");

	// We need to save some of our current settings in a session var
	// so we can return here properly
	$_SESSION['favorites'] = array(
		"tab" => $tab,
		"page" => $page,
		"sort" => $sort,
		"filter" => $filter
	);

	// Now populate the smarty data for the actual template
	$smarty_data = array(
		"tab" => $tab,
		"contents" => & $contents,
		"mystuff" => $html->mystuff(),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['VIEW_WATCH'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['VIEW_WATCH']}
BREADCRUMB
		,
		),
		"template" => "$template",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>