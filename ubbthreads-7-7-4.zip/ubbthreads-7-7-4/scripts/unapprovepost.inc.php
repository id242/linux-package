<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_unapprovepost_gpc() {
	return array(
		"input" => array(
			"Username" => array("Username", "post", ""),
			"Board" => array("Board", "both", "alphanum"),
			"what" => array("what", "post", "alpha"),
			"Number" => array("Number", "both", "int"),
		),
		"wordlets" => array("unapprovepost"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
}

function page_unapprovepost_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra, $debug, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	// ---------------------------------
	// Check if they moderate this board
	$query = "
	SELECT FORUM_ID
	FROM   {$config['TABLE_PREFIX']}MODERATORS
	WHERE  USER_ID = ?
	AND    FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $Board), __LINE__, __FILE__);
	list($check) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	if (($user['USER_MEMBERSHIP_LEVEL'] != 'Administrator') && ($user['USER_MEMBERSHIP_LEVEL'] != "GlobalModerator") && (!$check)) {
		$html->not_right($ubbt_lang['NO_ADMOD']);
	}

	// -------------------
	// Update the database
	$query = "
	UPDATE {$config['TABLE_PREFIX']}POSTS
	SET    POST_IS_APPROVED = '0'
	WHERE  POST_ID = ?
	";
	$dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

	// ---------------------------------
	// Get some information on this post
	$query = "
	SELECT t1.USER_ID,t1.POST_PARENT_ID,t1.POST_SUBJECT,t1.POST_BODY,t1.TOPIC_ID,t2.USER_DISPLAY_NAME,t1.POST_IS_TOPIC,t1.POST_ICON,t1.POST_POSTED_TIME,t1.POST_POSTER_NAME
	FROM  {$config['TABLE_PREFIX']}POSTS AS t1,
	{$config['TABLE_PREFIX']}USERS AS t2
	WHERE t1.POST_ID = ?
	AND   t2.USER_ID = t1.USER_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($Posterid, $Parent, $Subject, $Body, $Main, $Username, $post_is_topic, $Icon, $date, $guest_name) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	// ---------------------------------------------------------
	// If this is a new thread, we reduce up the thread total by 1
	// and also unapprove the topic itself
	if ($post_is_topic == 1) {
		$query = "
			update {$config['TABLE_PREFIX']}TOPICS
			set TOPIC_IS_APPROVED = 0
			where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($Main), __LINE__, __FILE__);
		$extra = ",FORUM_TOPICS = FORUM_TOPICS - 1";
	}


	// -------------------------------------------
	// Need to update the last post on this board
	$query = "
	SELECT TOPIC_ID,TOPIC_LAST_POST_ID,TOPIC_LAST_POSTER_ID,TOPIC_LAST_POSTER_NAME
	FROM {$config['TABLE_PREFIX']}TOPICS
	WHERE FORUM_ID = ?
	AND   TOPIC_IS_APPROVED = '0'
	ORDER BY TOPIC_LAST_REPLY_TIME DESC
	LIMIT 1
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list ($lastmain, $lastnumber, $posterid, $user_display) = $dbh->fetch_array($sth);

	if ($posterid == 1) {
		$user_display = $guest_name;
	}

	$query_vars = array($posterid, $date, $lastmain, $lastnumber, $user_display, $Subject, $Icon, $Board);
	$query = "
	UPDATE {$config['TABLE_PREFIX']}FORUMS
	SET   FORUM_POSTS = FORUM_POSTS + 1,
	FORUM_LAST_POSTER_ID = ? ,
	FORUM_LAST_POST_TIME = ? ,
	FORUM_LAST_TOPIC_ID = ? ,
	FORUM_LAST_POST_ID = ?,
	FORUM_LAST_POSTER_NAME = ? ,
	FORUM_LAST_POST_SUBJECT = ? ,
	FORUM_LAST_POST_ICON = ?
	$extra
	WHERE FORUM_ID = ?
	";
	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

	$query = "
		SELECT	FORUM_TITLE
		FROM	{$config['TABLE_PREFIX']}FORUMS
		WHERE	FORUM_ID = ?
	";

	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	$tmp = $dbh->fetch_array($sth);
	$forum_title = $tmp['FORUM_TITLE'];

	if ($post_is_topic == 0) {

		$query_vars = array($Posterid, $user_display, $date, $Number, $Main);
		$query = "
		UPDATE {$config['TABLE_PREFIX']}TOPICS
		SET    TOPIC_REPLIES = TOPIC_REPLIES +1,
		TOPIC_LAST_POSTER_ID = ? ,
		TOPIC_LAST_POSTER_NAME = ? ,
		TOPIC_LAST_REPLY_TIME = ? ,
		TOPIC_LAST_POST_ID = ? ,
		TOPIC_IS_APPROVED = 0
		WHERE  TOPIC_ID  = ?
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}

	$query = "
		SELECT USER_ID,POST_SUBJECT,POST_BODY,POST_DEFAULT_BODY
		FROM  {$config['TABLE_PREFIX']}POSTS
		WHERE POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Parent), __LINE__, __FILE__);
	list($MailUser, $PostSubject, $BodySig, $DefaultBody) = $dbh->fetch_array($sth);

	$notify_data = array(
		'EVENT' => ($post_is_topic ? 'TOPIC' : 'REPLY'),
		'USER' => $Posterid,
		'USERNAME' => $Username,
		'FORUM' => $Board,
		'POST' => $Mnumber,
		'TOPIC' => $Main,
		'BODY' => $DefaultBody,
		'HTMLBODY' => $BodySig,
		'TITLE' => $PostSubject,
		'FORUM_NAME' => $forum_title,
	);

	handle_watchlist_notifications($notify_data);

	// Log it
	admin_log("APPR_POST", "UNAPPROVE: <a href='" . make_ubb_url("ubb=showflat&Number=$Number#Post$Number", $Subject, false) . "' target='_blank'>$Subject</a>");


	// ----------------------------------------------
	// Make sure they get refreshed to the proper page
	$redirect = "";
	if (($what == "showthreaded") || ($what == "showflat") || ($what == "showgallery")) {
		$redirect = "$what&Number=$Number#Post$Number";
	} else {
		$redirect = "postlist&Board=$Board";
	}

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => $redirect,
			"Subject" => $Subject,
			"heading" => $ubbt_lang['UNAPPR_HEAD'],
			"body" => "{$ubbt_lang['UNAPPR_HEAD']} {$ubbt_lang['RET_TOPIC']}",
			"returnlink" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['UNAPPR_HEAD']}
BREADCRUMB
		,
		)
	);
}

?>