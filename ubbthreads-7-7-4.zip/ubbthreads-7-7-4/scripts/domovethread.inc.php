<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_domovethread_gpc() {
	return array(
		"input" => array(
			"Keyword" => array("Keyword", "post", "int"),
			"oldboard" => array("oldboard", "post", "int"),
			"number" => array("number", "post", "int"),
			"pointer" => array("pointer", "post", "int"),
			"reason" => array("reason", "post", ""),
			"delete" => array("delete", "post", "int"),
			"days" => array("days", "post", "int"),
			"type" => array("type", "post", "alpha"),
			"merge" => array("merge", "post", "int"),
			"sendpm" => array("sendpm", "post", "int"),
		),
		"wordlets" => array("domovethread", "admin/generic"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
}

function page_domovethread_run() {

	global $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Check if they can move posts
	if (!$userob->check_access("forum", "MOVE_ANY", $oldboard)) {
		$html->not_right("You can't move those posts");
	}

	// -------------------------------------------------
	// If we didn't get a keyword, then we don't move it
	if ($type == "move") {
		if (!$Keyword) {
			$html->not_right("{$ubbt_lang['NO_FORUM']}");
		}
		if ($Keyword == "category") {
			$html->not_right("{$ubbt_lang['NO_CAT']}");
		}
		if (!$number) {
			$html->not_right("{$ubbt_lang['NONUM']}");
		}
	}

	// Right up front, save the pre moved/merged topic info, if a PM is required
	if ($sendpm) {
		$query = "
			SELECT TOPIC_SUBJECT, USER_ID
			FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($number), __LINE__, __FILE__);
		list ($pmSubj, $pmWho) = $dbh->fetch_array($sth);
	}

	$merge_topic = "";
	// If merging, let's make sure we can find the post
	if ($type == "merge") {
		$query = "
			SELECT
				t1.POST_ID, t2.TOPIC_VIEWS
			FROM
				{$config['TABLE_PREFIX']}POSTS AS t1,
				{$config['TABLE_PREFIX']}TOPICS AS t2
			WHERE
				t1.TOPIC_ID = ?
			AND t1.TOPIC_ID = t2.TOPIC_ID
		";
		$sth = $dbh->do_placeholder_query($query, array($number), __LINE__, __FILE__);
		list($first_post, $current_views) = $dbh->fetch_array($sth);
		$query = "
			SELECT
				t2.FORUM_ID, t1.TOPIC_ID, t2.TOPIC_VIEWS
			FROM
				{$config['TABLE_PREFIX']}POSTS AS t1,
				{$config['TABLE_PREFIX']}TOPICS AS t2
			WHERE
				t1.TOPIC_ID = t2.TOPIC_ID
			AND t1.POST_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($merge), __LINE__, __FILE__);
		list($Keyword, $merge_topic, $topic_views) = $dbh->fetch_array($sth);
		if (!$Keyword) {
			$html->not_right($ubbt_lang['NOMERGE']);
		}

	}

	$query = "
		SELECT FORUM_TITLE, CATEGORY_ID, FORUM_PARENT, FORUM_IS_GALLERY
		FROM {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Keyword), __LINE__, __FILE__);
	list($Title, $cat_id, $parent_id, $is_gallery) = $dbh->fetch_array($sth);

	// ---------------------------------------------------------------------
	// If there are any unapproved posts in this thread then we can't move it
	$query = "
		SELECT POST_IS_APPROVED, POST_SUBJECT, POST_ID
		FROM {$config['TABLE_PREFIX']}POSTS
		WHERE TOPIC_ID = ?
		ORDER BY POST_ID ASC
	";
	$sth = $dbh->do_placeholder_query($query, array($number), __LINE__, __FILE__);
	$tsubject = "";
	while (list($check, $subject, $pd) = $dbh->fetch_array($sth)) {
		if (!$tsubject) {
			$tsubject = $subject;
			$post_id = $pid;
		}
		if ($check == "0") {
			$dbh->finish_sth($sth);
			$html->not_right("{$ubbt_lang['UNAPPROVED']}");
		}
	}

	// ---------------------------------------
	// Remove this from anyone's favorite list
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
		WHERE WATCH_ID = ?
		  AND WATCH_TYPE = 't'
	";
	$dbh->do_placeholder_query($query, array($number), __LINE__, __FILE__);

	// -------------------------
	// Are we leaving a pointer?
	$mnumber = "";
	if ($pointer) {
		$query = "
			SELECT TOPIC_LAST_REPLY_TIME, TOPIC_SUBJECT, TOPIC_ICON, USER_ID, TOPIC_VIEWS, TOPIC_REPLIES, TOPIC_LAST_POST_ID, TOPIC_LAST_POSTER_NAME, TOPIC_LAST_POSTER_ID
			FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($number), __LINE__, __FILE__);
		list ($c_posted, $c_subject, $c_icon, $c_posterid, $c_views, $c_replies, $c_post_id, $c_poster_name, $c_poster_id) = $dbh->fetch_array($sth);

		if ($type == "move") {
			$newloc = $Keyword . "-ML-" . $number . "-ML-$reason";
		} else {
			$newloc = $Keyword . "-MERGE-" . $first_post . "-MERGE-$reason";
		}

		$query_vars = array($oldboard, 0, $c_posterid, $c_subject, $c_posted, 1, 'M', '0', $c_posted, 0, 0, $c_views, $c_replies, $c_post_id, $c_poster_name, $c_poster_id);
		$query = "
			INSERT INTO
				{$config['TABLE_PREFIX']}TOPICS
				(FORUM_ID, POST_ID, USER_ID, TOPIC_SUBJECT, TOPIC_CREATED_TIME, TOPIC_IS_APPROVED, TOPIC_STATUS, TOPIC_IS_STICKY, TOPIC_LAST_REPLY_TIME, TOPIC_HAS_FILE, TOPIC_HAS_POLL, TOPIC_VIEWS, TOPIC_REPLIES, TOPIC_LAST_POST_ID, TOPIC_LAST_POSTER_NAME, TOPIC_LAST_POSTER_ID)
			VALUES
				(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

		// Get the topic id
		$query = "
			SELECT last_insert_id()
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		list ($Main) = $dbh->fetch_array($sth);

		$query_vars = array(0, $Main, 1, $c_posted, 0, $c_subject, $newloc, $newloc, 1, $c_icon, $c_posterid);

		$query = "
			INSERT INTO
				{$config['TABLE_PREFIX']}POSTS
				(POST_PARENT_ID, TOPIC_ID, POST_IS_TOPIC, POST_POSTED_TIME, POST_POSTER_IP, POST_SUBJECT, POST_BODY, POST_DEFAULT_BODY, POST_IS_APPROVED, POST_ICON, USER_ID)
			VALUES
				(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

		if ($delete) {
			$delete_date = $html->get_date() + ($days * 86400);
			$query = "
				INSERT INTO
					{$config['TABLE_PREFIX']}POINTER_DELETE
					(TOPIC_ID, DELETE_ON)
				VALUES
					(?, ?)
			";
			$dbh->do_placeholder_query($query, array($Main, $delete_date), __LINE__, __FILE__);
		}

		$query = "
			SELECT last_insert_id()
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		list($mnumber) = $dbh->fetch_array($sth);

		$query = "
			UPDATE {$config['TABLE_PREFIX']}TOPICS
			SET POST_ID = ?
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($mnumber, $Main), __LINE__, __FILE__);

	}

	// -------------------------------
	// How many replies in this topic?
	$query = "
		SELECT COUNT(*)
		FROM {$config['TABLE_PREFIX']}POSTS
		WHERE TOPIC_ID  = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($number), __LINE__, __FILE__);
	list($moved) = $dbh->fetch_array($sth);

	// Move the topic
	if ($type == "move") {
		$query = "
			UPDATE {$config['TABLE_PREFIX']}TOPICS
			SET FORUM_ID = ?
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($Keyword, $number), __LINE__, __FILE__);
	}

	// Merge the topic
	if ($type == "merge") {
		$query = "
			UPDATE {$config['TABLE_PREFIX']}POSTS
			SET POST_PARENT_ID = ? ,
				POST_IS_TOPIC = 0
			WHERE POST_ID = ?
			  AND TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($merge, $first_post, $number), __LINE__, __FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($number), __LINE__, __FILE__);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}POSTS
			SET TOPIC_ID = ?
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($merge_topic, $number), __LINE__, __FILE__);
		$number = $merge_topic;
		$new_views = $current_views + $topic_views;
		$query = "
			UPDATE {$config['TABLE_PREFIX']}TOPICS
			SET TOPIC_REPLIES = TOPIC_REPLIES + ? ,
				TOPIC_VIEWS = ?
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($moved, $new_views, $merge_topic), __LINE__, __FILE__);
		rebuild_topic_data($merge_topic);
	}

	// ---------------------------------------------------------
	// Grab the time that the last reply was made on this thread
	$query = "
		SELECT max(POST_POSTED_TIME)
		FROM {$config['TABLE_PREFIX']}POSTS
		WHERE TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($number), __LINE__, __FILE__);
	list ($lastpost) = $dbh->fetch_array($sth);

	// Update the LAST_POST_TIME field for the board this thread is getting moved to
	// as long as the new time is greater than the old time
	$query = "
		UPDATE {$config['TABLE_PREFIX']}FORUMS
		SET FORUM_LAST_POST_TIME = ?
		WHERE FORUM_ID = ?
		  AND FORUM_LAST_POST_TIME < ?
	";
	$dbh->do_placeholder_query($query, array($lastpost, $Keyword, $lastpost), __LINE__, __FILE__);


	// If we're moving the topic, we need to check for sticky
	if ($type == "move") {
		$query = "
			SELECT TOPIC_IS_STICKY, POST_ID
			FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($number), __LINE__, __FILE__);
		list($is_sticky, $mnumber) = $dbh->fetch_array($sth);

		if ($is_sticky == 1) {

			// This is sticky - update the announcements table
			$query = "
				UPDATE {$config['TABLE_PREFIX']}ANNOUNCEMENTS
				SET	FORUM_ID = ?
				WHERE TOPIC_ID = ?
			";
			$dbh->do_placeholder_query($query, array($Keyword, $number), __LINE__, __FILE__);
		}
	}


	// ------------------------------------------------------------
	// Now update the number of posts on both boards and other info
	// the data for the main display
	if ($oldboard != $Keyword) {
		rebuild_forum_data($oldboard);
	}
	rebuild_forum_data($Keyword);

	// Check if a PM should be sent to the topic Starter
	if (($sendpm) && ($user['USER_ID'] != $pmWho)) {
		$whereid = ($type == "merge") ? $merge_topic : $number;
		$query = "
			SELECT POST_ID
			FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($whereid), __LINE__, __FILE__);
		list ($pmPostID) = $dbh->fetch_array($sth);

		$Subj = ($type == "merge") ? $ubbt_lang['PM_MERGE_SUBJ'] : $ubbt_lang['PM_MOVE_SUBJ'];

		if ($reason) {
			$reason = nl2br($html->substitute($ubbt_lang['PM_REASON'], array('REASON' => $reason)));
		}
		$pmMsg = $html->substitute($ubbt_lang['PM_BODY'], array(
			'SUBJECT' => $pmSubj,
			'NEW_ADDY' => make_ubb_url("ubb=showflat&Number=$pmPostID", "", true),
			'IF_REASON' => $reason));
		$html->send_message($user['USER_ID'], $pmWho, $Subj, $pmMsg);
	}

	// Setup info for admin log
	$query = "
		SELECT FORUM_TITLE
		FROM {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($oldboard), __LINE__, __FILE__);
	list($oldtitle) = $dbh->fetch_array($sth);

	// ---------------
	// Log this action
	$logger = ($type == "merge") ? "MERGE_TOPIC" : "MOVE_TOPIC";
	admin_log($logger, "<a href='" . make_ubb_url("ubb=postlist&Board=$oldboard", $oldtitle, false) . "' target='_blank'>$oldtitle</a> -> <a href='" . make_ubb_url("ubb=showflat&Number=$mnumber", $tsubject, false) . "' target='_blank'>$tsubject</a>");

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "postlist&Board=$oldboard",
			"heading" => $ubbt_lang['COM_HEAD'],
			"body" => $ubbt_lang['COM_BODY'],
			"returnlink" => "",
			"Board" => $Keyword,
			"Category" => $cat_id,
			"forum_parent" => $parent_id,
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		)
	);
}

?>