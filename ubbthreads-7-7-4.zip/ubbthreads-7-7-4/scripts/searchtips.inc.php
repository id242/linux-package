<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);

function page_searchtips_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("searchtips"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_searchtips_run() {

	global $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $style_array;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array(
		"stylesheet" => "{$config['BASE_URL']}/styles/{$style_array['css']}",
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);

	return array(
		"header" => array(
			"title" => $ubbt_lang['SEARCH_TIPS'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['SEARCH_TIPS']}
BREADCRUMB
		,
		),
		"template" => "searchtips",
		"data" => &$smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>