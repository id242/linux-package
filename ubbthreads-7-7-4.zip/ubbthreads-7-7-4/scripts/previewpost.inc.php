<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);

function page_previewpost_gpc() {
	return array(
		"input" => array(
			"Body" => array("Body", "both", ""),
			"convert" => array("convert", "post", "alpha"),
			"gallery" => array("gallery", "post", "int"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
}

function page_previewpost_run() {

	global $style_array, $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (($user['USER_MEMBERSHIP_LEVEL'] == "User") && ($config['MARKUP_HTML_TOGGLE'] == 0) || !$convert) {
		$convert = "markup";
	}


	$convert_vals = array("both", "markup", "html", "none");
	if (!in_array($convert, $convert_vals)) $convert = "none";

	// If this is a user and HTML isn't allowed in the forum, then make sure
	// html isn't selected
	if ($user['USER_MEMBERSHIP_LEVEL'] == "User") {
		if ($convert == "both" || $convert == "html") {
			$convert = "none";
		}
	}

	if ($config['DO_CENSOR']) {
		$Body = $html->do_censor($Body);
	}

	$Body = $html->do_markup($Body, "post", $convert);
	$Body = graemlin_url($Body, $smarty);

	header("Content-Type: text/html; charset=UTF-8");
	echo $Body;

	// Bypass smarty completely
	return false;
}

?>