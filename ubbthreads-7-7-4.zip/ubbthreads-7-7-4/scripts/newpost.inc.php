<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_newpost_gpc() {
	return array(
		"input" => array(
			"Board" => array("Board", "get", "alphanum"),
			"what" => array("what", "get", "alpha"),
		),
		"wordlets" => array("newpost"),
		"user_fields" => " t2.USER_TOPIC_VIEW_TYPE,t2.USER_FLOOD_CONTROL_OVERRIDE,USER_TEXT_EDITOR",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_newpost_run() {

	global $style_array, $html, $smarty, $userob, $user, $in, $myinfo, $ubbt_lang, $config, $forumvisit, $visit, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars


	// -------------------------
	// Predefine a few variables
	$Pselected = "";
	$choosename = "";
	$canattach = 0;

	// Get this user's last post time
	$query = "
		SELECT USER_LAST_POST_TIME
		FROM {$config['TABLE_PREFIX']}USER_DATA
		WHERE USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	list($user['USER_LAST_POST_TIME']) = $dbh->fetch_array($sth);


	$Username = $user['USER_DISPLAY_NAME'];

	// Flood control settings
	if ($user['USER_FLOOD_CONTROL_OVERRIDE'] == "-1") {
		$floodcontrol = $userob->check_access("forum", "POST_THROTTLE", $Board);
	} else {
		$floodcontrol = $user['USER_FLOOD_CONTROL_OVERRIDE'];
	}
	$lastposttime = $user['USER_LAST_POST_TIME'];

	// -----------------------------------------------
	// Let's get the flood control settings
	$name_choice = 0;
	if (!$userob->is_logged_in) {
		$floodcontrol = $userob->check_access("forum", "POST_THROTTLE", $Board);
		$lastposttime = get_input("lastposttime", "cookie");
		$name_choice = 1;
	}

	// Check if they can make a post yet
	if (($html->get_date() - $lastposttime) < $floodcontrol) {
		$html->not_right($html->substitute($ubbt_lang['FLOODCONTROL'], array('SO_OFTEN' => $floodcontrol)));
	}

	$TEXT_AREA_COLUMNS = $config['TEXT_AREA_COLUMNS'];
	$TEXT_AREA_ROWS = $config['TEXT_AREA_ROWS'];

	// ----------------------------------------------------------
	// Find out if they are supposed to be posting on this board
	if (!$userob->check_access("forum", "CREATE_TOPICS", $Board)) {
		$html->not_right($html->substitute($ubbt_lang['READ_PERM'], array('BASE_URL' => $config['BASE_URL'])));
	}

	// ------------------
	// Get the board info
	$query = "
		SELECT FORUM_TITLE, FORUM_CUSTOM_HEADER, FORUM_STYLE, FORUM_PARENT, CATEGORY_ID, FORUM_IS_RSS, FORUM_RSS_TITLE, FORUM_IS_GALLERY
		FROM {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);

	$news_array = preg_split("#,#", $config['PORTAL_NEWS_FORUMS']);

	$is_news = 0;
	$imagelist = array();
	if (in_array($Board, $news_array) || $userob->check_access("forum", "CREATE_NEWS", $Board)) {
		$is_news = 1;
		$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['news']}");
		while (($file = readdir($dir)) != false) {
			if (($file == ".") || ($file == "..") || ($file == "index.html") || (!preg_match("/(gif|jpg|png)$/", $file))) {
				continue;
			}
			$imagelist[] = $file;
		}
		sort($imagelist);
	}

	// ----------------
	// Assign the stuff
	list($Title, $fheader, $fstyle, $forum_parent, $category_id, $is_rss, $rss_title, $is_gallery) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	$guest_captcha = $userob->check_access("forum", "CAPTCHA", $Board);

	// -------------------------------------------------
	// Here we need to figure out what stylesheet to use
	if ($fstyle) {
		$html->set_style($fstyle);
	}

	if (isset(${$config['COOKIE_PREFIX'] . "ubbt_pass"})) {
		if (${$config['COOKIE_PREFIX'] . "ubbt_pass"} == "invalid") {
			if (!$config['ALLOW_UNDER_13']) {
				$html->not_right($html->substitute($ubbt_lang['UNDERAGE'], array('MINIMUM_AGE' => $config['MINIMUM_AGE'])));
			} else {
				$html->not_right($html->substitute($ubbt_lang['NO_COPPA'], array('COPPA_URL' => make_ubb_url("ubb=coppaform", "", true))));
			}
		}
	}

	// -------------------------------
	// Check if HTML is enabled or not
	if ($userob->check_access("forum", "USE_HTML", $Board)) {
		$htmlstatus = "{$ubbt_lang['YES_HTML']}";
	} else {
		$htmlstatus = "{$ubbt_lang['NO_HTML']}";
	}

	// --------------------------------------------
	// Markup is disabled, so we better let them know
	if ($userob->check_access("forum", "USE_MARKUP", $Board)) {
		$markupstatus = "{$ubbt_lang['YES_MARKUP']}";
	} else {
		$markupstatus = "{$ubbt_lang['NO_MARKUP']}";
	}

	// ----------------------------------------------------------------------
	// If The Guest group can post here then we set the Username to Anonymous
	// and we set the reged flag to "n";
	$Reged = '1';
	if (!$Username) {
		$postername = $ubbt_lang['ANON_TEXT'];
		$Reged = '0';
	} else {
		$postername = $Username;
	}
	$addtofav = "";
	$makepoll = "";
	$addevent = "";
	$selectday = "";
	$selectmonth = "";
	$selectyear = "";
	// ---------------------
	// Can they post a poll?
	if ($userob->check_access("forum", "POLLS_IN_TOPICS", $Board)) {
		$makepoll = 1;
	}

	if ($postername != $ubbt_lang['ANON_TEXT']) {
		$addtofav = "
		<input type=\"checkbox\" id=\"dofav\" name=\"dofav\" value=\"1\" checked=\"checked\" class=\"form-checkbox\" />
		<label for=\"dofav\">{$ubbt_lang['ADDTOFAV']}</label>
		";

		// ----------------------------------------------------
		// Can they add an event to the calendar for this post?
		if ($userob->check_access("site", "CALENDAR_EVENTS") && $config['CALENDAR']) {
			$addevent = "
			<input type=\"checkbox\" id=\"addevent\" name=\"addevent\" value=\"1\" class=\"form-checkbox\" />
			<label for=\"addevent\">{$ubbt_lang['ADDEVENT']}</label>
			<span class=\"nw\">
			<select name=\"calmonth\" class=\"form-select\">
			";
			$temp = getdate();
			$year = $temp["year"];
			$day = $temp["mday"];
			$month = $temp["mon"];
			for ($i = 1; $i <= 12; $i++) {
				$mname = "MONTH$i";
				$mname = $ubbt_lang[$mname];
				$selected = "";
				if ($month == $i) {
					$selected = "selected=\"selected\"";
				}
				$selectmonth .= "<option value=\"$i\" $selected>$mname</option>";
			}
			$selectmonth .= "</select>";

			$selectday = "<select name=\"calday\" class=\"form-select\">";
			for ($i = 1; $i <= 31; $i++) {
				$selected = "";
				if ($day == $i) {
					$selected = "selected=\"selected\"";
				}
				$selectday .= "<option $selected value=\"$i\">$i</option>";
			}
			$selectday .= "</select>";

			$selectyear = "<select name=\"calyear\" class=\"form-select\">";
			$temp = getdate();
			$thisyear = $temp["year"];
			for ($i = $thisyear; $i <= $thisyear + 10; $i++) {
				$selected = "";
				if ($year == $i) {
					$selected = "selected=\"selected\"";
				}
				$selectyear .= "<option $selected value=\"$i\">$i</option>";
			}
			$selectyear .= "</select>";
		}
	}

	$postname = "<b>$postername</b>";
	$postname .= "<input type=\"hidden\" name=\"postername\" value=\"$postername\" />";

	$iconselect = $html->icon_select();
	if ($is_gallery) $iconselect = "";

	// --------------------------------------
	// Can they make this post a sticky post?
	$stickyselect = "";
	if ($userob->check_access("forum", "STICKY_ANY", $Board)) {
		$stickyselect = "<input type=\"checkbox\" id=\"Sticky\" name=\"Sticky\" value=\"1\" class=\"form-checkbox\" /> <label for=\"Sticky\">{$ubbt_lang['STICKY']}</label>";

	}

	$announce = "";
	if ($userob->check_access("site", "ANNOUNCEMENTS")) {
		$announce = "<input type=\"checkbox\" id=\"announcement\" name=\"announcement\" value=\"1\" class=\"form-checkbox\" /> <label for=\"announcement\">{$ubbt_lang['ANNOUNCE']}</label>";
	}

	$canlock = false;
	if ($userob->check_access("forum", "LOCK_ANY", $Board)) {
		$canlock = true;
	}


	// -------------------------------------
	// What options do they have for posting
	$markupselect = "";
	if (($config['MARKUP_HTML_TOGGLE'] == 1) || ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") || (preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
		$markupselect .= "<select name=\"convert\" id=\"convert\" class=\"form-select\">";
		if ($userob->check_access("forum", "USE_MARKUP", $Board)) {
			$markupselect .= "<option value=\"markup\" selected=\"selected\">{$ubbt_lang['USE_MARKUP']}</option>";
		}
		if ($userob->check_access("forum", "USE_HTML", $Board)) {
			$markupselect .= "<option value=\"html\">{$ubbt_lang['USE_HTML']}</option>";
		}
		if (($userob->check_access("forum", "USE_HTML", $Board)) && ($userob->check_access("forum", "USE_MARKUP", $Board))) {
			$markupselect .= "<option value=\"both\">{$ubbt_lang['USE_BOTH']}</option>";
		}
		if ((!$userob->check_access("forum", "USE_HTML", $Board)) && (!$userob->check_access("forum", "USE_MARKUP", $Board))) {
			$markupselect .= "<option value=\"none\">{$ubbt_lang['USE_NONE']}</option>";
		}
		$markupselect .= "</select>";
	}

	// ------------------------------------
	// No options, we use the board default
	else {
		$markupselect = "";
	}

	if (($is_gallery || ($userob->check_access("forum", "FILE_TOTAL", $Board))) && ($Reged == "1") && (ini_get('file_uploads'))) {
		$canattach = 1;
	}

	// -----------
	// Sig option?
	$addsig = "";
	if ($Reged == "1") {
		$addsig = "<input type=\"checkbox\" name=\"addsig\" id=\"addsig\" value=\"1\" checked=\"checked\" class=\"form-checkbox\" /> <label for=\"addsig\">{$ubbt_lang['ADDSIG']}</label>";
	}

	$text_editor = $html->create_text_editor("Body", "", 2, !$is_gallery);

	// Create an md5 for polls and files
	$md5_stamp = md5($user['USER_DISPLAY_NAME'] . time());

	// GALLERY SPECIFIC SETTINGS

	$header = $ubbt_lang['MAKENEW_HEAD'];
	if ($is_gallery) {
		$header = $ubbt_lang['MAKENEW_IMAGE'];
		$ubbt_lang['POST_TEXT'] = $ubbt_lang['POST_DESCRIPTION'];
		$makepoll = "";
		$stickyselect = "";
		$addevent = "";
		$announce = "";
//		$addsig = "";
		$canlock = "";
	}

	$smarty_data = array(
		"md5_stamp" => $md5_stamp,
		"Title" => $Title,
		"htmlstatus" => $htmlstatus,
		"markupstatus" => $markupstatus,
		"choosename" => $choosename,
		"postname" => $postname,
		"Reged" => $Reged,
		"what" => $what,
		"iconselect" => & $iconselect,
		"markupselect" => & $markupselect,
		"TEXT_AREA_COLUMNS" => $TEXT_AREA_COLUMNS,
		"TEXT_AREA_ROWS" => $TEXT_AREA_ROWS,
		"text_editor" => & $text_editor,
		"stickyselect" => $stickyselect,
		"announce" => $announce,
		"addevent" => $addevent,
		"selectmonth" => $selectmonth,
		"selectday" => $selectday,
		"selectyear" => $selectyear,
		"makepoll" => $makepoll,
		"addtofav" => $addtofav,
		"addsig" => $addsig,
		"canattach" => $canattach,
		"Board" => $Board,
		"is_news" => $is_news,
		"imagelist" => $imagelist,
		"guest_captcha" => $guest_captcha,
		"name_choice" => $name_choice,
		"is_gallery" => $is_gallery,
		"canlock" => $canlock,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $header,
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $category_id,
			"parent_forum" => $forum_parent,
			"custom_header_footer" => $fheader,
			"bypass" => 0,
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"onload" => "document.replier.Subject.focus()",
			"onunload" => "clearSubmit()",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
			"javascript" => array(
				0 => "standard_text_editor.js",
				1 => "image.js",
			),
		),
		"template" => "newpost",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>