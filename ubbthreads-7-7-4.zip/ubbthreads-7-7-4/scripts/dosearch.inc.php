<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.3
  Purpose:
  Future:
*/

function page_dosearch_gpc() {
	return array(
		"input" => array(
			"Words" => array("Words", "both", ""),
			"Searchpage" => array("Searchpage", "both", "int"),
			"Limit" => array("Limit", "both", "int"),
			"fromsearch" => array("fromsearch", "both", "int"),
			"fromprof" => array("fromprof", "both", "int"),
			"where" => array("where", "both", "alpha"),
			"Name" => array("Name", "both", ""),
			"daterange" => array("daterange", "both", "int"),
			"newerval" => array("newerval", "both", "int"),
			"newertype" => array("newertype", "both", "alpha"),
			"olderval" => array("olderval", "both", "int"),
			"oldertype" => array("oldertype", "both", "alpha"),
			"bodyprev" => array("bodyprev", "both", "int"),
			"checkwords" => array("checkwords", "post", "int"),
			"textsearch" => array("textsearch", "post", ""),
			"myposts" => array("myposts", "both", "int"),
		),
		"wordlets" => array("dosearch"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_dosearch_run() {

	global $tree, $style_array, $userob, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS);

	// Don't even bother with abusers and fail silently to save server resources
	if ((strlen($Words) > 100) || (strlen($Name) > 50)) exit;

	if ($textsearch == $ubbt_lang['ADVANCED_BUTTON']) {
		header("Location: " . make_ubb_url("ubb=search", "", true));
		exit;
	}

	// Clear out any favorites data from the session
	// we don't want to get sent back to the favorites
	// screen when navigating from here
	$_SESSION['favorites'] = array();

	if ($myposts) {
		$Name = $user['USER_DISPLAY_NAME'];
	}

	// Get some user data
	$query = "
		select	USER_LAST_SEARCH_TIME,SEARCH_SESSION_ID,USER_LAST_VISIT_TIME
		from	{$config['TABLE_PREFIX']}USER_DATA
		where	USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	list($user['USER_LAST_SEARCH_TIME'], $user['SEARCH_SESSION_ID'], $user['USER_LAST_VISIT_TIME']) = $dbh->fetch_array($sth);

	// Default word length
	if (!isset($config['MIN_SEARCH_LENGTH'])) {
		$config['MIN_SEARCH_LENGTH'] = 3;
	}

	$throttle = $userob->check_access("site", "SEARCH_THROTTLE");

	// Default to 200, if not configured at "Control Panel > Feature Settings"
	if (!isset($config['MAX_SEARCH_RESULTS']) || !$config['MAX_SEARCH_RESULTS']) {
		$config['MAX_SEARCH_RESULTS'] = '200';
	}

	// ---------------------------------------------------------
	// The forums we are searching will be in a different format
	// depending on where we are coming from
	if (@is_array($_POST['Forum'])) {
		$Forum = join(",", $_POST['Forum']);
	} elseif (@is_array($_GET['Forum'])) {
		$Forum = join(",", $_GET['Forum']);
	} elseif (isset($_POST['Forum'])) {
		$Forum = ",{$_POST['Forum']},";
	} elseif (isset($_GET['Forum'])) {
		$Forum = ",{$_GET['Forum']},";
	} else {
		$Forum = "";
	}

	// ------------------------
	// Predefine some variables
	$which = "";
	$catonly = "";
	$toffset = $config['SERVER_TIME_OFFSET'];
	$excluded = "";

	// -----------------
	// Get the user info
	$Username = $user['USER_DISPLAY_NAME'];
	$user['USER_TIME_OFFSET'] && $toffset = $user['USER_TIME_OFFSET'];
	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];

	if (!$newerval) {
		$newerval = 1;
	}

	if (!isset($config['MAX_SEARCH_RANGE_TYPE']) || !$config['MAX_SEARCH_RANGE_TYPE']) {
		$config['MAX_SEARCH_RANGE_TYPE'] = "years";
	}
	if (!isset($config['MAX_SEARCH_RANGE_VALUE']) || !$config['MAX_SEARCH_RANGE_VALUE']) {
		$config['MAX_SEARCH_RANGE_VALUE'] = 1;
	}

	// Make sure the daterange is valid if this is a new search
	if ($fromsearch) {
		$rangeseconds = 0;
		if (!$newerval && !$olderval) {
			$newerval = $config['MAX_SEARCH_RANGE_VALUE'];
			if ($config['MAX_SEARCH_RANGE_TYPE'] == "days") {
				$newertype = "d";
			} else if ($config['MAX_SEARCH_RANGE_TYPE'] == "weeks") {
				$newertype = "w";
			} else if ($config['MAX_SEARCH_RANGE_TYPE'] == "months") {
				$newertype = "m";
			} else if ($config['MAX_SEARCH_RANGE_TYPE'] == "years") {
				$newertype = "y";
			}
		}
		if ($config['MAX_SEARCH_RANGE_TYPE'] == "days") {
			$rangeseconds = $config['MAX_SEARCH_RANGE_VALUE'] * 86400;
		}
		if ($config['MAX_SEARCH_RANGE_TYPE'] == "weeks") {
			$rangeseconds = ($config['MAX_SEARCH_RANGE_VALUE'] * 7) * 86400;
		}
		if ($config['MAX_SEARCH_RANGE_TYPE'] == "months") {
			$rangeseconds = ($config['MAX_SEARCH_RANGE_VALUE'] * 31) * 86400;
		}
		if ($config['MAX_SEARCH_RANGE_TYPE'] == "years") {
			$rangeseconds = ($config['MAX_SEARCH_RANGE_VALUE'] * 365) * 86400;
		}
		$newer = "";
		if ($newerval && $newertype) {
			if ($newertype == "d") {
				$newer = $newerval * 86400;
			}
			if ($newertype == "w") {
				$newer = ($newerval * 7) * 86400;
			}
			if ($newertype == "m") {
				$newer = ($newerval * 31) * 86400;
			}
			if ($newertype == "y") {
				$newer = ($newerval * 365) * 86400;
			}
		}
		$older = "";
		if ($olderval && $oldertype) {
			if ($oldertype == "d") {
				$older = $olderval * 86400;
			}
			if ($oldertype == "w") {
				$older = ($olderval * 7) * 86400;
			}
			if ($oldertype == "m") {
				$older = ($olderval * 31) * 86400;
			}
			if ($oldertype == "y") {
				$older = ($olderval * 365) * 86400;
			}
		}
		$invalidrange = 0;
		if ($newer && !$older) {
			if ($newer > $rangeseconds) {
				$invalidrange = 1;
			}
		}
		if ($newer && $older) {
			if (($newer - $older) > $rangeseconds) {
				$invalidrange = 1;
			}
		}
		$resetnewer = "";
		if ($older && !$newer) {
			$resetnewer = $older + $rangeseconds;
		}
		if ($invalidrange) {
			if ($config['MAX_SEARCH_RANGE_VALUE'] == 1) {
				$config['MAX_SEARCH_RANGE_TYPE'] = preg_replace("/s$/", "", $config['MAX_SEARCH_RANGE_TYPE']);
			}
			$html->not_right($html->substitute($ubbt_lang['MAX_RANGE'], array(
				'SEARCH_VALUE' => $config['MAX_SEARCH_RANGE_VALUE'],
				'SEARCH_TYPE' => $config['MAX_SEARCH_RANGE_TYPE'])));
		}
	}

	$lastsearch = 0;

	if (!$userob->check_access("site", "CAN_SEARCH")) {
		$html->not_right($ubbt_lang['NO_SEARCH']);
	}

	if (!$userob->is_logged_in) {
		$lastsearch = get_input("lastsearch", "cookie");
	}

	$mode = $user['USER_TOPIC_VIEW_TYPE'];
	if (!$mode) {
		$mode = $config['TOPIC_DISPLAY_STYLE'];
	}
	$linker = "show$mode";

	// -----------------
	// 50 vs 25, READ THIS -- https://www.ubbcentral.com/forums/ubbthreads.php/ubb/showflat/Number/29074 --
	if (!$Limit) {
		$Limit = 50;
	}
	if ($Limit > 99) {
		$Limit = '99';
	}

	if (!$Searchpage) {
		$Searchpage = 1;
	}

	// Searchkey is saved in a cookie for guests
	if ($user['SEARCH_SESSION_ID']) {
		$oldkey = $user['SEARCH_SESSION_ID'];
	} else {
		$oldkey = get_input("searchkey", "cookie");
	}

	// If this is a new search, execute this
	if ($fromsearch) {

		// Generate a search session key
		$rightnow = time();
		list($usec, $sec) = explode(' ', microtime());
		srand((float)$sec + ((float)$usec * 100000));
		$random = rand();
		$session = md5("$rightnow$random");

		// Can they make another search yet?
		// Admins and moderators can bypass this setting

		$diff = $rightnow - $lastsearch;
		if ($diff < $throttle) {
			$html->not_right($ubbt_lang['TIMELIMIT']);
		}

		// Update their last search time
		if ($userob->is_logged_in) {
			$query_vars = array($rightnow, $session, $user['USER_ID']);
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USER_DATA
				SET USER_LAST_SEARCH_TIME= ? ,
				SEARCH_SESSION_ID= ?
				WHERE USER_ID = ?
			";
			$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
		} else {
			$html->ubbt_setcookie("lastsearch", $rightnow);
			$html->ubbt_setcookie("searchkey", $session);
		}

		// Delete the old search results or any older than a day
		$timestamp = $rightnow - 86400;
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}SEARCH_RESULTS
			WHERE SEARCH_SESSION_ID = ?
			OR SEARCH_TIMESTAMP < ?
		";
		$dbh->do_placeholder_query($query, array($oldkey, $timestamp), __LINE__, __FILE__);

// ---------------------------------------------------------
// Avoid some common boolean search errors
		if ($Words) {
			$Words = str_replace(array("---", "--"), "-", $Words);
			$Words = str_replace(array("+++", "++"), "+", $Words);
		}

		// ------------------------------------------------------
		// Escape any % signs as these are special SQL characters
		$printwords = ubbchars($Words);

		// ---------------------------
		// URL Encode the Search stuff
		$URLWords = rawurlencode($Words);

		// ----------------------------------------------------------------
		// Calculate the timestamp we are going to be using as our baseline
		$newertime = "";
		$oldertime = "";
		if ($daterange) {
			if (($newerval && $newertype) || $resetnewer) {
				$days = 0;
				if ($newertype == "d") {
					$days = $newerval;
				}
				if ($newertype == "w") {
					$days = $newerval * 7;
				}
				if ($newertype == "m") {
					$days = $newerval * 31;
				}
				if ($newertype == "y") {
					$days = $newerval * 365;
				}
				$time = $html->get_date();
				$time = $time - ($days * 86400);
				if ($resetnewer) {
					$time = $time - $resetnewer;
				}
				$newertime = "AND p.POST_POSTED_TIME > '$time'";
			}
			if ($olderval && $oldertype) {
				$days = 0;
				if ($oldertype == "d") {
					$days = $olderval;
				}
				if ($oldertype == "w") {
					$days = $olderval * 7;
				}
				if ($oldertype == "m") {
					$days = $olderval * 31;
				}
				if ($oldertype == "y") {
					$days = $olderval * 365;
				}
				$time = $html->get_date();
				$time = $time - ($days * 86400);

				$oldertime = "AND p.POST_POSTED_TIME < '$time'";
			}
		}

		// -------------------------------------------------------------------------
		// If we are searching for all posts by a user we need to know their usernumber
		$usersearch = "";
		$user_name_search = "";
		if ($Name) {
			$query = "
				SELECT USER_DISPLAY_NAME,USER_ID
				FROM  {$config['TABLE_PREFIX']}USERS
				WHERE USER_DISPLAY_NAME = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($Name), __LINE__, __FILE__);
			list($printname, $Name) = $dbh->fetch_array($sth);
			$printwords .= " $printname";
			$usersearch = "AND p.USER_ID = '$Name'";
			$user_name_search = $printname;
		}

		// ------------------------------------------------------
		// Now we need to figure out what forums we are searching
		$catin = "";
		$boardin = "";
		$allforums = "";
		$forumlist = "";
		$Forum = preg_split("#,#", $Forum);
		for ($i = 0; $i < sizeof($Forum); $i++) {
			$forumlist .= "$Forum[$i],";
			if ($Forum[$i] == "All_Forums") {
				$allforums = "1";
			}
			if (preg_match("/^c/", $Forum[$i])) {
				$cnum = str_replace("c", "", $Forum[$i]);
				if (!is_numeric($cnum)) continue;
				$catin .= "'$cnum',";
			}
			if (preg_match("/^f/", $Forum[$i])) {
				$bnum = str_replace("f", "", $Forum[$i]);
				if (!is_numeric($bnum)) continue;
				$boardin .= "'$bnum',";
				if (isset($tree['tree'])) {
					foreach ($tree['tree'] as $fid => $kids) {
						if (in_array($bnum, $kids) && !preg_match("/'$fid'/", $boardin)) {
							$boardin .= "'$fid',";
						}
					}
				}
			}
		}
		$catin = preg_replace("/,$/", "", $catin);
		$boardin = preg_replace("/,$/", "", $boardin);
		$forumlist = preg_replace("/,$/", "", $forumlist);
		if ($catin) {
			$catin = "CATEGORY_ID IN ($catin)";
			if ($boardin) {
				$catin .= " OR ";
			}
		}
		if ($boardin) {
			$boardin = "FORUM_ID IN ($boardin)";
		}
		if (!$catin && !$boardin) {
			$catin = "1";
		}

		// Regular query  here, since all query vars come from within the script
		$query = "
			SELECT FORUM_ID,FORUM_TITLE,CATEGORY_ID,FORUM_IS_ACTIVE
			FROM {$config['TABLE_PREFIX']}FORUMS
			WHERE FORUM_IS_ACTIVE = '1'
			AND ($catin $boardin)
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$boardin = "";

		while (list($key, $btitle, $bcat, $bo_active) = $dbh->fetch_array($sth)) {
			if (!$userob->check_access("forum", "SEE_FORUM", $key)) {
				continue;
			}
			$boardarray[$key]['title'] = $btitle;
			$boardarray[$key]['cat'] = $bcat;
			$key = addslashes($key);
			if ($bo_active) {
				$boardin .= "'$key',";
			}
		}
		$boardin = preg_replace("/,$/", "", $boardin);


		// Make sure they are searching for something
		if (!$Words && !$Name) {
			if (!$excluded) {
				$html->not_right($ubbt_lang['NO_WORDS']);
			} else {
				$html->not_right($ubbt_lang['SHORT']);
			}
		}

		// Formulate search
		if ($config['SEARCH_METHOD'] == "ubb") {
			preg_match_all("/(\")(.*?)(\")/is", $Words, $matches);
			for ($i = 0; $i < count($matches['0']); $i++) {
				$newphrase[$i] = preg_replace("/ +/", "_UBBT_PHRASE_", $matches[0][$i]);
				$Words = str_replace($matches[0][$i], $newphrase[$i], $Words);
			}
			$Words = str_replace('"', "", $Words);
			$keyarray = preg_split("/ +/", $Words);
			$andquery = "";
			$notquery = "";
			$orquery = "";
			$andconcat = "";
			$notconcat = "";
			$orconcat = "";
			for ($i = 0; $i < sizeof($keyarray); $i++) {
				$keyarray[$i] = trim($keyarray[$i]);
				if (!$keyarray[$i]) {
					continue;
				}
				// Exclude words that are too short.
				if (strlen($keyarray[$i]) < $config['MIN_SEARCH_LENGTH']) {
					$excluded .= " {$keyarray[$i]},";
					$Words = preg_quote($Words);
					$Words = @preg_replace("/\b$keyarray[$i]\b/", "", $Words);
					$printwords = ubbchars($Words);
				}
				if (preg_match("/^\+/", $keyarray[$i])) {
					$keyarray[$i] = preg_replace("/^\+/", "", $keyarray[$i]);
					$keyarray[$i] = str_replace("_UBBT_PHRASE_", " ", $keyarray[$i]);
					$word = addslashes($keyarray[$i]);
					if ($andquery) {
						$andconcat = " AND ";
					}
					if ($where == "sub") {
						$andquery .= "$andconcat (LOWER(p.POST_SUBJECT) LIKE LOWER('%$word%') AND p.POST_IS_TOPIC = '1')";
					}
					if ($where == "body") {
						$andquery .= "$andconcat (LOWER(p.POST_DEFAULT_BODY) LIKE LOWER('%$word%'))";
					}
					if ($where == "bodysub") {
						$andquery .= "$andconcat (LOWER(p.POST_SUBJECT) LIKE LOWER('%$word%') OR LOWER(p.POST_DEFAULT_BODY) LIKE LOWER('%$word%'))";
					}
				} elseif (preg_match("/^-/", $keyarray[$i])) {
					$keyarray[$i] = preg_replace("/^-/", "", $keyarray[$i]);
					$keyarray[$i] = str_replace("_UBBT_PHRASE_", " ", $keyarray[$i]);
					$word = addslashes($keyarray[$i]);
					if ($notquery) {
						$notconcat = " AND ";
					}
					if ($where == "sub") {
						$notquery .= "$notconcat (LOWER(p.POST_SUBJECT) NOT LIKE LOWER('%$word%'))";
					}
					if ($where == "body") {
						$andquery .= "$andconcat (LOWER(p.POST_DEFAULT_BODY) LIKE LOWER('%$word%'))";
					}
					if ($where == "bodysub") {
						$notquery .= "$notconcat (LOWER(p.POST_SUBJECT) NOT LIKE LOWER('%$word%') AND LOWER(p.POST_DEFAULT_BODY) NOT LIKE LOWER('%$word%'))";
					}
				} else {
					$keyarray[$i] = str_replace("_UBBT_PHRASE_", " ", $keyarray[$i]);
					$word = addslashes($keyarray[$i]);
					if ($orquery) {
						$orconcat = " OR ";
					}
					if ($where == "sub") {
						$orquery .= "$orconcat (LOWER(p.POST_SUBJECT) LIKE LOWER('%$word%') AND p.POST_IS_TOPIC = '1')";
					}
					if ($where == "body") {
						$andquery .= "$andconcat (LOWER(p.POST_DEFAULT_BODY) LIKE LOWER('%$word%'))";
					}
					if ($where == "bodysub") {
						$orquery .= "$orconcat (LOWER(p.POST_SUBJECT) LIKE LOWER('%$word%') OR LOWER(p.POST_DEFAULT_BODY) LIKE LOWER('%$word%'))";
					}
				}
			}
			$match_terms = "";
			if ($andquery) {
				$match_terms .= " AND ($andquery)";
				$orextra = " (1) OR ";
			}
			if ($notquery) {
				$match_terms .= " AND ($notquery)";
				$orextra = " (1) OR ";
			}
			if ($orquery) {
				$match_terms .= " AND ( $orextra $orquery) ";
			}
		} else {
			$match_terms = "";
			$words_escaped = addslashes($Words);
			if ($where == "sub") {
				$match_terms = "AND MATCH p.POST_SUBJECT AGAINST ('$words_escaped' IN BOOLEAN MODE) AND p.POST_IS_TOPIC = '1'";
			} elseif ($where == "body") {
				$match_terms = "AND MATCH p.{$config['FULL_TEXT']} AGAINST ('$words_escaped' IN BOOLEAN MODE)";
			} else {
				$match_terms = "AND MATCH (p.POST_SUBJECT, p.{$config['FULL_TEXT']}) AGAINST ('$words_escaped' IN BOOLEAN MODE)";
			}
		}

		if ($Name && $Words == "") {
			$match_terms = "";
		}


		// Another regular do_query, all values defined in script
		//		Note: we add a self join on the POST_ID column to pull in the index for the where clause
		$query = "
		SELECT p.POST_ID
		FROM 	{$config['TABLE_PREFIX']}POSTS p LEFT JOIN {$config['TABLE_PREFIX']}POSTS pp on p.POST_ID=pp.POST_ID,
					{$config['TABLE_PREFIX']}TOPICS t
		WHERE p.POST_IS_APPROVED = '1'
			AND t.TOPIC_STATUS <> 'M'
			AND t.FORUM_ID IN ($boardin)
			AND p.TOPIC_ID = t.TOPIC_ID
		$match_terms
		$usersearch
		$newertime
		$oldertime
		";
		$query = $query . "\nORDER BY p.POST_POSTED_TIME DESC\nLIMIT {$config['MAX_SEARCH_RESULTS']}";

		// Setup a string to hold the excluded words, if there are any
		$excluded = preg_replace("/(\s,|,)$/", "", $excluded);        // Hmmm... never gets set

		// ------------------------------------------------------------------
		// Now execute the query if we actually have some words to search for
		if ($excluded && !$Words) {
			$sth = array();
			$rows = 0;
		} elseif (!$boardin) {
			$sth = array();
			$rows = 0;
		} else {
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$rows = $dbh->total_rows($sth);
		}

		// If no rows, give them an error
		if (!$rows) {
			$html->not_right($ubbt_lang['NO_MATCH']);
		} else {
			$results = array();
			while (list($result) = $dbh->fetch_array($sth)) {
				$results[] = $result;
			}
			$results_q = addslashes(serialize($results));
			if (!$Words) {
				$Words = $user_name_search;
			}
			if (!$bodyprev) {
				$bodyprev = 0;
			}
			$sresults = serialize($results);
			$query_vars = array($session, $Words, $excluded, $sresults, $rightnow, $bodyprev, $Limit);
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}SEARCH_RESULTS
				(SEARCH_SESSION_ID,SEARCH_WORDS,SEARCH_EXCLUDED_WORDS,SEARCH_RESULTS,SEARCH_TIMESTAMP,SEARCH_PREVIEW_BODY,SEARCH_SQL_LIMIT)
				VALUES
				( ? , ? , ? , ? , ? , ? , ? )
			";
			$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
		}
	} // Otherwise we are retrieving a stored search result set
	else {
		$query = "
			SELECT SEARCH_WORDS,SEARCH_EXCLUDED_WORDS,SEARCH_RESULTS,SEARCH_PREVIEW_BODY,SEARCH_SQL_LIMIT
			FROM {$config['TABLE_PREFIX']}SEARCH_RESULTS
			WHERE SEARCH_SESSION_ID= ?
		";
		$sth = $dbh->do_placeholder_query($query, array($oldkey), __LINE__, __FILE__);
		list($Words, $excluded, $results, $bodyprev, $Limit) = $dbh->fetch_array($sth);
		$results = unserialize($results);
		$printwords = ubbchars($Words);

		$query = "
			SELECT FORUM_ID,FORUM_TITLE,CATEGORY_ID,FORUM_IS_ACTIVE
			FROM {$config['TABLE_PREFIX']}FORUMS
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$boardin = "";
		while (list($key, $btitle, $bcat, $bo_active) = $dbh->fetch_array($sth)) {
			$boardarray[$key]['title'] = $btitle;
			$boardarray[$key]['cat'] = $bcat;
		}
	}

	if ($excluded) {
		$excluded = "Muhaha ({$ubbt_lang['EXCLUDED']} $excluded)";
	}

	$color = "alt-1";

	$resultsize = 0;

	// Format a string that contains what result set we are showing
	if ($Searchpage > 1) {
		$s = (($Searchpage - 1) * $Limit) + 1;
		$e = ($s + $Limit) - 1;
	} else {
		$s = 1;
		$e = ($s + $Limit) - 1;
	}

	if ($e > sizeof($results)) {
		$e = sizeof($results);
	}

	$totalresults = count($results);

	if (sizeof($results)) {
		$TotalP = ceil($totalresults / $Limit);
	} else {
		$TotalP = 0;
	}
	if (!$topic) $topic = 0;
	$pages1 = $html->paginate($Searchpage, $TotalP, "dosearch&topic=$topic&Searchpage=");
	$pages2 = preg_replace('#pagination_\d+#', '', $pages1);
	// Build our inlist for our result set we're displaying
	$startkey = $s - 1;
	$endkey = $e - 1;
	$inlist = "";
	for ($i = 0; $i <= sizeof($results); $i++) {
		if ($i < $startkey) {
			continue;
		}
		if ($i > $endkey) {
			break;
		}
		$inlist .= "'$results[$i]',";
	}

	// Do the query to actually grab the info we need now
	$inlist = preg_replace("/,$/", "", $inlist);

	if (!$inlist) {
		$html->not_right($ubbt_lang['NO_SEARCH']);
	}
	// What order do we sort by
	$sortorder = "ORDER BY p.POST_ID DESC";
	if ($topic) {
		$sortorder = "ORDER BY t.TOPIC_LAST_REPLY_TIME DESC";
	}

	// Regular query here, $inlist comes directly from the script
	$query = "
		SELECT p.POST_ID,p.TOPIC_ID,u.USER_DISPLAY_NAME,u.USER_MEMBERSHIP_LEVEL,p.POST_SUBJECT,
					 p.POST_POSTED_TIME,t.FORUM_ID,up.USER_NAME_COLOR,p.POST_ICON,p.USER_ID,
					 t.TOPIC_STATUS,p.POST_BODY,t.TOPIC_LAST_POST_ID,t.TOPIC_LAST_REPLY_TIME,p.USER_ID,p.POST_IS_TOPIC
		FROM {$config['TABLE_PREFIX']}POSTS p,
				 {$config['TABLE_PREFIX']}USERS u,
				 {$config['TABLE_PREFIX']}TOPICS t,
				 {$config['TABLE_PREFIX']}USER_PROFILE up
		WHERE p.POST_ID IN ($inlist)
			AND p.USER_ID = u.USER_ID
			AND p.TOPIC_ID = t.TOPIC_ID
			AND p.USER_ID = up.USER_ID
		$sortorder
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);

	$headerwords = preg_replace("/</", "&lt;", $printwords);
	if ($topic) {
		$headerwords = $ubbt_lang['ACTIVE_' . $topic];
	}

	$i = 0;
	$linkwords = urlencode($printwords);
	while (list ($Number, $Main, $Username, $UserStatus, $Subject, $Posted, $ThisForum, $Color, $Icon, $posterid, $Open, $Body, $lastpostnum, $Last_Post, $poster_id, $IsTopic) = $dbh->fetch_array($sth)) {

		// ----------------------------------------------------------------------
		// We need to check and see if they have privileges for this forum.
		if (!$userob->check_access("forum", "SEE_FORUM", $ThisForum)) {
			continue;
		}

		if (!$Icon) {
			$Icon = "blank.gif";
		}
		$SearchURLForum = rawurlencode($ThisForum);
		$searchrow[$i]['Forum'] = $SearchURLForum;
		$searchrow[$i]['Icon'] = $Icon;
		$searchrow[$i]['Number'] = $Number;
		$searchrow[$i]['Main'] = $Main;
		$searchrow[$i]['goto'] = "";
		$searchrow[$i]['gotolast'] = "";
		$PostedTime = $html->convert_time($Posted, $toffset, $user['USER_TIME_FORMAT']);
		$LastPostTime = $html->convert_time($Last_Post, $toffset, $user['USER_TIME_FORMAT']);

		$searchrow[$i]['Subject'] = $Subject;
		$searchrow[$i]['Title'] = $boardarray[$ThisForum]['title'];

		$PUsername = $html->user_color($Username, $Color, $UserStatus);

		if ($poster_id != "1") {
			$Userlink = "<a href=\"" . make_ubb_url("ubb=showprofile&User=$posterid", $Username, false) . "\">$PUsername</a>";
		} else {
			$Userlink = "{$ubbt_lang['ANON_TEXT']}";
		}
		$searchrow[$i]['Userlink'] = $Userlink;
		$searchrow[$i]['Posted'] = $PostedTime;

		$searchrow[$i]['Body'] = "";
		$searchrow[$i]['Tooltip'] = "";
		if ($bodyprev) {
			$Body = strip_tags($Body, "<div>");
			$Body = preg_replace("/<(.*?)\/>/", "", $Body);
			$Body = preg_replace("/\[.*?]/", "", $Body);
			$Body = substr($Body, 0, 800) . " ...";
			$Highlight = str_replace("+", "", $Words);
			$Body = str_replace($Highlight, "<span class=\"search_highlight\">" . $Highlight . "</span>", $Body);
			$searchrow[$i]['Body'] = "<tr><td colspan=\"5\" class=\"topicsubject alvm\" style=\"padding:4px 10px 40px;\">$Body</td></tr>";
		} elseif ($config['TOOLTIP_LENGTH'] && $config['TOOLTIP_LENGTH'] > 0) {
			$Body = str_replace("]", "&rbr;", str_replace("[", "&lbr;", $Body));
			$Body = str_replace("<<GRAEMLIN_URL>>", "{$config['BASE_URL']}/images/{$style_array['graemlins']}", $Body);
			$Body = ubbchars($html->truncate($Body, $config['TOOLTIP_LENGTH']));
			$searchrow[$i]['Tooltip'] = "title=\"header=[{$ubbt_lang['TOOLTIP_HEADER']}] body=[{$Body}]\"";
		}

		// -------------------
		// alternate the colors
		$searchrow[$i]['color'] = $color;
		$color = $html->switch_colors($color);
		$i++;
	}
	$resultsize = 0;
	if (isset($searchrow)) {
		$resultsize = sizeof($searchrow);
	}
	if ($myposts) $linkwords = "";
	$linkwords = preg_replace("#/#", "", $Words);
	$linkwords = urlencode($linkwords);

	$headerwords = trim(preg_replace('/\s+/', ' ', $headerwords));

	$smarty_data = array(
		"headerwords" => $headerwords,
		"excluded" => $excluded,
		"searchrow" => $searchrow,
		"linker" => $linker,
		"Searchpage" => $Searchpage,
		"linkwords" => $linkwords,
		"topic" => $topic,
		"pages1" => $pages1,
		"pages2" => $pages2,
		"totalresults" => $html->substitute($ubbt_lang['TOTAL_SEARCH_RESULTS'], array(
			'SEARCH_TERMS' => $headerwords,
			'SEARCH_TOTAL' => $totalresults)),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$terms = $html->substitute($ubbt_lang['SEARCH_RES'], array('SEARCH_TERMS' => $headerwords));

	return array(
		"header" => array(
			"title" => $terms,
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"javascript" => ($config['TOOLTIP_LENGTH'] && $config['TOOLTIP_LENGTH'] > 0) ? array('boxover.js') : array(),
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> $terms
BREADCRUMB
		,
		),
		"template" => "dosearch",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>