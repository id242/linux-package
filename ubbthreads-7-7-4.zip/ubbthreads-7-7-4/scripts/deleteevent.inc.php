<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_deleteevent_gpc() {
	return array(
		"input" => array(
			"entry" => array("entry", "post", "int"),
			"month" => array("month", "post", "int"),
			"year" => array("year", "post", "int"),
		),
		"wordlets" => array("deleteevent"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_deleteevent_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	$query = "
	SELECT USER_ID
	FROM    {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	WHERE  CALENDAR_EVENT_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($entry), __LINE__, __FILE__);
	list ($owner) = $dbh->fetch_array($sth);

	if ($owner != $user['USER_ID'] && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
		$html->not_right("{$ubbt_lang['NO_EDIT']}");
	}

	// ------------------
	// Delete this event
	$query = "
	DELETE FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	WHERE CALENDAR_EVENT_ID = ?
	";
	$dbh->do_placeholder_query($query, array($entry), __LINE__, __FILE__);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "calendar&month=$month&year=$year",
			"heading" => $ubbt_lang['HEAD'],
			"body" => $ubbt_lang['BODY'],
			"returnlink" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['HEAD']}
BREADCRUMB
		,
		)
	);
}

?>