<?php defined("INCLUDE_TAB") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

$topics = array();

// No filtering for topics
$smarty->assign("filter_links", "");

// Grab this user's favorite topics
$query = "
	select	WATCH_ID
	from 	{$config['TABLE_PREFIX']}WATCH_LISTS
	where	USER_ID = ?
	and	WATCH_TYPE = 't'
";
$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);

$in_list = array();
$total_topics = 0;
while (list($fid) = $dbh->fetch_array($sth)) {
	$total_topics++;
	$in_list[] = $fid;
}


if (!sizeof($in_list)) {
	// We have no favorite topics
	$smarty->assign('display_no_favs', 1);
	$smarty->assign('no_favs', $ubbt_lang['NO_FAV_TOPICS']);

} else {

	// We have favorite topics, display in list mode
	$smarty->assign('display_no_favs', 0);
	$smarty->assign('favorite_users', 0);

	// We need to paginate this
	if (!$page || $page < 1) $page = 1;
	$PostsPer = array_get($user, 'USER_TOPICS_PER_PAGE', $config['TOPICS_PER_PAGE']);

	$total_pages = ceil($total_topics / $PostsPer);
	$pages1 = $html->paginate($page, $total_pages, "myhome&tab=$tab&sort=$sort&filter=$filter&page=");
	$pages2 = preg_replace('#pagination_\d+#', '', $pages1);
	$smarty->assignByRef("pages1", $pages1);
	$smarty->assignByRef("pages2", $pages2);

	if ($page == 1) {
		$limit_clause = "limit $PostsPer";
	} else {
		$limit_clause = "limit " . ($page - 1) * $PostsPer . "," . $PostsPer;
	}

	// We need the icon, subject, author and time posted
	$query = "
		SELECT t.TOPIC_ID,t.POST_ID,t.USER_ID,t.TOPIC_SUBJECT,t.TOPIC_ICON,t.TOPIC_CREATED_TIME,
					 u.USER_DISPLAY_NAME,t.TOPIC_LAST_REPLY_TIME,t.FORUM_ID,f.FORUM_TITLE,u.USER_MEMBERSHIP_LEVEL,
					 up.USER_NAME_COLOR
		FROM {$config['TABLE_PREFIX']}TOPICS t,
				 {$config['TABLE_PREFIX']}USERS u,
				 {$config['TABLE_PREFIX']}FORUMS f,
				 {$config['TABLE_PREFIX']}USER_PROFILE up
		WHERE	TOPIC_IS_APPROVED = '1'
			AND	t.USER_ID = u.USER_ID
			AND	f.FORUM_ID = t.FORUM_ID
			AND u.USER_ID = up.USER_ID
			AND	t.TOPIC_ID IN ( ? )
		ORDER BY $field_sort
		$limit_clause
	";
	$sth = $dbh->do_placeholder_query($query, array($in_list), __LINE__, __FILE__);
	$topic_key = 0;
	while (list($topic_id, $post_id, $user_id, $topic_subject, $topic_icon, $topic_created, $display_name, $last_reply, $forum_id, $forum_title, $level, $color) = $dbh->fetch_array($sth)) {
		$gonew = "";
		$folder = "nonewfolder.gif";
		if (isset($_SESSION['forumvisit']['visit'][$forum_id]) && $last_reply > $_SESSION['forumvisit']['visit'][$forum_id]) {
			$gonew = "&gonew=1#UNREAD";
			$folder = "newfolder.gif";
		}
		if (isset($_SESSION['topicread'][$topic_id]) && $_SESSION['topicread'][$topic_id] > $last_reply) {
			$gonew = "";
			$folder = "nonewfolder.gif";
		}

		$topics[$topic_key]['folder'] = "<img src='{$config['BASE_URL']}/images/{$style_array['general']}/$folder' alt='' />";
		$topics[$topic_key]['icon'] = "<img src='{$config['BASE_URL']}/images/{$style_array['icons']}/$topic_icon' alt='' />";
		$topics[$topic_key]['subject'] = "<a href=\"" . make_ubb_url("ubb=show{$user['USER_TOPIC_VIEW_TYPE']}&Number=$post_id$gonew", $topic_subject, false) . "\">$topic_subject</a>";
		if ($user_id == 1) {
			$topics[$topic_key]['author'] = "{$ubbt_lang['ANON_TEXT']}";
		} else {
			$display_name = $html->user_color($display_name, $color, $level);
			$topics[$topic_key]['author'] = "<a href='" . make_ubb_url("ubb=showprofile&User=$user_id", $display_name, false) . "'>$display_name</a>";
		}
		$topics[$topic_key]['posted'] = $html->convert_time($topic_created, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
		$topics[$topic_key]['forum'] = $forum_title;
		$topics[$topic_key]['color'] = ($topic_key & 1) ? "alt-topicsubject" : "topicsubject";
		$topic_key++;
	}
	$smarty->assignByRef("topics", $topics);
}

?>