<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);
function page_filemanager_gpc() {
	return array(
		"input" => array(
			"id" => array("id", "both", "alphanum"),
			"delete" => array("delete", "get", "int"),
			"post_id" => array("post_id", "get", "int"),
			"init" => array("init", "get", "int"),
			"description" => array("description", "post", ""),
			"g" => array("g", "both", "int"),
			"f" => array("f", "both", "int"),
			"addit" => array("addit", "post", "int"),
		),
		"wordlets" => array("filemanager"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_filemanager_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

// Purge orphaned files in the /tmp directory older than 2 hours
	$dir = opendir("{$config['FULL_PATH']}/tmp");
	while (($file = readdir($dir)) != false) {
		if (($file == ".") || ($file == "..") || ($file == "index.html")) {
			continue;
		}
		$modified = time() - filemtime("{$config['FULL_PATH']}/tmp/$file");
		if ($modified > 7200) {
			@unlink("{$config['FULL_PATH']}/tmp/$file");
		}
	}
// Purge orphaned file entries in the database older than 2 hours
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}FILES
		WHERE POST_ID = '0'
		  AND FILE_ADD_TIME < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 2 HOUR))
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);

	// Get the maximum file/photo attachment size for this forum.
	if ($g) {
		$attach_size = $userob->check_access("forum", "GALLERY_SIZE", $f);
	} else {
		$attach_size = $userob->check_access("forum", "FILE_SIZE", $f);
	}

	// Get the max upload size in php.ini
	$max_size = ini_get("upload_max_filesize");
	$multi = 1;
	if (preg_match("/K/", $max_size)) $multi = 1024;
	if (preg_match("/M/", $max_size)) $multi = 1048576;
	if (preg_match("/G/", $max_size)) $multi = 1073741824;
	$max_size_num = preg_replace("/(K|M|G| +)/", "", $max_size);
	$max_size_bytes = $max_size_num * $multi;

	if ($attach_size > $max_size_bytes) $attach_size = $max_size_bytes;

	// If this is a gallery upload, include the image library
	// also figure out how many photos we can post
	$max = 0;
	if (!$g) {
		$max = $userob->check_access("forum", "FILE_TOTAL", $f);
		$max_message = $html->substitute($ubbt_lang['MAX_ATTACH'], array('NUM_FILE' => $max));
		$count_message = $html->substitute($ubbt_lang['COUNT_ATTACH'], array('NUM_FILE' => $max));
		$maxsize = $attach_size;
		$maxsize_message = $html->substitute($ubbt_lang['MAX_SIZE'], array('FILE_SIZE' => file_size($maxsize)));
	} else {
		$max = $userob->check_access("forum", "GALLERY_TOTAL", $f);
		$max_message = $html->substitute($ubbt_lang['MAX_PHOTO'], array('NUM_PHOTO' => $max));
		$count_message = $html->substitute($ubbt_lang['COUNT_PHOTO'], array('NUM_PHOTO' => $max));
		$maxsize = $attach_size;
		$maxsize_message = $html->substitute($ubbt_lang['MAX_SIZE'], array('FILE_SIZE' => file_size($maxsize)));
	}

	// Always include the image processing bits
	include("{$config['FULL_PATH']}/libs/image.inc.php");

	$user_clause = "and USER_ID = ?";
	$user_var = $user['USER_ID'];

	if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator" || preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL'])) {
		$user_clause = "";
		$user_var = "";
	}

	if ($init) {
		if ($user_var) {
			$vars = array($id, $post_id, $user_var);
		} else {
			$vars = array($id, $post_id);
		}

		$query = "
			UPDATE {$config['TABLE_PREFIX']}FILES
			SET FILE_MD5 = ?
			WHERE POST_ID = ?
			$user_clause
		";
		$dbh->do_placeholder_query($query, $vars, __LINE__, __FILE__);
	}

	if ($delete) {
		if ($user_var) {
			$vars = array($delete, $user_var);
		} else {
			$vars = array($delete);
		}
		$query = "
			SELECT FILE_NAME, FILE_DIR
			FROM {$config['TABLE_PREFIX']}FILES
			WHERE FILE_ID = ?
			$user_clause
		";
		$sth = $dbh->do_placeholder_query($query, $vars, __LINE__, __FILE__);

		list($name, $filedir) = $dbh->fetch_array($sth);
		@unlink("{$config['FULL_PATH']}/tmp/$name");

		if ($filedir) {
			@unlink("{$config['FULL_PATH']}/gallery/$filedir/thumbs/$name");
			@unlink("{$config['FULL_PATH']}/gallery/$filedir/medium/$name");
			@unlink("{$config['FULL_PATH']}/gallery/$filedir/full/$name");
		} else {
			@unlink("{$config['ATTACHMENTS_PATH']}/$name");
		}
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}FILES
			WHERE FILE_ID = ?
		";
		$dbh->do_placeholder_query($query, array($delete), __LINE__, __FILE__);
		header("Location: {$config['FULL_URL']}/ubbthreads.php?ubb=filemanager&id=$id&g=$g&f=$f&post_id=$post_id");
		exit;
	}

	if ((($_FILES['userfile']['name'] == "none") || (!$_FILES['userfile']['name']) && $addit)) {
//		$html->not_right_bare($ubbt_lang['NO_FILE']);
	}


	// We have a file, deal with it
	// Let's see how many files we already have
	$query = "
		SELECT count(*)
		FROM {$config['TABLE_PREFIX']}FILES
		WHERE FILE_MD5 = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	list($filecount) = $dbh->fetch_array($sth);

//	if ($filecount >= $max && ($max != $ubbt_lang['UNLIMITED']) && !$post_id) {
//		$html->not_right_bare($html->substitute($ubbt_lang['TOO_MANY'], array('NUM_ATTACH' => $max)));
//	}

	// --------------------------------------
	// Let's see if we want this type of file
	$hasfile = 0;
	if (isset($_FILES['userfile'])) {
		if (($_FILES['userfile']['name'] != "none") && ($_FILES['userfile']['name'])) {
			$hasfile = 1;
			if ((preg_match("/\.(php|php3|php4|cgi|pl|exe|bat|reg)$/i", $_FILES['userfile']['name'])) && !$g) {
				$html->not_right_bare("{$ubbt_lang['FILESALLOWED']} {$config['ATTACHMENT_TYPES']}");
			}
			$checkfile = str_replace(",", "|", $config['ATTACHMENT_TYPES']);
			// Forum post attachment file check
			if ((!preg_match("/($checkfile)$/i", $_FILES['userfile']['name'])) && !$g) {
				$html->not_right_bare("{$ubbt_lang['FILESALLOWED']} {$config['ATTACHMENT_TYPES']}");
			}
			// Gallery image attachment file check
			if ($g && (!preg_match("/(.gif|.jpg|.jpeg|.png)$/i", $_FILES['userfile']['name']))) {
				$html->not_right_bare($ubbt_lang['GALLERYFILES']);
			}
		}

		// Forum post attachment filesize check
		if (!$g && ($_FILES['userfile']['size'] > $attach_size)) {
			$html->not_right_bare($html->substitute($ubbt_lang['FILE_TOO_BIG'], array('FILE_SIZE' => file_size($attach_size))));

		}
		// Gallery image attachment filesize check
		if ($g && ($_FILES['userfile']['size'] > $attach_size)) {
			$html->not_right_bare($html->substitute($ubbt_lang['PIC_TOO_BIG'], array('PIC_SIZE' => file_size($attach_size))));
		}

		// No file size at all, exceeded php.ini setting
		if ($_FILES['userfile']['size'] == 0) {
			$html->not_right_bare($html->substitute($ubbt_lang['INI_TOO_BIG'], array('FILE_SIZE' => file_size($attach_size))));
		}


		if (($_FILES['userfile']['name'] != "none") && ($_FILES['userfile']['name'])) {

			$ext = explode('.', $_FILES['userfile']['name']);
			$ext = strtolower($ext[count($ext) - 1]);

			$query_vars = array(time(), $ext, $_FILES['userfile']['size'], $id, $user['USER_ID'], $description, $_FILES['userfile']['sha1']);
			$query = "
				INSERT INTO
					{$config['TABLE_PREFIX']}FILES
					(FILE_ADD_TIME, FILE_TYPE, FILE_SIZE, FILE_MD5, USER_ID, FILE_DESCRIPTION, FILE_SHA1)
				VALUES
					(?, ?, ?, ?, ?, ?, ?)
			";
			$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
			$query = "
				SELECT last_insert_id()
			";
			$sth = $dbh->do_query($query);
			list($file_id) = $dbh->fetch_array($sth);

			$FileName = "{$_FILES['userfile']['name']}";
			$FileName = ubbchars(stripslashes($FileName));
			$newname = "{$file_id}.{$ext}";

			move_uploaded_file($_FILES['userfile']['tmp_name'], "{$config['FULL_PATH']}/tmp/$newname");
			chmod("{$config['FULL_PATH']}/tmp/$newname", 0666);

			// If this is an image, let's make sure it's a valid one
			if (preg_match("#gif|jpg|jpeg|png|bmp#is", $ext)) {
				$fp = fopen("{$config['FULL_PATH']}/tmp/$newname");
				if ($fp) {
					$header = fread($fp, 200);
					fclose($fp);
					if (preg_match("#<head|<html|<body|<script#is", $header)) {
						unlink("{$config['FULL_PATH']}/tmp/$newname");
						$query = "
							DELETE FROM {$config['TABLE_PREFIX']}FILES
							WHERE FILE_ID = ?
						";
						$dbh->do_placeholder_query($query, array($file_id), __LINE__, __FILE__);
						$html->not_right_bare($ubbt_lang['MALFORMED_PIC']);
					}
				}
				// If this is a good image, let's adjust its dimensions
				list($newfilename, $width, $height) = resize_image("inline", $newname);
				unlink("{$config['FULL_PATH']}/tmp/$newname");
				$file_size = filesize("{$config['FULL_PATH']}/tmp/$newfilename.inline");
				rename("{$config['FULL_PATH']}/tmp/$newfilename.inline", "{$config['FULL_PATH']}/tmp/$newfilename");
				$newname = $newfilename;
			}

			// If this is a gallery upload, resize
			if ($g) {
				resize_image("thumb", $newname);
				resize_image("medium", $newname);
				list($newfilename, $width, $height) = resize_image("full", $newname);
				unlink("{$config['FULL_PATH']}/tmp/$newname");
				$file_size = filesize("{$config['FULL_PATH']}/tmp/$newfilename.full");
				$newname = $newfilename;
			}

			if (!$file_size) {
				$file_size = filesize("{$config['FULL_PATH']}/tmp/$newname");
			}

			if ((!$file_sha1) && (!preg_match("#gif|jpg|jpeg|png|bmp|pdf#is", $ext))) {
				$file_sha1 = sha1_file("{$config['FULL_PATH']}/tmp/$newname");
			}

			$query = "
				UPDATE {$config['TABLE_PREFIX']}FILES
				SET    FILE_NAME = ?,
				       FILE_ORIGINAL_NAME = ? ,
				       FILE_WIDTH = ? ,
				       FILE_HEIGHT = ? ,
					   FILE_SIZE = ? ,
					   FILE_SHA1 = ?
				WHERE  FILE_ID = ?
			";
			$dbh->do_placeholder_query($query, array($newname, $FileName, $width + 0, $height + 0, $file_size, $file_sha1, $file_id), __LINE__, __FILE__);
		}

	}

	$query = "
		SELECT FILE_ID, FILE_NAME, FILE_ORIGINAL_NAME, FILE_DESCRIPTION, FILE_TYPE, POST_ID, FILE_SHA1
		FROM {$config['TABLE_PREFIX']}FILES
		WHERE FILE_MD5 = ?
		ORDER BY FILE_ID ASC
	";
	$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	$files = array();
	while (list($file_id, $file_name, $filename_orig, $file_descr, $filetype, $postid, $file_sha1) = $dbh->fetch_array($sth)) {
		$file_descr = htmlspecialchars($file_descr);
		$file_url = preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", true));
		$files[] = array(
			"ID" => $file_id,
			"FILE_NAME" => $file_name,
			"FILE_ORIGINAL_NAME" => $filename_orig,
			"DESCR" => $file_descr,
			"TYPE" => $filetype,
			"POST_ID" => $postid,
			"FILE_SHA1" => $file_sha1,
			"FILE_URL" => $file_url,
		);
	}

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	$bad_id = false;
	if (!$id) {
		$bad_id = true;
	}

	$maxFilesize = ($attach_size / 1048576);

	$totalfiles = sizeof($files);
	if (!sizeof($files)) $files = "";


	$smarty_data = array(
		"stylesheet" => $stylesheet,
		"files" => $files,
		"bad_id" => $bad_id,
		"id" => $id,
		"sha1" => $sha1,
		"totalfiles" => $totalfiles,
		"g" => $g,
		"f" => $f,
		"max" => $max,
		"max_message" => $max_message,
		"count_message" => $count_message,
		"maxsize_message" => $maxsize_message,
		"maxFilesize" => $maxFilesize,
		"post_id" => $post_id,
	);


	return array(
		"header" => array(
			"title" => "",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "filemanager",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>