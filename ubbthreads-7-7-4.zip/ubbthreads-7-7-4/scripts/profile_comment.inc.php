<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_profile_comment_gpc() {
	return array(
		"input" => array(
			"Body" => array("Body", "post", ""),
			"profile" => array("profile", "post", "int"),
			"md5_stamp" => array("md5_stamp", "post", "both"),
		),
		"wordlets" => array("profile_comment"),
		"user_fields" => "t2.USER_SIGNATURE,t2.USER_TOPIC_VIEW_TYPE,t2.USER_TOTAL_POSTS,t2.USER_FLOOD_CONTROL_OVERRIDE,t2.USER_TEXT_EDITOR,USER_EMAIL_WATCHLISTS",
		"regonly" => 0,
	);
}

function page_profile_comment_run() {

	global $style_array, $userob, $smarty, $user, $user_ip, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra, $debug, $myinfo, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	$Body = trim($Body);
	$DefaultBody = $Body;

	// 75x Make sure comments are enabled, and they have reached the minimum-posts threshold, and they aren't commenting in their own profile
//	if (!$config['COMMENTS'] || $user['USER_TOTAL_POSTS'] < $config['COMMENTS_MIN_POST'] || $profile == $user['USER_ID']) exit;
	// 76x Make sure comments are enabled, and they have reached the minimum-posts threshold
	if (!$config['COMMENTS'] || $user['USER_TOTAL_POSTS'] < $config['COMMENTS_MIN_POST']) exit;

	// Censor the input?
	if ($config['DO_CENSOR']) {
		$Body = $html->do_censor($Body);
	}

	// Add a space to the end of $Body, for auto-url encoding
	$Body .= " ";

	$Username = $user['USER_DISPLAY_NAME'];
	$posterid = $user['USER_ID'];
	$postername = $Username;

	// Get the user's last post time
	$query = "
		SELECT USER_LAST_POST_TIME
		FROM {$config['TABLE_PREFIX']}USER_DATA
		WHERE USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	list($user['USER_LAST_POST_TIME']) = $dbh->fetch_array($sth);

	// -----------------
	// Get the user info
	$IP = $user_ip;

	/* FLOOD CONTROL FOR PROFILE COMMENTS?
		// Flood control settings
		if ($userob->is_logged_in) {
			$lastposttime = $user['USER_LAST_POST_TIME'];
			if ($user['USER_FLOOD_CONTROL_OVERRIDE'] == "-1") {
				$floodcontrol = $userob->check_access("forum","POST_THROTTLE",$Board);
			}
			else {
				$floodcontrol = $user['USER_FLOOD_CONTROL_OVERRIDE'];
			}
		} else {
			$floodcontrol = $userob->check_access("forum","POST_THROTTLE",$Board);
			$lastposttime = get_input("lastposttime","cookie");
		}

		// ---------------------------------
		// Check if they can make a post yet
		if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL'])) {
			if (($html->get_date() - $lastposttime) < $floodcontrol) {
				$html->not_right($html->substitute($ubbt_lang['FLOODCONTROL'],array('FLOOD_LIMIT' => $floodcontrol)));
			}
		}

		// Let's make sure this post doesn't already exist
		if ($md5_stamp) {
			$query = "
				SELECT USER_ID, PROFILE_ID
				FROM {$config['TABLE_PREFIX']}PROFILE_COMMENTS
				WHERE COMMENT_MD5 = ?
			";
			$sth = $dbh->do_placeholder_query($query,array($md5_stamp),__LINE__,__FILE__);
			while(list($md5_user,$md5_profile) = $dbh->fetch_array($sth)) {
				if ($md5_user == $user['USER_ID'] && $md5_profile == $profile) {
					$html->not_right($ubbt_lang['NO_DUPS']);
				}
			}
		}
	*/

	// ------------------
	// Check the referer
	if (!$config['DISABLE_REFERER_CHECK']) {
		$html->check_refer();
	}


	$Body = $html->do_markup($Body, "post", "markup");

	// --------------------
	// Get the current time
	$date = $html->get_date();

	// ---------------------------------
	// INSERT THE COMMENT INTO THE DATABASE
	$query = "
		INSERT INTO
			{$config['TABLE_PREFIX']}PROFILE_COMMENTS
			(PROFILE_ID, USER_ID, COMMENT_BODY, COMMENT_DEFAULT_BODY, COMMENT_MD5, COMMENT_TIME)
		VALUES
			(?, ?, ?, ?, ?, ?)
	";
	$dbh->do_placeholder_query($query, array($profile, $user['USER_ID'], $Body, $DefaultBody, $comment_md5, $date), __LINE__, __FILE__);

	// Get the comment id
	$query = "
		SELECT last_insert_id()
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	list ($commentid) = $dbh->fetch_array($sth);

	$pm_body = $html->substitute($ubbt_lang['NEW_COMMENT_BODY'], array('USER' => $user['USER_DISPLAY_NAME'], 'LINK' => "<a href='" . make_ubb_url("ubb=showprofile&User=$profile", "", true) . "'>{$ubbt_lang['YOUR_PROFILE']}</a>"));

	$html->send_message($config['MAIN_ADMIN_ID'], $profile, $ubbt_lang['NEW_COMMENT'], $pm_body);


	return array(
		"data" => "",
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "showprofile&User=$profile&#comment=$commentid",
	);
}

?>