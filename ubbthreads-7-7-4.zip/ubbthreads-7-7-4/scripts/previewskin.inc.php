<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function &page_previewskin_gpc() {
	return array(
		"input" => array(
			"skin" => array("skin", "get", "int"),
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function &page_previewskin_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	$skin = preg_replace("/[^a-zA-Z0-9_\-]/", "", $_GET['skin']);
	if ($skin == "0") {
		$skin = $config['DEFAULT_STYLE'];
	}

	include("{$config['FULL_PATH']}/styles/$skin.php");
	$html->set_style($skin);

	ob_start();

	include_once("{$config['FULL_URL']}/ubbthreads.php?ubb=cfrm&s=$skin");

	$content = ob_get_contents();
	ob_end_clean();

	$content = preg_replace("/styles\/(.*?)\.css\"/", "styles/{$style_array['css']}\"", $content);
	$content = preg_replace("/<a href(.*?)=(.*?)\"(.*?)\">/", "<a href=\"javascript:void(0);\">", $content);

	echo $content;

	return false;
}

?>