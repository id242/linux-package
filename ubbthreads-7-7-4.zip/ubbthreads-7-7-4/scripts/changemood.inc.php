<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

// -----------------
// No navigation bar
define('NO_WRAPPER', 1);

function page_changemood_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("changemood"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_changemood_run() {
	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Set default user mood
	if (!$user['USER_MOOD']) {
		$user['USER_MOOD'] = "content.gif";
	}

	// ------------------------------
	// Let's grab all the mood images
	$mood_list = "";
	$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['mood']}");

	$i = 0;
	$x = 0;
	while (($file = readdir($dir)) != false) {
		if (($file == ".") || ($file == "..") || ($file == "index.html") || ($file == "offline.gif")) {
			continue;
		}
		if ($i == 0) {
			$mood_list .= "<tr>";
		}

		$checked = "";
		if ($file == $user['USER_MOOD']) {
			$checked = "checked='checked'";
		}
		$mood_alt = preg_replace("#.(gif|jpg|png)$#", "", $file);

		$tdwidth = ($x < 3) ? 'width="32%"' : '';

		$mood_list .= <<<MOODY_BLUES
<td class="alt-1" $tdwidth >
<input id="mood$x" type="radio" name="mood" value="$file" $checked onchange="updatemood('$file')">
<label class="radio" for="mood$x" style="cursor: pointer;">
<img src="{$config['BASE_URL']}/images/{$style_array['mood']}/$file" alt="$mood_alt" title="$mood_alt" />
</label>
</td>
MOODY_BLUES;

		$i++;
		$x++;
		if ($i == 3) {
			$mood_list .= "</tr>";
			$i = 0;
		}
	}

	if ($i > 0) {
		for ($x = $i; $x < 3; $x++) {
			$mood_list .= "<td class='alt-1'>&nbsp;</td>";
		}
	}

	$smarty_data = array(
		"stylesheet" => "{$config['BASE_URL']}/styles/{$style_array['css']}",
		"mood_list" => $mood_list,
	);

	return array(
		"header" => array(
			"title" => $ubbt_lang['MY_MOOD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "changemood",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>