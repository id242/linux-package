<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);

function page_dochangemood_gpc() {
	return array(
		"input" => array(
			"mood" => array("mood", "post", ""),
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_dochangemood_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	$html = new html;

	// Let's make sure this is a valid mood
	$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['mood']}");
	$i = 0;
	$found = false;
	while (($file = readdir($dir)) != false) {
		if ($file == $mood) {
			$found = true;
		}
	}


	if (!$found) {
		$mood = "content.gif";
	}

	// Update this person's mood
	$query = "
		update {$config['TABLE_PREFIX']}USER_PROFILE
		set USER_MOOD = ?
		where USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($mood, $user['USER_ID']), __LINE__, __FILE__);

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	$smarty_data = array(
		"stylesheet" => $stylesheet,
	);

	return array(
		"header" => array(
			"title" => "",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "dochangemood",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>