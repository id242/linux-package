<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_boardrules_gpc() {
	return array(
		"input" => array(
			"ocurl" => array("ocurl", "post", ""),
			"agree" => array("agree", "post", "int"),
			"v" => array("v", "get", "int"),
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_boardrules_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	// Just viewing?
	if ($v == 1) {
		$html->give_rules(1);
		exit;
	}

	// Make sure this is a legit submission
	if (!$agree) {
		$html->not_right($ubbt_lang['RULE_ACCEPT_BODY']);
	}

	if (!$user['USER_ID']) {
		$_SESSION['rules_accept'] = 1;
	} else {
		$query = "
			update {$config['TABLE_PREFIX']}USERS
			set USER_RULES_ACCEPTED = ?
			where USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($html->get_date(), $user['USER_ID']), __LINE__, __FILE__);
	}

	header("Location: $ocurl");
	exit;
}

?>