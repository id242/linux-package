<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_addevent_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("addevent"),
		"user_fields" => "",
		"regonly" => 0,
	);
}

function page_addevent_run() {

	global $in, $user, $ubbt_lang, $config, $dbh, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Smarty data
	$data = array();

	$html = new html;

	$cols = $config['TEXT_AREA_COLUMNS'];
	$rows = $config['TEXT_AREA_ROWS'];

	// ---------------------------
	// Can they add public events?
	$typeselection = "
	<option value=\"private\">{$ubbt_lang['PRIVATE']}</option>";
	if ($userob->check_access("site", "CALENDAR_EVENTS")) {
		$typeselection .= "
			<option value=\"public\">{$ubbt_lang['PUBLIC']}</option>
		";
	}

	// ---------------------------------
	// Get some info on the current date
	$temp = getdate();
	$thismonth = $temp["mon"];
	$thisyear = $temp["year"];
	$thisday = $temp["mday"];

	// ---------------------------------
	// Generate the date selection boxes
	$selectmonth = "<select name=\"month\" class=\"form-select\">";
	for ($i = 1; $i <= 12; $i++) {
		$selected = "";
		if ($i == $thismonth) {
			$selected = "selected=\"selected\"";
		}
		$mname = "MONTH$i";
		$mname = $ubbt_lang[$mname];
		$selectmonth .= "<option value=\"$i\" $selected>$mname</option>";
	}
	$selectmonth .= "</select>";

	$selectday = "<select name=\"day\" class=\"form-select\">";
	for ($i = 1; $i <= 31; $i++) {
		$selected = "";
		if ($i == $thisday) {
			$selected = "selected=\"selected\"";
		}
		$selectday .= "<option value=\"$i\" $selected>$i</option>";
	}
	$selectday .= "</select>";

	$selectyear = "<select name=\"year\" class=\"form-select\">";
	for ($i = $thisyear; $i <= ($thisyear + 10); $i++) {
		$selected = "";
		if ($i == $thisyear) {
			$selected = "selected=\"selected\"";
		}
		$selectyear .= "<option value=\"$i\" $selected>$i</option>";
	}
	$selectyear .= "</select>";

	$smarty_data['rows'] = $rows;
	$smarty_data['cols'] = $cols;
	$smarty_data['selectday'] = $selectday;
	$smarty_data['selectmonth'] = $selectmonth;
	$smarty_data['selectyear'] = $selectyear;
	$smarty_data['typeselection'] = $typeselection;

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"data" => $smarty_data,
		"header" => array(
			"title" => $ubbt_lang['EVENT_HEAD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<EOF
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['EVENT_HEAD']}
EOF
		,
		),
		"template" => "addevent",
		"footer" => true,
		"location" => "",
	);
}

?>