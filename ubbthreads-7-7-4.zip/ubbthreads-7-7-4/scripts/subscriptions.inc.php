<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_subscriptions_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("subscriptions"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_subscriptions_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select GROUP_ID,SUBSCRIPTION_NAME,SUBSCRIPTION_DESCRIPTION
		from {$config['TABLE_PREFIX']}SUBSCRIPTIONS
		where SUBSCRIPTION_BY_DONATION='1'
		or SUBSCRIPTION_BY_REGULAR='1'
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	$subs = array();
	$x = 0;
	$color = "alt-1";
	while (list($gid, $sub_name, $sub_desc) = $dbh->fetch_array($sth)) {
		$subs[$x]['group'] = $gid;
		$subs[$x]['name'] = $sub_name;
		$subs[$x]['desc'] = $sub_desc;
		$subs[$x]['color'] = $color;
		$x++;
		$color = $html->switch_colors($color);
	}

	if (!sizeof($subs)) {
		$nosubs = 1;
	}

	$query = "
		select t1.SUBSCRIPTION_ID,t2.SUBSCRIPTION_NAME,t1.SUBSCRIPTION_END_DATE,t1.SUBSCRIPTION_STATUS,t1.SUBSCRIPTION_IS_ACTIVE,t2.SUBSCRIPTION_DONATION_AMOUNT,t2.SUBSCRIPTION_REGULAR_AMOUNT,t1.SUBSCRIPTION_METHOD
		from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA as t1,
		{$config['TABLE_PREFIX']}SUBSCRIPTIONS as t2
		where USER_ID = ?
		and t1.GROUP_ID = t2.GROUP_ID
		order by SUBSCRIPTION_ID desc
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	$color = "alt-1";
	while (list($sub_id, $sub_name, $sub_end, $sub_status, $sub_active, $d_amount, $r_amount, $method) = $dbh->fetch_array($sth)) {
		if ($sub_active == 1) {
			$sub_active = "<span style=\"color:#0b8043;font-weight:900;\">" . $ubbt_lang['TEXT_YES'] . "</span>";
		} else {
			$sub_active = $ubbt_lang['TEXT_NO'];
		}

		if (!$sub_end) {
			$sub_end = "<span title=\"" . $ubbt_lang['NO_END'] . "\">" . $ubbt_lang['NONE'] . "</span>";
		} else {
			$sub_end = $html->convert_time($sub_end);
		}

		$current[] = array(
			"id" => $sub_id,
			"name" => $sub_name,
			"end" => $sub_end,
			"status" => $sub_status,
			"color" => $color,
			"active" => $sub_active,
		);
		$color = $html->switch_colors($color);
	}

	$smarty_data = array(
		"field" => $value,
		"subs" => & $subs,
		"nosubs" => $nosubs,
		"mystuff" => $html->mystuff(),
		"current" => $current,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);

	return array(
		"header" => array(
			"title" => $ubbt_lang['MY_SUBS'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['MY_SUBS']}
BREADCRUMB
		,
		),
		"template" => "subscriptions",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>