<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.3
  Purpose:
  Future:
*/

function page_doclosethreads_gpc() {
	return array(
		"input" => array(
			"Number" => array("Number", "both", "int"),
		),
		"wordlets" => array("admin/generic"),
		"user_fields" => "USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
}

function page_doclosethreads_run() {

	global $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	$query = "
		select FORUM_ID,POST_ID,TOPIC_SUBJECT
		from {$config['TABLE_PREFIX']}TOPICS
		where TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($Board, $first_post, $Subject) = $dbh->fetch_array($sth);

	if (!$userob->check_access("forum", "LOCK_ANY", $Board)) exit;

	$query = "
		select FORUM_TITLE,CATEGORY_ID,FORUM_PARENT
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list($Title, $cat_id, $parent_id) = $dbh->fetch_array($sth);

	$query = "
	UPDATE {$config['TABLE_PREFIX']}TOPICS
	SET    TOPIC_STATUS = ?
	WHERE  TOPIC_ID   = ?
	";
	$dbh->do_placeholder_query($query, array("C", $Number), __LINE__, __FILE__);

	// ----------------------------------------------------------------------------
	// Send them a page; If they came from a thread we return them to the postlist
	// screen, otherwise we return them to the admin section

	// ---------------
	// Log this action
	admin_log("CLOSE_TOPIC", "<a href='" . make_ubb_url("ubb=showflat&Number=$first_post", $Subject, false) . "' target='_blank'>$Subject</a>");

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "show{$user['USER_TOPIC_VIEW_TYPE']}&Number=$first_post",
			"heading" => $ubbt_lang['COM_HEAD'],
			"body" => $ubbt_lang['COM_BODY'],
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $parent_id,
			"returnlink" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		)
	);
}

?>