<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_add_favorite_user_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("add_favorite_user"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_add_favorite_user_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	$smarty_data = array(
		"mystuff" => $html->mystuff(),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['HEADER']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['HEADER']} <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
BREADCRUMB
		,
		),
		"template" => "add_favorite_user",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>