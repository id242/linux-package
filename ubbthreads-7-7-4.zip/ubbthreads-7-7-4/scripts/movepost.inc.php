<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_movepost_gpc() {
	return array(
		"input" => array(
			"Number" => array("Number", "post", "int"),
			"Keyword" => array("Keyword", "post", "int"),
			"view" => array("view", "post", "alpha"),
			"what" => array("what", "post", "alpha"),
			"sb" => array("sb", "post", "int"),
			"o" => array("o", "post", "int"),
			"fpart" => array("fpart", "post", "alphanum"),
			"from" => array("from", "post", "alpha"),
			"movepost" => array("movepost", "post", ""),
		),
		"wordlets" => array("movepost"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
}

function page_movepost_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $tree;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$number = $Number;
	$oldboard = $Keyword;

	// --------------------------------------------
	// Let's find out if they should be here or not
	$query = "
	SELECT FORUM_TITLE,CATEGORY_ID,FORUM_PARENT,FORUM_IS_RSS,FORUM_RSS_TITLE
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE  FORUM_ID = ?
	AND FORUM_IS_ACTIVE='1'
	";
	$sth = $dbh->do_placeholder_query($query, array($Keyword), __LINE__, __FILE__);
	list($FTitle, $cat_id, $parent_id, $is_rss, $rss_title) = $dbh->fetch_array($sth);


	if (!sizeof($tree)) {
		list($tree, $style_cache, $lang_cache) = build_forum_cache();
	}

	$options = "";
	$category = "";
	$forums = 0;
	foreach ($tree['categories'] as $cat => $cat_title) {
		$category = "";
		$forums = 0;
		$category .= "<option value=\"category\">$cat_title ------</option>";
		if (!isset($tree[$cat])) continue;
		foreach ($tree[$cat] as $forum_id => $forum_title) {
			if (!$userob->check_access("forum", "SEE_FORUM", $forum_id) || $tree['active'][$forum_id] != 1) {
				continue;
			}
			$category .= "<option value=\"f$forum_id\">$forum_title</option>";
			$forums++;
		}
		if ($forums) $options .= $category;
	}


	$smarty_data = array(
		"view" => $view,
		"o" => $o,
		"forums" => & $options,
		"oldboard" => $oldboard,
		"number" => $number,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['CHOOSE_HEAD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Keyword,
			"Category" => $cat_id,
			"parent_forum" => $parent_id,
			"bypass" => 0,
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		),
		"template" => "movepost",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>