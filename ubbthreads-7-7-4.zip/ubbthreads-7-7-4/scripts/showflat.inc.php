<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_showflat_gpc() {
	return array(
		"input" => array(
			"Number" => array("Number", "get", "int"),
			"fpart" => array("fpart", "get", "alphanum"),
			"Forum" => array("Forum", "get", "alphanum"),
			"Search" => array("Search", "get", "alpha"),
			"Searchpage" => array("Searchpage", "get", "int"),
			"Words" => array("Words", "get", ""),
			"topic" => array("topic", "get", "int"),
			"gonew" => array("gonew", "get", "int"),
			"an" => array("an", "get", "alphanum"),
			"nt" => array("nt", "get", "int"),
			"topic" => array("topic", "get", "int"),
			"site_id" => array("site_id", "get", "int"),
			"mode" => array("mode", "get", "alpha"),
			"ajax" => array("ajax", "get", "int"),
			"page" => array("page", "get", "alphanum"),
		),
		"wordlets" => array("showflat", "like"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE, t2.USER_TOPICS_PER_PAGE, t2.USER_POSTS_PER_TOPIC, t2.USER_SHOW_SIGNATURES, t2.USER_SHOW_AVATARS, t2.USER_IGNORE_LIST, t2.USER_POST_LAYOUT",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_showflat_run() {
	global $html, $style_array, $smarty, $userob, $user, $in, $myinfo, $ubbt_lang, $config, $dbh, $topic_tree, $topicread;
	extract($in, EXTR_OVERWRITE | EXTR_REFS);

	// Enable Likes
	$show_likes = (isset($config['ENABLE_LIKES'])) ? $config['ENABLE_LIKES'] : 1;

	// Allowed to like their own content? (button display)
	$self_like = (isset($config['LIKE_SELF'])) ? $config['LIKE_SELF'] : 0;

	// Display a list of which members liked each post
	$show_user_likes = (isset($config['SHOW_USER_LIKES'])) ? $config['SHOW_USER_LIKES'] : 1;

	// How many liked member names to display under the post
	$like_user_limit = (isset($config['SHOW_USER_LIKES_LIMIT'])) ? $config['SHOW_USER_LIKES_LIMIT'] : 6;
	$smarty->assign("like_user_limit", $like_user_limit);

	// If no mode has been set, define as showflat
	$mode = (!$mode) ? "showflat" : $mode;
	$show_all_posts = ($page == "all") ? 1 : 0;

	// Grab current page from session variable
	$page_was_kludged = false;
	if (!$page) {
		$page = $_SESSION['currentpage'];
		$page_was_kludged = true;
	}

	// Post layout, side or top
	$post_layout = $user['USER_POST_LAYOUT'];
	if (!$post_layout) $post_layout = $config['POST_LAYOUT'];

	// Set the switch mode
	if ($mode == "showflat") {
		$switch = "showthreaded";
		$switch_text = $ubbt_lang['SWITCH_THREADED'];
	} else {
		$switch = "showflat";
		$switch_text = $ubbt_lang['SWITCH_FLAT'];
	}

	// If board is locked into threaded/flat redirect if necessary
	if ($config['TOPIC_DISPLAY_OPTIONS'] != "both") $mode = "show{$config['TOPIC_DISPLAY_OPTIONS']}";

	// Watch lists are session based for speed
	$_SESSION['watch_lists'] = array_get($_SESSION, 'watch_lists', '');
	if (is_array($_SESSION['watch_lists'])) $_SESSION['watch_lists'] = "";
	$watch_lists = unserialize($_SESSION['watch_lists']);
	if (!isset($watch_lists['u'])) $watch_lists['u'] = array();
	if (!isset($watch_lists['t'])) $watch_lists['t'] = array();
	$o = (isset($_SESSION['myprefs']['age'])) ? $_SESSION['myprefs']['age'] : 0;

	// Define some variables
	$postrow = array();
	$replycount = 0;
	$prevlink = "";
	$nextlink = "";
	$addfavoption = "";
	$showpoll = "";
	$managejump = "";
	$manageoptions = "";
	$updatelast = 0;
	$popups = "";

	// Create a reasonable posts per page, if no default available
	isset($user['USER_POSTS_PER_TOPIC']) && $Totaldisplay = $user['USER_POSTS_PER_TOPIC'];
	if (!$Totaldisplay) {
		$Totaldisplay = array_get($config, 'POSTS_PER_PAGE', 40);
		$Totaldisplay = ($Totaldisplay == '') ? 40 : $Totaldisplay;
	}

	// User's time offset
	$useroffset = $config['SERVER_TIME_OFFSET'];
	if ($user['USER_TIME_OFFSET'] != "") {
		$useroffset = $user['USER_TIME_OFFSET'];
	}

	if (empty($Search)) $Search = "";

	// Show Avatars with Posts?
	$AVATARS_WITH_POSTS = $config['SHOW_AVATARS'];
	if ($userob->is_logged_in) {
		$AVATARS_WITH_POSTS = $user['USER_SHOW_AVATARS'];
	}

	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];
	!isset($user['USER_IGNORE_LIST']) && $user['USER_IGNORE_LIST'] = "";

	// ----------------------------------
	// Grab the current day/month for birthdays
	$temp = getdate();
	$month = $temp["mon"];
	$day = $temp["mday"];

	// This bit specifically handles redirects from old imports
	$import_number = "";
	if ($site_id) {
		if ($Number && !$topic && !$Forum) {
			$query_vars = array($Number, $site_id);
			$query = "
				SELECT POST_ID
				FROM {$config['TABLE_PREFIX']}IMPORT_MAP
				WHERE OLD_POST_ID = ?
				  AND SITE_ID = ?
			";
		} elseif ($Forum && $topic && $Number) {
			$query_vars = array($topic, $Forum, $Number, $site_id);
			$query = "
				SELECT POST_ID
				FROM {$config['TABLE_PREFIX']}IMPORT_MAP
				WHERE OLD_TOPIC_ID = ?
				  AND OLD_FORUM_ID = ?
				  AND OLD_POST_ID = ?
				  AND SITE_ID = ?
				ORDER BY POST_ID ASC
				LIMIT 1
			";
		} elseif ($Forum && $topic) {
			$query_vars = array($topic, $Forum, $site_id);
			$query = "
				SELECT POST_ID
				FROM {$config['TABLE_PREFIX']}IMPORT_MAP
				WHERE OLD_TOPIC_ID = ?
				  AND OLD_FORUM_ID = ?
				  AND SITE_ID = ?
				ORDER BY POST_ID ASC
				LIMIT 1
			";
		} elseif ($topic) {
			$query_vars = array($topic, $site_id);
			$query = "
				SELECT POST_ID
				FROM {$config['TABLE_PREFIX']}IMPORT_MAP
				WHERE OLD_TOPIC_ID = ?
				  AND SITE_ID = ?
				ORDER BY POST_ID ASC
				LIMIT 1
			";
		}
		$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
		list ($Number) = $dbh->fetch_array($sth);
		$import_number = $Number;

		$redirect = "showflat&Number=$Number";
		$plink = make_ubb_url("ubb=showflat&Number=$Number", "", true);
		$html->send_redirect(
			array(
				"redirect" => $redirect,
				"heading" => "This Page Has Moved",
				"body" => "Please update your bookmarks.",
				"Board" => "",
				"Category" => "",
				"forum_id" => "",
				"returnlink" => "Redirecting you to<br><a href=\"{$plink}\">{$plink}</a>",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
			)
		);

	}

	// If we only have a topic id, we need to grab the post id
	if ($topic && !$Number) {
		$query = "
			SELECT POST_ID
			FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($topic), __LINE__, __FILE__);
		list($Number) = $dbh->fetch_array($sth);
	}

	// If we didn't find the main post, then this post doesn't exist
	if (!$Number || !is_numeric($Number)) {
		header("X-Robots-Tag: noindex, nofollow");
		header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found");
		header("Status: 404 Not Found");
		$html->not_right($ubbt_lang['POST_PROB']);
	}

	// Grab some info about this thread
	$query = "
		SELECT
			t.TOPIC_REPLIES, t.TOPIC_VIEWS, t.TOPIC_LAST_REPLY_TIME, t.TOPIC_SUBJECT, t.TOPIC_TOTAL_RATES,
			t.TOPIC_RATING, t.TOPIC_STATUS, t.TOPIC_IS_STICKY, t.USER_ID, t.POST_ID,
			t.FORUM_ID, t.TOPIC_ID
		FROM
			{$config['TABLE_PREFIX']}TOPICS AS t,
			{$config['TABLE_PREFIX']}POSTS AS p
		WHERE
			p.POST_ID = ?
		AND p.TOPIC_ID = t.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

	$topic_info = $dbh->fetch_array($sth, MYSQLI_ASSOC);
	$facebookPost = $topic_info['POST_ID'];
	$opid = $topic_info['USER_ID'];

	// IF this is an announcement then we force $topic_info['FORUM_ID'] to the announcement value
	if ($an && $topic_info['TOPIC_IS_STICKY'] == 2) {
		$realboard = $topic_info['FORUM_ID'];
		$topic_info['FORUM_ID'] = $an;
	}

	// Special tracking for threaded mode
	if ($mode == "showthreaded") {
		// If this is a new thread, clear out the threaded_read data
		if (!isset($_SESSION['topicread']['threaded_read']) || ($topic_info['TOPIC_ID'] != $_SESSION['topicread']['threaded_read']['main'])) {
			$_SESSION['topicread']['threaded_read']['main'] = $topic_info['TOPIC_ID'];
			$_SESSION['topicread']['threaded_read']['track'] = array();
		}
	}

	// The forumvisit['visit']['boardname'] array holds the real last visit time for each forum
	// The forumvisit['boardname'] array holds the first visit time for each forum for this particular session.
	if (!is_array($_SESSION['forumvisit']['visit'])) {
		$_SESSION['forumvisit']['lastonline'] = $user['USER_LAST_VISIT_TIME'];
		if ($userob->is_logged_in) {
			$query = "
				SELECT LAST_VISIT_TIME, FORUM_ID
				FROM {$config['TABLE_PREFIX']}FORUM_LAST_VISIT
				WHERE USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
			while (list($l_last, $l_board) = $dbh->fetch_array($sth)) {
				$_SESSION['forumvisit']['visit'][$l_board] = $l_last;
			}
		}
	}


	// Grab the cookie or session to mark the posts as read or unread
	$rightnow = $html->get_date();
	if (isset($_SESSION['forumvisit'][$topic_info['FORUM_ID']])) {
		$unread = $_SESSION['forumvisit'][$topic_info['FORUM_ID']];
	} elseif (isset($_SESSION['forumvisit']['visit'][$topic_info['FORUM_ID']])) {
		$unread = $_SESSION['forumvisit']['visit'][$topic_info['FORUM_ID']];
		$_SESSION['forumvisit'][$topic_info['FORUM_ID']] = $unread;
		$updatelast = 1;
	} elseif (isset($_SESSION['forumvisit']['lastonline'])) {
		$unread = $_SESSION['forumvisit']['lastonline'];
		$updatelast = 1;
	} else {
		if ($user['USER_LAST_VISIT_TIME']) {
			$unread = $user['USER_LAST_VISIT_TIME'];
		} else {
			$unread = $rightnow;
		}
	}

	// Update their last visit time stamp to this forum for the main forum listing
	$_SESSION['forumvisit']['visit'][$topic_info['FORUM_ID']] = $rightnow;

	// Timestamp for unread posts in this topic.
	if (isset($_SESSION['topicread'][$topic_info['TOPIC_ID']])) {
		$newintopic = $_SESSION['topicread'][$topic_info['TOPIC_ID']];
	} else {
		$newintopic = $unread;
	}

	// If we didn't get a board or number then we give them an error
	if (!$topic_info['FORUM_ID']) {
		header("X-Robots-Tag: noindex, nofollow");
		header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found");
		header("Status: 404 Not Found");
		$html->not_right($ubbt_lang['POST_PROB']);
	}

	// Keep the current thread number for page linking
	$pagelinker = $Number;

	// Grab some forum information
	$query = "
		SELECT
			FORUM_TITLE, CATEGORY_ID, FORUM_CUSTOM_HEADER,
			FORUM_STYLE, FORUM_PARENT, FORUM_ISLAND_INSERT, FORUM_IS_RSS, FORUM_RSS_TITLE,
			FORUM_IS_GALLERY, FORUM_IS_TEASER
		FROM
			{$config['TABLE_PREFIX']}FORUMS
		WHERE
			FORUM_ID = ?
		AND FORUM_IS_ACTIVE = '1'
	";
	$sth = $dbh->do_placeholder_query($query, array($topic_info['FORUM_ID']), __LINE__, __FILE__);
	$forum_info = $dbh->fetch_array($sth, MYSQLI_ASSOC);

	// We could have done a join in the above query to get Guest Read, but permissions might not be yet set
	$q = "
		SELECT
			SEE_FORUM, READ_TOPICS
		FROM
			{$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		WHERE
			GROUP_ID=5 AND FORUM_ID={$topic_info['FORUM_ID']}
	";
	$sth = $dbh->do_query($q);
	list($guestSeeForum, $guestSeePosts) = $dbh->fetch_array($sth);

	// Determine if it is guest-readable when sharing to Facebook/Twitter/Reddit/Shareaholic
	$guestReadable = (isset($guestSeeForum)) ? ($guestSeeForum & $guestSeePosts) : 0;

	// If this is a gallery pic, we switch the layout to gallery
	$gallery_comments = $post_layout;
	if ($forum_info['FORUM_IS_GALLERY']) {
		$gallery_comments = $post_layout;
		$post_layout = "gallery";
		$mode = "showgallery";
	}

	// Custom Style for this forum?
	if ($forum_info['FORUM_STYLE']) $html->set_style($forum_info['FORUM_STYLE']);

	// Grab all moderators for this board
	$query = "
		SELECT
			t1.USER_ID, t2.USER_DISPLAY_NAME
		FROM
			{$config['TABLE_PREFIX']}MODERATORS AS t1,
			{$config['TABLE_PREFIX']}USERS AS t2
		WHERE
			t1.FORUM_ID = ?
		AND t1.USER_ID = t2.USER_ID
		ORDER BY
			USER_DISPLAY_NAME
	";
	$sth = $dbh->do_placeholder_query($query, array($topic_info['FORUM_ID']), __LINE__, __FILE__);
	$moderatorlist = ",";
	while (list($modid, $modname) = $dbh->fetch_array($sth)) {
		$moderator[$modid] = $modname;
		$moderatorlist .= "$modid,";
	}

	if (!$userob->check_access("forum", "READ_TOPICS", $topic_info['FORUM_ID'])) {
		header("X-Robots-Tag: noindex, nofollow");
		header($_SERVER["SERVER_PROTOCOL"] . " 401 Unauthorized");
		$html->not_right($ubbt_lang['BAD_GROUP']);
	}

	// Show moderators?
	$modarray = preg_split("#,#", $moderatorlist);
	$modsize = sizeof($modarray);
	$comma = 0;
	$modlist = "";
	$modcheck = ",";
	for ($i = 0; $i < $modsize; $i++) {
		if ($modarray[$i]) {
			if ($comma) {
				$modlist .= ", ";
			}
			$modcheck .= "{$modarray[$i]},";
			$modlist .= "<a href=\"" . make_ubb_url("ubb=showprofile&User=$modarray[$i]", $moderator[$modarray[$i]], false) . "\" rel=\"nofollow\">{$moderator[$modarray[$i]]}</a>";
			$comma++;
		} else {
			$modlist .= "&nbsp;";
		}
	}

	if ($userob->check_access("forum", "USE_MARKUP", $topic_info['FORUM_ID'])) {
		$ubbcode = "{$ubbt_lang['UBBCODE']} {$ubbt_lang['ENABLED']}";
	} else {
		$ubbcode = "{$ubbt_lang['UBBCODE']} {$ubbt_lang['DISABLED']}";
	}
	if ($userob->check_access("forum", "USE_HTML", $topic_info['FORUM_ID'])) {
		$htmlcode = "{$ubbt_lang['HTMLIS']} {$ubbt_lang['ENABLED']}";
	} else {
		$htmlcode = "{$ubbt_lang['HTMLIS']} {$ubbt_lang['DISABLED']}";
	}


	// If they are a normal user they can only see approved posts
	$ismod = "no";
	$Viewable = "AND p.POST_IS_APPROVED = 1";
	if ($userob->check_access("forum", "APPROVE_ANY", $topic_info['FORUM_ID'])) {
		$Viewable = "";
	}

	// If we don't have a post number then we can't view it
	if (!$Number) {
		header("X-Robots-Tag: noindex, nofollow");
		header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found");
		header("Status: 404 Not Found");
		$html->not_right($ubbt_lang['POST_PROB']);
	}

	// If this is our first visit to this topic, update the counter
	if ($_SESSION['current_topic'] != $topic_info['TOPIC_ID']) {
		$query = "
			INSERT INTO
				{$config['TABLE_PREFIX']}TOPIC_VIEWS
				(TOPIC_ID)
			VALUES
				(?)
		";
		$dbh->do_placeholder_query($query, array($topic_info['TOPIC_ID']), __LINE__, __FILE__);
		$_SESSION['current_topic'] = $topic_info['TOPIC_ID'];
	}

	$length = $topic_info['TOPIC_REPLIES'] + 1;

	$ratinghtml = "";
	$myrating = "";
	$ThreadRating = "";

	if ($config['TOPIC_RATINGS']) {
		if ($topic_info['TOPIC_RATING']) {
			$ThreadRating = "<span title=\"{$ubbt_lang['RATING']} {$topic_info['TOPIC_TOTAL_RATES']} {$ubbt_lang['T_RATES']}, {$topic_info['TOPIC_RATING']} {$ubbt_lang['A_RATES']}\">";
			for ($x = 1; $x <= $topic_info['TOPIC_RATING']; $x++) {
				$ThreadRating .= "<i class=\"far fa-star\" aria-hidden=\"true\"></i>";
			}
			$ThreadRating .= "</span>";
		}

		// Let's see if they rated this thread
		$query = "
			SELECT RATING_VALUE
			FROM {$config['TABLE_PREFIX']}RATINGS
			WHERE RATING_TARGET = ?
			  AND RATING_RATER = ?
			  AND RATING_TYPE  = 't'
		";
		$sth = $dbh->do_placeholder_query($query, array($topic_info['TOPIC_ID'], $user['USER_ID']), __LINE__, __FILE__);
		list($myrating) = $dbh->fetch_array($sth);

		// Figure out what we need to display
		$ratinghtml = false;
		if ($topic_info['USER_ID'] != $user['USER_ID']) {
			$ratinghtml = true;
		}
	}

	// Move the new marker up a page if necessary
	if ($nt && ($page > $nt)) $nt = $page;

	// If we didn't get a fpart then we need to figure out what fpart this post is on
	// If gonew is set then we need to figure out the first unread post
	if (($mode == "showflat" || $mode == "showgallery") && ($page_was_kludged) && ($length > $Totaldisplay)) {
		if ($gonew) {
			$query_vars = array($topic_info['TOPIC_ID'], $newintopic);
			$AND = "AND POST_POSTED_TIME <= ?";
			$adder = 1;
		} else {
			$query_vars = array($topic_info['TOPIC_ID'], $Number);
			$AND = "AND POST_ID <= ? ";
			$adder = 0;
		}
		$query = "
			SELECT COUNT(POST_ID)
			FROM {$config['TABLE_PREFIX']}POSTS
			WHERE TOPIC_ID = ?
			  $AND
		";
		$sti = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
		list($totalreplies) = $dbh->fetch_array($sti);
		$totalreplies = $totalreplies + $adder;
		$page = ceil($totalreplies / $Totaldisplay);
	}

	// If mode is threaded, and gonew = 1 then we need to load up the first unread post.
	if ($gonew == 1 && $mode == "showthreaded") {
		$query = "
			SELECT POST_ID
			FROM {$config['TABLE_PREFIX']}POSTS
			WHERE TOPIC_ID = ?
			  AND POST_POSTED_TIME >= ?
			ORDER BY POST_ID ASC
			LIMIT 1
		";
		$sti = $dbh->do_placeholder_query($query, array($topic_info['TOPIC_ID'], $newintopic), __LINE__, __FILE__);
		list($threaded_num) = $dbh->fetch_array($sti);
		if ($threaded_num) $Number = $threaded_num;
	}


	if (!$page) {
		$page = 1;
	}

	if ($gonew && !$nt) {
		$nt = $page;
	}

	if (!$nt) {
		$nt = 9999;
	}

	$ntlink = "";
	if ($nt && $nt != 9999) {
		$ntlink = "&nt=$nt";
	}

	// Let's see how many posts are in this thread
	$pages = ceil($length / $Totaldisplay);

	if ($page > $pages) $page = $pages;

	$pageprint1 = "";
	$pageprint2 = "";

	if ($mode != "showthreaded") {
		$pageprint1 = $html->paginate($page, $pages, "{$mode}&Number=$pagelinker{$ntlink}&page=");
		$pageprint2 = preg_replace('#pagination_\d+#', '', $pageprint1);
	}

	// Modern Hop-To menu (or Classic Jump Box) for all allowed forums
	list($jumpbox, $ishopto) = $html->jump_box($topic_info['FORUM_ID']);

	// Find out how many are browsing this forum
	$query = "
		SELECT ONLINE_USER_TYPE, MAX(ONLINE_BROWSING_FORUM), COUNT(*)
		FROM {$config['TABLE_PREFIX']}ONLINE
		WHERE ONLINE_BROWSING_FORUM = ?
		GROUP BY ONLINE_USER_TYPE
	";
	$sth = $dbh->do_placeholder_query($query, array($topic_info['FORUM_ID']), __LINE__, __FILE__);
	$a = "0";
	$r = "0";
	while (list($Type, $Extra, $onlinecount) = $dbh->fetch_array($sth)) {
		${$Type} = $onlinecount;
	}

	if (isset($_SESSION['favorites']['tab'])) {
		$return_to_link = make_ubb_url("ubb=myhome", "", false);
		$linktext = $ubbt_lang['FAVORITES'];
	} elseif ($Search != "true") {
		$return_to_link = make_ubb_url("ubb=postlist&Board={$topic_info['FORUM_ID']}&page={$_SESSION['currentpage']}", $forum_info['FORUM_TITLE'], false);
		$prevlink = make_ubb_url("ubb=grabnext&Board={$topic_info['FORUM_ID']}&mode={$mode}&sticky={$topic_info['TOPIC_IS_STICKY']}&dir=new&posted={$topic_info['TOPIC_LAST_REPLY_TIME']}", "", false);
		$linktext = $ubbt_lang['INDEX_ICON'];
		$alttext = $ubbt_lang['ALL_THREADS'];
		$nextlink = make_ubb_url("ubb=grabnext&Board={$topic_info['FORUM_ID']}&mode={$mode}&sticky={$topic_info['TOPIC_IS_STICKY']}&dir=old&posted={$topic_info['TOPIC_LAST_REPLY_TIME']}", "", false);
	} else {
		// Otherwise we came from the search so we can only return
		$return_to_link = make_ubb_url("ubb=dosearch&Searchpage=$Searchpage&topic=$topic", "", false);
		$linktext = $ubbt_lang['SEARCH_ICON'];
	}

	// Only certain options for users that are logged in
	if ($userob->is_logged_in) {
		if (in_array($topic_info['TOPIC_ID'], $watch_lists['t'])) {
			$text_print = $ubbt_lang['NO_ADD_FAV'];
			$fa_print = "fas";
		} else {
			$text_print = $ubbt_lang['ADD_FAV'];
			$fa_print = "far";
		}
		$addfavoption = "<div class=\"fl\" style=\"padding-bottom:3px;padding-right:3px;\"><div class=\"form-button nd\" onclick=\"location.href='" . make_ubb_url("ubb=addfav&Board={$topic_info['FORUM_ID']}&topic={$topic_info['TOPIC_ID']}&Number=$Number&fpart=$page&what={$mode}", "", false) . "';\" title=\"$text_print\"><i class=\"$fa_print fa-bookmark fa-fw\"></i></div></div>";
	}

	// We need to know how many posts of this thread to display per page
	if ($page <= 1) {
		$Totalgrab = $Totaldisplay;
	} else {
		$Startat = $Totaldisplay * ($page - 1);
		$Totalgrab = "$Startat, $Totaldisplay";
	}
	$Limit = "LIMIT $Totalgrab";
	if ($show_all_posts) $Limit = "LIMIT 200";
	$postnumber = $Number;

	// This is the main query that will be used
	$query = "
		SELECT
			p.POST_ID, u.USER_DISPLAY_NAME, u.USER_IS_BANNED, p.POST_POSTED_TIME, p.POST_POSTER_IP,
			p.POST_SUBJECT, p.POST_BODY, p.POST_IS_APPROVED, up.USER_AVATAR, up.USER_TITLE,
			up.USER_CUSTOM_TITLE, up.USER_NAME_COLOR, p.POST_ICON, p.POST_HAS_POLL,
			p.POST_HAS_FILE, p.POST_PARENT_ID, u.USER_MEMBERSHIP_LEVEL, up.USER_SIGNATURE,
			p.POST_LAST_EDITED_TIME, p.POST_LAST_EDIT_REASON, p.POST_LAST_EDITED_BY,
			up.USER_LOCATION, up.USER_TOTAL_POSTS, u.USER_REGISTERED_ON, up.USER_RATING, up.USER_LIKES,
			up.USER_AVATAR_WIDTH, up.USER_AVATAR_HEIGHT, u.USER_ID, p.POST_PARENT_USER_ID,
			up.USER_BIRTHDAY, up.USER_PUBLIC_BIRTHDAY, p.POST_ADD_SIGNATURE, up.USER_ACCEPT_PM,
			up.USER_HOMEPAGE, up.USER_VISIBLE_ONLINE_STATUS, up.USER_MOOD, p.POST_POSTER_NAME,up.USER_GROUP_IMAGES
		FROM
			{$config['TABLE_PREFIX']}POSTS AS p USE INDEX (indx_2),
			{$config['TABLE_PREFIX']}USERS AS u,
			{$config['TABLE_PREFIX']}USER_PROFILE AS up
		WHERE
			p.PREG_QUERY_FIELD = ?
		$Viewable
		AND p.USER_ID = u.USER_ID
		AND p.USER_ID = up.USER_ID
		ORDER BY
			p.POST_ID
	";

	// This holds the results of our query
	$results = array();

	// If this is a gallery post we always have to grab
	// the first post that contains the images
	if ($mode == "showgallery") {
		$query_var = $topic_info['POST_ID'];
		$query_field = "POST_ID";
		$new_query = preg_replace("#PREG_QUERY_FIELD#", $query_field, $query);
		$sth = $dbh->do_placeholder_query($new_query, array($query_var), __LINE__, __FILE__);
		while ($row = $dbh->fetch_array($sth)) {
			$results[] = $row;
		}
	}


	if ($mode == "showthreaded") {
		$query_var = $Number;
		$query_field = "POST_ID";
	} else {
		$query_var = $topic_info['TOPIC_ID'];
		$query_field = "TOPIC_ID";
	}
	$new_query = preg_replace("#PREG_QUERY_FIELD#", $query_field, $query);
	$new_query .= "$Limit";

	$sth = $dbh->do_placeholder_query($new_query, array($query_var), __LINE__, __FILE__);
	while ($row = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
		$results[] = $row;
	}

	$makepost = "";
	$unread = 0;
	$profile_popups = "";

	$commentrow['0'] = array();

	// Keep track of all users
	$users_in_topic = array();
	$popup_cache = array();
	$parentusers = '';
	$result_count = count($results);

	for ($i = 0; $i < $result_count; $i++) {
		// Just a little kludge until I can fix this completely in 7.4 - Ian
		$Number		=& $results[$i]['POST_ID'];
		$Approved	=& $results[$i]['POST_IS_APPROVED'];
		$Picture	=& $results[$i]['USER_AVATAR'];
		$Title		=& $results[$i]['USER_TITLE'];
		$CustomTitle	=& $results[$i]['USER_CUSTOM_TITLE'];
		$Icon		=& $results[$i]['POST_ICON'];
		$Poll		=& $results[$i]['POST_HAS_POLL'];
		$Files		=& $results[$i]['POST_HAS_FILE'];
		$ParentPost	=& $results[$i]['POST_PARENT_ID'];
		$PostStatus	=& $results[$i]['USER_MEMBERSHIP_LEVEL'];
		$Signature	=& $results[$i]['USER_SIGNATURE'];
		$LastEdit	=& $results[$i]['POST_LAST_EDITED_TIME'];
		$LastEditReason	=& $results[$i]['POST_LAST_EDIT_REASON'];
		$LastEditBy	=& $results[$i]['POST_LAST_EDITED_BY'];
		$Location	=& $results[$i]['USER_LOCATION'];
		$TotalPosts	=& $results[$i]['USER_TOTAL_POSTS'];
		$Registered	=& $results[$i]['USER_REGISTERED_ON'];
		$stars		=& $results[$i]['USER_RATING'];
		$likes		=& $results[$i]['USER_LIKES'];
		$picwidth	=& $results[$i]['USER_AVATAR_WIDTH'];
		$picheight	=& $results[$i]['USER_AVATAR_HEIGHT'];
		$usernum	=& $results[$i]['USER_ID'];
		$ParentUser	=& $results[$i]['POST_PARENT_USER_ID'];
		$bday		=& $results[$i]['USER_BIRTHDAY'];
		$showbday	=& $results[$i]['USER_PUBLIC_BIRTHDAY'];
		$addsig		=& $results[$i]['POST_ADD_SIGNATURE'];
		$accept_pm	=& $results[$i]['USER_ACCEPT_PM'];
		$homepage	=& $results[$i]['USER_HOMEPAGE'];
		$visible	=& $results[$i]['USER_VISIBLE_ONLINE_STATUS'];
		$postername	=& $results[$i]['POST_POSTER_NAME'];
		$gimages	=& $results[$i]['USER_GROUP_IMAGES'];
		$Banned		=& $results[$i]['USER_IS_BANNED'];

		$rateimage = "";

		$postrow[$i] = array();
		$postrow[$i]['Registered'] = "";
		$postrow[$i]['Location'] = "";
		$postrow[$i]['filelink'] = "";
		$postrow[$i]['Rating'] = "";
		$postrow[$i]['hasliked'] = 0;
		$postrow[$i]['likepage'] = "";
		$postrow[$i]['liketext'] = "";
		$postrow[$i]['Likes'] = "";
		$postrow[$i]['UserStatus'] = "";
		$postrow[$i]['Picture'] = "";
		$postrow[$i]['TotalPosts'] = "";
		$postrow[$i]['Signature'] = "";
		$postrow[$i]['replylink'] = "";
		$postrow[$i]['editlink'] = "";
		$postrow[$i]['quotelink'] = "";
		$postrow[$i]['addfavlinkstart'] = "";
		$postrow[$i]['addfavlinkstop'] = "";
		$postrow[$i]['notifylinkstart'] = "";
		$postrow[$i]['notifylinkstop'] = "";
		$postrow[$i]['replyto'] = "";
		$postrow[$i]['ParentPost'] = $ParentPost;
		$postrow[$i]['unread'] = "";
		$postrow[$i]['userid'] = $usernum;
		$postrow[$i]['identicon'] = "";

		// We're keeping track of all users that have made a post
		// here so we can query to see if they are online later
		// to avoid an extra join.
		if ($usernum != 1 && !isset($users_in_topic[$usernum])) {
			$users_in_topic[$usernum] = $visible;
		}

		if ($visible == "no" && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
			$postrow[$i]['online'] = 0;
		}


		// Is this an import redirect request?
		if ($import_number) {
			$postrow[$i]['import'] = '<a id="import"></a>';
		} else {
			$postrow[$i]['import'] = "";
		}
		// New posts in topic?
		if (($results[$i]['POST_POSTED_TIME'] > $newintopic) || (($page >= $nt) && !$gonew)) {
			if (!$nt) {
				$nt = $page;
			}
			if (!$unread) {
				$postrow[$i]['unread'] = '<a id="UNREAD"></a>';
				$unread = 1;
			}
			$postrow[$i]['subjectclass'] = "newsubjecttable";
			$postrow[$i]['newpost'] = "{$ubbt_lang['NEW_TEXT']}";
			$updatelast = 1;
		} else {
			$postrow[$i]['subjectclass'] = "subjecttable";
			$postrow[$i]['newpost'] = "";
		}

		// Threaded mode, unread check
		if ($mode == "showthreaded") {
			if (!in_array($Number, $_SESSION['topicread']['threaded_read']['track']) && $results[$i]['POST_POSTED_TIME'] > $newintopic) {
				$postrow[$i]['newpost'] = "{$ubbt_lang['NEW_TEXT']}";
				$_SESSION['topicread']['threaded_read']['track'][] = $Number;
				$_SESSION['topicread'][$main_topic_id] = $html->get_date();
			}
		}

		if ($usernum != 1) {
			if (isset($Registered)) {
				$Registered = $html->convert_time($Registered, $useroffset, "M Y", 1);
				$postrow[$i]['Registered'] = "{$ubbt_lang['REGED_ON']} $Registered";
			}
			$postrow[$i]['TotalPosts'] = "{$ubbt_lang['POSTS_TEXT']}: " . number_format($TotalPosts);
			if ($Location) {
				$LocationText = $Location;
				if (strlen($Location) > 30) {
					$LocationText = substr($LocationText, 0, 30);
					$LocationText = "<span title=\"$Location\">$LocationText... </span>";
				}
				if ($config['LOCINFO_URL']) {
					$postrow[$i]['Location'] = "<a href=\"{$config['LOCINFO_URL']}" . urlencode($Location) . "\" rel=\"nofollow\" target=\"_blank\">$LocationText</a>";
				} else {
					$postrow[$i]['Location'] = "$LocationText";
				}
			}

			if ($user['USER_SHOW_SIGNATURES'] == "no" || $user['USER_SHOW_SIGNATURES'] == "po" || !$addsig || $Banned) {
				$Signature = "";
			}
			if ($userob->check_access("site", "SIGNATURE_IMAGES")) {
				$Signature = preg_replace('#<img src="([^>]]*)"( /)?' . '>#i', '', $Signature);
			}

			$postrow[$i]['Signature'] = $Signature;

			if ($likes >= 1) {
				$postrow[$i]['Likes'] = $ubbt_lang["LIKES"] . ": " . $likes;
			}

			if (($stars) && ($config['USER_RATINGS'] == "1")) {
				for ($x = 1; $x <= $stars; $x++) {
					$rateimage .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/star.gif\" title= \"\" alt=\"*\">";
				}
				$postrow[$i]['Rating'] = $rateimage;
			}
			if (($Picture) && (($Picture != "http://") || ($Picture != "https://")) && ($AVATARS_WITH_POSTS == 1)) {
// IE11 and older will display the avatar at full size due to their lack of support for css3
// the css3 "object-fit:contain" became available as of edge16,ios8.1,android4.3
				$postrow[$i]['Picture'] = "$Picture";
			} else {
				$Picture = "";
			}
		}

		$postrow[$i]['PrintLastEdit'] = "";
		if ($LastEdit) {
			$LastEdit = $html->convert_time($LastEdit, $useroffset, $user['USER_TIME_FORMAT']);
			$postrow[$i]['PrintLastEdit'] = "{$ubbt_lang['EDITED_BY']} $LastEditBy; $LastEdit.";
			if ($LastEditReason) {
				$postrow[$i]['PrintLastEdit'] .= " {$ubbt_lang['EDIT_REASON']} $LastEditReason";
			}
		}

		$time = $html->convert_time($results[$i]['POST_POSTED_TIME'], $useroffset, $user['USER_TIME_FORMAT']);
		$postrow[$i]['time'] = $time;

		$PUsername = $html->user_color($results[$i]['USER_DISPLAY_NAME'], $results[$i]['USER_NAME_COLOR'], $results[$i]['USER_MEMBERSHIP_LEVEL']);

		// If we came from the search engine then we bold the search keywords
		// Thanks to Ian Spence for this code
		if ($Search == "true" && $Words) {
			$tags = array();
			$matches = array();
			preg_match_all("#(<[^>]+>)#is", $results[$i]['POST_BODY'], $matches);
			for ($x = 0; $x < count($matches[0]); $x++) {
				$results[$i]['POST_BODY'] = str_replace($matches[0][$x], "[HTmLS3ARCHH1GHL1G|-|T]{$x}[/HTmLS3ARCHH1GHL1G|-|T]", $results[$i]['POST_BODY']);
				$tags[$x] = $matches[1][$x];
			}
			$searchwords = str_replace(".", "", $Words);
			$searchwords = str_replace("+", " ", $searchwords);
			$searchwords = preg_quote($searchwords);
			$searchwords = preg_replace("/\//", "", $searchwords);
			$searchwords = preg_split("# +#", $searchwords);
			$searchwords = preg_replace("/#/", "\#", $searchwords);
			$size = sizeof($searchwords);
			for ($x = 0; $x < $size; $x++) {
				if (!$searchwords[$x]) {
					continue;
				}
				$results[$i]['POST_BODY'] = preg_replace("#(\b|^|\])({$searchwords[$x]})(\b|$|\[)#i", '\1<span class="search_highlight">\2</span>\3', $results[$i]['POST_BODY']);
			}

			foreach ($tags as $x => $tag) {
				$results[$i]['POST_BODY'] = str_replace("[HTmLS3ARCHH1GHL1G|-|T]{$x}[/HTmLS3ARCHH1GHL1G|-|T]", $tag, $results[$i]['POST_BODY']);
			}
		}

		// Set both the reply and edit buttons to off
		$reply = "off";
		$edit = "off";
		$newtopic = "off";

		// Check if they can do a new topic here
		if ($userob->check_access("forum", "CREATE_TOPICS", $topic_info['FORUM_ID'])) {
			$newtopic = "on";
		}

		// Can they post here?
		if ($userob->check_access("forum", "CREATE_REPLIES", $topic_info['FORUM_ID'])) {
			$makepost = "yes";
		}

		$closed = 0;
		if ($topic_info['TOPIC_STATUS'] == "C") {
			$closed = 1;
		}
		if (($makepost == "yes") && ($topic_info['TOPIC_STATUS'] != "C") && ($topic_info['TOPIC_STATUS'] != "M")) {
			$reply = "on";
		}

		// All users can reply to global announcements
		// as long as they have the ability to reply to regular topics.
		// Locking the announcement will make it so it cannot be replied to.
		// Uncomment to only allow admins to reply to global announcements
		if ($topic_info['TOPIC_IS_STICKY'] == '2' && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator")) {
//			$reply = "off";
		}

		// If this thread has been moved we need to send them properly
		if ($topic_info['TOPIC_STATUS'] == "M") {
			if (preg_match("#-ML-#", $results[$i]['POST_BODY'])) {
				@list($NewBoard, $NewNumber, $results[$i]['POST_BODY']) = preg_split("#-ML-#", $results[$i]['POST_BODY']);
				$results[$i]['POST_BODY'] = "<a href=\"" . make_ubb_url("ubb={$mode}&topic=$NewNumber", "", false) . "\">{$ubbt_lang['POINTER']}</a><br><br>{$results[$i]['POST_BODY']}";
			}
			if (preg_match("#-MERGE-#", $results[$i]['POST_BODY'])) {
				@list($NewBoard, $NewNumber, $results[$i]['POST_BODY']) = preg_split("#-MERGE-#", $results[$i]['POST_BODY']);
				$results[$i]['POST_BODY'] = "<a href=\"" . make_ubb_url("ubb={$mode}&Number=$NewNumber#Post$NewNumber", "", false) . "\">{$ubbt_lang['MERGE_POINTER']}</a><br><br>{$results[$i]['POST_BODY']}";
			}
		}

		// Do they get an edit button?
		$edit_timer = $userob->check_access("forum", "EDIT_POSTS", $topic_info['FORUM_ID']);
		$edit_now = time();
		$edit_window = $edit_timer * 60;
		$edit_good_until = $results[$i]['POST_POSTED_TIME'] + $edit_window;
		$still_editable = !$edit_timer ? true : ($edit_now < $edit_good_until ? true : false);

		if ($user['USER_DISPLAY_NAME'] && $topic_info['TOPIC_STATUS'] != "M") {
			if ((($user['USER_ID'] == $usernum && $topic_info['TOPIC_STATUS'] != 'C' && $topic_info['TOPIC_STATUS'] != 'M') && $still_editable) || ($userob->check_access("forum", "EDIT_ANY", $topic_info['FORUM_ID']))) {
				$edit = "on";
			}
		}

		// Mark it if it isn't approved
		if ($Approved == "0") {
			$postrow[$i]['Approved'] = "<i class=\"fas fa-exclamation-circle fa-fw\" title=\"{$ubbt_lang['NOT_APPROVED']}\"></i> ";
		}
		$postrow[$i]['Subject'] = $results[$i]['POST_SUBJECT'];


		if (!$Icon) {
			$Icon = "blank.gif";
		}
		$postrow[$i]['Icon'] = $Icon;

		// We need to know if this was made by an admin or moderator
		$userstatus = "";
		$userstatus = $html->user_status($usernum, $gimages, $modcheck);

		// If it is an anonymous post, don't give a link to their profile
		if ($usernum == "1") {
			if (!$postername) {
				$results[$i]['USER_DISPLAY_NAME'] = "{$ubbt_lang['ANON_TEXT']}";
			} else {
				$results[$i]['USER_DISPLAY_NAME'] = "$postername";
			}
			$Title = $ubbt_lang['UNREGED_USER'];
			$postrow[$i]['printuser'] = $results[$i]['USER_DISPLAY_NAME'];
		} else {
			$printUser = $results[$i]['USER_DISPLAY_NAME'];
			$postrow[$i]['printuser'] = $results[$i]['USER_DISPLAY_NAME'];

			$results[$i]['USER_DISPLAY_NAME'] = "<span id=\"menu_control_$Number\"><a href=\"javascript:void(0);\" onclick=\"showHideMenu('menu_control_$Number','profile_popup_$Number');\">$PUsername</a></span>";

			if (is_array($watch_lists['u']) && in_array($usernum, $watch_lists['u'])) {
				$watch_text = $ubbt_lang['REMOVE_WATCH'];
				$watch_fa = "fas";
//				$results[$i]['USER_DISPLAY_NAME'] .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/watch.gif\" alt=\"\" title=\"{$ubbt_lang['WATCHING_USER']}\">";
			} else {
				$watch_text = $ubbt_lang['ADD_WATCH'];
				$watch_fa = "far";
//				$results[$i]['USER_DISPLAY_NAME'] .= "";
			}

			$results[$i]['G_IMAGES'] = $userstatus;

			if (!isset($popup_cache[$Number])) {
				$popups .= "<div id=\"profile_popup_$Number\" style=\"display:none;\"><table class=\"popup_menu\">";
				$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=showprofile&User={$usernum}", "", false) . "\" class=\"nd\" rel=\"nofollow\"><i class=\"far fa-user fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['VIEW_PROFILE']}</a></td></tr>";
				if ($userob->check_access("cp", "EDIT_USERS")) {
					if ($PostStatus == "User") {
						$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"{$config['BASE_URL']}/admin/showuser.php?uid={$usernum}\" class=\"nd\" rel=\"nofollow\"><i class=\"fas fa-wrench fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['EDIT_USER']}</a></td></tr>";
					}
				}
				if (($user['USER_MEMBERSHIP_LEVEL'] == 'Administrator') && ($user['USER_ID'] != $usernum)) {
					$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"{$config['BASE_URL']}/admin/loginas.php?uid={$usernum}\" class=\"nd\" rel=\"nofollow\"><i class=\"far fa-meh fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['BECOME_USER']}</a></td></tr>";
				}
				if ($accept_pm) {
					$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=sendprivate&User={$usernum}", "", false) . "\" class=\"nd\" rel=\"nofollow\"><i class=\"far fa-envelope fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['SEND_PM']}</a></td></tr>";
				}
				if ($homepage) {
					$homepage = ubbchars($homepage);
					if (strpos($homepage, "://") === false) {
						$homepage = "//$homepage";
					}
					$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"$homepage\" class=\"nd\" target=\"_blank\"><i class=\"fas fa-link fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['VIEW_HOME']}</a></td></tr>";
				}
				if ($user['USER_ID'] != $usernum) {
					$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=addfavuser&User={$usernum}&n=$Number&p=$page&f=$page", "", false) . "\" class=\"nd\" rel=\"nofollow\"><i class=\"$watch_fa fa-bookmark fa-fw menu-item\" aria-hidden=\"true\"></i> $watch_text</a></td></tr>";
				}
				$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=userposts&id={$usernum}", "", false) . "\" class=\"nd\" rel=\"nofollow\"><i class=\"far fa-comment fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['VIEW_POSTS']}</a></td></tr>";
				if ($show_likes == 1) {
					$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=like&type=user&target={$usernum}", "", false) . "\" class=\"nd\" rel=\"nofollow\"><i class=\"far fa-thumbs-up fa-fw menu-item\" aria-hidden=\"true\"></i> {$ubbt_lang['THREAD_SUMMARY']}</a></td></tr>";
				}
				$popups .= "</table></div>";
				$popups .= "<script>registerPopup(\"profile_popup_$Number\");</script>";
				$popup_cache[$Number] = 1;
			}
		}

		// Is it their birthday?
		if ($showbday) {
			if (preg_match("/^$month\/$day\//", $bday)) {
				$results[$i]['USER_DISPLAY_NAME'] = "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/birthday.gif\" alt=\"{$ubbt_lang['HAPPYBDAY']}\" title=\"{$ubbt_lang['HAPPYBDAY']}\"> {$results[$i]['USER_DISPLAY_NAME']}";
			}
		}
		$postrow[$i]['Username'] = $results[$i]['USER_DISPLAY_NAME'];
		$postrow[$i]['UsernameTOP'] = $html->user_color(strip_tags($results[$i]['USER_DISPLAY_NAME']), $results[$i]['USER_NAME_COLOR'], $results[$i]['USER_MEMBERSHIP_LEVEL']);
		$postrow[$i]['GROUP_IMAGES'] = $results[$i]['G_IMAGES'];
//		$CustomTitle = $html->user_color($CustomTitle, $results[$i]['USER_NAME_COLOR'], $results[$i]['USER_MEMBERSHIP_LEVEL']);
//		$Title = $html->user_color($Title, $results[$i]['USER_NAME_COLOR'], $results[$i]['USER_MEMBERSHIP_LEVEL']);

		if ($CustomTitle && $config['ONLY_CUSTOM']) {
			$postrow[$i]['Title'] = $CustomTitle;
			$CustomTitle = "";
		} else {
			$postrow[$i]['Title'] = $Title;
			$postrow[$i]['CustomTitle'] = $CustomTitle;
		}

		if ($results[$i]['POST_POSTER_IP'] && $userob->check_access("site", "EXT_INFO")) {
			$postrow[$i]['IP'] = "{$results[$i]['POST_POSTER_IP']}";
		}

		if (($config['IDENTICONS_REGD']) && ($usernum != 1)) {
			$postrow[$i]['identicon'] = md5("{$config['BOARD_KEY']}.{$postrow[$i]['userid']}");
		}
		if (($config['IDENTICONS_ANON']) && ($usernum == 1)) {
			$postrow[$i]['identicon'] = md5("{$config['BOARD_KEY']}.{$results[$i]['POST_POSTER_IP']}");
		}

		$postrow[$i]['filelink'] = "";
		$postrow[$i]['gallery_pic'] = "";
		$postrow[$i]['gallery_desc'] = "";
		$postrow[$i]['thumbs'] = array();
		$filecount = 0;
		if ($Files) {
			$query = "
				SELECT
					FILE_ID, FILE_NAME, FILE_ORIGINAL_NAME, FILE_DOWNLOADS, FILE_SIZE, FILE_TYPE, FILE_DESCRIPTION,
					FILE_DIR, FILE_WIDTH, FILE_HEIGHT, FILE_SHA1
				FROM
					{$config['TABLE_PREFIX']}FILES
				WHERE
					POST_ID = ?
				ORDER BY
					FILE_ID ASC
			";
			$stx = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
			$img_array = array("gif", "png", "jpg", "jpeg");
			while (list($file_id, $file_name, $filename_orig, $downloads, $size, $ext, $file_desc, $file_dir, $file_width, $file_height, $file_sha1) = $dbh->fetch_array($stx)) {
				$file_desc = htmlspecialchars($file_desc);

				$filecount++;
				// If this is a gallery forum, grab the medium image
				if (!$postrow[$i]['gallery_pic'] && $forum_info['FORUM_IS_GALLERY']) {
					if (!$file_desc) {
						$img_link = "$filename_orig";
//						$file_desc = "$img_link";
					} else {
						$img_link = preg_replace("/ +/", "_", $file_desc) . ".$ext";
					}
					$postrow[$i]['gallery_pic'] = "<a href=\"{$config['FULL_URL']}/gallery/$file_dir/full/$file_id.$ext\" data-lightbox=\"gallery\" data-title=\"$filename_orig $file_width x $file_height (" . file_size($size) . ") $file_desc\"><img src=\"{$config['FULL_URL']}/gallery/$file_dir/medium/$file_id.$ext\" alt=\"{$img_link}\" alt=\"{$img_link}\" title=\"{$ubbt_lang['SHOW_FULL']}\" class=\"post-image p2 cp oi\"></a>";
					$postrow[$i]['filename_orig'] = $filename_orig;
					$postrow[$i]['gallery_desc'] = $file_desc;
					$postrow[$i]['thumb'] = "[img]{$config['FULL_URL']}/gallery/{$file_dir}/thumbs/{$file_id}.{$ext}[/img]";
					$postrow[$i]['medium'] = "[img]{$config['FULL_URL']}/gallery/{$file_dir}/medium/{$file_id}.{$ext}[/img]";
					$postrow[$i]['full'] = "[img]{$config['FULL_URL']}/gallery/{$file_dir}/full/{$file_id}.{$ext}[/img]";
					$postrow[$i]['width'] = $file_width;
					$postrow[$i]['height'] = $file_height;
					$postrow[$i]['size'] = file_size($size);
				}

				$filelink = preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", false));
				if (!strpos($results[$i]['POST_BODY'], $filelink) !== false) {
					// If this isn't a gallery, we're just displaying attachments ** ALSO EDIT printthread.inc.php AT/ABOUT LINE 255 FORWARD **
					if (!$forum_info['FORUM_IS_GALLERY']) {
						if (!$downloads) {
							$downloads = "0";
						}
						if ($size < $config['INLINE_IMAGE'] && in_array($ext, $img_array) && $userob->check_access("forum", "CAN_DOWNLOAD", $topic_info['FORUM_ID'])) {
							if ($config['IMAGE_DISPLAY'] == "inlined") {
								// Inlined attachments
								if (preg_match("/\b \b/", $file_name)) {
									$postrow[$i]['filelink'] .= "<a href=\"{$config['ATTACHMENTS_URL']}/$file_name\" data-lightbox=\"$Number\" data-title=\"$file_name $file_desc\"><img src=\"{$config['ATTACHMENTS_URL']}/$file_name\" alt=\"{$file_name}\" title=\"Name: {$file_name}\nViews: {$downloads}\nSize: " . file_size($size) . "\nID: {$file_id}\" class=\"post-image p2\"></a>";
								} else {
									$postrow[$i]['filelink'] .= "<a href=\"" . preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", false)) . "\" data-lightbox=\"$Number\" data-title=\"$filename_orig (" . file_size($size) . ") $file_desc\"><img src=\"" . preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", false)) . "\" alt=\"{$filename_orig}\" title=\"Name: {$filename_orig}\nViews: {$downloads}\nSize: " . file_size($size) . "\nID: {$file_id}\" class=\"post-image p2\"></a>";
								}
								if ($file_desc) {
									$postrow[$i]['filelink'] .= "<br><i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i><span class=\"fw\">$file_desc</span><br><br>";
								}
							} else {
								// Grouped attachments
								if (preg_match("/\b \b/", $file_name)) {
									$postrow[$i]['filelink'] .= "<a href=\"{$config['ATTACHMENTS_URL']}/$file_name\" data-lightbox=\"$Number\" data-title=\"$file_name $file_desc\"><img src=\"{$config['ATTACHMENTS_URL']}/$file_name\" alt=\"{$file_name}\" title=\"{$ubbt_lang['SHOW_FULL']}\n\nName: {$file_name}\nViews: {$downloads}\nSize: " . file_size($size) . "\nID: {$file_id}\" class=\"post-image p2\" style=\"width:{$config['MAX_THUMB_W_H']}px;\"></a>";
								} else {
									$postrow[$i]['filelink'] .= "<a href=\"" . preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", false)) . "\" data-lightbox=\"$Number\" data-title=\"$filename_orig (" . file_size($size) . ") $file_desc\"><img src=\"" . preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", false)) . "\" alt=\"{$filename_orig}\" title=\"{$ubbt_lang['SHOW_FULL']}\n\nName: {$filename_orig}\nViews: {$downloads}\nSize: " . file_size($size) . "\nID: {$file_id}\" class=\"post-image p2\" style=\"width:{$config['MAX_THUMB_W_H']}px;\"></a>";
								}
							}

						} else {
							if ($ext == "pdf" && $userob->check_access("forum", "CAN_DOWNLOAD", $topic_info['FORUM_ID'])) {
								$postrow[$i]['filelink'] .= "
<!-- pdf attachment -->
<div class=\"ubbcode-block\" style=\"margin-bottom:2px;margin-left:2px;\"><div class=\"ubbcode-header\">{$ubbt_lang['PDF_ATTACHED']} <input type=\"button\" class=\"form-button major-button\" style=\"margin:0 14px;padding:2px 14px;\" value=\"{$ubbt_lang['PDF_SHOW']}\" onClick=\"toggle_spoiler(this, '{$ubbt_lang['PDF_HIDE']}', '{$ubbt_lang['PDF_SHOW']}')\"></div>
<div class=\"ubbcode-body\" style=\"margin:0;padding:0;\"><div style=\"display:none;\">
<iframe src=\"//docs.google.com/gview?url={$config['ATTACHMENTS_URL']}/$file_id.pdf&embedded=true\" style=\"width:100%; height:800px;\" frameborder=\"0\"></iframe>
</div></div></div>
<!-- pdf download --><div class=\"p2\" style=\"margin-bottom:10px;\"><i class=\"far fa-file fa-fw\" aria-hidden=\"true\"></i> <a href=\"" . preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", false)) . "\">$filename_orig</a> <span class=\"op5 small nw\">(" . file_size($size) . ", $downloads {$ubbt_lang['DOWNLOADS']})</span></div><!-- pdf download -->
<!-- pdf attachment -->
";
							} else {
								$postrow[$i]['filelink'] .= "<div class=\"p2\"><i class=\"far fa-file fa-fw\" aria-hidden=\"true\"></i> <a href=\"" . preg_replace('#\.html$#', '', make_ubb_url("ubb=download&Number=$file_id&filename=$filename_orig", "", false)) . "\">$filename_orig</a> <span class=\"op5 small nw\">(" . file_size($size) . ", $downloads {$ubbt_lang['DOWNLOADS']})</span><br>";
								if ($file_desc) {
									$postrow[$i]['filelink'] .= "<i class=\"far fa-fw\" aria-hidden=\"true\">&nbsp;</i> <span class=\"small\">$file_desc</span><br>";
								}
								if ($file_sha1) {
									$postrow[$i]['filelink'] .= "<i class=\"far fa-fw\" aria-hidden=\"true\">&nbsp;</i> <span class=\"op5 small\">SHA1: $file_sha1</span><br>";
								}
								$postrow[$i]['filelink'] .= "</div>";
							}
						}
					} else {
						$postrow[$i]['thumbs'][] = array(
							"id" => $file_id,
							"src" => "{$config['FULL_URL']}/gallery/$file_dir/thumbs/$file_id.$ext",
							"med" => "{$config['FULL_URL']}/gallery/$file_dir/medium/$file_id.$ext",
							"url" => "{$config['FULL_URL']}/gallery/$file_dir/full/$file_id.$ext",
							"desc" => ubbchars($file_desc, ENT_QUOTES),
							"width" => $file_width,
							"height" => $file_height,
							"size" => file_size($size),
							"filename_orig" => $filename_orig,
						);
					}
				}
			}
		}

		$postrow[$i]['filecount'] = $filecount;

// Like Post
		if ($show_likes == 1) {

// Generate the like page
			$postrow[$i]["likepage"] = make_ubb_url("ubb=like&type=post&target={$Number}", "", false);

// Fetch the amount of likes each post has
			$query = "
				SELECT count(*)
				FROM {$config['TABLE_PREFIX']}LIKES
				WHERE TYPE = 'p'
				  AND POST_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
			list($likes) = $dbh->fetch_array($sth);
			$postrow[$i]["likes"] = $likes;

// Check if the user has liked this post before
			$query = "
				SELECT count(*)
				FROM {$config['TABLE_PREFIX']}LIKES
				WHERE TYPE = 'p'
				 AND POST_ID = ?
				 AND USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($Number, $user["USER_ID"]), __LINE__, __FILE__);
			list($user_like) = $dbh->fetch_array($sth);

// Adjust the wording if a user has already liked this post
			if ($user_like == 1) {
				$postrow[$i]['hasliked'] = 1;
				$postrow[$i]["liketext"] = "<i class=\"far fa-thumbs-up fa-fw\"></i> " . $ubbt_lang["POST_UNLIKE"];
				$postrow[$i]['isliked'] = "class=\"bold\"";
			} else {
				$postrow[$i]['hasliked'] = 0;
				$postrow[$i]["liketext"] = $ubbt_lang["POST_LIKE"];
				$postrow[$i]['isliked'] = "";
			}

// Fetch users who've liked this post
			if (($show_user_likes == 1) && ($postrow[$i]["likes"] >= 1)) {
				if ($postrow[$i]["likes"] == 1) {
					$postrow[$i]["liked"] = $ubbt_lang["LIKED1"];
				} else {
					$postrow[$i]["liked"] = $ubbt_lang["LIKED"];
				}
				$query = "
						SELECT
							u.USER_DISPLAY_NAME, u.USER_ID, u.USER_MEMBERSHIP_LEVEL, p.USER_NAME_COLOR, l.TIMESTAMP
						FROM
							{$config['TABLE_PREFIX']}LIKES AS l,
							{$config['TABLE_PREFIX']}USERS AS u,
							{$config['TABLE_PREFIX']}USER_PROFILE AS p
						WHERE
							l.TYPE = 'p'
						AND l.POST_ID = '" . $Number . "'
						AND	l.USER_ID = u.USER_ID
						AND u.USER_ID = p.USER_ID
						ORDER BY
							l.TIMESTAMP DESC
						LIMIT
							$like_user_limit
				";

				$sth = $dbh->do_query($query);

				if (($postrow[$i]["likes"] - $like_user_limit) >= 1) {
					$postrow[$i]["undisplayed_likes"] = $postrow[$i]["likes"] - $like_user_limit; // 1
				} else {
					$postrow[$i]["undisplayed_likes"] = 0;
				}

				$users = array();
				$l = 0;
				while (list($uname, $uid, $level, $color, $timestamp) = $dbh->fetch_array($sth)) {
					$postrow[$i]["users"][$l]["cname"] = $html->user_color($uname, $color, $level);
					$postrow[$i]["users"][$l]["name"] = $uname;
					$postrow[$i]["users"][$l]["uid"] = $uid;
					$postrow[$i]["users"][$l]["timestamp"] = $html->convert_time($timestamp, $useroffset, "M jS Y", 1, 0);
					$l++;
				}
			}
		}

		// Edit Button?
		$postrow[$i]['editlink'] = "";
		if ($edit == "on") {
			$postrow[$i]['editlink'] = make_ubb_url("ubb=editpost&Board={$topic_info['FORUM_ID']}&Number=$Number&what={$mode}", "", false);
		}

		// Reply and Quote Button?
		$postrow[$i]['replylink'] = "";
		$postrow[$i]['quotelink'] = "";

		if ($reply == "on") {
			$postrow[$i]['replylink'] = make_ubb_url("ubb=newreply&Board={$topic_info['FORUM_ID']}&Number=$Number&what={$mode}&fpart=$page", "", false);
			$postrow[$i]['quotelink'] = make_ubb_url("ubb=newreply&Board={$topic_info['FORUM_ID']}&Number=$Number&what={$mode}&fpart=$page&q=1", "", false);

		}

		// If there is a poll in this post, we need to include includepoll.php
		// or includepollresults.php depending on if they voted or not
		$postrow[$i]['showpoll'] = "";
		if ($Poll) {
			$what = "{$mode}";
			include("libs/includepoll.inc.php");
			$postrow[$i]['showpoll'] = $showpoll;
		}

		// Is Active Text enabled?
		if ($config['ENABLE_ACTIVE_TEXT']) {
			$results[$i]['POST_BODY'] = $html->active_text($results[$i]['POST_BODY']);
		}

		// Are we ignoring this user?
		if (stristr($user['USER_IGNORE_LIST'], "-{$usernum}-")) {
			$postrow[$i]['Ignoring'] = "1";
		}

		// Wrap the postrow body item
		$postrow[$i]['Body'] = "<div id=\"body$i\">{$results[$i]['POST_BODY']}</div>";

		// Grab SEO stuff here from 1st post
		if ($i == 0) {
			$ogUrl = make_ubb_url("ubb=showflat&Number={$Number}", '', true);
			$ogDescription = str_replace('<br>', ' ', $results[$i]['POST_BODY']);
			$ogDescription = ubbchars(strip_tags($ogDescription));
			if (strlen($ogDescription) > 290) {
				$ogDescription = substr($ogDescription, 0, 290) . '...';
			}

			// Now add any pagination SEO, only if there is more than one page
			$ogPagination = '';
			if (($show_all_posts == 0) && $pages > 1) {
				if ($page == 1) {
					$ogPagination = '<link rel="next" href="' . make_ubb_url("ubb=showflat&Number={$Number}&page=2", '', true) . '">';
				} elseif ($page == $pages) {
					$prevPage = $pages - 1;
					$ogPagination = '<link rel="prev" href="' . make_ubb_url("ubb=showflat&Number={$Number}&page={$prevPage}", '', true) . '">';
				} else {
					$nextPage = $page + 1;
					$prevPage = $page - 1;
					$ogPagination = '<link rel="next" href="' . make_ubb_url("ubb=showflat&Number={$Number}&page={$nextPage}", '', true) . '">
					';
					$ogPagination .= '<link rel="prev" href="' . make_ubb_url("ubb=showflat&Number={$Number}&page={$prevPage}", '', true) . '">';
				}
			}
		}

		// Only certain options for users that are logged in
		$addfavlinkstart = "";
		$addfavlinkstop = "";
		$mailpostlink = "";
		$notifylinkstart = "";
		$notifylinkstop = "";
		if ($user['USER_DISPLAY_NAME']) {
			if ($userob->check_access("site", "MAIL_POST") && $topic_info['TOPIC_STATUS'] != "M") {
				$postrow[$i]['mailpostlink'] = make_ubb_url("ubb=mailthread&Board={$topic_info['FORUM_ID']}&Number=$Number&fpart=$page&what={$mode}", "", false);
			}

			if ($topic_info['TOPIC_STATUS'] != "M") {
				$postrow[$i]['notifylink'] = make_ubb_url("ubb=notifymod&Board={$topic_info['FORUM_ID']}&Number=$Number&fpart=$page&what={$mode}", "", false);
			}
		}

		$postrow[$i]['Number'] = $Number;

		// Set a default mood
		if (!$results[$i]['USER_MOOD'] || !$config['ENABLE_MOODS']) {
			$results[$i]['USER_MOOD'] = "content.gif";
		}

		$mood_alt = preg_replace("#.(gif|jpg|png)$#", "", $results[$i]['USER_MOOD']);
		if (!$config['ENABLE_MOODS']) {
			$mood_alt = "";
		}

		$postrow[$i]['mood'] = $results[$i]['USER_MOOD'];
		$postrow[$i]['mood_alt'] = $mood_alt;


		// Need to setup a query for parentusers
		if ($ParentUser) {
			if (!preg_match("/'$ParentUser'/", $parentusers)) {
				$parentusers .= "'$ParentUser',";
			}
			$replyarray[$replycount]['postrow'] = $i;
			$replyarray[$replycount]['parentuser'] = $ParentUser;
			$replycount++;
		}

		// If this is a gallery post, then we need to seperate the gallery post and the comments

		$Subject = $postrow[$i]['Subject'];

		if ($forum_info['FORUM_IS_GALLERY'] && $i > 0) {
			if ($page == 1 && $i == 1) {
				$commentrow[$i] = array();
				unset($postrow[$i]);
			} else {
				$commentrow[$i] = $postrow[$i];
				unset($postrow[$i]);
			}
		}
	}

	if ($parentusers) {
		$parentusers = preg_replace("/,$/", "", $parentusers);
		$query = "
			SELECT USER_ID, USER_DISPLAY_NAME
			FROM {$config['TABLE_PREFIX']}USERS
			WHERE USER_ID IN ($parentusers)
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		while (list($pnumber, $pname) = $dbh->fetch_array($sth)) {
			if ($pname == "**DONOTDELETE**") {
				$pname = $ubbt_lang['ANON_TEXT'];
			}
			$parentarray[$pnumber] = $pname;
		}
		for ($i = 0; $i < $replycount; $i++) {
			$rownum = $replyarray[$i]['postrow'];
			$rowparent = $replyarray[$i]['parentuser'];

			if ($forum_info['FORUM_IS_GALLERY']) {
				$parentpost = $commentrow[$rownum]['ParentPost'];
				if (array_get($commentrow, $rownum, false)) {
					$commentrow[$rownum]['replyto'] = "<a href=\"" . make_ubb_url("ubb={$mode}&Number={$commentrow[$rownum]['ParentPost']}#Post{$commentrow[$rownum]['ParentPost']}", $parentarray[$rowparent], false) . "\" class=\"nd\" title=\"{$ubbt_lang['RESPONSE_TO']}\" rel=\"nofollow\"><i class=\"fas fa-share fa-fw\"></i> {$parentarray[$rowparent]}</a>";
				}
			} else {
				$parentpost = $postrow[$rownum]['ParentPost'];
				if (array_get($postrow, $rownum, false)) {
					$postrow[$rownum]['replyto'] = "<a href=\"" . make_ubb_url("ubb={$mode}&Number={$postrow[$rownum]['ParentPost']}#Post{$postrow[$rownum]['ParentPost']}", $parentarray[$rowparent], false) . "\" class=\"nd\" title=\"{$ubbt_lang['RESPONSE_TO']}\" rel=\"nofollow\"><i class=\"fas fa-share fa-fw\"></i> {$parentarray[$rowparent]}</a>";
				}
			}
		}
	}

	// If this is a gallery, we'll have a couple empty array elements at the beginning, shift those off
	if ($forum_info['FORUM_IS_GALLERY']) {
		if ($page == 1) {
			array_shift($commentrow);
			array_shift($commentrow);
		} else {
			array_shift($commentrow);
		}
	}

	// Now let's figure out who's online and who isn't
	$inlist = "";
	$online_status = array();
	foreach ($users_in_topic as $o_uid => $o_vis) {
		$online_status[$o_uid] = 0;
		if (!$config['DISABLE_ONLINE_INVISIBLE'] && $o_vis == "no" && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
			continue;
		}
		$inlist .= "'$o_uid',";
	}
	$inlist = preg_replace("#,$#", "", $inlist);

	if (!$inlist) $inlist = "''";
	$query = "
		SELECT USER_ID
		FROM {$config['TABLE_PREFIX']}ONLINE
		WHERE USER_ID IN ($inlist)
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	while (list($o_uid) = $dbh->fetch_array($sth)) {
		$online_status[$o_uid] = 1;
	}

	// Do they see the manage thread link?
	if ($userob->check_access("forum", "MOVE_ANY", $topic_info['FORUM_ID'])) {
		$manageoptions .= "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=movethread&Number={$topic_info['TOPIC_ID']}", "", false) . "\" class=\"nd\">{$ubbt_lang['MOVE_THREAD']}</a></td></tr>";
	}
	if ($userob->check_access("forum", "DELETE_TOPICS", $topic_info['FORUM_ID'])) {
		$manageoptions .= "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=expirethreads&Number={$topic_info['TOPIC_ID']}", "", false) . "\" class=\"nd\">{$ubbt_lang['DELETE_THREAD']}</a></td></tr>";
	}
	if ($userob->check_access("forum", "LOCK_ANY", $topic_info['FORUM_ID']) && $topic_info['TOPIC_STATUS'] != "M") {
		if ($topic_info['TOPIC_STATUS'] == "C") {
			$manageoptions .= "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=doopenthreads&Number={$topic_info['TOPIC_ID']}", "", false) . "\" class=\"nd\">{$ubbt_lang['UNLOCK_THREAD']}</a></td></tr>";
		} else {
			$manageoptions .= "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=doclosethreads&Number={$topic_info['TOPIC_ID']}", "", false) . "\" class=\"nd\">{$ubbt_lang['LOCK_THREAD']}</a></td></tr>";
		}
	}
	if ($userob->check_access("forum", "STICKY_ANY", $topic_info['FORUM_ID']) && !$forum_info['FORUM_IS_GALLERY']) {
		if (!$topic_info['TOPIC_IS_STICKY'] && $topic_info['TOPIC_STATUS'] != "M") {
			$manageoptions .= "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=stickpost&Number={$topic_info['TOPIC_ID']}", "", false) . "\" class=\"nd\">{$ubbt_lang['STICK_THREAD']}</a></td></tr>";
		} elseif ($topic_info['TOPIC_IS_STICKY'] == '1' && $topic_info['TOPIC_STATUS'] != "M") {
			$manageoptions .= "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=unstickpost&Number={$topic_info['TOPIC_ID']}", "", false) . "\" class=\"nd\">{$ubbt_lang['UNSTICK_THREAD']}</a></td></tr>";
		}
	}
	if ($userob->check_access("site", "ANNOUNCEMENTS")) {
		if (!$topic_info['TOPIC_IS_STICKY'] && $topic_info['TOPIC_STATUS'] != "M") {
			$manageoptions .= "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=stickpost&Number={$topic_info['TOPIC_ID']}&announce=1", "", false) . "\" class=\"nd\">{$ubbt_lang['ANNOUNCE_THREAD']}</a></td></tr>";
		} elseif ($topic_info['TOPIC_IS_STICKY'] == '1' && $topic_info['TOPIC_STATUS'] != "M") {
			$manageoptions .= "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=stickpost&Number={$topic_info['TOPIC_ID']}&announce=1", "", false) . "\" class=\"nd\">{$ubbt_lang['ANNOUNCE_THREAD']}</a></td></tr>";
		} elseif ($topic_info['TOPIC_IS_STICKY'] == '2') {
			$manageoptions .= "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=unstickpost&Number={$topic_info['TOPIC_ID']}&announce=1", "", false) . "\" class=\"nd\">{$ubbt_lang['NOANNOUNCE_THREAD']}</a></td></tr>";
		}
	}

	// If they get any manage options, then let them rename the topic
	if ($manageoptions) {
		$manageoptions = "<tr><td class='popup_menu_content'><a href=\"" . make_ubb_url("ubb=dorenamethreads&Number={$topic_info['TOPIC_ID']}", "", false) . "\" class=\"nd\">{$ubbt_lang['RENAME_THREAD']}</a></td></tr>" . $manageoptions;
	}

	if ($user['USER_ID'] && $updatelast) {
		$query_vars = array($rightnow, $topic_info['FORUM_ID'], $user['USER_ID']);
		$query = "
			REPLACE INTO
				{$config['TABLE_PREFIX']}FORUM_LAST_VISIT
				(LAST_VISIT_TIME, FORUM_ID, USER_ID)
			VALUES
				(?, ?, ?)
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}

	// If necessary set a cookie that marks this topic as read
	if ($updatelast) {
		$_SESSION['topicread'][$topic_info['TOPIC_ID']] = $html->get_date();
	}

	// If mode is showthreaded, then we need to show the tree
	$topic_tree = array();
	if ($mode == "showthreaded") {
		$topic_id = $topic_info['TOPIC_ID'];
		include("libs/topic_tree.inc.php");
	}

	// Load the quickreply template?
	$quickreply = "";
	$quickdisplay = "style=\"display:none;\"";
	$lastnumber = 0;
	if (($config['ENABLE_QUICK_REPLY']) && ($reply == "on")) {
		$qboard = $topic_info['FORUM_ID'];
		if (isset($realboard)) {
			$qboard = $realboard;
		}
		$lastnumber = $Number;
		$lastsubject = $Subject;
		if (!preg_match("/^Re:/", $lastsubject)) {
			$lastsubject = "Re: " . $lastsubject;
		}
		$lastsubject = str_replace('"', "&quot;", $lastsubject);
		$what = "{$mode}";
		$isreged = "0";
		if ($user['USER_DISPLAY_NAME']) {
			$addsig = "<input type=\"checkbox\" name=\"addsig\" id=\"addsig\" value=\"1\" checked=\"checked\" class=\"form-checkbox\"> <label for=\"addsig\">{$ubbt_lang['ADDSIG']}</label>";
			$isreged = "1";
		} else {
			$addsig = "";
		}

		// -------------------------------------
		// What options do they have for posting
		$markupselect = "";
		if (($config['MARKUP_HTML_TOGGLE'] == 1) || ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") || (preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
			$markupselect .= "<select name=\"convert\" id=\"convert\" class=\"form-select\">";
			if ($userob->check_access("forum", "USE_MARKUP", $topic_info['FORUM_ID'])) {
				$markupselect .= "<option value=\"markup\" selected=\"selected\">{$ubbt_lang['USE_MARKUP']}</option>";
			}
			if ($userob->check_access("forum", "USE_HTML", $topic_info['FORUM_ID'])) {
				$markupselect .= "<option value=\"html\">{$ubbt_lang['USE_HTML']}</option>";
			}
			if (($userob->check_access("forum", "USE_HTML", $topic_info['FORUM_ID'])) && ($userob->check_access("forum", "USE_MARKUP", $topic_info['FORUM_ID']))) {
				$markupselect .= "<option value=\"both\">{$ubbt_lang['USE_BOTH']}</option>";
			}
			if ((!$userob->check_access("forum", "USE_HTML", $topic_info['FORUM_ID'])) && (!$userob->check_access("forum", "USE_MARKUP", $topic_info['FORUM_ID']))) {
				$markupselect .= "<option value=\"none\">{$ubbt_lang['USE_NONE']}</option>";
			}
			$markupselect .= "</select>";
		}

		$smarty->assign("qboard", $qboard);
		$smarty->assign("parentPost", $topic_info['POST_ID']);
		$smarty->assign("isreged", $isreged);
		$smarty->assign("current", $topic_info['TOPIC_ID']);
		$smarty->assign("first_post", $topic_info['POST_ID']);
		$smarty->assign("lastnumber", $lastnumber);
		$smarty->assign("what", $mode);
		$smarty->assign("fpart", $page);
		$smarty->assign("gallery", $forum_info['FORUM_IS_GALLERY']);
		$smarty->assign("TEXT_AREA_COLUMNS", $config['TEXT_AREA_COLUMNS']);
		$smarty->assign("TEXT_AREA_ROWS", $config['TEXT_AREA_ROWS']);
		$smarty->assign("lastsubject", $lastsubject);
		$smarty->assign("htmlcode", $htmlcode);
		$smarty->assign("page", $page);
		$smarty->assign("ubbcode", $ubbcode);
		$smarty->assign("markupselect", $markupselect);
		$smarty->assign("addsig", $addsig);
		$smarty->assign("guest_captcha", $userob->check_access("forum", "CAPTCHA", $qboard));

		$quickreply = $smarty->fetch("quickreply.tpl");
		$quickdisplay = "";
	}

	// Displaying ads between 1st and 2nd post? If so, check if the user must see it
	if ($forum_info['FORUM_ISLAND_INSERT'] && $userob->check_access("forum", "AD_ISLAND", $topic_info['FORUM_ID'])) {
		$island_insert = get_portal_box("portal_box_{$forum_info['FORUM_ISLAND_INSERT']}.php");
	}

	// Determine social sharing options
//	if (!$config['YOUR_TWITTER']) $config['YOUR_TWITTER'] = "ubbcentral";
	$shareHeader = 0;
	if (!$guestReadable) {
		$facebook = 0;
		$twitter = 0;
		$reddit = 0;
		$shareaholic = 0;
	} else {
		$facebook = $config['FACEBOOK'];
		$twitter = $config['TWITTER'];
		$reddit = $config['REDDIT'];
		$shareaholic = 0;
		if (is_numeric($config['SHAREAHOLIC']) && $config['SHAREAHOLIC'] > 0) {
			$shareaholic = '<div class="shareaholic-canvas" data-link="' . $ogUrl . '" data-app="share_buttons" data-app-id="' . $config['SHAREAHOLIC'] . '"></div>';
			$shareHeader = 1;
		}
	}
	$smarty_data = array(
		"CatNumber" => $forum_info['CATEGORY_ID'],
		"facebook" => $facebook,
		"twitter" => $twitter,
		"reddit" => $reddit,
		"shareaholic" => $shareaholic,
		"Number" => $Number,
		"ratee" => $user['USER_ID'],
		"Board" => $topic_info['FORUM_ID'],
		"title" => $forum_info['FORUM_TITLE'],
		"prevlink" => $prevlink,
		"currentlink" => $return_to_link,
		"alttext" => $alttext,
		"linktext" => $linktext,
		"nextlink" => $nextlink,
		"threadnumber" => $postnumber,
		"an" => $an,
		"postrow" => & $postrow,
		"commentrow" => & $commentrow,
		"managejump" => & $managejump,
		"pageprint1" => $pageprint1,
		"pageprint2" => $pageprint2,
		"modlist" => $modlist,
		"addfavoption" => $addfavoption,
		"current" => $topic_info['TOPIC_ID'],
		"ThreadRating" => $ThreadRating,
		"ratingtotal" => $topic_info['TOPIC_TOTAL_RATES'],
		"ratingaverage" => $topic_info['TOPIC_RATING'],
		"myrating" => $myrating,
		"count" => $topic_info['TOPIC_VIEWS'],
		"comments" => $topic_info['TOPIC_REPLIES'],
		"opid" => $opid,
		"ratinghtml" => $ratinghtml,
		"jumpbox" => & $jumpbox,
		"ishopto" => $ishopto,
		"manageoptions" => & $manageoptions,
		"quickreply" => & $quickreply,
		"quickdisplay" => $quickdisplay,
		"island_insert" => & $island_insert,
		"popups" => & $popups,
		"closed" => $closed,
		"reply" => $reply,
		"first_post" => $topic_info['POST_ID'],
		"online_status" => & $online_status,
		"mode" => $mode,
		"switch" => $switch,
		"switch_text" => $switch_text,
		"topic_tree" => $topic_tree,
		"post_layout" => $post_layout,
		"gallery_comments" => $gallery_comments,
		"is_gallery" => $forum_info['FORUM_IS_GALLERY'],
		"newtopic" => $newtopic,
		"facebookURL" => $ogUrl,
		"show_likes" => $show_likes,
		"show_user_likes" => $show_user_likes,
		"self_like" => $self_like,
		"show_avatars" => $AVATARS_WITH_POSTS,
	);

	if ($ajax) {
		$data['template'] = "post_{$post_layout}";
		$data['data'] = $smarty_data;
		smartyDisplay($data);
		return false;
	}

	if ($forum_info['FORUM_IS_GALLERY']) {
		$js_array = array(
			0 => "quickquote.js",
			1 => "image.js",
			2 => "gallery.js",
			3 => "assets/jquery.clipboard.min.js",
		);
	} else {
		$js_array = array(
			0 => "quickquote.js",
			1 => "image.js",
			2 => "assets/jquery.clipboard.min.js",
		);
	}

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $topic_info['TOPIC_SUBJECT'],
			"forum_title" => $forum_info['FORUM_TITLE'],
			"ogUrl" => $ogUrl,
			"ogDescription" => $ogDescription,
			"ogPagination" => $ogPagination,
			"shareHeader" => $shareHeader,
			"breadcrumb" => ' <a href="' . $cfrm . '">' . $ubbt_lang['FORUM_TEXT'] . '</a>',
			"refresh" => 0,
			"user" => $user,
			"Board" => $topic_info['FORUM_ID'],
			"Category" => $forum_info['CATEGORY_ID'],
			"post_subject" => $topic_info['TOPIC_SUBJECT'],
			"post_id" => $Number,
			"forum_parent" => $forum_info['FORUM_PARENT'],
			"custom_header_footer" => $forum_info['FORUM_CUSTOM_HEADER'],
			"rss" => $forum_info['FORUM_IS_RSS'],
			"rss_title" => $forum_info['FORUM_RSS_TITLE'],
			"bypass" => 0,
			"onload" => "",
			"onunload" => "clearSubmit()",
			"javascript" => $js_array,
		),
		"template" => "showflat",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>