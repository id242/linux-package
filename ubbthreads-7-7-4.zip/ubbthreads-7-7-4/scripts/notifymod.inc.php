<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function &page_notifymod_gpc() {
	return array(
		"input" => array(
			"Board" => array("Board", "get", "int"),
			"Number" => array("Number", "get", "int"),
			"fpart" => array("fpart", "get", "alphanum"),
			"what" => array("what", "get", "alpha"),
		),
		"wordlets" => array("notifymod"),
		"user_fields" => "t2.USER_REAL_EMAIL",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function &page_notifymod_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$Username = $user['USER_DISPLAY_NAME'];
	$html = new html;

	// -----------------------------------------------------------------------------
	// Once and a while if people try to just put a number into the url, lets trap it
	if (!$Number) {
		$html->not_right($ubbt_lang['NO_POST']);
	}

	// --------------------------------------------
	// Let's find out if they should be here or not
	$query = "
		SELECT FORUM_TITLE,CATEGORY_ID,FORUM_PARENT,FORUM_IS_RSS,FORUM_RSS_TITLE
		FROM   {$config['TABLE_PREFIX']}FORUMS
		WHERE  FORUM_ID = ?
		AND FORUM_IS_ACTIVE='1'
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list($title, $CatNumber, $parent_id, $is_rss, $rss_title) = $dbh->fetch_array($sth);


	if (!$userob->check_access("forum", "SEE_FORUM", $Board)) {
		$html->not_right($ubbt_lang['BAD_GROUP']);
	}

	// --------------------------------------------------
	// Now let's see if the mod has already been notified
	$query = "
		SELECT POST_ID
		FROM   {$config['TABLE_PREFIX']}MODERATOR_NOTIFICATIONS
		WHERE  POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($check) = $dbh->fetch_array($sth);
	if ($check) {
		$html->not_right("{$ubbt_lang['NO_NOTIFY']}");
	}

	$smarty_data = array(
		"Board" => $Board,
		"Number" => $Number,
		"what" => $what,
		"fpart" => $fpart,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['NOTIFY_MOD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $CatNumber,
			"parent_forum" => $parent_id,
			"bypass" => 0,
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		),
		"template" => "notifymod",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>