<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.2
  Purpose:
  Future:
*/

function page_delete_gpc() {
	return array(
		"input" => array(
			"checked" => array("check-inline", "post", "int"),
			"page" => array("page", "post", "int"),
			"deletecheck" => array("deletecheck", "post", ""),
			"emailcheck" => array("emailcheck", "post", ""),
			"thendelcheck" => array("thendelcheck", "post", "int"),
		),
		"wordlets" => array("mess_handler"),
		"user_fields" => "t2.USER_REAL_EMAIL",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_delete_run() {
	global $user, $html, $in, $ubbt_lang, $config, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$processed = 0;
	foreach ($checked as $id) {
		$processed++;

		// Email before possible deletion
		if ($emailcheck) {
			// ----------------------------------------
			// Get the message(s) in this Private topic
			$query = "
				SELECT	p.POST_ID, t.TOPIC_SUBJECT, p.POST_BODY, p.POST_DEFAULT_BODY, u.USER_DISPLAY_NAME, p.POST_TIME
				FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS p,
							{$config['TABLE_PREFIX']}USERS u,
							{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS t
				WHERE	p.TOPIC_ID = ?
					AND	p.TOPIC_ID = t.TOPIC_ID
					AND	p.USER_ID = u.USER_ID
				ORDER BY p.POST_TIME
			";
			$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);

			// Format this up and send it
			$mailer = new mailer();
			$mailer->set_language($user['USER_LANGUAGE']);
			$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $user['USER_DISPLAY_NAME']));
			$mailer->set_subject('DMP_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
			$mailer->add_content('DMP_CONTENT', null);

			// Loop thru all the posts
			$numposts = $dbh->total_rows($sth);
			for ($i = 0; $i < $numposts; $i++) {
				list($postid, $tsubject, $hbody, $tbody, $username, $rawtime) = $dbh->fetch_array($sth);

				$posttime = array($rawtime, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
				$mailer->add_post($username, $tsubject, $posttime, $hbody, $tbody, array(), true);
			}
			$mailer->ubbt_mail($user['USER_REAL_EMAIL']);
		}

		// Check if deletion is desired
		if ($deletecheck || ($thendelcheck == 1)) {
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
				WHERE	 USER_ID = ?
					AND	 TOPIC_ID = ?
			";
			$dbh->do_placeholder_query($query, array($user['USER_ID'], $id), __LINE__, __FILE__);

			if (!$dbh->affected_rows()) {
				continue;
			}
			$query = "
				SELECT 	count(*)
					FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
				WHERE	  TOPIC_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
			list($total) = $dbh->fetch_array($sth);

			// If no one is left in this topic, we kill it. Otherwise add a 'removed from topic message'
			if (!$total) {
				$query = "
					DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
					WHERE TOPIC_ID = ?
				";
				$dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
				$query = "
					DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
					WHERE  TOPIC_ID = ?
				";
				$dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
			} else {
				$note = "{$user['USER_DISPLAY_NAME']} {$ubbt_lang['REMOVED']}";
				$query_vars = array($id, $user['USER_ID'], $note, $html->get_date(), $note);
				$query = "
					INSERT INTO {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
						(TOPIC_ID,USER_ID,POST_BODY,POST_TIME,POST_DEFAULT_BODY)
					VALUES
						( ? , ? , ? , ? , ? )
				";
				$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
			}
		}
	}

	// Only do this, if we are deleting
	if ($deletecheck || ($thendelcheck == 1)) {
		// Check and see if there are any more unread PMs
		$query = "
			SELECT count(*)
				FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS pmu,
						 {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS pmt
			WHERE	pmu.TOPIC_ID = pmt.TOPIC_ID
				AND	pmt.TOPIC_LAST_REPLY_TIME > pmu.MESSAGE_LAST_READ
				AND pmu.USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
		list($total_unread) = $dbh->fetch_array($sth);

		$query = "
			UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
			SET		 USER_TOTAL_PM = ?
			WHERE	 USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($total_unread, $user['USER_ID']), __LINE__, __FILE__);
	}

	// ---------------------------------------------------
	// Give confirmation and return to thread viewmessages
	$body = $html->substitute($ubbt_lang['PM_HOWMANY'], array('HOWMANY' => $processed));
	$html->send_redirect(
		array(
			"redirect" => "viewmessages&page=$page",
			"heading" => $ubbt_lang['PM_SUBJECT'],
			"body" => $body,
			"returnlink" => "<a href=\"" . make_ubb_url("ubb=viewmessages&page=$page", "", false) . "\">{$ubbt_lang['PM_RETURN']}</a>",
		)
	);
}

?>