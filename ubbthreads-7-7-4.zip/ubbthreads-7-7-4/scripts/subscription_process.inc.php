<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_subscription_process_gpc() {
	return array(
		"input" => array(
			"id" => array("id", "post", "int"),
			"method" => array("method", "post", "alpha"),
			"payment" => array("payment", "both", "alpha"),
			"cancel" => array("cancel", "both", ""),
			"thanks" => array("thanks", "both", ""),
			"invoice" => array("invoice", "post", "int"),
		),
		"wordlets" => array("subscriptions"),
		"user_fields" => "t1.USER_LOGIN_NAME",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_subscription_process_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Cancel this order
	if ($cancel) {

		$query = "
			delete from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
			where SUBSCRIPTION_ID = ?
		";
		$dbh->do_placeholder_query($query, array($invoice), __LINE__, __FILE__);

		$html->send_redirect(
			array(
				"redirect" => "subscriptions",
				"heading" => "{$ubbt_lang['CANCEL']}",
				"body" => "{$ubbt_lang['CANCEL_BODY']}",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['CANCEL']}
BREADCRUMB
			,
			)
		);
		exit;
	}

	// Thank you for this order
	if ($thanks) {

		$html->send_redirect(
			array(
				"redirect" => "subscriptions",
				"heading" => "{$ubbt_lang['THANKS']}",
				"body" => "{$ubbt_lang['THANKS_BODY']}",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['THANKS']}
BREADCRUMB
			,
			)
		);
		exit;
	}

	// Make sure a payment type is specified
	if (!$payment) {
		$html->not_right($ubbt_lang['NO_METHOD']);
	}

	$query = "
		select SUBSCRIPTION_NAME,SUBSCRIPTION_DESCRIPTION,SUBSCRIPTION_BY_DONATION,SUBSCRIPTION_DONATION_AMOUNT,SUBSCRIPTION_BY_TRIAL,SUBSCRIPTION_TRIAL_AMOUNT,SUBSCRIPTION_TRIAL_DURATION,SUBSCRIPTION_TRIAL_INTERVAL,SUBSCRIPTION_BY_REGULAR,SUBSCRIPTION_REGULAR_AMOUNT,SUBSCRIPTION_REGULAR_DURATION,SUBSCRIPTION_REGULAR_INTERVAL,SUBSCRIPTION_IS_RECURRING
		from {$config['TABLE_PREFIX']}SUBSCRIPTIONS
		where GROUP_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	list($name, $desc, $donation, $d_amount, $trial, $trial_amount, $trial_duration, $trial_interval, $regular, $regular_amount, $regular_duration, $regular_interval, $recurr) = $dbh->fetch_array($sth);

	// Make sure this group has an active subscription
	if (!$donation && !$regular) {
		$html->not_right($ubbt_lang['NOT_ENABLED']);
	}

	$mystuff = $html->mystuff($user['USER_ID']);

	/*
		if ($d_amount == "0.00") {
			$d_amount = $html->substitute($ubbt_lang['D_AMOUNT'], array('CURRENCY' => $ubbt_lang['ANY'],'AMOUNT' => $ubbt_lang['AMOUNT']));
		} else {
			$d_amount = $html->substitute($ubbt_lang['D_AMOUNT'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $d_amount));
		}

		$check_mo = 0;
		if ($config['ALLOW_MAIL'] != "no_check_mo") {
			$check_mo = 1;
			$check_mo_text = $ubbt_lang[strtoupper($config['ALLOW_MAIL'])];
		}

	*/

	if ($method == "donate") {
		$order_type = $ubbt_lang['DONATION'];
	} else {
		$order_type = $ubbt_lang['BY_SUB'];
	}

	// Order by Check or Money Order
	if ($payment == "check") {
		if ($config['ALLOW_MAIL'] == "check") {
			$allowed = $ubbt_lang['CHECK'];
		} elseif ($config['ALLOW_MAIL'] == "mo") {
			$allowed = $ubbt_lang['MO'];
		} elseif ($config['ALLOW_MAIL'] == "check_mo") {
			$allowed = $ubbt_lang['CHECK_MO'];
		}

		if ($method == "donate") {
			if ($d_amount == "0.00" || !$d_amount) {
				$ins_string = $html->substitute($ubbt_lang['MAIL_INS_BODY'], array('CURRENCY' => "", 'AMOUNT' => "{$ubbt_lang['ANY_AMOUNT']}", 'PAYCURRENCY' => $ubbt_lang['PAY' . $config['CURRENCY']], 'PAYMENT' => $allowed));
				$order_details = $html->substitute($ubbt_lang['CONFIRM_D_AMOUNT'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => '________.__'));
				$payment_amount = $html->substitute($ubbt_lang['PAYMENT_LINE'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => '________.__'));
			} else {
				$ins_string = $html->substitute($ubbt_lang['MAIL_INS_BODY'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $d_amount, 'PAYCURRENCY' => $ubbt_lang['PAY' . $config['CURRENCY']], 'PAYMENT' => $allowed));
				$order_details = $html->substitute($ubbt_lang['CONFIRM_D_AMOUNT'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $d_amount));
				$payment_amount = $html->substitute($ubbt_lang['PAYMENT_LINE'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $d_amount));

			}
		} else {

			$order_details = "";
			if ($trial) {
				$period = $trial_duration;
				if ($trial_interval == "D") $period .= " {$ubbt_lang['DAY']}";
				if ($trial_interval == "W") $period .= " {$ubbt_lang['WEEK']}";
				if ($trial_interval == "M") $period .= " {$ubbt_lang['MONTH']}";
				if ($trial_interval == "Y") $period .= " {$ubbt_lang['YEAR']}";
				$order_details = $html->substitute($ubbt_lang['TRIAL_PERIOD'], array('PERIOD' => $period, 'CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $trial_amount)) . "<br>";
			}

			$regular_string = "";
			if ($regular) {
				if ($recurr) $recurring = $ubbt_lang['RECURRING'];
				$period = $regular_duration;
				if (regular_duration == 1) {
					if ($regular_interval == "D") $period .= " {$ubbt_lang['DAY']}";
					if ($regular_interval == "W") $period .= " {$ubbt_lang['WEEK']}";
					if ($regular_interval == "M") $period .= " {$ubbt_lang['MONTH']}";
					if ($regular_interval == "Y") $period .= " {$ubbt_lang['YEAR']}";
				} else {
					if ($regular_interval == "D") $period .= " {$ubbt_lang['DAYS']}";
					if ($regular_interval == "W") $period .= " {$ubbt_lang['WEEKS']}";
					if ($regular_interval == "M") $period .= " {$ubbt_lang['MONTHS']}";
					if ($regular_interval == "Y") $period .= " {$ubbt_lang['YEARS']}";
				}
				$order_details .= $html->substitute($ubbt_lang['REGULAR_PERIOD'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $regular_amount, 'PERIOD' => $period, 'RECURRING' => ''));
			}

			$total_amount = $trial_amount + $regular_amount;
			$ins_string = $html->substitute($ubbt_lang['MAIL_INS_BODY'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $total_amount, 'PAYCURRENCY' => $ubbt_lang['PAY' . $config['CURRENCY']], 'PAYMENT' => $allowed));
			$payment_amount = $html->substitute($ubbt_lang['PAYMENT_LINE'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $total_amount));
		}


		$address = nl2br($config['PAYMENT_ADDRESS']);

		if ($method == "donate") {
			$order_type = $ubbt_lang['DONATION'];
		} else {
			$order_type = $ubbt_lang['BY_SUB'];
		}

		$smarty_data = array(
			"ins_string" => $ins_string,
			"mystuff" => $mystuff,
			"address" => $address,
			"login_name" => $user['USER_LOGIN_NAME'],
			"display_name" => $user['USER_DISPLAY_NAME'],
			"sub_name" => $name,
			"order_type" => $order_type,
			"order_details" => $order_details,
			"payment_amount" => $payment_amount,
		);

		$cfrm = make_ubb_url("ubb=cfrm", "", false);
		$subs = make_ubb_url("ubb=subscriptions", "", false);

		return array(
			"header" => array(
				"title" => $ubbt_lang['MAIL_INS'],
				"refresh" => 0,
				"user" => $user,
				"Board" => "",
				"bypass" => 0,
				"onload" => "",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 <a href="{$subs}">{$ubbt_lang['MY_SUBS']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 {$ubbt_lang['MAIL_INS']}
BREADCRUMB
			,
			),
			"template" => "subscription_mail",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
		);

	}
}

?>