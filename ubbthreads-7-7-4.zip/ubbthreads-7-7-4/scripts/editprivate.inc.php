<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_editprivate_gpc() {
	return array(
		"input" => array(
			"message" => array("message", "get", "int"),
			"subj" => array("subj", "get", "int"),
		),
		"wordlets" => array("editprivate"),
		"user_fields" => "t2.USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_editprivate_run() {

	global $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!isset($PHPSESSID)) {
		$PHPSESSID = "";
	}

	$query = "
		SELECT	p.TOPIC_ID, p.POST_DEFAULT_BODY, p.USER_ID, t.TOPIC_SUBJECT
		FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS p,
				{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS t
		WHERE	POST_ID = ?
		AND		p.TOPIC_ID = t.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query, array($message), __LINE__, __FILE__);
	list ($topic_id, $post_body, $poster, $Subject) = $dbh->fetch_array($sth);

	if ($poster != $user['USER_ID']) {
		$html->not_right($ubbt_lang['NO_PERM']);
	}

	// Make sure they can access this pm
	$query = "
		select 	count(*)
		from		{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		where		USER_ID = ?
		and			TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $topic_id), __LINE__, __FILE__);
	list($perm_check) = $dbh->fetch_array($sth);
	if (!$perm_check) {
		$html->not_right($ubbt_lang['NO_PERM']);
	}

	// Check if this is the first post
	$query = "
		select 	POST_ID
		from		{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		where		TOPIC_ID = ?
		order by POST_ID asc
		limit 1
	";
	$sth = $dbh->do_placeholder_query($query, array($topic_id), __LINE__, __FILE__);
	list($first_post) = $dbh->fetch_array($sth);

	$delete = 1;
	if ($first_post == $message) {
		$delete = 0;
	}

	$Body = str_replace("<br>", "\n", $Body);
	$Body = ubbchars($Body);

	$text_editor = $html->create_text_editor("Body", $post_body, 2);

	$onsubmit = "";
	if ($user['USER_TEXT_EDITOR'] == "richtext") {
		$onsubmit = "onsubmit='return submitForm();'";
	}

	$smarty_data = array(
		"message" => $message,
		"text_editor" => & $text_editor,
		"delete" => $delete,
		"onsubmit" => $onsubmit,
		"subj" => $subj,
		"Subject" => $Subject,
		"mystuff" => $html->mystuff(),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['EDIT_IT']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "<a href=\"{$cfrm}\">{$ubbt_lang['FORUM_TEXT']}</a> <i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i> {$ubbt_lang['EDIT_IT']}",
			"javascript" => array('standard_text_editor.js'),
		),
		"template" => "editprivate",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>