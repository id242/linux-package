<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_paypal_ipn_gpc() {
	return array(
		"input" => array(
			"id" => array("id", "post", "int"),
			"method" => array("method", "post", "alpha"),
			"payment" => array("payment", "post", "alpha"),
			"item_name" => array("item_name", "post", ""),
			"business" => array("business", "post", ""),
			"item_number" => array("item_number", "post", ""),
			"payment_status" => array("payment_status", "post", ""),
			"mc_gross" => array("mc_gross", "post", ""),
			"payment_currency" => array("payment_currency", "post", ""),
			"txn_id" => array("txn_id", "post", ""),
			"receiver_email" => array("receiver_email", "post", ""),
			"receiver_id" => array("receiver_id", "post", ""),
			"quantity" => array("quantity", "post", ""),
			"num_cart_items" => array("num_cart_items", "post", ""),
			"payment_date" => array("payment_date", "post", ""),
			"first_name" => array("first_name", "post", ""),
			"last_name" => array("last_name", "post", ""),
			"payment_type" => array("payment_type", "post", ""),
			"payment_gross" => array("payment_gross", "post", ""),
			"payment_fee" => array("payment_fee", "post", ""),
			"settle_amount" => array("settle_amount", "post", ""),
			"memo" => array("memo", "post", ""),
			"payer_email" => array("payer_email", "post", ""),
			"txn_type" => array("txn_type", "post", ""),
			"payer_status" => array("payer_status", "post", ""),
			"address_street" => array("address_street", "post", ""),
			"address_city" => array("address_city", "post", ""),
			"address_state" => array("address_state", "post", ""),
			"address_zip" => array("address_zip", "post", ""),
			"address_country" => array("address_country", "post", ""),
			"address_status" => array("address_status", "post", ""),
			"tax" => array("tax", "post", ""),
			"option_name1" => array("option_name1", "post", ""),
			"option_selection1" => array("option_selection1", "post", ""),
			"option_name2" => array("option_name2", "post", ""),
			"option_selection2" => array("option_selection2", "post", ""),
			"invoice" => array("invoice", "post", ""),
			"custom" => array("custom", "post", ""),
			"notify_version" => array("notify_version", "post", ""),
			"verify_sign" => array("verify_sign", "post", ""),
			"payer_business_name" => array("payer_business_name", "post", ""),
			"payer_id" => array("payer_id", "post", ""),
			"mc_currency" => array("mc_currency", "post", ""),
			"mc_fee" => array("mc_fee", "post", ""),
			"exchange_rate" => array("exchange_rate", "post", ""),
			"settle_currency" => array("settle_currency", "post", ""),
			"parent_txn_id" => array("parent_txn_id", "post", ""),
			"pending_reason" => array("pending_reason", "post", ""),
			"reason_code" => array("reason_code", "post", ""),
			"subscr_id" => array("subscr_id", "post", ""),
			"subscr_date" => array("subscr_date", "post", ""),
			"subscr_effective" => array("subscr_effective", "post", ""),
			"period1" => array("period1", "post", ""),
			"period2" => array("period2", "post", ""),
			"period3" => array("period3", "post", ""),
			"amount1" => array("amount1", "post", ""),
			"amount2" => array("amount2", "post", ""),
			"amount3" => array("amount3", "post", ""),
			"mc_amount1" => array("mc_amount1", "post", ""),
			"mc_amount2" => array("mc_amount2", "post", ""),
			"mc_amount3" => array("mc_amount3", "post", ""),
			"recurring" => array("recurring", "post", ""),
			"reattempt" => array("reattempt", "post", ""),
			"retry_at" => array("retry_at", "post", ""),
			"recur_times" => array("recur_times", "post", ""),
			"username" => array("username", "post", ""),
			"password" => array("password", "post", ""),
		),
		"wordlets" => array("paypal_ipn"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_paypal_ipn_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$subsc_vars = array(
		"ITEM_NAME" => $item_name,
		"BUSINESS" => $business,
		"ITEM_NUMBER" => $item_number,
		"PAYMENT_STATUS" => $payment_status,
		"MC_GROSS" => $mc_gross,
		"PAYMENT_CURRENCY" => $payment_currency,
		"TXN_ID" => $txn_id,
		"RECEIVER_EMAIL" => $receiver_email,
		"RECEIVER_ID" => $receiver_id,
		"QUANTITY" => $quantity,
		"NUM_CART_ITEMS" => $num_cart_items,
		"PAYMENT_DATE" => $payment_date,
		"FIRST_NAME" => $first_name,
		"LAST_NAME" => $last_name,
		"PAYMENT_TYPE" => $payment_type,
		"PAYMENT_GROSS" => $payment_gross,
		"PAYMENT_FEE" => $payment_fee,
		"SETTLE_AMOUNT" => $settle_amount,
		"MEMO" => $memo,
		"PAYER_EMAIL" => $payer_email,
		"TXN_TYPE" => $txn_type,
		"PAYER_STATUS" => $payer_status,
		"ADDRESS_STREET" => $address_street,
		"ADDRESS_CITY" => $address_city,
		"ADDRESS_STATE" => $address_state,
		"ADDRESS_ZIP" => $address_zip,
		"ADDRESS_COUNTRY" => $address_country,
		"ADDRESS_STATUS" => $address_status,
		"TAX" => $tax,
		"OPTION_NAME1" => $option_name1,
		"OPTION_SELECTION1" => $option_selection1,
		"OPTION_NAME2" => $option_name2,
		"OPTION_SELECTION2" => $option_selection2,
		"CUSTOM_ID" => $custom,
		"INVOICE" => $invoice,
		"NOTIFY_VERSION" => $notify_version,
		"VERIFY_SIGN" => $verify_sign,
		"PAYER_BUSINESS_NAME" => $payer_business_name,
		"PAYER_ID" => $payer_id,
		"MC_CURRENCY" => $mc_currency,
		"MC_FEE" => $mc_fee,
		"EXCHANGE_RATE" => $exchange_rate,
		"SETTLE_CURRENCY" => $settle_currency,
		"PARENT_TXN_ID" => $parent_txn_id,
		"PENDING_REASON" => $pending_reason,
		"REASON_CODE" => $reason_code,
		"SUBSCR_ID" => $subscr_id,
		"SUBSCR_DATE" => $subscr_date,
		"SUBSCR_EFFECTIVE" => $subscr_effective,
		"PERIOD1" => $period1,
		"PERIOD2" => $period2,
		"PERIOD3" => $period3,
		"AMOUNT1" => $amount1,
		"AMOUNT2" => $amount2,
		"AMOUNT3" => $amount3,
		"MC_AMOUNT1" => $mc_amount1,
		"MC_AMOUNT2" => $mc_amount2,
		"MC_AMOUNT3" => $mc_amount3,
		"RECURRING" => $recurring,
		"REATTEMPT" => $reattempt,
		"RETRY_AT" => $retry_at,
		"RECUR_TIMES" => $recur_times,
		"USERNAME" => $username,
		"PASSWORD" => $password,
	);


//	Link to PayPal Codes
//	https://developer.paypal.com/docs/classic/paypal-payments-standard/integration-guide/Appx_websitestandard_htmlvariables/

//	Link to PayPal Codes - Recurring / Subscriptions
//	https://developer.paypal.com/docs/classic/paypal-payments-standard/integration-guide/Appx_websitestandard_htmlvariables/#recurring-payment-variables

	// read the post from PayPal system and add 'cmd'
	$req = 'cmd=_notify-validate';
	$paypal_stuff = "i1234";
	foreach ($_POST as $key => $value) {
		$value = urlencode(stripslashes($value));
		$req .= "&$key=$value";
		$paypal_stuff .= "$key = $value\n";
	}
	lock_and_write("{$config['FULL_PATH']}/paypal.log", $paypal_stuff);


	// post back to PayPal system to validate
	$header = "POST /cgi-bin/webscr HTTP/1.1\r\n";
	$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
	$header .= "Host: www.paypal.com\r\n";
//	$header .= "Host: www.sandbox.paypal.com\r\n";									// PayPal Sandbox
	$header .= "Connection: close\r\n";
	$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
//	$fp = fsockopen ('www.paypal.com', 80, $errno, $errstr, 30);					// Obsolete after May 2018
	$fp = fsockopen('ssl://www.paypal.com', 443, $errno, $errstr, 30);
//	$fp = fsockopen ('ssl://www.sandbox.paypal.com', 443, $errno, $errstr, 30);		// PayPal Sandbox

	if (!$fp) {
		// HTTP ERROR - error connecting to paypal
	} else {
		// HTTP GOOD - successful connection
		fputs($fp, $header . $req);
		while (!feof($fp)) {
			$res = fgets($fp, 1024);
			$res = trim($res); // NEW & IMPORTANT
			if (strcmp($res, "VERIFIED") == 0) {
				// SUCCESS - insert order into database
				//check if transaction ID has been processed before
				$duplicate_txn = "";
				if ($txn_id) {
					if ($new_txn_id == stripslashes($txn_id_q) && $check_custom == stripslashes($custom_q) && $check_pstatus == "Pending") {
						$new_txn_id = "";
					}
					$query = "
						SELECT TXN_ID, PAYMENT_STATUS, CUSTOM_ID
						FROM {$config['TABLE_PREFIX']}PAYPAL_DATA
						WHERE TXN_ID = ?
					";
					$sth = $dbh->do_placeholder_query($query, array($txn_id), __LINE__, __FILE__);
					list($duplicate_txn, $this_status, $this_custom) = $dbh->total_rows($sth);

					// If this is an echeck, then the custom and status
					// should be currently set to pending
					if (($this_custom == $custom) && ($this_status == "Pending")) {
						$duplicate_txn = "";
					}
				}

				// Duplicate transaction
				if ($duplicate_txn) {
				} else {

					$delete = false;
					$add = false;
					$active = 0;
					$subject = '';
					$message = '';
					$admin_message = '';
					$status = '';
					$nochanges = false;

					// Get User ID
					$query = "
						SELECT USER_ID, GROUP_ID, SUBSCRIPTION_END_DATE
						FROM {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
						WHERE CUSTOM_ID = ?
					";
					$sth = $dbh->do_placeholder_query($query, array($custom), __LINE__, __FILE__);
					list($user_id, $group_id, $end_date) = $dbh->fetch_array($sth);

					// Get the Subscription Details
					$query = "
						SELECT SUBSCRIPTION_NAME, SUBSCRIPTION_REGULAR_DURATION, SUBSCRIPTION_REGULAR_INTERVAL
						FROM {$config['TABLE_PREFIX']}SUBSCRIPTIONS
						WHERE GROUP_ID = ?
					";
					$sth = $dbh->do_placeholder_query($query, array($group_id), __LINE__, __FILE__);
					list($subscription_name, $sub_dur, $sub_int) = $dbh->fetch_array($sth);

					// If we have a parent_txn_id make sure it matches
					// an original transaction and then process
					$check = 0;
					if ($parent_txn_id) {
						$query = "
							SELECT count(*)
							FROM {$config['TABLE_PREFIX']}PAYPAL_DATA
							WHERE CUSTOM_ID = ?
							  AND TXN_ID = ?
						";
						$sth = $dbh->do_placeholder_query($query, array($custom, $parent_txn_id), __LINE__, __FILE__);
						list($check) = $dbh->fetch_array($sth);
					}

					if ($parent_txn_id && $check) {
						if ($payment_status == "Refunded") {

							$status = "REFUND";
							$active = 0;
							$delete = true;
							$subject = $ubbt_lang['REFUND_SUB'];
							$message = $html->substitute($ubbt_lang['REFUND'], array('GROUP' => $subscription_name));

						} elseif ($payment_status == "Reversed") {

							$status = "REVERSAL";
							$active = 0;
							$delete = true;
							$subject = $ubbt_lang['REVERSAL_SUB'];
							$message = $html->substitute($ubbt_lang['REVERSAL'], array('GROUP' => $subscription_name));

						} elseif ($payment_status == "Canceled_Reversal") {

							$status = "CANCELED REVERSAL";
							$active = 1;
							$add = true;
							$subject = $ubbt_lang['CANCEL_REVERSAL_SUB'];
							$message = $html->substitute($ubbt_lang['CANCEL_REVERSAL'], array('GROUP' => $subscription_name));

						}
					}

					/*
					 * Initial Signup for a subscription
					 */
					if ($txn_type == "subscr_signup") {
						// FREE Trial?
						if (strcmp($amount1, "0.00") == 0) {

							$status = "FREE TRIAL";
							$active = 1;
							$add = true;
							$subject = $ubbt_lang['FREE_TRIAL_SUB'];
							$message = $html->substitute($ubbt_lang['FREE_TRIAL'], array('GROUP' => $subscription_name));

						} else {

							$nochanges = true;
							// Update sub data table
							$query = "
								UPDATE {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
								SET SUBSCRIPTION_STATUS = 'SIGNUP'
								WHERE CUSTOM_ID = ?
							";
							$dbh->do_placeholder_query($query, array($custom), __LINE__, __FILE__);
						}

					} elseif ($txn_type == "subscr_payment") { // PAYMENT
						// This is a payment notification of some sort.
						if ($payment_status == "Completed") { // Completed

							$status = "PAYMENT RECEIVED";
							$active = 1;
							$add = true;
							$subject = $ubbt_lang['PAYMENT_RECEIVED_SUB'];
							$message = $html->substitute($ubbt_lang['PAYMENT_RECEIVED'], array('GROUP' => $subscription_name));
							// Need to update the new end date
							if ($sub_int == "D") {
								$end_date = $end_date + (86400 * ($sub_dur));
							}
							if ($sub_int == "W") {
								$end_date = $end_date + (86400 * ($sub_dur * 7));
							}
							if ($sub_int == "M") {
								$end_date = $end_date + (86400 * ($sub_dur * 30));
							}
							if ($sub_int == "Y") {
								$end_date = $end_date + (86400 * ($sub_dur * 365));
							}

						} elseif ($payment_status == "Pending") { // Pending

							$status = "PAYMENT PENDING";
							$active = 0;
							$delete = true;
							$subject = $ubbt_lang['PAYMENT_PENDING_SUB'];
							$message = $html->substitute($ubbt_lang['PAYMENT_PENDING'], array('GROUP' => $subscription_name));

						} elseif ($payment_status == "Failed") { // Failed!

							$status = "PAYMENT FAILED";
							$active = 0;
							$delete = true;
							$subject = $ubbt_lang['PAYMENT_FAILED_SUB'];
							$message = $html->substitute($ubbt_lang['PAYMENT_FAILED'], array('GROUP' => $subscription_name));

						} elseif ($payment_status == "Denied") { // Denied?

							$status = "PAYMENT DENIED";
							$active = 0;
							$delete = true;
							$subject = $ubbt_lang['PAYMENT_DENIED_SUB'];
							$message = $html->substitute($ubbt_lang['PAYMENT_DENIED'], array('GROUP' => $subscription_name));

						}

					} elseif ($txn_type == "subscr_failed") { // FAILED

						$status = "SUBSCRIPTION FAILED";
						$active = 0;
						$delete = true;
						$subject = $ubbt_lang['SUB_FAILED_SUB'];
						$message = $html->substitute($ubbt_lang['SUB_FAILED'], array('GROUP' => $subscription_name));

					} elseif ($txn_type == "subscr_eot") { // EOT

						$status = "EOT";
						$active = 0;
						$delete = true;
						$subject = $ubbt_lang['SUBSCRIPTION_EOT_SUB'];
						$message = $html->substitute($ubbt_lang['SUBSCRIPTION_EOT'], array('GROUP' => $subscription_name));
						$admin_message = $html->substitute($ubbt_lang['SUBSCRIPTION_EOT_USER'], array('USER' => "{$config['FULL_URL']}/admin/showuser.php?uid=$user_id", 'GROUP' => $subscription_name));

					} elseif ($txn_type == "subscr_cancel") { // CANCELED
						/* 7.5.1 CHANGE
						   When a user cancels their subscription, it shouldn't do anything except for
						   change the status to CANCELED since they still should get the remaining time
						   that they already paid for. A cancel is only for future payments.
					    */
						$status = "CANCELED";
						$active = 1;
						$delete = false;
						$subject = '';
						$message = '';

					} elseif ($txn_type == "web_accept") { // DONATION

						$status = "DONATION";
						$active = 1;
						$add = true;
						$subject = $ubbt_lang['DONATION_SUB'];
						$message = $html->substitute($ubbt_lang['DONATION'], array('GROUP' => $subscription_name));

					}

					if (!$nochanges) {

						// Update sub data table
						$query = "
							UPDATE
								{$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
							SET
								SUBSCRIPTION_STATUS = ? ,
								SUBSCRIPTION_IS_ACTIVE = ? ,
								SUBSCRIPTION_END_DATE = ?
							WHERE
								CUSTOM_ID = ?
						";
						$dbh->do_placeholder_query($query, array($status, $active, $end_date, $custom), __LINE__, __FILE__);

						if ($delete) {

							// Remove this user from this group
							$query = "
								DELETE FROM {$config['TABLE_PREFIX']}USER_GROUPS
								WHERE USER_ID = ?
								  AND GROUP_ID = ?
							";
							$dbh->do_placeholder_query($query, array($user_id, $group_id), __LINE__, __FILE__);

							// Remove Group Image from this user
							$group_images = "";
							$query = "
								UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
								SET USER_GROUP_IMAGES = ?
								WHERE USER_ID = ?
							";
							$dbh->do_placeholder_query($query, array($group_images, $user_id), __LINE__, __FILE__);

						} else {

							// Add user to this group
							$query = "
								REPLACE INTO
									{$config['TABLE_PREFIX']}USER_GROUPS
									(USER_ID, GROUP_ID)
								VALUES
									(?, ?)
							";
							$dbh->do_placeholder_query($query, array($user_id, $group_id), __LINE__, __FILE__);

						}

						if ($message) {
							$html->send_message($config['MAIN_ADMIN_ID'], $user_id, $subject, $message);
						}
						if ($admin_message) {
							$html->send_message($config['MAIN_ADMIN_ID'], $config['MAIN_ADMIN_ID'], $subject, $admin_message);
						}

					}

					// Insert into Paypal Data table for logging
					$fields = "";
					$vars = "";
					$query_vars = array();
					foreach ($subsc_vars as $k => $v) {
						$fields .= "$k,";
						$vars .= "?,";
						$query_vars[] = $v;
					}
					$fields = preg_replace("/,$/", "", $fields);
					$vars = preg_replace("/,$/", "", $vars);

					$query = "
						INSERT INTO
							{$config['TABLE_PREFIX']}PAYPAL_DATA
							($fields)
						VALUES
							($vars)
					";
					$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
				}

			} else if (strcmp($res, "INVALID") == 0) {
				// FAIL - Insert into DB in a table for bad payments to process later
			}
		}
	}
	fclose($fp);

	return false;
}

?>