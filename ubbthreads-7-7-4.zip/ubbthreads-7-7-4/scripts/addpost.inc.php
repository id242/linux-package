<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_addpost_gpc() {
	return array(
		"input" => array(
			"Board" => array("Board", "post", "alphanum"),
			"what" => array("what", "post", "alpha"),
			"Subject" => array("Subject", "post", ""),
			"Body" => array("Body", "post", ""),
			"Icon" => array("Icon", "post", ""),
			"convert" => array("convert", "post", "alpha"),
			"postername" => array("postername", "post", ""),
			"Main" => array("Main", "post", "int"),
			"Parent" => array("Parent", "post", "int"),
			"oldnumber" => array("oldnumber", "post", "int"),
			"fpart" => array("fpart", "post", "alphanum"),
			"frompreview" => array("frompreview", "post", "int"),
			"PStatus" => array("PStatus", "post", "alpha"),
			"dofav" => array("dofav", "post", "int"),
			"addevent" => array("addevent", "post", "int"),
			"calmonth" => array("calmonth", "post", "int"),
			"calday" => array("calday", "post", "int"),
			"calyear" => array("calyear", "post", "int"),
			"Sticky" => array("Sticky", "post", "int"),
			"announcement" => array("announcement", "post", "int"),
			"addsig" => array("addsig", "post", "int"),
			"quickreply" => array("quickreply", "post", "int"),
			"md5_stamp" => array("md5_stamp", "post", "alphanum"),
			"news_image" => array("news_image", "post"),
			"captcha" => array("captcha", "post", "alphanum"),
			"g-recaptcha-response" => array("g-recaptcha-response", "post", "alphanum"),
			"Username" => array("Username", "post", ""),
			"closetopic" => array("closetopic", "post", ""),
			"lock" => array("lock", "post", "int"),
		),
		"wordlets" => array("addpost"),
		"user_fields" => "t2.USER_SIGNATURE,t2.USER_TOPIC_VIEW_TYPE,t2.USER_TOTAL_POSTS,t2.USER_FLOOD_CONTROL_OVERRIDE,t2.USER_TEXT_EDITOR,USER_EMAIL_WATCHLISTS",
		"regonly" => 0,
	);
}

function page_addpost_run() {

	global $style_array, $userob, $smarty, $user, $user_ip, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra, $debug, $myinfo, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	// -------------------------
	// Predefine a few variables
	$parentboard = "";
	$RealSubject = "";
	$attachfile = "";
	$fileinput = "";
	$Pselected = "";
	$extra = "";
	$okay = "";

	$Subject = trim($Subject);
	$Body = trim($Body);
	$DefaultBody = $Body;

	// Censor the input?
	if ($config['DO_CENSOR']) {
		$Body = $html->do_censor($Body);
		$Subject = $html->do_censor($Subject);
	}

	// Add a space to the end of $Body, for auto-url encoding
	$Body .= " ";

	if (!$Username) $Username = $ubbt_lang['ANON_TEXT'];

	if ($user['USER_ID']) {
		$Username = $user['USER_DISPLAY_NAME'];
		$posterid = $user['USER_ID'];
		$postername = $Username;
		$Reged = 1;
	} else {
		if ($Username != $ubbt_lang['ANON_TEXT']) {
			list($ok, $err) = is_valid_name($Username, "display");
			if ($ok === false) $html->not_right($ubbt_lang[$err]);
		}
		$postername = $Username;
		$posterid = "1";
		$user['USER_ID'] = 1;
		$Reged = 0;
	}

	// Get the user's last post time
	$query = "
		SELECT USER_LAST_POST_TIME
		FROM {$config['TABLE_PREFIX']}USER_DATA
		WHERE USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);
	list($user['USER_LAST_POST_TIME']) = $dbh->fetch_array($sth);

	// -----------------
	// Get the user info
	$IP = $user_ip;

	// Flood control settings
	if ($userob->is_logged_in) {
		$lastposttime = $user['USER_LAST_POST_TIME'];
		if ($user['USER_FLOOD_CONTROL_OVERRIDE'] == "-1") {
			$floodcontrol = $userob->check_access("forum", "POST_THROTTLE", $Board);
		} else {
			$floodcontrol = $user['USER_FLOOD_CONTROL_OVERRIDE'];
		}
	} else {
		$floodcontrol = $userob->check_access("forum", "POST_THROTTLE", $Board);
		$lastposttime = get_input("lastposttime", "cookie");
	}

	// ---------------------------------
	// Check if they can make a post yet
	if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL'])) {
		if (($html->get_date() - $lastposttime) < $floodcontrol) {
			$html->not_right($html->substitute($ubbt_lang['FLOODCONTROL'], array('FLOOD_LIMIT' => $floodcontrol)));
		}
	}

	// ------------------
	// Check the referer
	if (!$config['DISABLE_REFERER_CHECK']) {
		$html->check_refer();
	}

	// ---------------------
	// Check maximum quote level
	unset($total);
	$max = $config['NESTED_QUOTES'] + 1;
	preg_match_all('%(\[quote=.+?\]|\[quote\]|\[/quote\])%', $Body, $result, PREG_PATTERN_ORDER);
	for ($i = 0; $i < count($result[0]); $i++) {
		$total .= $result[0][$i];
	}
	if (preg_match("%(\[/quote\]){{$max},}%", $total)) {
		$html->not_right($html->substitute($ubbt_lang['MAX_QUOTE'], array('QUOTE' => $config['NESTED_QUOTES'])));
	}

	// -------------------------------------
	// Make sure there is a subject and body
	$Subject = rtrim($Subject);
	if ((preg_match("/^\s*$/", $Subject)) || ($postername == "")) {
		$html->not_right($ubbt_lang['ALL_FIELDS']);
	}

	$haspoll = 0;
	$hasfile = 0;

	// Let's make sure this post doesn't already exist
	if ($md5_stamp) {
		$query = "
			SELECT USER_ID
			FROM {$config['TABLE_PREFIX']}POSTS
			WHERE POST_MD5 = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($md5_stamp), __LINE__, __FILE__);
		// On an extremely large forum it's possible for md5 collisions...
		// though very slight, so we'll check for that
		while (list($md5_user) = $dbh->fetch_array($sth)) {
			if ($md5_user == $user['USER_ID']) {
				$html->not_right($ubbt_lang['NO_DUPS']);
			}
		}
	}

	$query = "
		SELECT count(*)
		FROM {$config['TABLE_PREFIX']}POLL_DATA
		WHERE POLL_MD5 = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($md5_stamp), __LINE__, __FILE__);
	list($haspoll) = $dbh->fetch_array($sth);

	// Are there any attached files?
	$query = "
		SELECT count(*)
		FROM {$config['TABLE_PREFIX']}FILES
		WHERE FILE_MD5 = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($md5_stamp), __LINE__, __FILE__);
	list($hasfile) = $dbh->fetch_array($sth);

	// -----------------------------------------------
	// If we are adding a poll the body could be blank
	$Body = rtrim($Body);
	if ((!$haspoll) && preg_match("/^s*$/", $Body)) {
		$html->not_right($ubbt_lang['ALL_FIELDS']);
	}


	// Grab the board that this thread is in if it's a reply
	if ($Main) {
		$query = "
			SELECT
				t1.FORUM_ID, t1.POST_ID
			FROM
				{$config['TABLE_PREFIX']}TOPICS AS t1,
				{$config['TABLE_PREFIX']}POSTS AS t2
			WHERE
				t1.TOPIC_ID = ?
			AND t1.TOPIC_ID = t2.TOPIC_ID
		";
		$sth = $dbh->do_placeholder_query($query, array($Main), __LINE__, __FILE__);
		list($Board, $checkPost) = $dbh->fetch_array($sth);
		if (!$Parent) $Parent = $checkPost;
	}

	if ($Parent) {
		$query = "
			SELECT
				t1.POST_ID, t2.FORUM_ID, t1.USER_ID, t1.POST_SUBJECT
			FROM
				{$config['TABLE_PREFIX']}POSTS AS t1,
				{$config['TABLE_PREFIX']}TOPICS AS t2
			WHERE
				t1.POST_ID = ?
			AND	t1.TOPIC_ID = t2.TOPIC_ID
		";
		$sth = $dbh->do_placeholder_query($query, array($Parent), __LINE__, __FILE__);
		list ($check, $parentboard, $ParentUser, $ParentSubject) = $dbh->fetch_array($sth);
		if (!$check) {
			$html->not_right($ubbt_lang['PARENT_DELETED']);
		}
		$Board = $parentboard;
	}

	// --------------------------------------------------------------
	// Let's make sure they are supposed to be looking at this board
	$whichperm = "CREATE_TOPICS";
	if ($Parent) {
		$whichperm = "CREATE_REPLIES";
	}

	if (!$userob->check_access("forum", $whichperm, $Board)) {
		$html->not_right($ubbt_lang['READ_PERM']);
	}


	// ------------------------------------
	// Grab the necessary board information
	$query = "
		SELECT FORUM_TITLE, FORUM_CUSTOM_HEADER, FORUM_STYLE, CATEGORY_ID, FORUM_PARENT, FORUM_IS_RSS, FORUM_RSS_TITLE, FORUM_IS_GALLERY, FORUM_POSTS_COUNT
		FROM {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_ID = ?
		  AND FORUM_IS_ACTIVE = '1'
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list($Title, $fheader, $fstyle, $cat_id, $parent_id, $is_rss, $rss_title, $is_gallery, $posts_count) = $dbh->fetch_array($sth);

	// TOPICS in a gallery must have file attachments
	if ($is_gallery && !$hasfile && !$Parent) {
		$html->not_right($ubbt_lang['NOIMAGES']);
	}

	// Gallery posts get the image icon
	// Also, we don't allow linked images in gallery replies
	if ($is_gallery) {
		$Icon = "image.gif";
	}

	// Captcha for guests?
	if ($userob->check_access("forum", "CAPTCHA", $Board)) {
		if (isset($config['RECAPTCHA_SITE']) && !empty($config['RECAPTCHA_SITE'])) {
			$secret = "{$config['RECAPTCHA_SECRET']}";
			$verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secret . '&response=' . $_POST['g-recaptcha-response']);
			$responseData = json_decode($verifyResponse);
			if (!$responseData->success) {
				$html->not_right($ubbt_lang['NO_IMAGE_VERIFY']);
			}
		} elseif (!$captcha || (strtolower($captcha) != strtolower($_SESSION['cp_code']))) {
			$html->not_right($ubbt_lang['NO_IMAGE_VERIFY']);
		}
	}

	// -------------------------------------------------------------------------
	// Lets see if this post is locked or not if we don't already have a PStatus
	// Also make sure the parent post still exists
	if (!$PStatus) {
		$PStatus = "O";
		if ($Parent) {
			$query = "
				SELECT TOPIC_STATUS, TOPIC_SUBJECT, TOPIC_IS_STICKY
				FROM {$config['TABLE_PREFIX']}TOPICS
				WHERE TOPIC_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query, array($Main), __LINE__, __FILE__);
			list($PStatus, $RealSubject, $issticky) = $dbh->fetch_array($sth);

			if ($issticky == "2" && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator")) {
				$html->not_right($ubbt_lang['NO_R_ANNOUNCE']);
			}

		}
	}

	// ---------------------------------------------------------------------------
	// If this thread is locked and they are not a admin or mod they can't proceed
	if (($PStatus != "O" && $PStatus != "") && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && (!preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
		$html->not_right($ubbt_lang['LOCKED']);
	}

	// -----------------------------------------------------------
	// If username is anonymous then we set the mail variable to 0
	if ($Reged == "0") {
		$posterid = "1";
	}

	$HTML = $userob->check_access("forum", "USE_HTML", $Board);
	$Markup = $userob->check_access("forum", "USE_MARKUP", $Board);

	if (($user['USER_MEMBERSHIP_LEVEL'] == "User" || !$Reged) && ($config['MARKUP_HTML_TOGGLE'] == 0) || !$convert) {
		if ($Markup && $HTML) {
			$convert = "both";
		} elseif ($HTML) {
			$convert = "html";
		} elseif ($Markup) {
			$convert = "markup";
		} else {
			$convert = "none";
		}
	}

	// If this is a user and HTML isn't allowed in the forum, then make sure
	// html isn't selected
	if ($user['USER_MEMBERSHIP_LEVEL'] == "User") {
		if (($convert == "both" || $convert == "html") && !$HTML) {
			$convert = "none";
		}
	}

	$convert_vals = array("both", "markup", "html", "none");
	if (!in_array($convert, $convert_vals)) $convert = "none";


	// ------------------------------------------------------------------
	// Get rid of <, >, &, and " in the subject because we don't want them using
	// these character types in the subject line
	$Subject = ubbchars($Subject);

	$Body = $html->do_markup($Body, "post", $convert);

	// -------------------------
	// Check for real moderation
	if ($userob->check_access("forum", "POSTS_ARE_MODERATED", $Board)) {
		$Approved = "0";
	} else {
		$Approved = "1";
	}

	// --------------------------------------------------------------------
	// If they are in they are this boards moderator the post goes right in
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
		$query = "
			SELECT USER_ID
			FROM {$config['TABLE_PREFIX']}MODERATORS
			WHERE FORUM_ID = ?
			AND USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query, array($Board, $user['USER_ID']), __LINE__, __FILE__);
		list($modcheck) = $dbh->fetch_array($sth);
		if ($modcheck) {
			$Approved = "1";
		}
	}

	if ($user['USER_MEMBERSHIP_LEVEL'] == "GlobalModerator") {
		$Approved = "1";
	}

	// Make sure they can stick the post
	if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL'])) {
		$Sticky = 0;
	}

	// -------------------------
	// Quote everything properly
	if (!$PStatus) {
		$PStatus = "O";
	}
	$BodySig = $Body;
	isset($user['USER_AVATAR']) && $Picture = $user['USER_AVATAR'];
	if (!isset($Picture)) {
		$Picture = "http://";
	}
	if (!$addsig) {
		$addsig = "0";
	}
	if (!$Sticky) {
		$Sticky = "0";
	}
	if ($announcement) {
		$Sticky = '2';
	}

	// --------------------
	// Get the current time
	$date = $html->get_date();

	// --------------------------------------------------
	// Set the default UserTitle variable to Unregistered
	$UserTitle = $ubbt_lang['UNREGED_USER'];

	// -----------------------------------------------------
	// If this isn't a reply post then $Parent gets set to 0
	if (!$Parent) {
		$Parent = 0;
	}

	if (!isset($Color)) {
		$Color = " ";
	}

	// ------------------------------------
	// Are we listing this on the calendar?
	if (!$addevent) {
		$calday = "0";
		$calmonth = "0";
		$calyear = "0";
	}

	// ---------------------------------
	// INSERT THE POST INTO THE DATABASE

	if (!$ParentUser) $ParentUser = 0;

	// News image?
	$news_array = preg_split("#,#", $config['PORTAL_NEWS_FORUMS']);

	if ((in_array($Board, $news_array) && !$Main) || ($userob->check_access("forum", "CREATE_NEWS", $Board) && !$Main)) {
		$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['news']}");
		$found = 0;
		while (($file = readdir($dir)) != false) {
			if (($file == ".") || ($file == "..") || ($file == "index.html") || (!preg_match("/(gif|jpg|png)$/i", $file))) {
				continue;
			}
			if ($file == $news_image) {
				$found = 1;
			}
		}
		if (!$found) {
			$news_image = "";
		}
	} else {
		$news_image = "";
	}


	// -------------------------------------------------------------------
	// If this is a new topic then we need to insert into the TOPICS table
	$post_is_topic = 0;
	if (!$Main) {
		$post_is_topic = 1;
		$event = 0;
		if ($calday) $event = 1;
		if ($lock) $PStatus = "C";
		$query_vars = array($Board, 0, $posterid, $Subject, $date, $Approved, $PStatus, $Sticky, $date, $hasfile, $haspoll, 0, $Icon, $posterid, $postername, $event, $news_image, $postername);
		$query = "
			INSERT INTO
				{$config['TABLE_PREFIX']}TOPICS
				(FORUM_ID, POST_ID, USER_ID, TOPIC_SUBJECT, TOPIC_CREATED_TIME, TOPIC_IS_APPROVED, TOPIC_STATUS, TOPIC_IS_STICKY, TOPIC_LAST_REPLY_TIME, TOPIC_HAS_FILE, TOPIC_HAS_POLL, TOPIC_RATING, TOPIC_ICON, TOPIC_LAST_POSTER_ID, TOPIC_LAST_POSTER_NAME, TOPIC_IS_EVENT, TOPIC_NEWS_ICON, TOPIC_POSTER_NAME)
			VALUES
				(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

		// Get the topic id
		$query = "
			SELECT last_insert_id()
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		list ($Main) = $dbh->fetch_array($sth);
	}

	$query_vars = array($Parent, $Main, $post_is_topic, $date, $IP, $Subject, $BodySig, $DefaultBody, $Approved, $Icon, $haspoll, $hasfile, $convert, $posterid, $ParentUser, $addsig, 0, $postername, $md5_stamp);
	$query = "
		INSERT INTO
			{$config['TABLE_PREFIX']}POSTS
			(POST_PARENT_ID, TOPIC_ID, POST_IS_TOPIC, POST_POSTED_TIME, POST_POSTER_IP, POST_SUBJECT, POST_BODY, POST_DEFAULT_BODY, POST_IS_APPROVED, POST_ICON, POST_HAS_POLL, POST_HAS_FILE, POST_MARKUP_TYPE, USER_ID, POST_PARENT_USER_ID, POST_ADD_SIGNATURE, POST_LAST_EDITED_TIME, POST_POSTER_NAME, POST_MD5)
		VALUES
			(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	";
	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

	// ------------------------------------------------------------------
	// Now we need to find out what the number of the post we entered was
	$checkuser = $user['USER_ID'];
	if (!$user['USER_ID']) {
		$checkuser = 1;
	}
	$query = "
		SELECT last_insert_id()
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	list ($Mnumber) = $dbh->fetch_array($sth);

	// If this is a topic, now we need to update the TOPICS table
	// with the post information
	if ($post_is_topic == 1) {
		$query = "
			UPDATE {$config['TABLE_PREFIX']}TOPICS
			SET POST_ID = ?, TOPIC_LAST_POST_ID = ?
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($Mnumber, $Mnumber, $Main), __LINE__, __FILE__);
	}

	// If this isn't a topic then we need to update the topic
	// with information about the last post
	if ($post_is_topic == 0 && $Approved) {

		$query_vars = array($date, $Mnumber, $postername, $posterid, $Main);
		$query = "
			UPDATE
				{$config['TABLE_PREFIX']}TOPICS
			SET
				TOPIC_REPLIES = TOPIC_REPLIES + 1,
				TOPIC_LAST_REPLY_TIME = ? ,
				TOPIC_LAST_POST_ID = ? ,
				TOPIC_LAST_POSTER_NAME = ? ,
				TOPIC_LAST_POSTER_ID = ?
			WHERE
				TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}

	// Calendar Event?
	if ($calday) {
		$query_vars = array($posterid, $Main, $calday, $calmonth, $calyear, $Subject, "public");
		$query = "
			INSERT INTO
				{$config['TABLE_PREFIX']}CALENDAR_EVENTS
				(USER_ID, TOPIC_ID, CALENDAR_EVENT_DAY, CALENDAR_EVENT_MONTH, CALENDAR_EVENT_YEAR, CALENDAR_EVENT_SUBJECT, CALENDAR_EVENT_TYPE)
			VALUES
				(?, ?, ?, ?, ?, ?, ?)
		";
		$dbh->do_placeholder_query($query, $query_vars);
	}

	if ($haspoll) {
		$query = "
			UPDATE {$config['TABLE_PREFIX']}POLL_DATA
			SET POST_ID = ?
			WHERE POLL_MD5 = ?
		";
		$dbh->do_placeholder_query($query, array($Mnumber, $md5_stamp), __LINE__, __FILE__);
	}

	if ($hasfile) {

		$filedir = "";

		if ($is_gallery) {
			if (ini_get('safe_mode')) {
				$filedir = "default";

			} else {
				$filedir = $Board;
			}
		}

		$topic_thumbnail = "";
		$query = "
			SELECT FILE_NAME, FILE_ADD_TIME
			FROM {$config['TABLE_PREFIX']}FILES
			WHERE FILE_MD5 = ?
			ORDER BY FILE_ADD_TIME ASC
		";
		$sth = $dbh->do_placeholder_query($query, array($md5_stamp), __LINE__, __FILE__);
		while (list($filename) = $dbh->fetch_array($sth)) {
			if (!$filename) continue;
			if ($is_gallery) {
				if (!$topic_thumbnail) {
					$topic_thumbnail = true;
					$query = "
						UPDATE {$config['TABLE_PREFIX']}TOPICS
						SET TOPIC_THUMBNAIL = ?
						WHERE TOPIC_ID = ?
					";
					$dbh->do_placeholder_query($query, array("$filedir/thumbs/$filename", $Main), __LINE__, __FILE__);
					$topic_thumbnail = 1;
				}
				rename("{$config['FULL_PATH']}/tmp/$filename.thumb", "{$config['FULL_PATH']}/gallery/$filedir/thumbs/$filename");
				chmod("{$config['FULL_PATH']}/gallery/$filedir/thumbs/$filename", 0666);
				rename("{$config['FULL_PATH']}/tmp/$filename.medium", "{$config['FULL_PATH']}/gallery/$filedir/medium/$filename");
				chmod("{$config['FULL_PATH']}/gallery/$filedir/medium/$filename", 0666);
				rename("{$config['FULL_PATH']}/tmp/$filename.full", "{$config['FULL_PATH']}/gallery/$filedir/full/$filename");
				chmod("{$config['FULL_PATH']}/gallery/$filedir/full/$filename", 0666);
			} else {
				rename("{$config['FULL_PATH']}/tmp/$filename", "{$config['ATTACHMENTS_PATH']}/$filename");
				chmod("{$config['ATTACHMENTS_PATH']}/$filename", 0666);
			}
		}

		$query = "
			UPDATE {$config['TABLE_PREFIX']}FILES
			SET POST_ID = ? , FILE_DIR = ?
			WHERE FILE_MD5 = ?
		";
		$dbh->do_placeholder_query($query, array($Mnumber, $filedir, $md5_stamp), __LINE__, __FILE__);
	}

	// ------------------------------------------------------------------
	// If this post was Sticky then we add it to the announcements table
	if ($Sticky || $announcement) {
		$sboard = $Board;
		if ($announcement) {
			$sboard = "ubbt_all_forums";
		}
		$query = "
			INSERT INTO
				{$config['TABLE_PREFIX']}ANNOUNCEMENTS
				(TOPIC_ID, FORUM_ID)
			VALUES
				(?, ?)
		";
		$dbh->do_placeholder_query($query, array($Main, $sboard), __LINE__, __FILE__);
	}

	// ------------------------------------------------------------------------
	// As long as the User didn't post Anonymously we need to update some stuff
	if ($Reged == "1") {

		// ------------------------
		// Up their totalposts by 1
		$Totalposts = $user['USER_TOTAL_POSTS'];
		if ($posts_count == '1') {
			$Totalposts++;
		}
		$Color = $user['USER_NAME_COLOR'];

		// --------------------------------------------
		// Now we check and see if they get a new title
		$query = "
			SELECT USER_TITLE_POST_COUNT, USER_TITLE_NAME
			FROM {$config['TABLE_PREFIX']}USER_TITLES
			ORDER BY USER_TITLE_POST_COUNT
		";
		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$UserTitle = $user['USER_TITLE'];
		while (list($uposts, $utitle) = $dbh->fetch_array($sth)) {
			if ($Totalposts >= $uposts) {
				$UserTitle = $utitle;
			}
		}

		$userob->check_group_join($user['USER_ID'], $Totalposts);

		// --------------------------------------
		// Now update some stuff in their profile
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
			SET USER_TOTAL_POSTS = ? ,
				USER_TITLE = ?
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($Totalposts, $UserTitle, $user['USER_ID']), __LINE__, __FILE__);

		$query_vars = array($date, $date, $IP, $Mnumber, $user['USER_ID']);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USER_DATA
			SET USER_LAST_VISIT_TIME = ? ,
				USER_LAST_POST_TIME = ? ,
				USER_LAST_IP = ? ,
				USER_LAST_POST = ?
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	} else {
		// Set a cookie that holds their last post time
		$html->ubbt_setcookie("lastposttime", $date);
	}

	// ----------------------
	// Mark this post as read
	$_SESSION['topicread'][$Main] = $date + 1;
	$_SESSION['forumvisit']['visit'][$Board] = $date + 1;

	// Optionally close this puppy if perms allow it
	if ($closetopic) {
		if ($userob->check_access("forum", "LOCK_ANY", $Board)) {
			$query = "
				UPDATE {$config['TABLE_PREFIX']}TOPICS
				SET TOPIC_STATUS = ?
				WHERE TOPIC_ID = ?
			";
			$dbh->do_placeholder_query($query, array("C", $Main), __LINE__, __FILE__);
		}
	}

	// --------------------------------------
	// Are we adding this to their favorites?
	if (($dofav) && ($Approved == "1")) {

		$favthread = $Main;
		if (!$favthread) {
			$favthread = $Mnumber;
		}

		$query = "
			SELECT count(*)
			FROM {$config['TABLE_PREFIX']}WATCH_LISTS
			WHERE USER_ID = ?
			  AND WATCH_ID = ?
			  AND WATCH_TYPE = 't'
		";
		$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $favthread), __LINE__, __FILE__);
		list($check) = $dbh->fetch_array($sth);
		if (!$check) {

			// ------------------------------------------------------
			// Insert this post into the favorites
			if (!isset($lastpost)) {
				$lastpost = 0;
			}
			if ($user['USER_EMAIL_WATCHLISTS']) {
				$notify = 1;
			} else {
				$notify = 0;
			}

			$query = "
				INSERT INTO
					{$config['TABLE_PREFIX']}WATCH_LISTS
					(USER_ID, WATCH_ID,WATCH_TYPE,WATCH_NOTIFY_IMMEDIATE)
				VALUES
					(?, ?, ?, ?)
			";
			$dbh->do_placeholder_query($query, array($user['USER_ID'], $favthread, 't', $notify), __LINE__, __FILE__);

			// Update session variables
			$watch_lists = unserialize($_SESSION['watch_lists']);
			$watch_lists['t'][$favthread] = $favthread;
			$_SESSION['watch_lists'] = serialize($watch_lists);

		}
	}

	if ($Approved == "1") {
		$notify_data = array(
			'EVENT' => ($post_is_topic ? 'TOPIC' : 'REPLY'),
			'USER' => $user['USER_ID'],
			'USERNAME' => $postername,
			'FORUM' => $Board,
			'POST' => $Mnumber,
			'TOPIC' => $Main,
			'BODY' => $DefaultBody,
			'HTMLBODY' => $BodySig,
			'TITLE' => $Subject,
			'FORUM_NAME' => $Title,
		);

		handle_watchlist_notifications($notify_data);

		// -------------------------------------------
		// If main isn't set then this is a new thread
		if ($post_is_topic == 1) {
			$extra = ",FORUM_TOPICS = FORUM_TOPICS + 1";
			$Main = $Mnumber;
		}

		$query_vars = array($date, $user['USER_ID'], $postername, $Mnumber, $Main, $Subject, $Icon, $Board);

		$query = "
			UPDATE
				{$config['TABLE_PREFIX']}FORUMS
			SET
				FORUM_POSTS = FORUM_POSTS + 1 ,
				FORUM_LAST_POST_TIME = ? ,
				FORUM_LAST_POSTER_ID = ? ,
				FORUM_LAST_POSTER_NAME = ? ,
				FORUM_LAST_POST_ID = ? ,
				FORUM_LAST_TOPIC_ID = ? ,
				FORUM_LAST_POST_SUBJECT = ? ,
				FORUM_LAST_POST_ICON = ?
			$extra
			WHERE
				FORUM_ID = ?
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

	}

	if (!$Approved) {
		// Loop through all moderators, who wish to be notified and inform them.
		$query = "
			SELECT
				up.USER_REAL_EMAIL, up.USER_LANGUAGE, u.USER_DISPLAY_NAME
			FROM
				{$config['TABLE_PREFIX']}USER_PROFILE AS up,
				{$config['TABLE_PREFIX']}MODERATORS AS m,
				{$config['TABLE_PREFIX']}USERS AS u
			WHERE
				m.FORUM_ID = ?
			AND up.USER_UNAPPROVED_POST_NOTIFY = '1'
			AND up.USER_ID = m.USER_ID
			AND up.USER_ID = u.USER_ID
		";
		$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);

		$mailer = new mailer();
		while (list($email, $lang, $username) = $dbh->fetch_array($sth)) {
			$mailer->set_language($lang);
			$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $username));
			$mailer->set_subject('UAN_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
			$mailer->add_content('UAN_CONTENT', array('FORUM_TITLE' => $Title));
			$mailer->add_content('UAN_CONTENT1', array('POST_URL' => make_ubb_url("ubb=showflat&Number=$Mnumber#Post$Mnumber", $Title, true, true)), true);
			$mailer->add_post($postername, $Subject, array(), $BodySig, $DefaultBody);
			$mailer->ubbt_mail($email);

			// Log this action
			admin_log("MAIL_ADDPOST", $Title . "<br>-> " . $username . " (" . $email . ")");

		}
	}

	clear_online();

	rebuild_islands(0);

	generate_rss_feeds();

	// Update the views
	update_views_counter();

	// -----------------------------
	// Figure out where to send them
	$page = 0;
	$redirect_text = "";
	if (($what == "showthreaded") || ($what == "showflat")) {
		$redirect_text = $ubbt_lang['RET_TOPIC'];
		$redirect = "$what&Number=$Mnumber#Post$Mnumber";

	} else {
		$_SESSION['currentpage'] = 1;
		$redirect_text = $ubbt_lang['RET_FORUM'];
		$redirect = "postlist&Board=$Board";
	}


	// Update their last visit to this forum
	if ($user['USER_ID']) {

		$query_vars = array($date, $Board, $user['USER_ID']);
		$query = "
			REPLACE INTO
				{$config['TABLE_PREFIX']}FORUM_LAST_VISIT
				(LAST_VISIT_TIME, FORUM_ID, USER_ID)
			VALUES
				(?, ?, ?)
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}

	// ------------------------------------
	// Now we give them a confirmation page
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	if ($Approved == "0") {
		$_SESSION['currentpage'] = 1;
		$html->send_redirect(
			array(
				"redirect" => $redirect,
				"Subject" => $Subject,
				"heading" => $ubbt_lang['POST_ENTERED'],
				"body" => "{$ubbt_lang['MOD_CONFIRM']} $redirect_text",
				"Board" => $Board,
				"Category" => $cat_id,
				"parent_forum" => $parent_id,
				"delay" => 10,
				"custom_header_footer" => $fheader,
				"returnlink" => "<a href=\"" . make_ubb_url("ubb=$redirect", "", false) . "\">{$ubbt_lang['FORUM_RETURN']}</a>",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
			)
		);

	} else {

		if (!$what) {
			$what = $user['USER_TOPIC_VIEW_TYPE'];
			if ($is_gallery) {
				$what = "gallery";
			}
			if (!$what) {
				$what = $config['TOPIC_DISPLAY_STYLE'];
			}
			$what = "show$what";
		}

		return array(
			"data" => $data,
			"header" => "",
			"template" => "",
			"footer" => false,
			"location" => "$what&Number=$Mnumber&#Post$Mnumber",
		);
	}
}

?>