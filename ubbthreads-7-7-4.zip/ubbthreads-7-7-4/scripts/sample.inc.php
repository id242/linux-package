<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose: Script skeleton descriptions
  Future:
*/

// Function name should always be page_scriptname_gpc ()
function page_sample_gpc() {
	return array(
		"input" => array(
			// This is an array of variables that you expect from the user
			// "varname" => array("fieldname","requesttype","vartype");
			// requesttype can be either "get", "post" or "both"
			// vartype can be "int", "alpha", "alphanum" or just blank if it can contain any characters
			"var1" => array("var1", "get", "int"),
			"var2" => array("var2", "get", "alphanum"),
		),
		// If you are making a wordlet file to go with your script you specify that here
		"wordlets" => array("sample"),
		// Any special USER_PROFILE fields you require for the script go here
		"user_fields" => "",
		// If this is only available to registered users, set regonly to 1
		"regonly" => 0,
		// If this is only available to admins, set admin_only to 1
		"admin_only" => 0,
		// If this is only available to admins and mods, set admin_or_mod to 1
		"admin_or_mod" => 0,
	);
}


// This is the meat and bones of the script
// function name should always be page_scriptname_run
function page_sample_run() {

	// Normally, the following global variables are needed.
	global $myinfo, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	// Don't change this line, it's always needed
	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars


	// Any variables that you are going to be using in the template for this script need to be defined in this array
	$var1 = $var2 = "Hi! - Ian";
	$smarty_data = array(
		"var1" => $var1,
		"var2" => $var2,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	// This defines some things on how the page is built
	return array(
		"header" => array(
			"title" => "PAGE TITLE", // Title of the page
			"refresh" => 0, // Should the page periodically refresh?
			"user" => "", // You shouldn't need to change
			"Board" => "", // Is this tied to a board?
			"bypass" => 0, // You shouldn't need to change
			"onload" => "", // Any onload properties?
			// Breadcrumb links.
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['LOGIN_PROMPT']}
BREADCRUMB
		,
		),
		"template" => "sample", // The template that is used for this page
		"data" => & $smarty_data,  // Don't change
		"footer" => true, // Shouldn't need to change
		"location" => "", // This is only used in the case of a redirect
	);
}

?>