<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_doratethread_gpc() {
	return array(
		"input" => array(
			"Ratee" => array("Ratee", "post", "int"),
			"Board" => array("Board", "post", "int"),
			"what" => array("what", "post", "alpha"),
			"Number" => array("Number", "post", "int"),
			"Main" => array("Main", "post", "int"),
			"rating" => array("rating", "post", "int"),
		),
		"wordlets" => array("doratethread"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_doratethread_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// -------------------------------
	// Make sure it is between 1 and 5
	if (($rating < 1) || ($rating > 5) || (!is_int($rating))) {
		$html->not_right($ubbt_lang['INVALID_RATING']);
	}

	$query = "
		select FORUM_TITLE,CATEGORY_ID,FORUM_PARENT
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list($Title, $cat_id, $parent_id) = $dbh->fetch_array($sth);

	// ---------------------------------------------------
	// Let's find out if they have rated this topic already
	$query_vars = array($Main, $user['USER_ID']);
	$query = "
	SELECT RATING_TARGET, RATING_VALUE
	FROM   {$config['TABLE_PREFIX']}RATINGS
	WHERE  RATING_TARGET = ?
	AND    RATING_RATER    = ?
	AND    RATING_TYPE    = 't'
	";
	$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	list($check, $rateold) = $dbh->fetch_array($sth);

	if (!$check) {

		// ------------------------------
		// Grab the current rating/rates
		$query = "
			select sum(RATING_VALUE) as RATING_SUM, count(*) as RATING_COUNT
			from {$config['TABLE_PREFIX']}RATINGS
			where RATING_TARGET = ?
			and RATING_TYPE = 't'
		";
		$sth = $dbh->do_placeholder_query($query, array($Main), __LINE__, __FILE__);
		list($crating, $crates) = $dbh->fetch_array($sth);
		$crating = $crating + $rating;
		$crates = $crates + 1;
		$stars = $crating / $crates;
		$stars = intval($stars);

		// ------------------------------------------------------
		// Insert the details into the database
		$query_vars = array($Main, $user['USER_ID'], $rating, 't');
		$query = "
		INSERT INTO {$config['TABLE_PREFIX']}RATINGS
		(RATING_TARGET,RATING_RATER,RATING_VALUE,RATING_TYPE)
		VALUES ( ? , ? , ? , ? )
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

		$query = "
		UPDATE {$config['TABLE_PREFIX']}TOPICS
		SET    TOPIC_RATING = ? ,
		TOPIC_TOTAL_RATES = TOPIC_TOTAL_RATES + 1
		where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($stars, $Main), __LINE__, __FILE__);

	} else {
		// ---------------------
		// Already rated. Time to update their rating.

// ---------------------
//	To prevent users from changing their vote
//	1) uncomment the following single line
//	2) comment-out the rest of this entire "else" section
//		$html -> not_right($ubbt_lang['NOMORERATE']);
// ---------------------

		$query = "
			select sum(RATING_VALUE) as RATING_SUM, count(*) as RATING_COUNT
			from {$config['TABLE_PREFIX']}RATINGS
			where RATING_TARGET = ?
			and RATING_TYPE = 't'
		";
		$sth = $dbh->do_placeholder_query($query, array($Main), __LINE__, __FILE__);
		list($crating, $crates) = $dbh->fetch_array($sth);
		$crating = ($crating + $rating) - $rateold;
		$stars = $crating / $crates;
		$stars = intval($stars);

		// ------------------------------------------------------
		// Update the details in the database
		$query_vars = array($Main, $user['USER_ID'], 't');
		$query = "
		UPDATE {$config['TABLE_PREFIX']}RATINGS
		SET RATING_VALUE = $rating
		WHERE RATING_TARGET = ?
		AND RATING_RATER    = ?
		AND RATING_VALUE	= $rateold
		AND RATING_TYPE		= ?
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);


		$query = "
		UPDATE {$config['TABLE_PREFIX']}TOPICS
		SET    TOPIC_RATING = ? ,

		TOPIC_TOTAL_RATES = TOPIC_TOTAL_RATES

		where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query, array($stars, $Main), __LINE__, __FILE__);

	}

	$cfrm = make_ubb_url("ubb=cfrm", "", false);

	$html->send_redirect(
		array(
			"redirect" => "$what&Number=$Number",
			"heading" => $ubbt_lang['THANKS'],
			"body" => "{$ubbt_lang['RATED']} {$ubbt_lang['RET_TOPIC']}",
			"returnlink" => "",
			"Board" => $Board,
			"Category" => $cat_id,
			"parent_forum" => $parent_id,
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		)
	);
}

?>