<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_changeprefs_gpc() {
	return array(
		"input" => array(
			"what" => array("what", "get", "alpha"),
			"value" => array("value", "get", "int"),
			"curl" => array("curl", "get", ""),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_changeprefs_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob, $lang_cache;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if ($what == "style") {
		if ($userob->is_logged_in) {
			$query = "
				update {$config['TABLE_PREFIX']}USER_PROFILE
				set USER_STYLE = ?
				where USER_ID = ?
			";
			$dbh->do_placeholder_query($query, array($value, $user['USER_ID']), __LINE__, __FILE__);
		}
		$_SESSION['myprefs']['style'] = $value;
	}

	if ($what == "lang") {
		$newlang = $lang_cache[$value]['dir'];
		if (!$newlang) $newlang = $config['LANGUAGE'];
		if ($userob->is_logged_in) {
			$query = "
				update {$config['TABLE_PREFIX']}USER_PROFILE
				set USER_LANGUAGE = ?
				where USER_ID = ?
			";
			$dbh->do_placeholder_query($query, array($newlang, $user['USER_ID']), __LINE__, __FILE__);

		}
		$_SESSION['myprefs']['lang'] = $newlang;
	}

	header("Location: $curl");
	exit;
}

?>