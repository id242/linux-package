<?php defined('UBB_MAIN_PROGRAM') or exit;
/*
  Version: 7.7.3
  Purpose: Display shouts for the ShoutChat box
  Future:
*/

define('NO_WRAPPER', 1);

function page_getshouts_gpc() {
	return array(
		"input" => array(
			"side" => array("side", "both", "alpha"),
			"shout" => array("shout", "post", "int"),
		),
		"wordlets" => array("island_shoutbox"),
		"user_fields" => "USER_IGNORE_LIST",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
}

function page_getshouts_run() {
	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;
	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$shout_limit = 50;

	$delete = false;
	if (!$shout) {
		$delete = true;
		$shout = 0;
	}

	$shouts = array();
	$query = "
		SELECT	s.SHOUT_ID, s.USER_ID, u.USER_DISPLAY_NAME, s.SHOUT_TEXT, s.USER_ID, s.SHOUT_TIME,
			up.USER_NAME_COLOR, u.USER_MEMBERSHIP_LEVEL
		FROM	{$config['TABLE_PREFIX']}SHOUT_BOX as s,
			{$config['TABLE_PREFIX']}USER_PROFILE as up,
			{$config['TABLE_PREFIX']}USERS as u
		WHERE	up.USER_ID = u.USER_ID AND u.USER_ID = s.USER_ID AND
			s.SHOUT_ID > ?
		ORDER BY s.SHOUT_ID DESC
		LIMIT	$shout_limit
	";

	$sth = $dbh->do_placeholder_query($query, array($shout), __LINE__, __FILE__);
	$min_id = "";
	$shout_data = array();
	$shouts = array();
	while ($shout_row = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
		$shout_data[] = $shout_row;
	}
	$shout_list = array_reverse($shout_data);
	$color = "alt-1";

	$last_shout = "";
	$counter = 0;
	foreach ($shout_list as $k => $shout) {
		$last_shout = $shout['SHOUT_ID'];
		$delete = false;
		if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator" || preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']) || $shout['USER_ID'] == $user['USER_ID']) {
			$delete = true;
		}
		$shout['USER_DISPLAY_NAME'] = ubbchars($shout['USER_DISPLAY_NAME']);

		$shout['SHOUT_TEXT'] = str_replace("&lt;br&gt;", "<br>", $shout['SHOUT_TEXT']);

		if (strpos($user['USER_IGNORE_LIST'], "-{$shout['USER_ID']}-") !== false) {
			$shout['SHOUT_TEXT'] = $ubbt_lang['IGNORED_USER'];
		}

		$name_color = $html->user_color($shout['USER_DISPLAY_NAME'], $shout['USER_NAME_COLOR'], $shout['USER_MEMBERSHIP_LEVEL']);

		$is_slash_me = false;

		if (preg_match('#^\s*/me\s+#', $shout['SHOUT_TEXT'])) {
			$is_slash_me = true;
			$shout['SHOUT_TEXT'] = preg_replace('#^\s*/me\s+#', '', $shout['SHOUT_TEXT']);
		}

		$shout['TIME'] = $html->convert_time($shout['SHOUT_TIME'], $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT'], 0, 0);
		$shout['SLASH_ME'] = $is_slash_me;
		$shout['NAME_COLOR'] = $name_color;
		$shout['DELETE'] = $delete;
		$shout['COLOR'] = $side . $color;

		$shouts[] = $shout;

		$color = $html->switch_colors($color);

		if (!$min_id) {
			$min_id = $shout['SHOUT_ID'];
		}
		$counter++;
	}

	// Delete any old shouts
	if ($delete == true && $counter == $shout_limit) {
		$query = "
			delete from {$config['TABLE_PREFIX']}SHOUT_BOX
			where SHOUT_ID < ?
		";
		$dbh->do_placeholder_query($query, array($min_id), __LINE__, __FILE__);
	}


	header('Content-type: text/xml;');
	$smarty->assignByRef("shouts", $shouts);
	$smarty->assign("last_shout", $last_shout);
	$smarty->assign("first_shout", $min_id);
	echo trim(graemlin_url($smarty->fetch("getshouts.tpl"), $smarty));
	return false;
}

?>