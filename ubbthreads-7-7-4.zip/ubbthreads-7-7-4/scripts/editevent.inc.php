<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_editevent_gpc() {
	return array(
		"input" => array(
			"entry" => array("entry", "get", "int"),
		),
		"wordlets" => array("editevent"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_editevent_run() {

	global $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ----------------------------------------
	// Let's make sure they can edit this event
	$query = "
	SELECT USER_ID,CALENDAR_EVENT_DAY,CALENDAR_EVENT_MONTH,CALENDAR_EVENT_YEAR,CALENDAR_EVENT_RECURRING,CALENDAR_EVENT_SUBJECT,CALENDAR_EVENT_DEFAULT_BODY,CALENDAR_EVENT_TYPE
	FROM    {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	WHERE  CALENDAR_EVENT_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($entry), __LINE__, __FILE__);
	list ($owner, $day, $month, $year, $recurring, $subject, $comments, $type) = $dbh->fetch_array($sth);

	if ($owner != $user['USER_ID'] && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
		$html->not_right("{$ubbt_lang['NO_EDIT']}");
	}

	$cols = $config['TEXT_AREA_COLUMNS'];
	$rows = $config['TEXT_AREA_ROWS'];

	// ----------------
	// Is it recurring?
	$never = "";
	$monthly = "";
	$yearly = "";
	${$recurring} = "selected = \"selected\"";

	// ---------------------------
	// Can they add public events?
	if ($userob->check_access("site", "CALENDAR_EVENTS")) {
		// Set default type
		$pri_sel = "";
		$pub_sel = "";
		if ($type == "private") {
			$pri_sel = "selected=\"selected\"";
		} else {
			$pub_sel = "selected=\"selected\"";
		}
		$typeselection = "
			<option value=\"private\" $pri_sel>{$ubbt_lang['PRIVATE']}</option>
			<option value=\"public\" $pub_sel>{$ubbt_lang['PUBLIC']}</option>";
	} else {
		$typeselection = "
			<option value=\"private\">{$ubbt_lang['PRIVATE']}</option>";
	}

	// ---------------------------------
	// Generate the date selection boxes
	$selectmonth = "<select name=\"month\" class=\"form-select\">";
	for ($i = 1; $i <= 12; $i++) {
		$mname = "MONTH$i";
		$mname = $ubbt_lang[$mname];
		$selected = "";
		if ($i == $month) {
			$selected = "selected=\"selected\"";
		}
		$selectmonth .= "<option value=\"$i\" $selected>$mname</option>";
	}
	$selectmonth .= "</select>";

	$selectday = "<select name=\"day\" class=\"form-select\">";
	for ($i = 1; $i <= 31; $i++) {
		$selected = "";
		if ($i == $day) {
			$selected = "selected=\"selected\"";
		}
		$selectday .= "<option $selected>$i</option>";
	}
	$selectday .= "</select>";

	$selectyear = "<select name=\"year\" class=\"form-select\">";
	$temp = getdate();
	$thisyear = $temp["year"];
	for ($i = $thisyear; $i <= ($thisyear + 10); $i++) {
		$selected = "";
		if ($i == $year) {
			$selected = "selected=\"selected\"";
		}
		$selectyear .= "<option $selected>$i</option>";
	}
	$selectyear .= "</select>";

	$text_editor = $html->create_text_editor("comments", "$comments", 2);
	$smarty_data = array(
		"entry" => $entry,
		"subject" => $subject,
		"rows" => $rows,
		"cols" => $cols,
		"selectmonth" => $selectmonth,
		"selectday" => $selectday,
		"selectyear" => $selectyear,
		"never" => $never,
		"monthly" => $monthly,
		"yearly" => $yearly,
		"typeselection" => $typeselection,
		"comments" => $comments,
		"text_editor" => &$text_editor,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['EVENT_HEAD']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['EVENT_HEAD']}
BREADCRUMB
		,
			"javascript" => array(
				0 => "standard_text_editor.js",
			),
		),
		"template" => "editevent",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>