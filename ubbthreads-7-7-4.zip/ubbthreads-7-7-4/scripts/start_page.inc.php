<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_start_page_gpc() {
	return array(
		"input" => array(
			"Loginname" => array("Loginname", "post", ""),
			"Loginpass" => array("Loginpass", "post", ""),
			"firstlogin" => array("firstlogin", "post", ""),
			"buttlogin" => array("buttlogin", "post", ""),
			"Email" => array("Email", "post", ""),
			"ocu" => array("ocu", "post", ""),
			"buttforgot" => array("buttforgot", "post", ""),
			"rememberme" => array("rememberme", "post", ""),
			"from" => array("from", "post", ""),
		),
		"wordlets" => array("start_page"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_start_page_run() {
	global $user, $user_ip, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// -------------------
	// Where are we going?
	$Username = $Loginname;
	$Password = $Loginpass;

	if ($buttforgot) {
		return mail_password($Username, $Email);
	} elseif ($buttlogin) {
		return $html->do_login($Username, $Password, $rememberme, $from, $in['ocu']);
	} else {
		$html->not_right($ubbt_lang['ALL_FIELDS']);
	}
}

// ########################################################################
// mail_password function - Mails a password to a given email address
// ########################################################################

function mail_password($Username = "", $Email = "") {

	global $dbh, $config, $ubbt_lang, $html, $user_ip;

	$ip = $user_ip;

	$checkemail = $Email;
	$checkname = $Username;

	$x_query = "";
	$query_vars = array();
	if ($Username) {
		$x_query = "AND	t1.USER_LOGIN_NAME = ?";
		$query_vars = array($Username);
	} elseif ($Email) {
		$x_query = "AND	t2.USER_REAL_EMAIL = ?";
		$query_vars = array($Email);
	} else {
		// No input?
	}


	if ($Email || $Username) {
		$query = "
			SELECT
				t1.USER_LOGIN_NAME, t2.USER_REAL_EMAIL, t1.USER_ID, t1.USER_DISPLAY_NAME, t2.USER_LANGUAGE
			FROM 
				{$config['TABLE_PREFIX']}USERS AS t1,
				{$config['TABLE_PREFIX']}USER_PROFILE AS t2
			WHERE
				t1.USER_ID = t2.USER_ID
			$x_query
		";
		$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
		list($Username, $Email, $Uid, $Displayname, $Userlang) = $dbh->fetch_array($sth);
	}

	// --------------------------------------------------------------
	// If we found an email address then we mail the password to them
	if ($Email) {
		// -------------------
		// Generate a password
		$a = time();
		mt_srand($a);
		$passset = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '2', '3', '4', '5', '6', '7', '8', '9');
		$chars = sizeof($passset);
		$pass = "";
		for ($i = 0; $i < 6; $i++) {
			$randnum = intval(mt_rand(0, $chars));
			$pass .= $passset[$randnum];
		}

		// ----------------------------
		// Now let's crypt the password
		$crypt = md5($pass);

		// -----------------------------
		// Now let's update the database
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
			SET USER_TEMPORARY_PASSWORD = ?
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query, array($crypt, $Uid), __LINE__, __FILE__);

		// -----------------------
		// Now we mail it to them
		$mailer = new mailer();
		$mailer->set_language($Userlang);
		$mailer->set_subject('PREQ_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $Displayname));
		$mailer->add_content('PREQ_CONTENT', array(
			'IP_ADDY' => $ip,
			'BOARD_TITLE' => $config['COMMUNITY_TITLE'],
			'USERNAME' => $Username,
			'PASSWORD' => $pass
		));
		$mailer->add_content('PREQ_CONTENT1', null);
		$mailer->add_content('PREQ_CONTENT2', array('FULL_URL' => $config['FULL_URL']));
		$mailer->ubbt_mail($Email);

		// ---------------------------
		// Let them know it was mailed
		$cfrm = make_ubb_url("ubb=cfrm", "", false);
		$html->send_redirect(
			array(
				"redirect" => "",
				"heading" => $ubbt_lang['PASS_MAILED'],
				"body" => $ubbt_lang['PASS_MAILED2'],
				"returnlink" => "",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['PASS_MAILED']}
BREADCRUMB
			,
			)
		);
	} else {

		// --------------------------------------------------------------
		// We couldn't find the email address so we need to let them know
		if ($Email) {
			$html->not_right("{$ubbt_lang['NO_EMAIL']} \"$checkemail\"");
		} else {
			$html->not_right("{$ubbt_lang['NO_USERNAME']} \"$checkname\"");
		}

	}
}

?>