<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_faq_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("faq"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_faq_run() {
	global $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Update language string substitutions
	$ubbt_lang['B_HELP'] = $html->substitute($ubbt_lang['B_HELP'], array("BASE_URL" => $config['BASE_URL']));
	$ubbt_lang['B_MISTAKE'] = $html->substitute($ubbt_lang['B_HELP'], array("MAX_EDIT_TIME" => $config['MAX_EDIT_TIME']));
	$ubbt_lang['B_MOREPOSTS'] = $html->substitute($ubbt_lang['B_HELP'], array("TOPICS_PER_PAGE" => $config['TOPICS_PER_PAGE']));

	// ---------------------
	// Send the page to them

	$FULL_URL = $config['FULL_URL'];

	$query = "
		SELECT USER_TITLE_POST_COUNT, USER_TITLE_NAME
		FROM {$config['TABLE_PREFIX']}USER_TITLES
		ORDER BY USER_TITLE_ID ASC
	";
	$sth = $dbh->do_query($query);
	$usertitles = "";
	while (list($posts, $title) = $dbh->fetch_array($sth)) {
		$usertitles .= "$posts\t$title<br>";
	}

	if ($config['CONTACT_LINK_TYPE'] == "url") {
		$ubbt_lang['FAQ_BODY2'] .= " <a href=\"{$config['CONTACT_URL']}\">{$config['SITE_EMAIL_TITLE']}</a>.";
	} else {
		$ubbt_lang['FAQ_BODY2'] .= " <a href=\"mailto:{$config['SITE_EMAIL']}\">{$config['SITE_EMAIL_TITLE']}</a>.";
	}

	$rules = @file_get_contents("{$config['FULL_PATH']}/includes/boardrules.php");
	$smarty_data = array(
		"usertitles" => $usertitles,
		"attach" => $attach,
		"rules" => "$rules",
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['HEAD'],
			"refresh" => 0,
			"user" => "",
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['HEAD']}
BREADCRUMB
		,
		),
		"template" => "faq",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>