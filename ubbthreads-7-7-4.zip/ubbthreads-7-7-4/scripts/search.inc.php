<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_search_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("search"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_search_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $tree;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars


	// -------------------------
	// Predefine a few variables
	$referer = "";
	$board = "";
	$groupquery = "";
	$initialcat = "";
	$options = "";

	if (!$userob->check_access("site", "CAN_SEARCH")) {
		$html->not_right($ubbt_lang['NO_SEARCH']);
	}

	// ------------------------------------------------------------------------
	// Let's figure out if they were on a forum, so we can default to searching
	// that forum
	$referer = find_environmental("HTTP_REFERER");
	if ($referer != "") {
		if (preg_match("#/Board/#", $referer)) {
			preg_match("#Board/(.*)#", $referer, $piece);
		} else {
			preg_match("#Board=(.*)#", $referer, $piece);
		}
		if (isset($piece['1'])) {
			$referer = $piece['1'];
			$board = $referer;
			if (stristr($referer, "&")) {
				list ($board, $crap) = preg_split("#&#", $referer);
			}
			if (stristr($referer, "/")) {
				list ($board, $crap) = preg_split("#/#", $referer);
			}
		}
	}

	if (!sizeof($tree)) {
		list($tree, $style_cache, $lang_cache) = build_forum_cache();
	}

	$allselected = "selected=\"selected\"";
	$options = "";
	$category = "";
	$forums = 0;
	foreach ($tree['categories'] as $cat => $cat_title) {
		$category = "";
		$forums = 0;
		$category .= "<option value=\"c$cat\">$cat_title ------</option>";
		if (!isset($tree[$cat])) continue;
		foreach ($tree[$cat] as $forum_id => $forum_title) {
			$selected = "";
			if ($board == $forum_id) {
				$selected = "selected=\"selected\"";
				$allselected = "";
			}
			if (!$userob->check_access("forum", "READ_TOPICS", $forum_id) || $tree['active'][$forum_id] != 1) {
				continue;
			}
			$category .= "<option value=\"f$forum_id\" $selected>$forum_title</option>";
			$forums++;
		}
		if ($forums) $options .= $category;
	}

	// What type of range?
	if (!isset($config['MAX_SEARCH_RANGE_TYPE']) || !$config['MAX_SEARCH_RANGE_TYPE']) {
		$config['MAX_SEARCH_RANGE_TYPE'] = "years";
	}
	if (!isset($config['MAX_SEARCH_RANGE_VALUE']) || !$config['MAX_SEARCH_RANGE_VALUE']) {
		$config['MAX_SEARCH_RANGE_VALUE'] = 1;
	}
	$config['MAX_SEARCH_RANGE_TYPE'] = preg_replace("/s$/", "", $config['MAX_SEARCH_RANGE_TYPE']);
	$config['MAX_SEARCH_RANGE_TYPE'] = $ubbt_lang[strtoupper($config['MAX_SEARCH_RANGE_TYPE'])];


	$smarty_data = array(
		"allselected" => $allselected,
		"options" => & $options,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['TEXT_SEARCH'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['TEXT_SEARCH']}
BREADCRUMB
		,
		),
		"template" => "search",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>