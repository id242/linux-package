<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_subscription_gpc() {
	return array(
		"input" => array(
			"id" => array("id", "get", "int"),
		),
		"wordlets" => array("subscriptions"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_subscription_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select SUBSCRIPTION_NAME,SUBSCRIPTION_DESCRIPTION,SUBSCRIPTION_BY_DONATION,SUBSCRIPTION_DONATION_AMOUNT,SUBSCRIPTION_BY_TRIAL,SUBSCRIPTION_TRIAL_AMOUNT,SUBSCRIPTION_TRIAL_DURATION,SUBSCRIPTION_TRIAL_INTERVAL,SUBSCRIPTION_BY_REGULAR,SUBSCRIPTION_REGULAR_AMOUNT,SUBSCRIPTION_REGULAR_DURATION,SUBSCRIPTION_REGULAR_INTERVAL,SUBSCRIPTION_IS_RECURRING
		from {$config['TABLE_PREFIX']}SUBSCRIPTIONS
		where GROUP_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	list($name, $desc, $donation, $d_amount, $trial, $trial_amount, $trial_duration, $trial_interval, $regular, $regular_amount, $regular_duration, $regular_interval, $recurr) = $dbh->fetch_array($sth);

	if (!$donation && !$regular) {
		$html->not_right($ubbt_lang['NOT_ENABLED']);
	}

	if ($d_amount == "0.00") {
		$d_amount = $html->substitute($ubbt_lang['D_AMOUNT'], array('CURRENCY' => $ubbt_lang['ANY'], 'AMOUNT' => $ubbt_lang['AMOUNT']));
	} else {
		$d_amount = $html->substitute($ubbt_lang['D_AMOUNT'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $d_amount));
	}

	$check_mo = 0;
	$trial_by_check = "";
	if ($config['ALLOW_MAIL'] != "no_check_mo") {
		$check_mo = 1;
		$check_mo_text = $ubbt_lang[strtoupper($config['ALLOW_MAIL'])];
		if ($trial) {
			$trial_by_check = $html->substitute($ubbt_lang['NO_TRIAL_CHECK'], array('PAYMETHOD' => $ubbt_lang[strtoupper($config['ALLOW_MAIL'])]));
		}
	}

	$trial_string = "";
	if ($trial) {
		$period = $trial_duration;
		if ($trial_interval == "D") $period .= " {$ubbt_lang['DAY']}";
		if ($trial_interval == "W") $period .= " {$ubbt_lang['WEEK']}";
		if ($trial_interval == "M") $period .= " {$ubbt_lang['MONTH']}";
		if ($trial_interval == "Y") $period .= " {$ubbt_lang['YEAR']}";
		$trial_string = $html->substitute($ubbt_lang['TRIAL_PERIOD'], array('PERIOD' => $period, 'CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $trial_amount));
	}

	$regular_string = "";
	if ($regular) {
		if ($recurr) $recurring = $ubbt_lang['RECURRING'];
		$period = $regular_duration;
		if (regular_duration == 1) {
			if ($regular_interval == "D") $period .= " {$ubbt_lang['DAY']}";
			if ($regular_interval == "W") $period .= " {$ubbt_lang['WEEK']}";
			if ($regular_interval == "M") $period .= " {$ubbt_lang['MONTH']}";
			if ($regular_interval == "Y") $period .= " {$ubbt_lang['YEAR']}";
		} else {
			if ($regular_interval == "D") $period .= " {$ubbt_lang['DAYS']}";
			if ($regular_interval == "W") $period .= " {$ubbt_lang['WEEKS']}";
			if ($regular_interval == "M") $period .= " {$ubbt_lang['MONTHS']}";
			if ($regular_interval == "Y") $period .= " {$ubbt_lang['YEARS']}";
		}
		$regular_string = $html->substitute($ubbt_lang['REGULAR_PERIOD'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $regular_amount, 'PERIOD' => $period, 'RECURRING' => $recurring));
	}

	$smarty_data = array(
		"id" => $id,
		"name" => $name,
		"desc" => $desc,
		"donation" => $donation,
		"d_amount" => $d_amount,
		"check_mo" => $check_mo,
		"check_mo_text" => $check_mo_text,
		"regular" => $regular,
		"trial_string" => $trial_string,
		"regular_string" => $regular_string,
		"mystuff" => $html->mystuff(),
		"trial_by_check" => $trial_by_check,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$subs = make_ubb_url("ubb=subscriptions", "", false);

	return array(
		"header" => array(
			"title" => $ubbt_lang['SUB_DETAILS'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 <a href="{$subs}">{$ubbt_lang['MY_SUBS']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 {$ubbt_lang['SUB_DETAILS']}
BREADCRUMB
		,
		),
		"template" => "subscription",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>