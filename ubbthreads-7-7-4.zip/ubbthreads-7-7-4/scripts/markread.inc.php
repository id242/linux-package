<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_markread_gpc() {
	return array(
		"input" => array(
			"forum" => array("forum", "get", "int"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_markread_run() {
	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$currtime = $html->get_date();

	$query = "
		REPLACE INTO
			{$config['TABLE_PREFIX']}FORUM_LAST_VISIT
			(USER_ID, FORUM_ID, LAST_VISIT_TIME)
		VALUES
			(?, ?, ?)
	";
	$dbh->do_placeholder_query($query, array($user['USER_ID'], $forum, $currtime), __LINE__, __FILE__);

	$_SESSION['forumvisit']['visit']["$forum"] = $currtime;
	$_SESSION['forumvisit']["$forum"] = $currtime;

	return false;
}

?>