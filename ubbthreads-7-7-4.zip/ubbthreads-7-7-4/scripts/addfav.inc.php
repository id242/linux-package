<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_addfav_gpc() {
	return array(
		"input" => array(
			"Board" => array("Board", "get", "alphanum"),
			"topic" => array("topic", "get", "int"),
			"Number" => array("Number", "get", "int"),
			"what" => array("what", "get", "alpha"),
		),
		"wordlets" => array("addfav"),
		"user_fields" => "USER_EMAIL_WATCHLISTS",
		"regonly" => 1,
	);
}

function page_addfav_run() {

	global $userob, $user, $in, $html, $ubbt_lang, $config, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	$lastpost = 0;

	// --------------------------
	// What board is this post in
	$query_vars = array($topic);
	$query = "
	select	FORUM_ID, TOPIC_SUBJECT
	from	{$config['TABLE_PREFIX']}TOPICS
	where	TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	list($Board, $Subject) = $dbh->fetch_array($sth);

	// --------------------------------------------
	// Let's find out if they should be here or not
	if (!$userob->check_access("forum", "SEE_FORUM", $Board)) {
		$html->not_right($ubbt_lang['NO_PERM']);
	}

	// $type and $user['USER_ID'] are defined in scripts..no need to escape
	$query_vars = array($user['USER_ID'], $topic);
	$query = "
	SELECT count(*)
	FROM   {$config['TABLE_PREFIX']}WATCH_LISTS
	WHERE  USER_ID  = ?
	AND    WATCH_ID = ?
	AND	 WATCH_TYPE = 't'
	";
	$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	list($check) = $dbh->fetch_array($sth);
	if (!$check) {

		if ($user['USER_EMAIL_WATCHLISTS']) {
			$notify = 1;
		} else {
			$notify = 0;
		}

		$query_vars_2 = array($user['USER_ID'], $topic, $notify);
		$query = "
		INSERT INTO {$config['TABLE_PREFIX']}WATCH_LISTS
		(USER_ID, WATCH_ID, WATCH_TYPE, WATCH_NOTIFY_IMMEDIATE)
		VALUES ( {$user['USER_ID']} , {$topic} , 't' , {$notify} )
		";
		$dbh->do_query($query);

		$confirm = $ubbt_lang['FAV_CONFIRM'];
		$header = $ubbt_lang['ENTRY_IN'];
		$watch_lists = unserialize($_SESSION['watch_lists']);
		$watch_lists['t'][$topic] = $topic;
		$_SESSION['watch_lists'] = serialize($watch_lists);
	} else {
		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
		WHERE  USER_ID  = ?
		AND    WATCH_ID = ?
		AND    WATCH_TYPE = 't'
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
		$confirm = $ubbt_lang['REM_FAV'];
		$header = $ubbt_lang['ENTRY_OUT'];
		$watch_lists = unserialize($_SESSION['watch_lists']);
		unset($watch_lists['t'][$topic]);
		$_SESSION['watch_lists'] = serialize($watch_lists);
	}

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$return = make_ubb_url("ubb={$what}&Board=$Board&Number={$Number}", $Subject, false);

	$html->send_redirect(
		array(
			"redirect" => "$what&Number=$Number&Board=$Board",
			"Subject" => $Subject,
			"heading" => $header,
			"body" => "{$confirm} {$ubbt_lang['RET_TOPIC']}",
			"returnlink" => "<a href=\"{$return}\">{$ubbt_lang['TOPIC_RETURN']}</a>",
			"breadcrumb" => ' <a href="' . $cfrm . '">' . $ubbt_lang['FORUM_TEXT'] . '</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> ' . $header,
		)
	);
}

?>