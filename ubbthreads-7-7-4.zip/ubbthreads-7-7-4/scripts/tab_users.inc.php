<?php defined("INCLUDE_TAB") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

$topics = array();

// We need to exclude any posts from forums we don't have access to.
$no_read = "";
$query = "
	select	FORUM_ID
	from 		{$config['TABLE_PREFIX']}FORUMS
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($fid) = $dbh->fetch_array($sth)) {
	if (!$userob->check_access("forum", "READ_TOPICS", $fid)) {
		$no_read .= "'$fid',";
	}
}

$no_read = preg_replace("/,$/", "", $no_read);
if ($no_read) {
	$no_read = "and t.FORUM_ID not in ($no_read)";
}

// Grab this user's favorite users
// Need to create a list of links so users can filter down to just one of their favorites.
$query = "
	SELECT f.WATCH_ID,u.USER_DISPLAY_NAME
	FROM {$config['TABLE_PREFIX']}WATCH_LISTS f,
			 {$config['TABLE_PREFIX']}USERS u
	WHERE	f.USER_ID = ?
		AND	f.WATCH_ID = u.USER_ID
		AND	f.WATCH_TYPE = 'u'
";
$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);

$in_list = array();

if ($filter) {
	$filter_links = "<tr><td class='popup_menu_content'><a href='" . make_ubb_url("ubb=myhome&tab=$tab&type=$type&sort=$sort", "", false) . "'>{$ubbt_lang['ALL_USERS']}</a></td></tr>";
}

while (list($uid, $name) = $dbh->fetch_array($sth)) {
	$filter_links .= "<tr><td class='popup_menu_content'><a href='" . make_ubb_url("ubb=myhome&tab=$tab&type=$type&sort=$sort&filter=$uid", "", false) . "'>{$ubbt_lang['SHOW_ONE']} $name</a></td></tr>";
	if ($filter && $uid != $filter) continue;
	$in_list[] = $uid;
}

$smarty->assign("filter_links", $filter_links);

if (!sizeof($in_list)) {

	// We have no favorite users
	$smarty->assign('display_no_favs', 1);
	$smarty->assign('no_favs', $ubbt_lang['NO_FAV_USERS']);

} else {

	// We have favorite forums, display in list mode
	$smarty->assign('display_no_favs', 0);
	$smarty->assign('favorite_users', 1);

	// Let's see how many total topics we have
	$query = "
		SELECT count(p.POST_ID)
		FROM {$config['TABLE_PREFIX']}POSTS p,
				 {$config['TABLE_PREFIX']}TOPICS t
		WHERE p.USER_ID IN ( ? )
			AND	p.TOPIC_ID = t.TOPIC_ID
		$no_read
	";
	$sth = $dbh->do_placeholder_query($query, array($in_list), __LINE__, __FILE__);
	list($total_topics) = $dbh->fetch_array($sth);

	$topics_per = array_get($user, 'USER_TOPICS_PER_PAGE', $config['TOPICS_PER_PAGE']);

	// We need to paginate this
	$total_pages = ceil($total_topics / $topics_per);
	$pages1 = $html->paginate($page, $total_pages, "myhome&tab=$tab&sort=$sort&filter=$filter&page=");
	$pages2 = preg_replace('#pagination_\d+#', '', $pages1);
	$smarty->assignByRef("pages1", $pages1);
	$smarty->assignByRef("pages2", $pages2);


	// Current topics per page is 1
	$limit_clause = "";
	if ($page <= 1) {
		$limit_clause = "limit $topics_per";
	} else {
		$limit_clause = "limit " . ($page - 1) * $topics_per . ",$topics_per";
	}

	// We need the icon, subject, author and time posted
	$query = "
		SELECT t.TOPIC_ID,p.POST_ID,p.USER_ID,t.TOPIC_SUBJECT,t.TOPIC_ICON,t.TOPIC_CREATED_TIME,
					 u.USER_DISPLAY_NAME,t.TOPIC_LAST_REPLY_TIME,t.FORUM_ID,f.FORUM_TITLE,p.POST_POSTED_TIME,
					 u.USER_MEMBERSHIP_LEVEL,up.USER_NAME_COLOR
		FROM {$config['TABLE_PREFIX']}TOPICS t,
				 {$config['TABLE_PREFIX']}USERS u,
				 {$config['TABLE_PREFIX']}POSTS p,
				 {$config['TABLE_PREFIX']}FORUMS f,
				 {$config['TABLE_PREFIX']}USER_PROFILE up
		WHERE p.POST_IS_APPROVED = '1'
			AND	p.USER_ID = u.USER_ID
			AND	p.USER_ID IN ( ? )
			AND	p.TOPIC_ID = t.TOPIC_ID
			AND	f.FORUM_ID = t.FORUM_ID
			AND up.USER_ID = u.USER_ID
		$no_read
		ORDER BY $field_sort
		$limit_clause
	";
	$sth = $dbh->do_placeholder_query($query, array($in_list), __LINE__, __FILE__);
	$topic_key = 0;
	while (list($topic_id, $post_id, $user_id, $topic_subject, $topic_icon, $topic_created, $display_name, $last_reply, $forum_id, $forum_title, $posted_time, $level, $color) = $dbh->fetch_array($sth)) {

		$folder = "nonewfolder.gif";
		if (isset($_SESSION['forumvisit']['visit'][$forum_id]) && $posted_time > $_SESSION['forumvisit']['visit'][$forum_id]) {
			$folder = "newfolder.gif";
		}
		if (isset($_SESSION['topicread'][$topic_id]) && $_SESSION['topicread'][$topic_id] > $posted_time) {
			$gonew = "";
			$folder = "nonewfolder.gif";
		}
		$display_name = $html->user_color($display_name, $color, $level);
		$topics[$topic_key]['author'] = "<a href='" . make_ubb_url("ubb=showprofile&User=$user_id", $display_name, false) . "'>$display_name</a>";
		$topics[$topic_key]['folder'] = "<img src='{$config['BASE_URL']}/images/{$style_array['general']}/$folder' alt='' />";
		$topics[$topic_key]['icon'] = "<img src='{$config['BASE_URL']}/images/{$style_array['icons']}/$topic_icon' alt='' />";
		$topics[$topic_key]['subject'] = "<a href=\"" . make_ubb_url("ubb=show{$user['USER_TOPIC_VIEW_TYPE']}&Number=$post_id#Post$post_id", $topic_subject, false) . "\">$topic_subject</a>";
		$topics[$topic_key]['posted'] = $html->convert_time($posted_time, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
		$topics[$topic_key]['forum'] = $forum_title;
		$topics[$topic_key]['color'] = ($topic_key & 1) ? "alt-topicsubject" : "topicsubject";
		$topic_key++;
	}

	$smarty->assignByRef("topics", $topics);
}

?>