<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);
function page_getmediumpic_gpc() {
	return array(
		"input" => array(
			"id" => array("id", "both", "int"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
}

function page_getmediumpic_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select FILE_NAME,FILE_ORIGINAL_NAME,FILE_DIR,FILE_WIDTH,FILE_HEIGHT,FILE_DESCRIPTION,FILE_TYPE,FILE_SIZE
		from {$config['TABLE_PREFIX']}FILES
		where FILE_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	list($name, $name_orig, $dir, $width, $height, $description, $type, $size) = $dbh->fetch_array($sth);
	$description = ubbchars($description);
	if (!$description) {
		$link = $name_orig;
		$description = "&nbsp;";
	} else {
		$link = preg_replace("/ +/", "_", $description) . ".$type";
	}

	$link = htmlentities(preg_replace("/</", "&lt;", $link));

	$description = str_replace("&", "&amp;", $description);
	$link = str_replace("&", "&amp;", $link);


	header('Content-type: text/xml');
	echo "<?xml version=\"1.0\" ?>";
	echo "<imgdata>";
	echo "<imgsrc>{$config['FULL_URL']}/gallery/$dir/medium/$id.$type</imgsrc>";
	echo "<width>$width</width>";
	echo "<height>$height</height>";
	echo "<id>$id</id>";
	echo "<description>$description</description>";
	echo "<thumb>[img]{$config['FULL_URL']}/gallery/{$dir}/thumbs/{$id}.{$type}[/img]</thumb>";
	echo "<medium>[img]{$config['FULL_URL']}/gallery/{$dir}/medium/{$id}.{$type}[/img]</medium>";
	echo "<full>[img]{$config['FULL_URL']}/gallery/{$dir}/full/{$id}.{$type}[/img]</full>";
	echo "<size>" . file_size($size) . "</size>";
	echo "</imgdata>";
	return false;
}

?>