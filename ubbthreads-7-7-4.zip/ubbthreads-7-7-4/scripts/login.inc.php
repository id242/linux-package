<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.3
  Purpose:
  Future:
*/

function page_login_gpc() {
	return array(
		"input" => array(
			"myhome" => array("myhome", "get", "int"),
			"lostpw" => array("lostpw", "get", "int"),
			"ocu" => array("ocu", "get", ""),
		),
		"wordlets" => array("login", "stop_forum_spam"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_login_run() {
	global $myinfo, $smarty, $user, $user_ip, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// TRIGGER some basic housecleaning
	include("libs/triggers.inc.php");
	trigger_pointer_delete();
	trigger_subscriptions();
	update_views_counter();

// Stop Forum Spam
// The PostToHost function is for submitting data to the Stop Forum Spam database.
	function PostToHost($data) {
		$fp = fsockopen("www.stopforumspam.com", 80);
		fputs($fp, "POST /add.php HTTP/1.1\n");
		fputs($fp, "Host: www.stopforumspam.com\n");
		fputs($fp, "Content-type: application/x-www-form-urlencoded\n");
		fputs($fp, "Content-length: " . strlen($data) . "\n");
		fputs($fp, "Connection: close\n\n");
		fputs($fp, $data);
		$output = "";
		while (!feof($fp)) {
			$output .= fgets($fp, 1024);
		}
		fclose($fp);
	}

	if (($config["SFS_ENABLE"] == 1) && ($config["SFS_LEVEL"] > 2)) {
		if (function_exists("file_get_contents") && (ini_get("allow_url_fopen") == 1)) {
			$xml_string = @file_get_contents("https://www.stopforumspam.com/api?ip=" . $user_ip);

			if ($xml_string != false) {
				if ($xml_string != "Error") {
					$xml = new SimpleXMLElement($xml_string);

					if ($xml->appears == "yes") {
						// Only submit to the database if there is a key supplied
						if ($config["SFS_KEY"] != "") {
							PostToHost("username=" . $Loginname . "&ip_addr=" . $user_ip . "&email=" . $Email . "&api_key=" . $config["SFS_KEY"]);
						}
						// Only inform the user of an error if Level 4 (Silent Fail)
						if ($config["SFS_LEVEL"] == 3) {
							$html->not_right($ubbt_lang["SFS_DETECTED_LOGIN"]);
						} else {
							return array("location" => "cfrm");
						}
					}
				} else {
					return array("location" => "cfrm");
				}
			}
		} else {
			$html->not_right($ubbt_lang["SFS_ERROR_REMOTE"]);
		}
	}

	// ----------------------------------------------------------------
	// If we already have a username and password, go to the start page
	if (isset($myinfo['id']) && $myinfo['id'] && isset($myinfo['session']) && ($myinfo['id'] != "deleted")) {
		return $html->start_page('0', '0', '0', $myhome);
	}

	if (isset($in['ocu']) && oncomplete_validate($in['ocu'])) {
		$smarty_data['ocu'] = ubbchars($in['ocu']);
	}

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['LOGIN_PROMPT'],
			"refresh" => 0,
			"user" => "",
			"Board" => "",
			"bypass" => 0,
			"onload" => "document.login.Loginname.focus()",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['LOGIN_PROMPT']}
BREADCRUMB
		,
		),
		"template" => $lostpw ? "lost_password" : "login",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>