<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_domarkallread_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("markallread"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_domarkallread_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$currtime = $html->get_date();

	$_SESSION['forumvisit']['lastonline'] = $currtime;

	$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_DATA
		SET USER_LAST_VISIT_TIME = ?
		WHERE USER_ID = ?
	";

	$dbh->do_placeholder_query($query, array($currtime, $user['USER_ID']), __LINE__, __FILE__);

	$query = "
		SELECT FORUM_ID
		FROM {$config['TABLE_PREFIX']}FORUMS
	";

	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	while (list($board) = $dbh->fetch_array($sth)) {
		$_SESSION['forumvisit']['visit'][$board] = $currtime;
		$_SESSION['forumvisit'][$board] = $currtime;

		$query = "
			REPLACE INTO
				{$config['TABLE_PREFIX']}FORUM_LAST_VISIT
				(USER_ID, FORUM_ID, LAST_VISIT_TIME)
			VALUES
				(?, ?, ?)
		";

		$dbh->do_placeholder_query($query, array($user['USER_ID'], $board, $currtime), __LINE__, __FILE__);
	}

	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "cfrm",
	);
}

?>