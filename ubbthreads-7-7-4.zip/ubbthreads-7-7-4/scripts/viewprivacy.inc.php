<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_viewprivacy_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_viewprivacy_run() {

	global $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------
	// Predefine some variables
	$boardprivacy = "";

	$date = date("M/d/Y");

	$privacy = @file("{$config['FULL_PATH']}/includes/privacy.php");
	if (!is_array($privacy)) {
		$privacy = @file("{config['BASE_URL']}/includes/privacy.php");
	}
	if ($privacy) {
		foreach ($privacy as $linenum => $line) {
			$boardprivacy .= $line;
		}
	}

	$smarty_data['boardprivacy'] = &$boardprivacy;
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['PRIVACY'],
			"refresh" => 0,
			"user" => "",
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['PRIVACY']}
BREADCRUMB
		,
		),
		"template" => "viewprivacy",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>