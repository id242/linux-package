<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_jumper_gpc() {
	return array(
		"input" => array(
			"board" => array("board", "post"),
		),
		"wordlets" => array("jumper"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_jumper_run() {
	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!isset($PHPSESSID)) {
		$PHPSESSID = "";
	}

	if (!$board) {
		$html->not_right("{$ubbt_lang['NO_JUMP']}");
	}

	if (preg_match("/c:/", $board)) {
		$cat = preg_replace("/c:/", "", $board);
		if (!is_numeric($cat)) {
			$cat = "";
		}
		return array(
			"header" => "",
			"template" => "",
			"data" => "",
			"footer" => false,
			"location" => "cfrm&c=$cat&PHPSESSID=$PHPSESSID",
		);
		exit;
	} else {
		if (!is_numeric($board)) {
			$html->not_right("{$ubbt_lang['NO_JUMP']}");
		}
		return array(
			"header" => "",
			"template" => "",
			"data" => "",
			"footer" => false,
			"location" => "postlist&Board=$board&page=1&PHPSESSID=$PHPSESSID",
		);
	}
}

?>