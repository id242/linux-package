<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_addaddress_gpc() {
	return array(
		"input" => array(
			"User" => array("User", "get", "int"),
			"Board" => array("Board", "get", "alphanum"),
			"Number" => array("Number", "get", "int"),
			"what" => array("what", "get", "alpha"),
			"page" => array("page", "get", "int"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 1,
	);
}


function page_addaddress_run() {
	global $in, $user, $ubbt_lang, $config, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Smarty data
	$data = array();

	// ------------------------------------------------------
	// Insert the details into the database
	$query_vars = array($user['USER_ID'], $User);
	$query = "
		REPLACE INTO
			{$config['TABLE_PREFIX']}ADDRESS_BOOK
			(USER_ID, ADDRESS_ENTRY_USER_ID)
		VALUES
			(?, ?)
	";
	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);


	// ---------------------
	// Return to the profile
	return array(
		"data" => $data,
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "showprofile&User=$User",
	);
}

?>