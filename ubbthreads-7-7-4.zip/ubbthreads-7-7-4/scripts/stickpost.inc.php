<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_stickpost_gpc() {
	return array(
		"input" => array(
			"Number" => array("Number", "both", "int"),
			"announce" => array("announce", "both", "int"),
		),
		"wordlets" => array("admin/stickpost", "admin/generic"),
		"user_fields" => "USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
}

function page_stickpost_run() {

	global $html, $user, $in, $ubbt_lang, $config, $myinfo, $forumvisit, $visit, $dbh, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select FORUM_ID,POST_ID
		from {$config['TABLE_PREFIX']}TOPICS
		where TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($Board, $first_post) = $dbh->fetch_array($sth);

	if (!$userob->check_access("forum", "STICKY_ANY", $Board)) exit;

	// ------------------
	// Get the forum info
	$query = "
	SELECT FORUM_CUSTOM_HEADER,FORUM_STYLE,FORUM_TITLE,CATEGORY_ID,FORUM_PARENT,FORUM_IS_RSS,FORUM_RSS_TITLE
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE  FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Board), __LINE__, __FILE__);
	list ($fheader, $fstyle, $Title, $cat_id, $parent_id, $is_rss, $rss_title) = $dbh->fetch_array($sth);

	// -------------------------------------------------
	// Here we need to figure out what stylesheet to use
	if ($fstyle) {
		$html->set_style($fstyle);
	}

	// -----------------------------------------------------------------------
	// Mark the POST_POSTED_TIME and POST_TOPIC_LAST_POST_TIME as sticky and update the sticky field
	$stickvalue = 1;
	$stickboard = $Board;
	$head = "STICKHEAD";
	$body = "STICKBODY";

	if ($announce) {
		$stickvalue = 2;
		$stickboard = "ubbt_all_forums";
		$head = "ANNOUNCEHEAD";
		$body = "ANNOUNCEBODY";
	}

	$query_vars = array($stickvalue, $Number, $Board);
	$query = "
	UPDATE {$config['TABLE_PREFIX']}TOPICS
	SET    TOPIC_IS_STICKY    = ?
	WHERE  TOPIC_ID    = ?
	AND    FORUM_ID     = ?
	";
	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

	// Also insert this into the announcements table.
	$query_vars = array($Number, $stickboard);
	$query = "
	INSERT INTO {$config['TABLE_PREFIX']}ANNOUNCEMENTS
	VALUES
	( ? , ? )
	";
	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

	// ------------------------
	// Send them a page
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "show{$user['USER_TOPIC_VIEW_TYPE']}&Number=$first_post",
			"heading" => $ubbt_lang[$head],
			"body" => $ubbt_lang[$body],
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $parent_id,
			"custom_header_footer" => $fheader,
			"returnlink" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		,
		)
	);
}

?>