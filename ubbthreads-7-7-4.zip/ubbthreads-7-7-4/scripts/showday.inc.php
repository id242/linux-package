<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_showday_gpc() {
	return array(
		"input" => array(
			"day" => array("day", "get", "int"),
			"month" => array("month", "get", "int"),
			"year" => array("year", "get", "int"),
		),
		"wordlets" => array("showday"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_showday_run() {

	global $style_array, $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$event = array();

	// -------------------------------------------------------------------------
	// Need to see what forums they have access to, so we don't show events with
	// topics in private forums

	$query = "
		SELECT FORUM_ID
		FROM   {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_IS_ACTIVE = '1'
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	$i = 0;
	while (list($thisboard) = $dbh->fetch_array($sth)) {
		if (!$userob->check_access("forum", "SEE_FORUM", $thisboard)) {
			continue;
		}
		$canview[$i] = $thisboard;
		$i++;
	}

	// --------------------------------------
	// Do we link to showthreaded or showflat
	isset($user['USER_TOPIC_VIEW_TYPE']) && $mode = $user['USER_TOPIC_VIEW_TYPE'];
	if (!$mode) {
		$mode = $config['TOPIC_DISPLAY_STYLE'];
	}
	$mode = "show$mode";

	// --------------------------------------------------------------
	// Make sure that we have the day we are supposed to be showing
	if (!is_numeric($day) || !is_numeric($month) || !is_numeric($year)) {
		$html->not_right("{$ubbt_lang['ALL_FIELDS']}");
	}


	// ------------------------------------
	// Grab all the birthday's for this day
	$query = "
	SELECT t1.USER_DISPLAY_NAME,t1.USER_ID,t2.USER_BIRTHDAY
	FROM   {$config['TABLE_PREFIX']}USERS as t1,
		 {$config['TABLE_PREFIX']}USER_PROFILE as t2
	WHERE  t2.USER_BIRTHDAY LIKE ?
	AND    t2.USER_PUBLIC_BIRTHDAY = '1'
	AND    t1.USER_ID = t2.USER_ID
	";
	$sth = $dbh->do_placeholder_query($query, array("$month/$day/%"), __LINE__, __FILE__);
	$i = 0;
	while (list($uname, $unumber, $birthday) = $dbh->fetch_array($sth)) {
		@list($bmonth, $bday, $byear) = @preg_split("#/#", $birthday);
		$age = "";
		if ($config['AGE_WITH_BIRTHDAYS'] && $byear) {
			$age = $year - $byear;
			$age = "($age)";
		}
		$event[$i]['edit'] = "";
		$event[$i]['type'] = $ubbt_lang['BDAY'];
		$event[$i]['brief'] = "<a href=\"" . make_ubb_url("ubb=showprofile&User=$unumber", $uname, false) . "\">$uname</a> $age";
		$event[$i]['desc'] = "";
		$i++;
	}

	// ----------------------------------
	// Now grab all events for this day
	$query_vars = array($month, $year, $day, $month, $day, $day, $user['USER_ID']);
	$query = "
	SELECT t1.CALENDAR_EVENT_ID,t1.CALENDAR_EVENT_SUBJECT,t1.CALENDAR_EVENT_BODY,t1.USER_ID,t2.USER_DISPLAY_NAME,t1.CALENDAR_EVENT_TYPE,t1.TOPIC_ID
	FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS AS t1,
	{$config['TABLE_PREFIX']}USERS AS t2
	WHERE ( (t1.CALENDAR_EVENT_MONTH = ? AND t1.CALENDAR_EVENT_YEAR = ? AND t1.CALENDAR_EVENT_DAY = ? AND t1.CALENDAR_EVENT_RECURRING='never')
	OR   (t1.CALENDAR_EVENT_MONTH = ? AND t1.CALENDAR_EVENT_DAY = ? AND t1.CALENDAR_EVENT_RECURRING='yearly')
	OR   (t1.CALENDAR_EVENT_RECURRING='monthly' AND t1.CALENDAR_EVENT_DAY = ?) )
	AND ( (t1.CALENDAR_EVENT_TYPE='public')
	OR   (t1.CALENDAR_EVENT_TYPE='private' AND t1.USER_ID = ? ) )
	AND t1.USER_ID = t2.USER_ID
	";
	$sth = $dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	while (list($entry, $brief, $desc, $owner, $ownername, $type, $topic) = $dbh->fetch_array($sth)) {
		if ($topic) {
			$query = "
				select FORUM_ID
				from {$config['TABLE_PREFIX']}TOPICS
				where TOPIC_ID = ?
			";
			$stx = $dbh->do_placeholder_query($query, array($topic), __LINE__, __FILE__);
			list($forum_id) = $dbh->fetch_array($stx);
			if (!$userob->check_access("forum", "SEE_FORUM", $forum_id)) {
				continue;
			}
		}
		if ($type == "public") {
			$event[$i]['pub_priv'] = "({$ubbt_lang['PUBLIC']})";
		} else {
			$event[$i]['pub_priv'] = "({$ubbt_lang['PRIVATE']})";
		}

		if ($topic) {
			$event[$i]['pub_priv'] = "";
			$event[$i]['type'] = $ubbt_lang['TOPIC'];
			$event[$i]['brief'] = "<a href=\"" . make_ubb_url("ubb=$mode&topic=$topic", $brief, false) . "\">$brief</a> <span class=\"small\">(<i>{$ubbt_lang['BY']} <a href=\"" . make_ubb_url("ubb=showprofile&User=$owner", $ownername, false) . "\">$ownername</a></i>)</span>";
			$event[$i]['desc'] = "";
			$event[$i]['edit'] = "";
		} else {
			$event[$i]['type'] = $ubbt_lang['EVENT'];
			$event[$i]['brief'] = "$brief <span class=\"small\">(<i>{$ubbt_lang['BY']} <a href=\"" . make_ubb_url("ubb=showprofile&User=$owner", $ownername, false) . "\">$ownername</a></i>)</span>";
			if ($desc) {
				$desc = str_replace("\n", "<br>", $desc);
				$event[$i]['desc'] = "<br><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$desc</i>";
			} else {
				$event[$i]['desc'] = "";
			}
			$event[$i]['edit'] = "";
			if ($owner == $user['USER_ID'] || $user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
				$event[$i]['edit'] = "<a href=\"" . make_ubb_url("ubb=editevent&entry=$entry", "", false) . "\">{$ubbt_lang['EDIT_ICON']}</a>";
			}
		}

		$i++;
	}

	$mname = "MONTH$month";

	$date_string = "$month/$day/$year 12:01 PM";
	$converted_date = $html->convert_time(strtotime($date_string), "", "", 1);
	preg_match("/<span class=\"date\">(.*?)<\/span>/", $converted_date, $matches);
	$current = trim($matches['1']);

	$smarty_data = array(
		"month" => $month,
		"day" => $day,
		"year" => $year,
		"mname" => $mname,
		"event" => $event,
		"current_date" => $current,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['HEAD']} $current",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['HEAD']} $current
BREADCRUMB
		,
		),
		"template" => "showday",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>