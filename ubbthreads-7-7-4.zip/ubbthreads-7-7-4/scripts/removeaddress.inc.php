<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_removeaddress_gpc() {
	return array(
		"input" => array(
			"User" => array("User", "get", "int"),
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_removeaddress_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// -----------------------
	// Let's delete the entry
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}ADDRESS_BOOK
		WHERE  USER_ID  = ?
		AND    ADDRESS_ENTRY_USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($user['USER_ID'], $User), __LINE__, __FILE__);

	// ----------------------
	// Return to the addressbook
	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "showprofile&User={$User}",
	);
}

?>