<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_doaddevent_gpc() {
	return array(
		"input" => array(
			"month" => array("month", "post", "int"),
			"day" => array("day", "post", "int", ""),
			"year" => array("year", "post", "int"),
			"subject" => array("subject", "post", ""),
			"comments" => array("comments", "post", ""),
			"recurring" => array("recurring", "post", "alpha"),
			"type" => array("type", "post", "alpha"),
		),
		"wordlets" => array("doaddevent"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_doaddevent_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	$default_comments = $comments;

	// -----------------
	// Censor the input?
	if ($config['DO_CENSOR']) {
		$subject = $html->do_censor($subject);
		$comments = $html->do_censor($comments);
	}

	// ------------------
	// Check the referer
	if (!$config['DISABLE_REFERER_CHECK']) {
		$html->check_refer();
	}

	// ---------------------------
	// Can they add public events?
	if (!$userob->check_access("site", "CALENDAR_EVENTS")) {
		$type = "private";
	}

	// -----------------------------------
	// Make sure we at least got a subject
	if (!$subject) {
		$html->not_right("{$ubbt_lang['ALL_FIELDS']}");
	}

	// ---------------------------------
	// Get some info on the current date
	$temp = getdate();
	$thismonth = $temp["mon"];
	$thisyear = $temp["year"];
	$thisday = $temp["mday"];

	// --------------------------------
	// Add this event into the database
	$subject = str_replace("&", "&amp;", $subject);
	$subject = str_replace("<", "&lt;", $subject);

	$comments = $html->do_markup($comments, "post", "markup");

	$query_vars = array($user['USER_ID'], $day, $month, $year, $recurring, $subject, $comments, $default_comments, $type);

	$query = "
	INSERT INTO {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	(USER_ID,CALENDAR_EVENT_DAY,CALENDAR_EVENT_MONTH,CALENDAR_EVENT_YEAR,CALENDAR_EVENT_RECURRING,CALENDAR_EVENT_SUBJECT,CALENDAR_EVENT_BODY,CALENDAR_EVENT_DEFAULT_BODY,CALENDAR_EVENT_TYPE)
	VALUES
	( ? , ? , ? , ? , ? , ? , ? , ? , ?)
	";
	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "calendar&month=$month&year=$year",
			"heading" => $ubbt_lang['HEAD'],
			"body" => $ubbt_lang['BODY'],
			"returnlink" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['HEAD']}
BREADCRUMB
		,
		)
	);
}

?>