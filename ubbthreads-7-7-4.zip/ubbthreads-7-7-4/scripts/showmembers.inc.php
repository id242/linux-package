<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_showmembers_gpc() {
	return array(
		"input" => array(
			"sb" => array("sb", "get", "int"),
			"page" => array("page", "get", "int"),
			"like" => array("like", "get", "alphanum"),
			"contain" => array("contain", "both", "alphanum"),
		),
		"wordlets" => array("showmembers"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_showmembers_run() {
	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!$userob->check_access("site", "MEMBER_LIST")) {
		$html->not_right($ubbt_lang['MEMBER_DIRECTORY_ANON']);
	}

	$per_page = 50;

	$Sorting = array(
		null,
		array("asc", "lower(u.USER_DISPLAY_NAME) ASC", 2, "USER", ""),
		array("desc", "lower(u.USER_DISPLAY_NAME) DESC", 1, "USER", ""),
		array("asc", "lower(u.USER_MEMBERSHIP_LEVEL) ASC", 4, "STATUS", ""),
		array("desc", "lower(u.USER_MEMBERSHIP_LEVEL) DESC", 3, "STATUS", ""),
		array("asc", "lower(p.USER_HOMEPAGE) ASC", 6, "HOMEPAGE", ""),
		array("desc", "lower(p.USER_HOMEPAGE) DESC", 5, "HOMEPAGE", ""),
		array("asc", "p.USER_TOTAL_POSTS ASC", 8, "POSTS", ""),
		array("desc", "p.USER_TOTAL_POSTS DESC", 7, "POSTS", ""),
		array("asc", "u.USER_ID ASC", 10, "REGISTERED", ""),
		array("desc", "u.USER_ID DESC", 9, "REGISTERED", ""),
		array("asc", "p.USER_AVATAR ASC", 12, "AVATAR", ""),
		array("desc", "p.USER_AVATAR DESC", 11, "AVATAR", ""),
		array("asc", "o.ONLINE_LAST_ACTIVITY ASC, d.USER_LAST_VISIT_TIME ASC", 14, "ONLINE", ""),
		array("desc", "o.ONLINE_LAST_ACTIVITY DESC, d.USER_LAST_VISIT_TIME DESC", 13, "ONLINE", ""),
		array("asc", "lower(p.USER_LOCATION) ASC", 16, "LOCATION", " AND lower(p.USER_LOCATION) <> '' "),
		array("desc", "lower(p.USER_LOCATION) DESC", 15, "LOCATION", " AND lower(p.USER_LOCATION) <> '' "),
		array("asc", "lower(p.USER_OCCUPATION) ASC", 18, "OCCUPATION", " AND lower(p.USER_OCCUPATION) <> '' "),
		array("desc", "lower(p.USER_OCCUPATION) DESC", 17, "OCCUPATION", " AND lower(p.USER_OCCUPATION) <> '' "),
	);

	$sort_by = $Sorting[1][1];
	$sorts = array();
	$images = array();

	if ($sb < 1 || !isset($Sorting[$sb])) {
		$sb = 8; // 8 = Sort by POSTS
//		$sb = 9; // 9 = Sort by REGISTERED
	}

	if ($like == "") {
		$like = -1;
	}

	for ($i = 1; $i < count($Sorting); $i++) {
		$images[$Sorting[$i][3]] = "";
		$sorts[$Sorting[$i][3]] = $i - (($i % 2) ? -1 : 1);
	}

	$sort_by = $Sorting[$sb][1];
	$extra = $Sorting[$sb][4];
	$sorts[$Sorting[$sb][3]] = $sb - (($sb % 2) ? -1 : 1);

	if ($Sorting[$sb][0] == "asc") {
		$images[$Sorting[$sb][3]] = sprintf(' <i class="%s" aria-hidden="true"></i>', "fas fa-sort-up");
	}
	if ($Sorting[$sb][0] == "desc") {
		$images[$Sorting[$sb][3]] = sprintf(' <i class="%s" aria-hidden="true"></i>', "fas fa-sort-down");
	}

	$user['USER_TIME_OFFSET'] = array_get($user, 'USER_TIME_OFFSET', 0);
	$user['USER_TIME_FORMAT'] = array_get($user, 'USER_TIME_FORMAT', $config['TIME_FORMAT']);


	// --------------------
	// Set the default sort
	$andlike = "";
	$t1_andlike = "";
	if (empty($sb)) {
		$sb = 1;
	}

	// We're handling this query directly without calling the placeholder
	// query.
	if ($like != "" && $like != -1) {
		$like_q = addslashes($like);
		if (in_array($like_q, explode(',', $ubbt_lang['USER_SORT']))) {
			$andlike = "AND (u.USER_DISPLAY_NAME LIKE '$like_q%' OR u.USER_DISPLAY_NAME LIKE '" . strtoupper($like_q) . "%')";
			$t1_andlike = "AND (u.USER_DISPLAY_NAME LIKE '$like_q%' OR u.USER_DISPLAY_NAME LIKE '" . strtoupper($like_q) . "%')";
		} else {
			$andlike = "AND u.USER_DISPLAY_NAME LIKE '$like_q%'";
			$t1_andlike = "AND u.USER_DISPLAY_NAME LIKE '$like_q%'";
		}
	}

	// --------------------------------------------------
	// Grab the total number of users out of the database
	$query = "
		SELECT
			COUNT(u.USER_ID)
		FROM
			{$config['TABLE_PREFIX']}USERS AS u,
			{$config['TABLE_PREFIX']}USER_PROFILE AS p
		WHERE
			u.USER_IS_APPROVED = 'yes'
		AND u.USER_IS_BANNED <> '1'
		AND (u.USER_IS_UNDERAGE = '0' OR u.USER_IS_UNDERAGE IS NULL)
		AND u.USER_ID = p.USER_ID
		$andlike $extra
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	list($totalusers) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	$TotalP = ceil($totalusers / $per_page);

	if ($page < 1) {
		$page = 1;
	}

	if ($page > $TotalP) {
		$page = $TotalP;
	}

	// -------------------------------------
	// Here we grab the users for this page
	if ($page == 1) {
		$Totalgrab = $per_page;
	} else {
		$Startat = (($page - 1) * $per_page);
		if ($Startat < 0) $Startat = 0;
		$Totalgrab = "$Startat, $per_page";
	}

	// If we're searching, modify the $t1_andlike clause
	if ($contain) {
		$contain_q = preg_replace("/[^A-Za-z0-9_.-]/", " ", $_GET["contain"]);
		$contain_q = preg_replace('/ +/', ' ', $contain_q);
		$contain_q = strtolower(str_replace(array(" ", "+"), ".*", preg_quote($contain_q)));
		$contain_q = trim($contain_q);
		$t1_andlike = "AND ((LOWER(u.USER_DISPLAY_NAME) REGEXP '$contain_q') OR (LOWER(p.USER_LOCATION) REGEXP '$contain_q'))";
	}

	$pages1 = $html->paginate($page, $TotalP, "showmembers&sb=$sb&like=$like&page=");
	$pages2 = preg_replace('#pagination_\d+#', '', $pages1);


	$limitit = "LIMIT $Totalgrab";

	$cutoff = $html->get_date() - ($config['ONLINE_TIME'] * 60);

	$query = "
		SELECT
			u.USER_DISPLAY_NAME, u.USER_REGISTERED_ON, p.USER_HOMEPAGE, p.USER_TOTAL_POSTS, p.USER_NAME_COLOR, u.USER_MEMBERSHIP_LEVEL, u.USER_ID,
			p.USER_LOCATION, p.USER_OCCUPATION, p.USER_VISIBLE_ONLINE_STATUS, p.USER_MOOD, o.ONLINE_LAST_ACTIVITY, d.USER_LAST_VISIT_TIME,
			p.USER_TITLE, p.USER_CUSTOM_TITLE
		FROM
			{$config['TABLE_PREFIX']}USERS AS u
			LEFT JOIN {$config['TABLE_PREFIX']}USER_PROFILE AS p ON u.USER_ID = p.USER_ID
			LEFT JOIN {$config['TABLE_PREFIX']}USER_DATA AS d ON d.USER_ID = u.USER_ID
			LEFT JOIN {$config['TABLE_PREFIX']}ONLINE AS o ON u.USER_ID = o.USER_ID
		WHERE
			u.USER_IS_APPROVED = 'yes'
		AND u.USER_ID <> 1
		AND u.USER_IS_BANNED = '0'
		AND u.USER_ID = p.USER_ID
		AND (u.USER_IS_UNDERAGE <> '1' OR u.USER_IS_UNDERAGE IS NULL)
		$t1_andlike $extra
		ORDER BY
			{$sort_by}
		$limitit
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	$total = $dbh->total_rows($sth);
	$newpage = 0;

	// -----------------------
	// Set the first row color
	$color = "alt-1";

	$userrow = array();

	// ----------------------------------------------------------------
	// Cycle through the users

	while ($result = $dbh->fetch_array($sth, MYSQLI_ASSOC)) {
		$result['USER_UNCOLORED_NAME'] = $result['USER_DISPLAY_NAME'];
		$result['USER_DISPLAY_NAME'] = $html->user_color($result['USER_DISPLAY_NAME'], $result['USER_NAME_COLOR'], $result['USER_MEMBERSHIP_LEVEL']);

		if ($result['USER_HOMEPAGE'] && $result['USER_HOMEPAGE'] != "http://" && $result['USER_HOMEPAGE'] != "none") {
			$result['USER_HOMEPAGE'] = "http://" . $result['USER_HOMEPAGE'];
			$result['USER_HOMEPAGE'] = preg_replace("#^(http://)+#", "http://", $result['USER_HOMEPAGE']);
			$result['USER_HOMEPAGE'] = sprintf('<a href="%s" target="_blank">%s</a>', $result['USER_HOMEPAGE'], $result['USER_HOMEPAGE']);
		} else {
			$result['USER_HOMEPAGE'] = '';
		}

		$result['USER_REGISTERED_ON'] = $html->convert_time($result['USER_REGISTERED_ON'], $user['USER_TIME_OFFSET'], "m/d/Y");


		if (!$result['USER_MOOD'] || !$config['ENABLE_MOODS']) {
			$result['USER_MOOD'] = "content.gif";
		}

		if ($result['ONLINE_LAST_ACTIVITY'] > $cutoff) {
			if ((!$config['DISABLE_ONLINE_INVISIBLE'] && $result['USER_VISIBLE_ONLINE_STATUS'] == "no") && $result['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
				$result['USER_MOOD'] = "offline.gif";
			}
		} else {
			$result['USER_MOOD'] = "offline.gif";
		}
		if ($result['USER_LAST_VISIT_TIME']) {
			$result['USER_LAST_VISIT_TIME'] = $html->convert_time($result['USER_LAST_VISIT_TIME'], $user['USER_TIME_OFFSET'], "m/d/Y");
		}

		$result['USER_MOOD'] = sprintf('<img src="%s/images/%s/%s" style="vertical-align: middle" alt="" />', $config['BASE_URL'], $style_array['mood'], $result['USER_MOOD']);
		$result['MEMBER_NUMBER'] = $html->substitute($ubbt_lang['USER_NUMBER'], array('USER_ID' => $result['USER_ID']));
		switch ($result['USER_MEMBERSHIP_LEVEL']) {
			case "Administrator":
				$result['USER_MEMBERSHIP_LEVEL'] = $ubbt_lang['USER_ADMIN'];
				break;
			case "GlobalModerator":
				$result['USER_MEMBERSHIP_LEVEL'] = $ubbt_lang['USER_GMOD'];
				break;
			case "Moderator":
				$result['USER_MEMBERSHIP_LEVEL'] = $ubbt_lang['USER_MOD'];
				break;
			default:
				$result['USER_MEMBERSHIP_LEVEL'] = $ubbt_lang['USER_USER'];
		}

		$result['ROW_COLOR'] = $color;

		$userrow[] = $result;
		$color = $html->switch_colors($color);
	}
	// ---------------------------------------
	// Print out the page jumper at the bottom


	$userrowsize = count($userrow);


	// --------------------------
	// Setup the usersort options
	$letters = preg_split("#,#", $ubbt_lang['USER_SORT']);
	$size = sizeof($letters);
	$sortlinks = "<span class=\"nw\">";
	for ($i = 0; $i < $size; $i++) {
		if ($letters[$i] == $like) {
			$sortlinks .= " [" . strtoupper($letters[$i]) . "]";
		} else {
			$sortlinks .= " <a href=\"" . make_ubb_url("ubb=showmembers&like={$letters[$i]}&sb=$sb&page=1", "", false) . "\">" . strtoupper($letters[$i]) . "</a>";
		}
	}

	$sortlinks .= "</span> <span class=\"p10 nw\">";
	for ($i = 0; $i < 10; $i++) {
		if ($i == $like && (preg_match("/^[0-9]$/", $like))) {
			$sortlinks .= " [" . $i . "]";
		} else {
			$sortlinks .= " <a href=\"" . make_ubb_url("ubb=showmembers&like=$i&sb=$sb&page=1", "", false) . "\">$i</a>";
		}
	}
	$sortlinks .= "</span> <span class=\"p10 nw\">";
	$sortlinks .= " <a href=\"" . make_ubb_url("ubb=showmembers&like=-1&sb=$sb&page=1", "", false) . "\">{$ubbt_lang['SHOW_ALL']}</a>";
	$sortlinks .= "</span>";

	if (!$page) $page = "1";

	$smarty_data = array(
		"sortlinks" => & $sortlinks,
		"page" => $page,
		"like" => $like,
		"sorts" => $sorts,
		"userrow" => & $userrow,
		"pages1" => $pages1,
		"pages2" => $pages2,
		"images" => $images,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $config['COMMUNITY_TITLE'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['USER_LIST_TITLE']}
BREADCRUMB
		,
		),
		"template" => "showmembers",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>