<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.2
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);
function page_smilies_gpc() {
	return array(
		"input" => array(
			"name" => array("name", "get"),
		),
		"wordlets" => array("smilies"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_smilies_run() {

	global $style_array, $user, $in, $ubbt_lang, $config, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html->get_graemlins();

	$smarty_data = array();

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	// --------------------------------------------------
	// We need to grab all of the graemlins out of the db
	$query = "
		SELECT GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE
		FROM {$config['TABLE_PREFIX']}GRAEMLINS
		WHERE GRAEMLIN_IS_ACTIVE='1'
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	$i = 0;
	$graemlinlist = "";
	$altcode = "";
	foreach ($html->graemlins as $graemlin) {
		$code = $graemlin['GRAEMLIN_MARKUP_CODE'];
		$smiley = $graemlin['GRAEMLIN_SMILEY_CODE'];
		$image = $graemlin['GRAEMLIN_IMAGE'];
		if (stristr("$code", "$")) {
			@eval("\$code = $code;");
		}
		$code = ":$code:";
		$altcode = "$code";
		if ($smiley) {
			$code = $smiley;
			$altcode .= "     $smiley";
		}
		$graemlinlist .= <<<EOF
			<img onclick="insertAtCaret(goal, ' $code'); goal.focus();" src="{$config['BASE_URL']}/images/{$style_array['graemlins']}/$image" alt="$altcode" title="$altcode" class="cp p2"></a>\n
EOF;
		$i++;

	}

	$smarty_data = array(
		"graemlinlist" => $graemlinlist,
		"stylesheet" => $stylesheet,
		"name" => $name,
	);

	return array(
		"header" => array(
			"title" => $ubbt_lang['SMILIES'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "smiley_markup",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>