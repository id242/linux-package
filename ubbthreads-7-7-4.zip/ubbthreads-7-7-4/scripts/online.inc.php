<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_online_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("online"),
		"user_fields" => "t2.USER_TIME_FORMAT, t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_online_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Define any necessary variables
	$anonrow = array();
	$regrow = array();
	$botrow = array();

	$toffset = $config['SERVER_TIME_OFFSET'];
	if ($user['USER_TIME_OFFSET'] != "") {
		$toffset = $user['USER_TIME_OFFSET'];
	}
	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];

	// Grab all of the known agents from the database
	$agent_array = get_spider_list();
	$known_agents = array();

	// -------------------------
	// Delete the inactive users
	clear_online();

	// ------------------
	// Send a html header
	$query = "
		SELECT
			t1.ONLINE_DISPLAY_NAME, t1.ONLINE_LAST_ACTIVITY, t1.ONLINE_SCRIPT_NAME, t1.ONLINE_BROWSING_FORUM,
			t3.USER_MEMBERSHIP_LEVEL, t2.USER_VISIBLE_ONLINE_STATUS, t2.USER_TITLE, t2.USER_CUSTOM_TITLE, t2.USER_NAME_COLOR,
			t2.USER_ID, t1.ONLINE_USER_IP, t1.ONLINE_REFERER, t1.ONLINE_AGENT, t2.USER_MOOD, t1.ONLINE_POST_ID,
			t1.ONLINE_POST_SUBJECT
		FROM
			{$config['TABLE_PREFIX']}ONLINE AS t1
			LEFT JOIN {$config['TABLE_PREFIX']}USER_PROFILE AS t2
			ON t1.USER_ID = t2.USER_ID
			LEFT JOIN {$config['TABLE_PREFIX']}USERS AS t3
			ON t2.USER_ID = t3.USER_ID
		WHERE
			t1.ONLINE_USER_TYPE LIKE '%r%'
		ORDER BY
			t1.ONLINE_LAST_ACTIVITY DESC
	";
	$reged = $dbh->do_query($query, __LINE__, __FILE__);
	$regrows = $dbh->total_rows($reged);

	$color = "alt-1";

	// Array key tracker
	$x = 0;


	while (list($Username, $Last, $RealWhat, $Board, $Status, $Visible, $Title, $CustomTitle, $Color, $Uid, $IP, $referer, $agent, $mood, $post_id, $post_subject) = $dbh->fetch_array($reged)) {

		$referer = preg_replace("#<#", "&lt;", $referer);
		$agent = preg_replace("#<#", "&lt;", $agent);

		// Check if referer has our url in it
		if (preg_match("#({$config['REFERERS']})#", $referer)) {
			$referer = "";
		}

		$mode = array_get($user, 'USER_TOPIC_VIEW_TYPE', $config['TOPIC_DISPLAY_STYLE']);
		if (!$mode) $mode = "flat";

		// -----------------------------------------------
		// Let's see if we need to block some information
		$Private = 0;
		if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			$Private = 1;
		}
		// ------------------------------------------------------
		// Replace their location with something that makes sense
		// FIXME:  Online location is b0rked
		$What = $ubbt_lang[$RealWhat];
		if (!$What) {
			$What = $ubbt_lang['all_admin'];
		}


		if ((!$config['DISABLE_ONLINE_INVISIBLE']) && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && ($Visible == "no")) {
			continue;
		}
		$extra1 = "";
		$extra2 = "";
		if ($Visible == "no" && !$config['DISABLE_ONLINE_INVISIBLE']) {
			$extra1 = "<span style=\"opacity:0.4;text-shadow: 0 0 5px #666;font-style:italic;\">";
			$extra2 = "</span>";
		}
		$regrow[$x]['extra1'] = $extra1;
		$regrow[$x]['extra2'] = $extra2;
		$Last = $html->convert_time($Last, $toffset, $user['USER_TIME_FORMAT']);
		$EUsername = $Uid;
		$PUsername = $html->user_color($Username, $Color, $Status);

		if ($Status == "Administrator") {
			$Status = $ubbt_lang['USER_ADMIN'];
		}
		if ($Status == "GlobalModerator") {
			$Status = $ubbt_lang['USER_GMOD'];
		}
		if ($Status == "Moderator") {
			$Status = $ubbt_lang['USER_MOD'];
		}
		if ($Status == "User") {
			$Status = $ubbt_lang['USER_USER'];
		}

		// Set a default mood
		if (!$mood) $mood = "content.gif";

		$mood_pieces = explode(".", $mood);

		$regrow[$x]['color'] = $color;
		$regrow[$x]['EUsername'] = $EUsername;
		$regrow[$x]['PUsername'] = $PUsername;
		$regrow[$x]['Username'] = $Username;
		$regrow[$x]['referer'] = $referer;
		$regrow[$x]['agent'] = $agent;
		$regrow[$x]['mood'] = $mood;
		$regrow[$x]['mood_alt'] = preg_replace("#.(gif|jpg|png)$#", "", $mood);

		$legend = $ubbt_lang['THREAD'];
		if ($Board) {
			if (!isset($Boards[$Board])) {
				$query = "
					SELECT FORUM_TITLE, FORUM_IS_GALLERY
					FROM {$config['TABLE_PREFIX']}FORUMS
					WHERE FORUM_ID = '$Board'
				";
				$sti = $dbh->do_query($query, __LINE__, __FILE__);
				list($thisboard, $isgallery) = $dbh->fetch_array($sti);
				$Boards[$Board]['title'] = $thisboard;
				$Boards[$Board]['gallery'] = $isgallery;
			}
			if ($Boards[$Board]['gallery']) {
				$What = $ubbt_lang['showgallery'];
				$mode = "gallery";
				$legend = $ubbt_lang['GALLERY'];
			}
//			$Extra = "<span class=\"small\"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{$ubbt_lang['FORUM']} <a href=\"" . make_ubb_url("ubb=postlist&Board=$Board", $Boards[$Board]['title'], false) . "\">{$Boards[$Board]['title']}</a></span>";
			$Extra = "";
		}

		if ($post_id) {
//			$Extra .= "<span class=\"small\"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$legend <a href=\"" . make_ubb_url("ubb=show{$mode}&Number=$post_id#Post$post_id", $post_subject, false) . "\">$post_subject</a></span>";
			$Extra .= "<a href=\"" . make_ubb_url("ubb=show{$mode}&Number=$post_id", $post_subject, false) . "\">$post_subject</a>";
		}

		if ($Board) {
			if (!$userob->check_access("forum", "SEE_FORUM", $Board)) {
				$Extra = "";
			}
		} else {
			$Extra = "";
		}

		if ($CustomTitle && $config['ONLY_CUSTOM']) {
			$Title = "$CustomTitle";
		}
		if ($CustomTitle && !$config['ONLY_CUSTOM']) {
			$Title = "$Title<br>$CustomTitle";
		}

		$IP = str_replace(":", ":<WBR>", $IP);
		$IP = str_replace(",", ",<WBR>", $IP);

		$regrow[$x]['Status'] = $Status;
		$regrow[$x]['Title'] = $Title;
		$regrow[$x]['Last'] = $Last;
		$regrow[$x]['What'] = $What;
		$regrow[$x]['Extra'] = $Extra;
		$regrow[$x]['IP'] = $IP;

		$color = $html->switch_colors($color);
		$x++;

	}
	$regsize = 0;
	if (isset($regrow)) {
		$regsize = sizeof($regrow);
	}
	$dbh->finish_sth($reged);

	// ----------------------------------------
	// Now show the ones that aren't logged in
	$query = "
		SELECT
			ONLINE_DISPLAY_NAME, ONLINE_LAST_ACTIVITY, ONLINE_SCRIPT_NAME, ONLINE_BROWSING_FORUM, ONLINE_USER_IP,
			ONLINE_REFERER, ONLINE_AGENT, ONLINE_POST_ID, ONLINE_POST_SUBJECT
		FROM
			{$config['TABLE_PREFIX']}ONLINE
		WHERE
			ONLINE_USER_TYPE LIKE '%a%'
		ORDER BY
			ONLINE_LAST_ACTIVITY DESC
	";
	$unreged = $dbh->do_query($query, __LINE__, __FILE__);
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator" || preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL'])) {
		$visitor = $ubbt_lang['FROM_IP'];
	} else {
		$visitor = $ubbt_lang['USERNAME_TEXT'];
	}
	$colorAnon = "alt-1";
	$colorBot = "alt-1";

	$What = "";
	$Extra = "";

	// Anonrow array key number
	$a = 0;
	$b = 0;
	while (list($Username, $Last, $RealWhat, $Board, $IP, $referer, $agent, $post_id, $post_subject) = $dbh->fetch_array($unreged)) {
		$mode = array_get($user, 'USER_TOPIC_VIEW_TYPE', $config['TOPIC_DISPLAY_STYLE']);
		if (!$mode) $mode = "flat";

		$referer = preg_replace("#<#", "&lt;", $referer);
		$agent = preg_replace("#<#", "&lt;", $agent);

		$isbot = false;

		$this_agent = $ubbt_lang['ANON_TEXT'];
		if (isset($known_agents[$agent])) {
			$this_agent = "{$known_agents[$agent]}";
			$isbot = true;
		} else {
			foreach ($agent_array as $k => $spidey) {
				if (preg_match("#" . preg_quote($spidey, "#") . "#i", $agent)) {
					$spiders_cache[$agent] = $k;
					$this_agent = $k;
					$isbot = true;
					break;
				}
			}
		}

		$refererlink = "";

// TOP TRAFFIC SOURCES AS OF 2019Q4
// ** SEARCH **
		$refererlink = preg_match("/\bgoogle\b/i", $referer) ? "Google" : $refererlink;
		$refererlink = preg_match("/\bbing\b/i", $referer) ? "Bing" : $refererlink;
		$refererlink = preg_match("/\byahoo\b/i", $referer) ? "Yahoo" : $refererlink;
		$refererlink = preg_match("/\bbaidu\b/i", $referer) ? "Baidu" : $refererlink;
		$refererlink = preg_match("/\bask\b/i", $referer) ? "Ask" : $refererlink;
		$refererlink = preg_match("/\bexcite\b/i", $referer) ? "Excite" : $refererlink;
		$refererlink = preg_match("/\bduckduckgo\b/i", $referer) ? "DuckDuckGo" : $refererlink;
		$refererlink = preg_match("/\bwolframalpha\b/i", $referer) ? "WoldramAlpha" : $refererlink;
		$refererlink = preg_match("/\byandex\b/i", $referer) ? "Yandex" : $refererlink;
		$refererlink = preg_match("/\blycos\b/i", $referer) ? "Lycos" : $refererlink;
		$refererlink = preg_match("/\baol\b/i", $referer) ? "AOL" : $refererlink;
		$refererlink = preg_match("/\bwebcrawler\b/i", $referer) ? "WebCrawler" : $refererlink;
		$refererlink = preg_match("/\bdogpile\b/i", $referer) ? "Dogpile" : $refererlink;
		$refererlink = preg_match("/\bpintrest\b/i", $referer) ? "Pintrest" : $refererlink;
// ** SOCIAL **
		$refererlink = preg_match("/\bfacebook\b/i", $referer) ? "Facebook" : $refererlink;
		$refererlink = preg_match("/\blinkedin\b/i", $referer) ? "Linkedin" : $refererlink;
		$refererlink = preg_match("/\btwitter\b/i", $referer) ? "Twitter" : $refererlink;
		$refererlink = preg_match("/\breddit\b/i", $referer) ? "Reddit" : $refererlink;
		$refererlink = preg_match("/\bsnapchat\b/i", $referer) ? "Snapchat" : $refererlink;
// ** VIDEO **
		$refererlink = preg_match("/\byoutube\b/i", $referer) ? "YouTube" : $refererlink;
		$refererlink = preg_match("/\bvimeo\.com\b/i", $referer) ? "Vimeo" : $refererlink;
		$refererlink = preg_match("/\btwitch\.tv\b/i", $referer) ? "twitch" : $refererlink;
// ** PHOTO SHARING **
		$refererlink = preg_match("/\binstagram\b/i", $referer) ? "Instagram" : $refererlink;
		$refererlink = preg_match("/\bimger\b/i", $referer) ? "Imger" : $refererlink;
// ** CLASSIFIEDS/FORUMS/Q&A **
		$refererlink = preg_match("/\bebay\b/i", $referer) ? "Ebay" : $refererlink;
		$refererlink = preg_match("/\bquora\b/i", $referer) ? "Quora" : $refererlink;
		$refererlink = preg_match("/\bcraigslist\b/i", $referer) ? "Craigslist" : $refererlink;

// Bold referals from IMAGE searches
		$refererlink = (preg_match("/\bisch\b/i", $referer)) || (preg_match("/\bimages\b/i", $referer)) ? "<span class=\"bold\">" . $refererlink . " Images</span>" : $refererlink;
// Bold forwards from UBB.threads v6 imports
		$refererlink = preg_match("/#\bimport\b/i", $referer) ? "<span class=\"bold\">" . $refererlink . " Import</span>" : $refererlink;

// This is ourself, so we dont need to be listed in the referer list
		$referer = preg_match("#({$config['REFERERS']})#", $referer) ? "" : $referer;

		if ($isbot == true) {
			$botrow[$b]['color'] = $colorBot;
			$botrow[$b]['referer'] = $referer;
			$botrow[$b]['refererlink'] = $refererlink;
			$botrow[$b]['agent'] = $agent;
			$botrow[$b]['id'] = $b;
			$botrow[$b]['guestname'] = $this_agent;
			$colorBot = $html->switch_colors($colorBot);
		} else {
			$anonrow[$a]['color'] = $colorAnon;
			$anonrow[$a]['referer'] = $referer;
			$anonrow[$a]['refererlink'] = $refererlink;
			$anonrow[$a]['agent'] = $agent;
			$anonrow[$a]['id'] = $a;
			$anonrow[$a]['guestname'] = $this_agent;
			$colorAnon = $html->switch_colors($colorAnon);
		}

		$Extra = "";


		// ------------------------------------------------------
		// Replace their location with something that makes sense
		$What = $ubbt_lang[$RealWhat];

		$IP = str_replace(":", ":<WBR>", $IP);
		$IP = str_replace(",", ",<WBR>", $IP);

		if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && (!preg_match("/Moderator/", $user['USER_MEMBERSHIP_LEVEL']))) {
			if ($isbot == true) {
				$botrow[$b]['IP'] = "";
			} else {
				$anonrow[$a]['IP'] = '';
			}
		} else {
			if ($isbot == true) {
				$botrow[$b]['IP'] = $IP;
			} else {
				$anonrow[$a]['IP'] = $IP;
			}
		}

		$Last = $html->convert_time($Last, $toffset, $user['USER_TIME_FORMAT']);

		// -----------------------------------------------------
		// Here we give more information on what they are doing
		$legend = $ubbt_lang['THREAD'];
		if ($Board) {
			if (!isset($Boards[$Board])) {
				$query = "
					SELECT FORUM_TITLE, FORUM_IS_GALLERY
					FROM {$config['TABLE_PREFIX']}FORUMS
					WHERE FORUM_ID = '$Board'
				";
				$sti = $dbh->do_query($query, __LINE__, __FILE__);
				list($thisboard, $isgallery) = $dbh->fetch_array($sti);
				$Boards[$Board]['title'] = $thisboard;
				$Boards[$Board]['gallery'] = $isgallery;
			}
			if ($Boards[$Board]['gallery']) {
				$What = $ubbt_lang['showgallery'];
				$mode = "gallery";
				$legend = $ubbt_lang['GALLERY'];
			}
//			$Extra = "<span class=\"small\"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{$ubbt_lang['FORUM']} <a href=\"" . make_ubb_url("ubb=postlist&Board=$Board", $Boards[$Board]['title'], false) . "\">{$Boards[$Board]['title']}</a></span>";
			$Extra = "";
		}

		if ($post_id) {
//			$Extra .= "<span class=\"small\"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$legend <a href=\"" . make_ubb_url("ubb=show{$mode}&Number=$post_id#Post$post_id", $post_subject, false) . "\">$post_subject</a></span>";
			$Extra .= "<a href=\"" . make_ubb_url("ubb=show{$mode}&Number=$post_id", $post_subject, false) . "\">$post_subject</a>";
		}

		if (!$Extra) {
			$Extra = "";
		}

		if ($isbot == true) {
			$botrow[$b]['Username'] = $Username;
			$botrow[$b]['Last'] = $Last;
			$botrow[$b]['What'] = $What;
			$botrow[$b]['Extra'] = $Extra;
			$b++;
		} else {
			$anonrow[$a]['Username'] = $Username;
			$anonrow[$a]['Last'] = $Last;
			$anonrow[$a]['What'] = $What;
			$anonrow[$a]['Extra'] = $Extra;
			$a++;
		}


	}
	rebuild_islands(0, array("online"));

	// Who gets to see the IP?
	$showip = 0;
	if ($userob->check_access("site", "EXT_INFO")) $showip = 1;

	$anonrows = sizeof($anonrow);
	$botrows = sizeof($botrow);

	$smarty_data = array(
		"regrows" => $regrows,
		"regrow" => $regrow,
		"anonrows" => $anonrows,
		"anonrow" => $anonrow,
		"visitor" => $visitor,
		"showip" => $showip,
		"botrows" => $botrows,
		"botrow" => $botrow,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array(
			"title" => $ubbt_lang['ONLINE_HEAD'],
			"refresh" => "<meta http-equiv=\"refresh\" content=\"180; url=" . make_ubb_url("ubb=online", "", false) . "\" />",
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i> {$ubbt_lang['ONLINE_HEAD']}
BREADCRUMB
		,
		),
		"template" => "online",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>