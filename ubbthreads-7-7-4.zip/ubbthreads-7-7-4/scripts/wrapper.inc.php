<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);

function page_wrapper_gpc() {
	return array(
		"input" => array(
			"style" => array("style", "both", "int"),
			"wrapper" => array("wrapper", "both", "int"),
		),
		"wordlets" => array("wrapper"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 1,
		"admin_or_mod" => 0,
	);
}

function page_wrapper_run() {
	global $wrappers, $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$style = (isset($style) == false || $style == "0") ? $config['DEFAULT_STYLE'] : $style;
	include("{$config['FULL_PATH']}/styles/{$style}.php");

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	$query = "
		SELECT STYLE_ID, STYLE_NAME
		FROM {$config['TABLE_PREFIX']}STYLES
		WHERE STYLE_IS_ACTIVE = '1'
		ORDER BY UPPER(STYLE_NAME) ASC
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	$options = "";
	while (list($style_id, $style_name) = $dbh->fetch_array($sth)) {
		$selected = "";
		$style_name = str_replace("_", " ", $style_name);
		if ($style_id == $style) {
			$selected = "selected=\"selected\"";
		}
		$options .= "<option value=\"$style_id\" $selected>$style_name</option>";
	}

	if ($wrapper || $wrapper == "0") {
		$tbopen = $wrappers[$wrapper]['open'];
		$tbclose = $wrappers[$wrapper]['close'];
		$uri = make_ubb_url("ubb=wrapper&wrapper=$wrapper", "", false);
	}

	$smarty_data = array(
		"stylesheet" => $stylesheet,
		"options" => $options,
		"tbopen" => $tbopen,
		"tbclose" => $tbclose,
		"wrapper" => $wrapper,
		"uri" => $uri,
	);

	return array(
		"header" => array(
			"title" => $ubbt_lang[''],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "wrapper",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>