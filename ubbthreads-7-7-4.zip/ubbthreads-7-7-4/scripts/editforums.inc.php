<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.4
  Purpose:
  Future:
*/

function page_editforums_gpc() {
	return array(
		"input" => array(),
		"wordlets" => array("editforums"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_editforums_run() {

	global $smarty, $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$forum_array = array();
	$forum_data = array();
	$subforums = array();

	$query = "
		select 	c.CATEGORY_TITLE,f.FORUM_ID,f.FORUM_TITLE,fav.WATCH_NOTIFY_IMMEDIATE,fav.WATCH_ID,f.FORUM_PARENT
		from	{$config['TABLE_PREFIX']}CATEGORIES as c,
			{$config['TABLE_PREFIX']}FORUMS as f
		left join {$config['TABLE_PREFIX']}WATCH_LISTS as fav on (f.FORUM_ID = fav.WATCH_ID and fav.USER_ID = ? and fav.WATCH_TYPE = 'f')
		where	f.CATEGORY_ID = c.CATEGORY_ID
		and	f.FORUM_IS_ACTIVE = '1'
		order by c.CATEGORY_SORT_ORDER,f.FORUM_SORT_ORDER
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID']), __LINE__, __FILE__);

	while (list($cat, $id, $title, $immediate, $fav_check, $forum_parent) = $dbh->fetch_array($sth)) {
		if (!$userob->check_access("forum", "SEE_FORUM", $id)) {
			continue;
		}

		if ($forum_parent) {
			$subforums[$forum_parent][] = $id;
		}

		$forum_data[$id] = array(
			"CATEGORY" => $cat,
			"ID" => $id,
			"TITLE" => $title,
			"IMMEDIATE" => $immediate,
			"FAVORITE" => $fav_check,
			"PARENT_TITLE" => "",
			"FORUM_PARENT" => $forum_parent,
		);

	}

	$forum_list = array();

	foreach ($forum_data as $k => $v) {
		$forum_list[] = $v['ID'];
	}

	$is_checked = ' selected="selected" ';
	$is_not_checked = '';
	$i = 0;

	foreach ($forum_list as $v) {
		$email_new_topic = ($forum_data[$v]['IMMEDIATE'] == 2) ? $is_checked : $is_not_checked;
		$email_immediate = ($forum_data[$v]['IMMEDIATE'] == 1) ? $is_checked : $is_not_checked;
		$email_none = ($email_new_topic || $email_immediate) ? $is_not_checked : $is_checked;

		$is_favorite = "";
		$not_favorite = "";
		if ($forum_data[$v]['FAVORITE']) {
			$is_favorite = "checked=\"checked\"";
		} else {
			$not_favorite = "checked=\"checked\"";
		}
		if ($forum_data[$v]['PARENT_TITLE']) {
			$forum_data[$v]['CATEGORY'] = "{$forum_data[$v]['CATEGORY']} <i class=\"fas fa-angle-right fa-fw\" aria-hidden=\"true\"></i> {$forum_data[$v]['PARENT_TITLE']}";
		}
		$forum_data[$v]['class'] = ($i & 1) ? "alt-topicsubject" : "topicsubject";

		$forum_array[] = array(
			"cat" => $forum_data[$v]['CATEGORY'],
			"id" => $forum_data[$v]['ID'],
			"title" => $forum_data[$v]['TITLE'],
			"class" => $forum_data[$v]['class'],
			"none" => $email_none,
			"immediate" => $email_immediate,
			"newtopic" => $email_new_topic,
			"is_favorite" => $is_favorite,
			"not_favorite" => $not_favorite,
		);
		$i++;
	}

	$smarty_data = array(
		"forum_array" => $forum_array,
		"mystuff" => $html->mystuff(),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$home = make_ubb_url("ubb=myhome", "", false);
	return array(
		"header" => array(
			"title" => "{$ubbt_lang['EDIT_FAV_FORUMS']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"javascript" => array('inline_moderation.js'),
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 <a href="{$home}">{$ubbt_lang['VIEW_WATCH']}</a> <i class="fas fa-angle-right fa-fw" aria-hidden="true"></i>
 {$ubbt_lang['EDIT_FAV_FORUMS']}
BREADCRUMB
		,
		),
		"template" => "editforums",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>