<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_previewsig_gpc() {
	return array(
		"input" => array(
			"sig" => array("sig", "post", ""),
		),
		"wordlets" => array("previewsig"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
}

function page_previewsig_run() {

	global $style_array, $smarty, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html, $userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$length = strlen($sig);
	$sig = $html->do_markup($sig, "signature", "markup");

	$span = "";
	$extra = "";

	$max = $userob->check_access("site", "SIGNATURE_LENGTH");
	if ($length > $max) {
		$span = "standouttext";
		$extra = $ubbt_lang['SHORTEN'];
	}

	$sig = graemlin_url($sig, $smarty);
	$sigpreview = $html->substitute($ubbt_lang['LENGTH'], array(
		'SPAN_CLASS' => $span,
		'ACTUAL' => $length,
		'ALLOWED' => $max));
	echo $sigpreview . " $extra<br><hr class=\"signature\"><span class=\"signature\">$sig</span>";

	return false;
}

?>