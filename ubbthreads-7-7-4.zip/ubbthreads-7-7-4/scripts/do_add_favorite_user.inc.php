<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_do_add_favorite_user_gpc() {
	return array(
		"input" => array(
			"user_id" => array("user_id", "post", "int"),
		),
		"wordlets" => array(),
		"user_fields" => "USER_EMAIL_WATCHLISTS",
		"regonly" => 1,
	);
}

function page_do_add_favorite_user_run() {

	global $in, $user, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select 	count(*)
		from		{$config['TABLE_PREFIX']}WATCH_LISTS
		where		USER_ID = ?
		and			WATCH_ID = ?
		and			WATCH_TYPE = 'u'
	";
	$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $user_id), __LINE__, __FILE__);
	list($check) = $dbh->fetch_array($sth);

	if (!$check) {

		if ($user['USER_EMAIL_WATCHLISTS']) {
			$notify = 1;
		} else {
			$notify = 0;
		}

		$query = "
			insert into {$config['TABLE_PREFIX']}WATCH_LISTS
			(USER_ID,WATCH_ID,WATCH_TYPE,WATCH_NOTIFY_IMMEDIATE)
			values
			( ? , ? , 'u' , ? )
		";
		$dbh->do_placeholder_query($query, array($user['USER_ID'], $user_id, $notify), __LINE__, __FILE__);

	}

	// ---------------------
	// Return to the profile
	return array(
		"data" => $data,
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "editusers",
	);
}

?>