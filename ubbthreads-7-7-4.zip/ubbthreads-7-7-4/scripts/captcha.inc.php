<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_captcha_gpc() {
	return array(
		"input" => array(
			"init" => array("init", "get", "int"),
			"id" => array("id", "get", "alphanum"),
			"type" => array("t", "get", "alpha"),
			"test" => array("test", "get", "alphanum"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
}

function page_captcha_run() {

	global $style_array, $smarty, $userob, $user, $user_ip, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// If this is in test mode, make sure they are an admin
	if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
		$test = 0;
	}

	// Delete entries over a half hour old
	$query = "
		delete from {$config['TABLE_PREFIX']}CAPTCHA
		where CAPTCHA_TIMESTAMP < ?
	";
	$dbh->do_placeholder_query($query, array(time() - 1800), __LINE__, __FILE__);

	if ($init) {
		$id = md5(uniqid($user_ip . microtime()));
		echo "$id&t=$type";
		$query = "
			insert into {$config['TABLE_PREFIX']}CAPTCHA
			values
			( ? , ? )
		";
		$dbh->do_placeholder_query($query, array($id, time()), __LINE__, __FILE__);
		exit;
	}

	$query = "
		select CAPTCHA_ID
		from {$config['TABLE_PREFIX']}CAPTCHA
		where CAPTCHA_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	list ($valid) = $dbh->fetch_array($sth);
	if (!$valid && !$test) exit;

	include("{$config['FULL_PATH']}/libs/captcha.inc.php");

	captcha_setup($type, $test);

	// Bypass smarty completely
	return false;
}

?>