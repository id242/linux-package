<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function &page_favlinker_gpc() {
	return array(
		"input" => array(
			"Entry" => array("Entry", "get", "int"),
			"F_Board" => array("F_Board", "get", "alphanum"),
			"Thread" => array("Thread", "get", "int"),
			"partnumber" => array("partnumber", "get", "int"),
			"postmarker" => array("postmarker", "get"),
		),
		"wordlets" => array("addfav"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function &page_favlinker_run() {

	global $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $var_start, $var_eq, $var_sep, $var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------
	// Predefine some variables
	if (!isset($PHPSESSID)) {
		$PHPSESSID = "";
	}

	$html = new html;

	$Board = $F_Board;


	// ----------------------------------------------------------------------------
	// If display is threaded then we need to link to the proper new post, if there
	// is one
	if (($postmarker) && ($user['USER_TOPIC_VIEW_TYPE'] == "threaded")) {
		$Thread = $postmarker;
	}

	// ---------------------------
	// Now send them to the thread
	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "show{$user['USER_TOPIC_VIEW_TYPE']}&Board=$Board&Number=$Thread&fpart=$partnumber$postmarker&PHPSESSID=$PHPSESSID",
	);
}

?>