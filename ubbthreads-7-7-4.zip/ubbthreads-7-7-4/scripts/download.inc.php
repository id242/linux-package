<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

function page_download_gpc() {
	return array(
		"input" => array(
			"Number" => array("Number", "get", "int"),
		),
		"wordlets" => array("download"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_download_run() {

	global $userob, $user, $in, $ubbt_lang, $config, $forumvisit, $visit, $dbh, $html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------------------------------
	// Let's grab the board and filename for this post
	$query = "
	select	t1.FORUM_ID,t3.FILE_NAME,t3.FILE_TYPE,t3.FILE_ORIGINAL_NAME
	from	{$config['TABLE_PREFIX']}TOPICS as t1,
		{$config['TABLE_PREFIX']}POSTS as t2,
		{$config['TABLE_PREFIX']}FILES as t3
	where	t2.POST_ID = t3.POST_ID
	and	t1.TOPIC_ID = t2.TOPIC_ID
	and	t3.FILE_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);
	list($board, $file, $file_extension, $file_orig) = $dbh->fetch_array($sth);


	// --------------------------------------------------------
	// Make sure user can download attachments from this forum.
	if (!$userob->check_access("forum", "CAN_DOWNLOAD", $board)) {
		$html->not_right($ubbt_lang['NO_DOWNLOAD']);
	}

	// ---------------------------------------------
	// Now let's update the total # of downloads by 1
	$query = "
		UPDATE {$config['TABLE_PREFIX']}FILES
		SET FILE_DOWNLOADS = FILE_DOWNLOADS + 1
		WHERE FILE_ID = ?
	";
	$dbh->do_placeholder_query($query, array($Number), __LINE__, __FILE__);

	$file = rawurlencode($file);

	if (function_exists('apache_request_headers')) {
		$headers = apache_request_headers();

		if (isset($headers['If-Modified-Since']) && (strtotime($headers['If-Modified-Since']) == filemtime("{$config['ATTACHMENTS_PATH']}/$file"))) {
			// Checking if the client is validating his cache and if it is current.
			// Client's cache IS current, so we just respond '304 Not Modified'.
			header('Last-Modified: ' . gmdate('D, d M Y H:i:s', filemtime("{$config['ATTACHMENTS_PATH']}/$file")) . ' GMT', true, 304);
			exit;
		}

		header('Last-Modified: ' . gmdate('D, d M Y H:i:s', filemtime("{$config['ATTACHMENTS_PATH']}/$file")) . ' GMT', true, 200);
	}

	// Get rid of spaces in the filename
	$file_orig = preg_replace("/ +/", "-", $file_orig);

	// Display inline
	if ($file_extension == "txt") {
		header("Pragma: public"); // required
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: private", false); // required for certain browsers
		header("Location:  {$config['ATTACHMENTS_URL']}/$file");
	} elseif (preg_match("#(gif|jpg|png)#i", $file_extension)) {
		if ($file_extension == "jpg") $file_extension = "jpeg";
		header("Content-type: image/$file_extension");
		header("Content-Disposition: inline; filename=\"$file_orig\";");
		readfile("{$config['ATTACHMENTS_PATH']}/$file");
	} else {
		header("Content-Type: application/octet-stream");
		header("Content-Disposition: attachment; filename=\"$file_orig\";");
		header("Content-Length: " . filesize("{$config['ATTACHMENTS_PATH']}/$file"));
		readfile("{$config['ATTACHMENTS_PATH']}/$file");
	}
	exit();
}

?>