<?php defined("UBB_MAIN_PROGRAM") or exit;
/*
  Version: 7.7.0
  Purpose:
  Future:
*/

define('NO_WRAPPER', 1);
function page_showimage_gpc() {
	return array(
		"input" => array(
			"id" => array("id", "get", "int"),
			"type" => array("type", "get", "alpha"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

function page_showimage_run() {

	global $html, $style_array, $smarty, $userob, $user, $in, $myinfo, $ubbt_lang, $config, $forumvisit, $visit, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select FILE_NAME,FILE_ORIGINAL_NAME,FILE_DIR,FILE_WIDTH,FILE_HEIGHT,FILE_TYPE
		from {$config['TABLE_PREFIX']}FILES
		where FILE_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);
	list($filename, $filename_orig, $filedir, $width, $height, $ext) = $dbh->fetch_array($sth);


	// ---------------------------------------------
	// Now let's update the total # of downloads by 1
	$query = "
        	UPDATE {$config['TABLE_PREFIX']}FILES
        	SET FILE_DOWNLOADS = FILE_DOWNLOADS + 1
        	WHERE FILE_ID = ?
        ";
	$dbh->do_placeholder_query($query, array($id), __LINE__, __FILE__);


	if ($type == "f") {
		$type = "full";
	} elseif ($type == "m") {
		$type = "medium";
	} elseif ($type == "t") {
		$type = "thumbs";
	} else {
		return false;
	}


	if ($ext == "jpg") {
		header("Content-type: image/jpeg");
	} elseif ($ext == "gif") {
		header("Content-type: image/gif");
	} elseif ($ext == "png") {
		header("Content-type: image/png");
	} else {
		return false;
	}

	readfile("{$config['FULL_PATH']}/gallery/$filedir/$type/$filename");

	return false;
}

?>