<?php
$ubbt_lang['LOGIN_PROMPT'] = "Forum Member Login";
// login
$ubbt_lang['LOGIN_HEAD'] = "Log in to join the conversation";
$ubbt_lang['TEXT_LOGIN'] = "Login Name";
$ubbt_lang['TEXT_PASSWORD'] = "Password";
$ubbt_lang['REMEMBER_ME'] = "Keep me logged in";
$ubbt_lang['FORGOT_PASS'] = "Forgot login name or password?";
$ubbt_lang['REG_HEAD'] = "Don't have a forum account?";
$ubbt_lang['REG_ONE'] = "Register for a new account";
// forgot login/password
$ubbt_lang['RESET_HEAD'] = "Reset Your Password";
$ubbt_lang['RESET_BODY'] = "Have you forgotten your Login Name or Password? No problem. Just enter one of the following that you registered with to have your Login Name and a temporary password emailed to you.";
$ubbt_lang['TEXT_EMAIL'] = "Email Address";
$ubbt_lang['TEXT_OR'] = "or";
// notright/bare
$ubbt_lang['LOGIN_HEAD2'] = "Log In To";
// logout
$ubbt_lang['LOGOUT_HEADER'] = "Logout";
$ubbt_lang['LOGOUT_BODY'] = "Logging you out...";
$ubbt_lang['TEXT_SHOWHIDE'] = "show/hide";
?>