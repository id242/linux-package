<?php
$ubbt_lang['JUMP_NEW'] = "Jump to new posts";
$ubbt_lang['SPOILER_CONTENT'] = "[HIDDEN SPOILER CONTENT]";
$ubbt_lang['NO_RESULTS_FOUND'] = "No results were found.";
$ubbt_lang['TOPIC_REPLIES'] = "Comments";
$ubbt_lang['TOPIC_VIEWS'] = "Views";
$ubbt_lang['ACTIVE_24'] = "Today";
$ubbt_lang['ACTIVE_48'] = "Since Yesterday";
$ubbt_lang['ACTIVE_7'] = "This Week";
$ubbt_lang['MORE'] = "Read More";
$ubbt_lang['EXPAND'] = "EXPAND &#x25BC;";
$ubbt_lang['COLLAPSE'] = "COLLAPSE &#x25B2;";
?>