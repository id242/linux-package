<?php
$ubbt_lang['ADDEVENT'] = "List as event in calendar on ";
$ubbt_lang['ADDSIG'] = "Add Signature";
$ubbt_lang['LOCKED'] = "This topic is locked. You may not edit your post.";
$ubbt_lang['DOPREVIEW'] = "Preview Changes";
$ubbt_lang['POST_TEXT'] = "Post";
$ubbt_lang['MOVE_POST'] = "Move/Merge This Post and Any Replies";
$ubbt_lang['NO_EDIT'] = "You cannot edit this post.";
$ubbt_lang['EDITTIME'] = "This post can no longer be edited because the maximum edit time has expired.";
$ubbt_lang['PEDIT_HEAD'] = "Edit Post";
$ubbt_lang['POST_ICON'] = "Post Icon";
$ubbt_lang['MARK_EDIT'] = "Mark As Edited";
$ubbt_lang['MARK_EDIT_RES'] = "Reason For Edit";
$ubbt_lang['PEDIT_CHANGE'] = "Change Post";
$ubbt_lang['PEDIT_DELETE'] = "Delete Post";
$ubbt_lang['PEDIT_APPROVE'] = "Approve Post";
$ubbt_lang['PEDIT_UNAPPROVE'] = "Unapprove Post";
$ubbt_lang['MANAGE_THREAD'] = "Manage Topic";
$ubbt_lang['NEWS_IMAGE'] = "News Image";
$ubbt_lang['NEWS_IMAGE_1'] = "Choosing a News Image will allow this topic to display on the Forum Portal, regardless of it being within a News Forum. This ignores user groups. Anyone will be able to read this post regardless of their group permissions.<br><br>Only the first post will be displayed on the Forum Portal. To read its replies or download its attachments, users must belong to a group which allows those permissions for which forum the post is located within.";
$ubbt_lang['NO_HTML'] = "HTML is disabled.";
$ubbt_lang['YES_HTML'] = "HTML is enabled.";
$ubbt_lang['NO_MARKUP'] = "UBBCode is disabled.";
$ubbt_lang['YES_MARKUP'] = "UBBCode is enabled.";
?>