<?php
$ubbt_lang['IGNORING_YOU'] = "This user is ignoring you. You cannot include them in a Private Topic.";
$ubbt_lang['NOPRIVS'] = "Private Topics are disabled for your current member level.<br><br>Creating useful topics/replies in the forums will increase your member level and allow you to create new Private Topics.";
$ubbt_lang['MESS_PREVIEW'] = "Preview Message";
$ubbt_lang['ADD_BOOK'] = "Add to Friend List";
$ubbt_lang['NO_LOGGED'] = "You must be logged in to send Private Messages.";
$ubbt_lang['NO_PRIVATE'] = "This user is not accepting Private Messages.";
$ubbt_lang['PRIV_BODY2'] = "You may invite up to %%MAX_IN_PM%% people to a Private Topic. Click the \"Add\" button to add each person.";
$ubbt_lang['TEXT_DELETE'] = "Delete";
$ubbt_lang['SEND_TO'] = "Send to";
$ubbt_lang['OPEN_ADDRESS'] = " or add from your Friend List";
$ubbt_lang['MESSAGE'] = "Message";
$ubbt_lang['ADD_RECIP'] = "Add by Display Name";
$ubbt_lang['RECIP_TEXT'] = "Recipients";
$ubbt_lang['ADD'] = "Add";
$ubbt_lang['ALREADY_ADDED'] = "This recipient has already been added.";
$ubbt_lang['TOO_MANY'] = "You have reached your limit of Private Topic participants.";
$ubbt_lang['NOT_FOUND'] = "We could not find the user: ";
$ubbt_lang['OVERLIMIT'] = "%%USER%% is over their Private Topic limit.";
$ubbt_lang['NOTFOUND'] = "User not found";
$ubbt_lang['SUBMIT_MSG'] = "Post Message";
$ubbt_lang['PRIV_HEAD2'] = "(Private Topic)";
?>