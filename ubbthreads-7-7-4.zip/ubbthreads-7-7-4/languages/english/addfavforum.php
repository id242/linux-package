<?php
$ubbt_lang['NO_PERM'] = "You do not have permission to view this forum. You cannot add it to your Followed Forum list.";
$ubbt_lang['FORUM_IN'] = "Forum Added To Followed List";
$ubbt_lang['FORUM_OUT'] = "Forum Removed From Followed List";
$ubbt_lang['FORUM_CONFIRM'] = "The selected forum has been added to your list of Followed Forums.";
$ubbt_lang['FORUMOUT_CONFIRM'] = "The selected forum has been removed from your list of Followed Forums.";
$ubbt_lang['FORUM_RETURN'] = "Return To Forum";
?>