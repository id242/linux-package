<?php
$ubbt_lang['STOPPED'] = "Voting for this poll has been disabled. Votes are no longer being accepted.";
$ubbt_lang['NO_VOTE'] = "You didn't vote for anything! Please select an option and try again.";
$ubbt_lang['POLL_REGED'] = "You do not have permission to vote in polls.";
$ubbt_lang['POLL_IP'] = "We already have a vote for this poll from your IP address.";
$ubbt_lang['POLL_USER'] = "We already have a vote for this poll from your user profile.";
$ubbt_lang['TOO_MANY'] = "You chose too many options!";
?>