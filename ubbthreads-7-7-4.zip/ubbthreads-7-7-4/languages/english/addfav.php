<?php
$ubbt_lang['REM_FAV'] = "The selected Thread has been removed from your list of Followed Threads";
$ubbt_lang['ENTRY_OUT'] = "Thread Removed From Followed List";
$ubbt_lang['NO_PERM'] = "You do not have permission to view this thread. You cannot add it to your Followed Threads list.";
$ubbt_lang['MAIN_ONLY'] = "You can only add main posts to your Followed Threads list.";
$ubbt_lang['DUP_ENTRY'] = "This has already been added to your Followed Threads.";
$ubbt_lang['ENTRY_IN'] = "Thread Added To Followed List";
$ubbt_lang['FAV_CONFIRM'] = "The selected Thread has been added to your list of Followed Threads.";
$ubbt_lang['FORUM_RETURN'] = "Return To Thread";
?>