<?php
$ubbt_lang['MAIL_FRIEND'] = "Forward A Post By Email";
$ubbt_lang['SENT_FROM'] = "Your Email Address (cannot be changed)";
$ubbt_lang['USE_REAL'] = "Your Name";
$ubbt_lang['WHAT_EMAIL'] = "To Email Address (separate multiple addresses with commas)";
$ubbt_lang['SEND_IT'] = "Send Email";
$ubbt_lang['EMAIL_WHAT'] = "What To Send";
$ubbt_lang['EMAIL_1POST'] = "Just this post";
$ubbt_lang['EMAIL_TOEND'] = "This post and all replies";
$ubbt_lang['EMAIL_ENTIRE'] = "The entire thread";
$ubbt_lang['EMAIL_EXTRA'] = "Your Message. This will be added above the post content (text only. no html or bbcode.)";
$ubbt_lang['EMAIL_NOTE'] = "I thought this might be of interest to you.";
?>