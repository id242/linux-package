<?php
$ubbt_lang['NOTIFY_SENT'] = "Moderator(s) notified";
$ubbt_lang['MAIL_SUBJECT'] = "Moderator notification of post in: %%FORUM_TITLE%% about: %%POST_SUBJECT%%";
$ubbt_lang['MAIL_BODY'] = "%%USERNAME%% has notified you of a post you should look at titled:\n\n'%%POST_SUBJECT%%'\n\nThe reason you are being notified is:\n\n---\n%%REASON%%\n---\n\nPost content below:\n\n---\n%%CONTENT%%\n---\n\nYou can view this post here:\n\n%%POST_URL%%";
?>