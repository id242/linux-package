<?php
$ubbt_lang['CHOOSE_HEAD'] = "Choose a Forum";
$ubbt_lang['CHOOSE_BODY'] = "Which forum should this topic be moved to?";
$ubbt_lang['POINTER'] = "Leave a pointer at the old location?";
$ubbt_lang['DELETE_POINTER'] = "Delete pointer in";
$ubbt_lang['DELETE_DAYS'] = "days";
$ubbt_lang['REASON'] = "Reason for moving? (Will be displayed with the pointer and/or PM)";
$ubbt_lang['SEND_PM'] = "Should a PM be sent to the topic starter?";
$ubbt_lang['SUBMIT'] = "Submit";
$ubbt_lang['GLOBAL'] = "You cannot move a global announcement.";
$ubbt_lang['MOVE_TOPIC'] = "Move topic to:";
$ubbt_lang['MERGE_TOPIC'] = "Merge topic with Post #:";
$ubbt_lang['NO_PERM_MOVE'] = "You do not have permission to move topics in this forum.";
$ubbt_lang['NOTE'] = "Note that the thread starter will see this notice even if they can no longer view their thread.";
?>