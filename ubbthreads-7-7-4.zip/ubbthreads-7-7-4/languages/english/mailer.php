<?php
// Common
$ubbt_lang['EMAIL_HEADER_TEXT'] = "%%COMMUNITY_TITLE%%<br>----------------------------------<br>";
$ubbt_lang['EMAIL_HEADER_HTML'] = "%%COMMUNITY_TITLE%%";
$ubbt_lang['EMAIL_FOOTER_TEXT'] = "This email was auto-generated. Please do not reply.<br>This email was sent by %%HOMEPAGE_TITLE%% (%%HOMEPAGE_URL%%).<br><br>Manage your email preferences:<br>%%FULL_URL%%/ubbthreads.php?ubb=editdisplay<br><br>Update your forum profile:<br>%%FULL_URL%%/ubbthreads.php?ubb=editbasic<br><br>";
$ubbt_lang['EMAIL_FOOTER_HTML'] = "This email was auto-generated. Please do not reply.<br>This email was sent by <a href=\"%%HOMEPAGE_URL%%\">%%HOMEPAGE_TITLE%%</a>.<br>To control which emails we send you, <a href=\"%%FULL_URL%%/ubbthreads.php?ubb=editdisplay\">update your email preferences</a>.";
$ubbt_lang['EMAIL_SALUTE'] = "Hello %%USERNAME%%,";
$ubbt_lang['EMAIL_SALUTE_GEN'] = "Hello,";
$ubbt_lang['EMAIL_ATTACH'] = "<br><br>Post Attachments:<br>";
$ubbt_lang['SPOILER_CONTENT'] = "<b>[HIDDEN SPOILER CONTENT]</b>";
// Common (watchnotify.php is obsolete)
$ubbt_lang['WNT_SUBJECT'] = "New Reply: %%TITLE%%";
$ubbt_lang['WNF_SUBJECT'] = "New Post: %%TITLE%%";
$ubbt_lang['WNU_SUBJECT'] = "New Post by %%USER%%: %%TITLE%%";
$ubbt_lang['WNT_CONTENT'] = "%%USERNAME%% has just created a new thread in a forum you are following at %%BOARD_TITLE%%.";
$ubbt_lang['WNP_CONTENT'] = "%%USERNAME%% has just replied to a thread you are following in the %%FORUM%% forum of %%BOARD_TITLE%%.";
$ubbt_lang['WNX_CONTENT'] = "<br><br>This post is located at:<br>";
$ubbt_lang['WNX_CONTENT1_TEXT'] = "%%POST_URL%%<br><br>Here is the message that has just been posted:<br>----------------------------------<br>";
$ubbt_lang['WNX_CONTENT1_HTML'] = "<a href=\"%%POST_URL%%\">%%POST_URL%%</a><br><br>Here is the message that has just been posted:<br>";
// addpost.php
$ubbt_lang['UAN_SUBJECT'] = "Post Moderation Required at %%BOARD_TITLE%%.";
$ubbt_lang['UAN_CONTENT'] = "A post was made in a forum where you moderate: %%FORUM_TITLE%%<br><br>";
$ubbt_lang['UAN_CONTENT1_TEXT'] = "It requires your approval and is located at:<br>%%POST_URL%%";
$ubbt_lang['UAN_CONTENT1_HTML'] = "It requires your approval and is located at:<br><a href=\"%%POST_URL%%\">%%POST_URL%%</a>";
// adduser, verifyemail
$ubbt_lang['REG_SUBJECT'] = "Thank You For Registering at %%BOARD_TITLE%%";
$ubbt_lang['REG_CONTENT'] = "Thank you for registering at %%BOARD_TITLE%%.<br><br>For your records, your login information is as follows:<br><br>";
$ubbt_lang['REG_CONTENT1'] = " Login Name: %%USERNAME%%<br> Password: %%PASSWORD%%<br><br>You can login to the forums at:<br>";
$ubbt_lang['REG_CONTENT2_TEXT'] = " the link below:<br><br> %%BOARD_URL%%";
$ubbt_lang['REG_CONTENT2_HTML'] = " <a href=\"%%BOARD_URL%%\">%%BOARD_URL%%</a>";
$ubbt_lang['REG_CONTENT3'] = "<br><br>To activate this account, you must first click:<br>";
$ubbt_lang['REG_CONTENT4_TEXT'] = " the following link:<br><br> %%VERIFY_URL%%";
$ubbt_lang['REG_CONTENT4_HTML'] = " <a href=\"%%VERIFY_URL%%\">%%VERIFY_URL%%</a>";
$ubbt_lang['REG_CONTENT5'] = "<br><br>Your account needs to be approved by an Administrator before you can log in. You will receive an email once this has been done.";
$ubbt_lang['REGN_SUBJECT'] = "A New User Has Registered at %%BOARD_TITLE%%";
$ubbt_lang['REGN_CONTENT'] = "A new user has registered at %%BOARD_TITLE%%.<br><br>Here are the details of the user's profile:<br><br> Display Name: <a href=\"%%PROFILE_URL%%\">%%DISPLAY_NAME%%</a><br> Email Address: %%EMAIL_ADDY%%<br><br> IP Address: %%IP_ADDY%% %%IP_GEO%%<br><br> %%REGAGENT%%";
$ubbt_lang['REGN_CONTENT1'] = "<br><br>This account can be approved by visiting:<br>";
$ubbt_lang['REGN_CONTENT2_TEXT'] = " the following link:<br><br> %%MANAGE_URL%%";
$ubbt_lang['REGN_CONTENT2_HTML'] = " <a href=\"%%MANAGE_URL%%\">%%MANAGE_URL%%</a>";
$ubbt_lang['REGN_CONTENT3'] = "<br><br>There is no approval required, but you have chosen to be notified of all new user registrations.";
// reverse geo-ip lookups (adduser, verifyemail)
$ubbt_lang['GEOIP_MOBILE'] = "Mobile";
$ubbt_lang['GEOIP_BROADBAND'] = "Broadband";
$ubbt_lang['GEOIP_ESTIMATED'] = "Estimated";
$ubbt_lang['GEOIP_NOLOC'] = "Unable to get location";
// cfrm (called from triggers)
$ubbt_lang['BDAY_SUBJECT'] = "Happy Birthday from %%BOARD_TITLE%%";
$ubbt_lang['BDAY_CONTENT'] = "%%BOARD_TITLE%% would like to wish you a Happy Birthday!";
// changebasic
$ubbt_lang['PDN_SUBJECT'] = "Display Name Change Request at %%BOARD_TITLE%%";
$ubbt_lang['PDN_CONTENT'] = "A user has requested a display name change.<br><br> Original: %%OLDNAME%%<br><br> Desired: %%NEWNAME%%<br><br>To approve this, please visit ";
$ubbt_lang['PDN_CONTENT1_TEXT'] = "the following link:<br><br> %%APPROVE_URL%%";
$ubbt_lang['PDN_CONTENT1_HTML'] = "<a href=\"%%APPROVE_URL%%\">%%APPROVE_URL%%</a>";
// start_page
$ubbt_lang['PREQ_SUBJECT'] = "Request For Password at %%BOARD_TITLE%%";
$ubbt_lang['PREQ_CONTENT'] = "A user from the IP Address %%IP_ADDY%% has requested a temporary password for the website \"%%BOARD_TITLE%%.\"<br><br>Login Name: %%USERNAME%%<br>Temporary Password: %%PASSWORD%%<br><br>";
$ubbt_lang['PREQ_CONTENT1'] = "This is a temporary password that can be used if you have forgotten your original password. If you did not request this, please ignore this message, as your original password will still work fine.<br><br>";
$ubbt_lang['PREQ_CONTENT2'] = "This password is temporary until you log in. If you do not log in, it will expire after 24 hours.<br><br>Once you have logged in, you should update your password within your <a href=\"%%FULL_URL%%/ubbthreads.php?ubb=editbasic\">Account Profile</a> page.";
// admin/sendpassword
$ubbt_lang['PSND_SUBJECT'] = "Request For Password at %%BOARD_TITLE%%";
$ubbt_lang['PSND_CONTENT'] = "Below you will find the login information for %%BOARD_TITLE%%.<br><br>Login Name: %%USERNAME%%<br> Temporary Password: %%PASSWORD%%";
// sendmessage (merged in mess_reply too)
$ubbt_lang['PMN_SUBJECT'] = "New Private Message at %%BOARD_TITLE%%";
$ubbt_lang['PMN_CONTENT'] = "%%FROMNAME%% has just sent you a private message at %%BOARD_TITLE%%.";
$ubbt_lang['PMN_CONTENT1_TEXT'] = "<br><br>You can reply to this message at:<br><br>%%PM_URL%%<br><br>";
$ubbt_lang['PMN_CONTENT1_HTML'] = "<br><br>You can reply to this message by visiting:<br><a href=\"%%PM_URL%%\">%%PM_URL%%</a><br><br>";
$ubbt_lang['PMN_CONTENT2_TEXT'] = "The private message contents are shown below:<br>----------------------------------<br>";
$ubbt_lang['PMN_CONTENT2_HTML'] = "The private message contents are shown below:<br>";
// donotifymod
$ubbt_lang['DNM_SUBJECT'] = "Moderator Notification of post in %%FORUM_TITLE%% about: %%POST_SUBJECT%%";
$ubbt_lang['DNM_CONTENT'] = "%%USERNAME%% has notified you of a post you should look at titled:<br><br> '%%POST_SUBJECT%%'<br><br>";
$ubbt_lang['DNM_CONTENT1'] = "The reason you are being notified is:<br><br> %%REASON%%<br><br>This post is located at ";
$ubbt_lang['DNM_CONTENT2_TEXT'] = "the following link:<br><br>%%POST_URL%%<br><br>The Post contents are shown below:<br>----------------------------------<br>";
$ubbt_lang['DNM_CONTENT2_HTML'] = "<br><a href=\"%%POST_URL%%\">%%POST_URL%%</a><br><br> The Post contents are shown below:<br>";
// admin/doadduser
$ubbt_lang['DAUSR_SUBJECT'] = "New User Created at %%BOARD_TITLE%%";
$ubbt_lang['DAUSR_CONTENT'] = "Below you will find the login information for %%BOARD_TITLE%%.<br><br> Login Name: %%USERNAME%%<br> Password: %%PASSWORD%%<br><br>Please login and change your password to something secure and more to your liking.<br><br>The forum can be found at:";
$ubbt_lang['DAUSR_CONTENT1_TEXT'] = "<br><br>%%LOGIN_URL%%<br><br>";
$ubbt_lang['DAUSR_CONTENT1_HTML'] = "<br><a href=\"%%LOGIN_URL%%\">%%LOGIN_URL%%</a><br><br>";
// admin/doapproveusers
$ubbt_lang['DAUV_SUBJECT'] = "Verify email for %%USERNAME%%";
$ubbt_lang['DAUV_CONTENT_TEXT'] = "To activate your account, you need to verify your email address by visiting:<br>%%VERIFY_URL%%";
$ubbt_lang['DAUV_CONTENT_HTML'] = "To activate your account, you need to verify your email address by visiting:<br><a href=\"%%VERIFY_URL%%\">%%VERIFY_URL%%</a>";
$ubbt_lang['DAUA_SUBJECT'] = "Your Registration Has Been Approved";
$ubbt_lang['DAUA_CONTENT'] = "Your registration of '%%USERNAME%%' at %%BOARD_TITLE%% has been approved.";
$ubbt_lang['DAUD_SUBJECT'] = "Your Registration Was Denied";
$ubbt_lang['DAUD_CONTENT'] = "Your registration of '%%USERNAME%%' at %%BOARD_TITLE%% has been denied.<br><br>The reason for this is:<br>%%REASON%%<br>";
// admin/doexportemails
$ubbt_lang['DEE_SUBJECT'] = "Email List Request";
$ubbt_lang['DEE_CONTENT'] = "You just created an email list from %%BOARD_TITLE%%. This list does not include those users that have opted out from Admin Emails.<br><br>%%EL_LISTO%%";
// admin/dosendemail
$ubbt_lang['DSE_SUBJECT'] = "%%SUBJECT%%";
$ubbt_lang['DSE_CONTENT'] = "%%CONTENT%%";
// domailthread
$ubbt_lang['DMT_SUBJECT'] = "Post(s) from %%BOARD_TITLE%%";
$ubbt_lang['DMT_CONTENT'] = "%%USERNAME%% has forwarded to you a post or group of posts from %%BOARD_TITLE%%.<br><br>Included note from %%USERNAME%%:<br><i>%%NOTES%%</i><br><br><br>";
$ubbt_lang['DMT_CONTENT1_TEXT'] = "This thread is located at:<br>%%POST_URL%%<br><br>";
$ubbt_lang['DMT_CONTENT1_HTML'] = "This thread is located at:<br><a href=\"%%POST_URL%%\">%%POST_URL%%</a><br><br>";
$ubbt_lang['DMT_CONTENT2'] = "The selected posts are shown below:<br>";
$ubbt_lang['DMP_SUBJECT'] = "Private Message(s) from %%BOARD_TITLE%%";
$ubbt_lang['DMP_CONTENT'] = "Here is the content of your private message(s):";
$ubbt_lang['VER_EMAIL_SUB'] = "Email Verification for %%BOARD_TITLE%%";
$ubbt_lang['VER_EMAIL_CONTENT'] = "A request has been made to update your email address to %%EMAIL%%.<br><br>In order for us to continue with this change, you'll need to visit the link below to validate the email:<br>%%VERIFY_URL%%<br>";
?>