<?php
$ubbt_lang['EVENT_HEAD'] = "Add a New Event";
$ubbt_lang['EVENT_BODY'] = "Add a new event to the calendar by filling out the information below.";
$ubbt_lang['SUBJECT'] = "Event Title";
$ubbt_lang['COMMENTS'] = "Comments";
$ubbt_lang['DATE'] = "Event Date";
$ubbt_lang['RECURRING'] = "Recurring";
$ubbt_lang['YEARLY'] = "Yearly";
$ubbt_lang['MONTHLY'] = "Monthly";
$ubbt_lang['NEVER'] = "Never";
$ubbt_lang['TYPE'] = "Type";
$ubbt_lang['EVENTADMIN'] = "Only Admins can add public events.";
$ubbt_lang['EVENTMODADMIN'] = "Only Admins and Moderators can add public events.";
$ubbt_lang['PUBLIC'] = "Public";
$ubbt_lang['PRIVATE'] = "Private";
$ubbt_lang['ADD'] = "Add Event";
?>