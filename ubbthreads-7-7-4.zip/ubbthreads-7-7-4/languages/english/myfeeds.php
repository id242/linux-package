<?php
$ubbt_lang['NO_MY_FEEDS'] = "The admin hasn't enabled this feature, so there is nothing to display.";
$ubbt_lang['RSS_INFO'] = "RSS Feeds Overview";
$ubbt_lang['RSS_HELP_TOPIC'] = "Some helpful information";
$ubbt_lang['RSS_HELP'] = "The RSS Icons allow you to subscribe to the particular feed. You can subscribe to the most recent posts or topics for a particular forum, or you can choose to subscribe to one of the global feeds which will allow you to see Recent Posts and Topics for all forums. You can also subscribe to your PM inbox and be notified when you have a new message waiting.<br>Enjoy!";
$ubbt_lang['RSS_FORUM'] = "Forum";
$ubbt_lang['RSS_ALL_FORUMS'] = "Taken from all forums";
$ubbt_lang['RSS_SUB_FORUM'] = "Sub forum";
$ubbt_lang['RSS_POSTS'] = "Posts";
$ubbt_lang['RSS_POSTS_R'] = "Recent Posts";
$ubbt_lang['RSS_TOPICS'] = "Topics";
$ubbt_lang['RSS_TOPICS_R'] = "Recent Topics";
$ubbt_lang['RSS_SPECIAL_INFO'] = "Various RSS Feed Information";
$ubbt_lang['RSS_DESC'] = "Description";
$ubbt_lang['RSS_SP1'] = "Private Messages Inbox";
$ubbt_lang['RSS_SP2'] = "Recent Topics: All allowed forums";
$ubbt_lang['RSS_SP3'] = "Recent Posts: All allowed forums";
$ubbt_lang['RSS_FEED'] = "Feed";
$ubbt_lang['RSS_OPML'] = "Opml: ";
$ubbt_lang['RSS_BY'] = "Posted by: ";
$ubbt_lang['RSS_ON'] = " on: ";
$ubbt_lang['RSS_LANG'] = "en-us";
$ubbt_lang['RSS_ERR_TITLE'] = "My Feeds generator";
$ubbt_lang['RSS_ERR_DESC'] = "Explanation";
$ubbt_lang['RSS_ERR_ITEM_TITLE'] = "Unable to return any feed data";
$ubbt_lang['RSS_ERR_ITEM_DESC'] = "Make sure your reader accepts cookies and that you are logged in.";
$ubbt_lang['RSS_IN_DESC'] = "Inbox Description";
?>