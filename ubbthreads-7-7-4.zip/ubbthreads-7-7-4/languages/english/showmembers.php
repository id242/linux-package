<?php
$ubbt_lang['USER_LIST_TITLE'] = "Member List";
$ubbt_lang['PICTURE_TEXT'] = "Picture";
$ubbt_lang['SHOW_ALL'] = "All";
$ubbt_lang['USER_SORT'] = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z";
$ubbt_lang['USER_STATUS'] = "Member Status";
$ubbt_lang['TEXT_HOME'] = "Website";
$ubbt_lang['TOTAL_POSTS'] = "Posts";
$ubbt_lang['REGGED_ON'] = "Joined";
$ubbt_lang['USER_USER'] = "User";
$ubbt_lang['MEMBER_DIRECTORY_ANON'] = "You do not have access to view the Member List.";
$ubbt_lang['ONLINE_STATUS'] = "Last On";
$ubbt_lang['USER_LOCATION'] = "Location";
$ubbt_lang['USER_NUMBER'] = "%%USER_ID%%";
$ubbt_lang['USER_DISPLAY_NAME'] = "Display Name";
$ubbt_lang['USER_OCCUPATION'] = "Occupation";
$ubbt_lang['NO_RESULTS'] = "No users were found matching that criteria.";
$ubbt_lang['USER_TITLE'] = "Title";
?>