<?php
$ubbt_lang['DISABLED'] = "The calendar is disabled.";
$ubbt_lang['NEXTMONTH'] = "Next Month";
$ubbt_lang['PREVMONTH'] = "Previous Month";
$ubbt_lang['ADDEVENT'] = "Add Event";
$ubbt_lang['TOPIC'] = "Forum Topic";
$ubbt_lang['BDAY'] = "Birthday";
$ubbt_lang['EVENT'] = "Event";
$ubbt_lang['TODAY'] = "Today";
$ubbt_lang['CAL_HEAD'] = "Calendar";
$ubbt_lang['SUNDAY'] = "Sun";
$ubbt_lang['MONDAY'] = "Mon";
$ubbt_lang['TUESDAY'] = "Tue";
$ubbt_lang['WEDNESDAY'] = "Wed";
$ubbt_lang['THURSDAY'] = "Thu";
$ubbt_lang['FRIDAY'] = "Fri";
$ubbt_lang['SATURDAY'] = "Sat";
$ubbt_lang['BIRTHDAYS'] = "birthdays";
$ubbt_lang['EVENTS'] = "events";
?>