<?php
$ubbt_lang['DOPREVIEW'] = "Preview Changes";
$ubbt_lang['PEDIT_HEAD'] = "Edit Comment";
$ubbt_lang['PEDIT_CHANGE'] = "Change Comment";
$ubbt_lang['PEDIT_DELETE'] = "Delete Comment";
$ubbt_lang['NO_EDIT'] = "You do not have permission to edit this comment.";
$ubbt_lang['DELETE'] = "Delete Comment";
$ubbt_lang['DELETE_BODY'] = "You may delete this comment if you no longer want it to display on your profile.";
?>