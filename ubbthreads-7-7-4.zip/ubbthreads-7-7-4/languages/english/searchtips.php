<?php
$ubbt_lang['TIPS'] = "Advanced Search Tips";
$ubbt_lang['AND'] = "Use <b>+keyword</b> for required keywords.";
$ubbt_lang['NOT'] = "Use <b>-keyword</b> to exclude posts containing a keyword.";
$ubbt_lang['PHRASE'] = "Use quotes around a phrase to search for exact phrase.";
$ubbt_lang['WILD'] = "Use an * at the end of the word to match partial words.";
$ubbt_lang['SEP_WORDS'] = "Separate words with spaces, not commas.";
$ubbt_lang['GENERAL'] = "Use of multiple keywords without any parameters will return results for any all or just some of the keywords.";
?>