<?php
$ubbt_lang['NO_NOTIFY_F'] = "You will no longer receive notifications regarding the <b>%%NAME%%</b> forum.";
$ubbt_lang['IMMEDIATE_NOTIFY_F'] = "You will now receive a notification when a new post is made in the <b>%%NAME%%</b> forum.";
$ubbt_lang['NEW_TOPIC_NOTIFY_F'] = "You will now receive a notification when a new thread is made in the <b>%%NAME%%</b> forum.";
$ubbt_lang['SUBSCRIBED_T_ONLY_F'] = "You will now receive a notification when a new thread is made in the <b>%%NAME%%</b> forum.";
$ubbt_lang['REMOVE_F'] = "You are no longer watching the <b>%%NAME%%</b> forum.";
$ubbt_lang['NO_NOTIFY_T'] = "You will no longer receive notifications when new posts are made in the <b>%%NAME%%</b> thread.";
$ubbt_lang['IMMEDIATE_NOTIFY_T'] = "You will now receive a notification when a new post is made in the <b>%%NAME%%</b> thread.";
$ubbt_lang['REMOVE_T'] = "You are no longer watching the <b>%%NAME%%</b> thread.";
$ubbt_lang['NO_NOTIFY_U'] = "You will no longer receive notifications when new posts are made by the user <b>%%NAME%%</b>.";
$ubbt_lang['IMMEDIATE_NOTIFY_U'] = "You will now receive notifications when new posts are made by the user <b>%%NAME%%</b>.";
$ubbt_lang['NEW_TOPIC_NOTIFY_U'] = "You will now receive notifications when new thread are made by the user <b>%%NAME%%</b>.";

$ubbt_lang['PLEASE_WAIT_CFRM'] = "Please wait while you are returned to the forum list.";
$ubbt_lang['PLEASE_WAIT_POSTLIST'] = "Please wait while you are returned to the <b>%%NAME%%</b> forum.";
$ubbt_lang['ACTION_COMPLETED'] = "Action Completed";
$ubbt_lang['TYPE_NOT_SPECIFIED'] = "You must specify a forum or thread id to use this page.";
$ubbt_lang['INVALID_TOPIC_ID'] = "The thread you have selected does not exist, or you are now allowed to access that thread.";
$ubbt_lang['INVALID_FORUM_ID'] = "The forum you have selected does not exist, or you are now allowed to access that forum.";
$ubbt_lang['INVALID_USER_ID'] = "The user you have selected does not exist.";
?>