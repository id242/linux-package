<?php
$ubbt_lang['EDIT_FAV_FORUMS'] = "Edit Your Followed Forums";
$ubbt_lang['REMOVE'] = "Remove";
$ubbt_lang['FORUM'] = "Forum";
$ubbt_lang['EMAIL'] = "Notification Type";
$ubbt_lang['DAILY_EMAIL'] = "Daily";
$ubbt_lang['IMMEDIATE_EMAIL'] = "Instant";
$ubbt_lang['REMOVE_BUTTON'] = "Update Followed Forums";
$ubbt_lang['FAVORITE'] = "Followed";
$ubbt_lang['NO'] = "No";
$ubbt_lang['YES'] = "Yes";
$ubbt_lang['NO_EMAIL'] = "None";
$ubbt_lang['EMAIL_ON_NEW_TOPIC'] = "Only new threads";
$ubbt_lang['EMAIL_ON_NEW_POST'] = "All new threads & replies";
?>