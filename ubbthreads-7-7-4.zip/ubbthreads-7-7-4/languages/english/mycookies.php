<?php
$ubbt_lang['COOKIE_INFO_1'] = "Expiring (deleting) the cookies set in your browser by this forum may be useful if you suspect that this forum is malfunctioning for you.";
$ubbt_lang['COOKIE_INFO_2'] = "Expiring these cookies will do NO harm, but it will log you out from this forum. Once you log in and start using the forum again, new cookies will be set automatically.";
$ubbt_lang['COOKIE_CURRENT'] = "Current Cookie Information";
$ubbt_lang['COOKIE_NAME'] = "Cookie Name";
$ubbt_lang['COOKIE_VALUE'] = "Cookie Value";
$ubbt_lang['COOKIE_EXPIRE'] = "Expire Cookies";
?>