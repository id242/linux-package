<?php
$ubbt_lang['REPLY_TEXT'] = "New Reply";
$ubbt_lang['LOCKED'] = "This thread is locked. You can not reply to it.";
$ubbt_lang['NO_R_ANNOUNCE'] = "You may not reply to announcement.";
$ubbt_lang['ADDSIG'] = "Add Signature";
$ubbt_lang['ADDPOLL'] = "Add a poll to this post. Total questions: ";
$ubbt_lang['ADDTOFAV'] = "Add this thread to my Followed Threads";
$ubbt_lang['READ_PERM'] = "You are not logged in or you have read-only privileges for this forum. This could be due to one of several reasons:<br><br><span style=\"font-weight:normal;\">1. You are not logged in. Fill in the form at the bottom of this page and try again.<br>2. You may not have sufficient privileges to access this page.<br>3. If you are trying to post, your account may be awaiting activation.</span>";
$ubbt_lang['NOT_APP'] = "You cannot reply to a post that has not been approved.";
$ubbt_lang['REPLY_HEAD'] = "Reply To:";
$ubbt_lang['FILL_FORM'] = "New Reply";
$ubbt_lang['NO_HTML'] = "HTML is disabled.";
$ubbt_lang['YES_HTML'] = "HTML is enabled.";
$ubbt_lang['NO_MARKUP'] = "UBBCode is disabled.";
$ubbt_lang['YES_MARKUP'] = "UBBCode is enabled.";
$ubbt_lang['CHOOSE_NAME'] = "Anonymous postings are allowed, so you may choose any unregistered name by which to post.";
$ubbt_lang['POST_ICON'] = "Post Icon";
$ubbt_lang['POST_TEXT'] = "Post";
$ubbt_lang['SUBMIT_REPLY'] = "Post Reply";
$ubbt_lang['DO_PREVIEW'] = "Preview Reply";
$ubbt_lang['CAN_ATTACH'] = "and/or Attach File.";
$ubbt_lang['IN_RESPONSE'] = "In Response To:";
$ubbt_lang['FLOODCONTROL'] = "You can only make a post every %%SO_OFTEN%% seconds. Please try again once this time has expired.";
$ubbt_lang['CLOSE_TOPIC'] = "Lock this thread";
?>