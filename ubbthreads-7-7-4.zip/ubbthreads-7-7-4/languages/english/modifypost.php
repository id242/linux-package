<?php
$ubbt_lang['DELETE_THREAD'] = "Delete Topic";
$ubbt_lang['NO_DELETE_FIRST'] = "Since this post is the first post in a topic and already has replies it may not be deleted.";
$ubbt_lang['DELETE_TIMER'] = "This post may no longer be deleted.";
$ubbt_lang['FILE_TOO_BIG'] = "Files can be no larger than %%ATTACH_SIZE%% bytes.";
$ubbt_lang['FILESALLOWED'] = "You may upload files with the following extension only:";
$ubbt_lang['NO_EDIT'] = "You cannot edit this post.";
$ubbt_lang['PEDIT_DELETE'] = "Delete Post";
$ubbt_lang['DELETE_CONF'] = "Confirm that you want to delete this post.";
$ubbt_lang['YES_DELETE'] = "Delete This Post";
$ubbt_lang['PEDIT_APPROVE'] = "Approve Post";
$ubbt_lang['APPROVE_CONF'] = "Confirm that you want to approve this post.";
$ubbt_lang['YES_APPROVE'] = "Approve This Post";
$ubbt_lang['PEDIT_UNAPPROVE'] = "Unapprove Post";
$ubbt_lang['UNAPPROVE_CONF'] = "Confirm that you want to unapprove this post.";
$ubbt_lang['YES_UNAPPROVE'] = "Unapprove This Post";
$ubbt_lang['MAKE_STICKY'] = "Make Sticky Thread";
$ubbt_lang['TEXT_STICKY'] = "This will make this thread always appear on top when sorting by descending date.";
$ubbt_lang['RET_NORM'] = "Return to normal date.";
$ubbt_lang['MODIF_HEAD'] = "The post has been modified.";
$ubbt_lang['VIEW_POST'] = "View your post";
$ubbt_lang['EDIT_MORE'] = "Edit more.";
$ubbt_lang['PEDIT_CHANGE'] = "Change this post.";
$ubbt_lang['POST_TEXT'] = "Post";
$ubbt_lang['EDITTIME'] = "This post can no longer be edited because the maximum edit time has expired.";
$ubbt_lang['MAX_QUOTE'] = "For readability, you can only quote messages %%QUOTE%% levels deep. Please edit your message and try again.";
?>