<?php
$ubbt_lang['MB_USERNAME'] = "Display Name";
$ubbt_lang['MB_SENDPM'] = "Send PM";
$ubbt_lang['MB_SELECT'] = "Select";
$ubbt_lang['MB_PMSEL'] = "PM Selected Users";
$ubbt_lang['MB_DELSEL'] = "Unfriend Selected Users";
$ubbt_lang['MB_POSTS'] = "Posts";
$ubbt_lang['MB_VIEW'] = "View";
$ubbt_lang['MB_PM'] = "Compose";
?>