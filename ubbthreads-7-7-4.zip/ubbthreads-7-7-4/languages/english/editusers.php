<?php
$ubbt_lang['EDIT_FAV_USERS'] = "Edit Followed Users";
$ubbt_lang['REMOVE'] = "Unfollow";
$ubbt_lang['USER'] = "Display Name";
$ubbt_lang['EMAIL'] = "Notification Type";
$ubbt_lang['IMMEDIATE_EMAIL'] = "Instant";
$ubbt_lang['REMOVE_BUTTON_USERS'] = "Update Followed Users";
$ubbt_lang['ADD_FAVORITE'] = "Add A User";
$ubbt_lang['EDIT_FAV_TOPICS'] = "Edit Your Followed Threads";
$ubbt_lang['TOPIC'] = "Topic";
$ubbt_lang['REMOVE_BUTTON_TOPICS'] = "Update Followed Threads";
$ubbt_lang['EDIT_FAV_FORUMS'] = "Edit Your Followed Forums";
$ubbt_lang['REMOVE_BUTTON_FORUMS'] = "Update Followed Forums";
$ubbt_lang['FORUM'] = "Forum";
$ubbt_lang['YES'] = "Yes";
$ubbt_lang['NO'] = "No";
$ubbt_lang['VIEW_WATCH'] = "Follow Lists";
$ubbt_lang['WATCH_IT_FORUM'] = "Follow This Forum";
$ubbt_lang['NO_EMAIL'] = "None";
$ubbt_lang['EMAIL_ON_NEW_TOPIC'] = "Only new threads";
$ubbt_lang['EMAIL_ON_NEW_POST'] = "All new threads & replies";
?>