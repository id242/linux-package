<?php
$ubbt_lang['POSTED_BY'] = "by";
$ubbt_lang['POSTED_ON'] = "Posted:";
$ubbt_lang['VIEWS'] = "Views";
$ubbt_lang['REPLIES'] = "Comments";
$ubbt_lang['FILES'] = "Attachments";
$ubbt_lang['MORE'] = "Read More";
$ubbt_lang['EXPAND'] = "EXPAND &#x25BC;";
$ubbt_lang['COLLAPSE'] = "COLLAPSE &#x25B2;";
?>