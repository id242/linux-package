<?php
$ubbt_lang['UNAPPR_HEAD'] = "Post Unapproved";
?>