<?php
$ubbt_lang['AVATAR'] = "Choose An Avatar";
$ubbt_lang['SELECT_AV'] = "Use This Avatar";
$ubbt_lang['NO_AV'] = "No Avatar";
$ubbt_lang['CANCEL'] = "Cancel";
?>