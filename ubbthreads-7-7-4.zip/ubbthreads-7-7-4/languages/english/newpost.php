<?php
$ubbt_lang['ADDSIG'] = "Add Signature";
$ubbt_lang['ADDEVENT'] = "List as an event in the calendar on ";
$ubbt_lang['STICKY'] = "Make this thread a Sticky Thread";
$ubbt_lang['ANNOUNCE'] = "Make this thread a Global Announcement";
$ubbt_lang['ADDTOFAV'] = "Add this thread to my Followed Threads";
$ubbt_lang['READ_PERM'] = "You are not logged in or you do not have permission to post here. This could be due to one of several reasons:<br><ol><li style=\"font-weight:normal;\">You may not be not logged in. <a href=\"%%BASE_URL%%/ubbthreads.php/ubb/login.html\">Login</a> and try again.</li><li style=\"font-weight:normal;\">You may not have sufficient privileges to create a new topic here.</li><li style=\"font-weight:normal;\">If you are trying to post a new topic, your account may be awaiting activation.</li></ol>";
$ubbt_lang['MAKENEW_HEAD'] = "New Thread";
$ubbt_lang['MAKENEW_IMAGE'] = "New Gallery";
$ubbt_lang['FILL_FORM'] = "New Thread";
$ubbt_lang['NO_HTML'] = "HTML is disabled";
$ubbt_lang['YES_HTML'] = "HTML is enabled";
$ubbt_lang['NO_MARKUP'] = "UBBCode is disabled";
$ubbt_lang['YES_MARKUP'] = "UBBCode is enabled";
$ubbt_lang['POST_ICON'] = "Post Icon";
$ubbt_lang['POST_TEXT'] = "Message";
$ubbt_lang['POST_DESCRIPTION'] = "Description";
$ubbt_lang['DO_PREVIEW'] = "Preview New Thread";
$ubbt_lang['FLOODCONTROL'] = "You can only make a post every %%SO_OFTEN%% seconds. Please try again once this time has expired.";
$ubbt_lang['NEWS_IMAGE'] = "News Image";
$ubbt_lang['NEWS_IMAGE_1'] = "Choosing a News Image will allow this topic to display on the Forum Portal, regardless of it being within a News Forum. This ignores user groups. Anyone will be able to read this post regardless of their group permissions.<br><br>Only the first post will be displayed on the Forum Portal. To read its replies or download its attachments, users must belong to a group which allows those permissions for which forum the post is located within.";
$ubbt_lang['LOCK_TOPIC'] = "Lock this thread";
$ubbt_lang['SUBMIT_NEWTOPIC'] = "Post New Thread";
?>