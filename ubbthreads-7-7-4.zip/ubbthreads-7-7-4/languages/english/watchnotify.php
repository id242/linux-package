<?
$ubbt_lang['WATCHED_TOPIC_TITLE'] = "Followed Topic: %%TITLE%%";
$ubbt_lang['WATCHED_FORUM_TITLE'] = "Followed Forum: %%TITLE%% - %%FORUM%%";
$ubbt_lang['WATCHED_USER_TITLE'] = "Followed User: %%USER%% - %%TITLE%%";
$ubbt_lang['NEW_POST_BOD'] = "has created a new thread at ";
$ubbt_lang['REPLY_BOD'] = "has made a new post at ";
?>