<?php
$ubbt_lang['CHOOSE_HEAD'] = "Move Post Thread";
$ubbt_lang['MOVE_TO'] = "Move post and its replies to:";
$ubbt_lang['MERGE_WITH'] = "Merge post and its replies with Post #:";
$ubbt_lang['REASON'] = "Reason for moving? (Will be included, if a PM is sent)";
$ubbt_lang['SEND_PM'] = "Should a PM be sent to this thread starter?";
$ubbt_lang['SUBMIT'] = "Submit";
$ubbt_lang['NOTE'] = "Note that this thread starter will see this notice even if they can no longer view their thread.";
?>