<?php
$ubbt_lang['POSTS_PER'] = "Your selection for maximum number of Threads to show per page is invalid.";
$ubbt_lang['FLAT_BAD'] = "Your selection for maximum number of Posts to show per page is invalid.";
?>