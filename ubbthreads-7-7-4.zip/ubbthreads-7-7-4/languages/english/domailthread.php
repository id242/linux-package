<?php
$ubbt_lang['EMAIL_SENT'] = "Email Has Been Sent";
$ubbt_lang['EMAIL_CONFIRM'] = "An email of this post has been sent to";
$ubbt_lang['FORUM_RETURN'] = "Return To Forum";
$ubbt_lang['NOT_YOURS'] = "Um, dude that's not your PM to send";
$ubbt_lang['MAIL_LOG'] = "<a href=\"%%POST_URL%%\" target=\"_blank\">%%SUBJECT%%</a><br>To: %%EMAIL%%";
?>