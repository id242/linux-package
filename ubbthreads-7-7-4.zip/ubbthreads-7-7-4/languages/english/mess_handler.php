<?php
$ubbt_lang['NO_PERM'] = "You do not have permission to access this private message.";
$ubbt_lang['REPLY_HEAD'] = "Reply To Private Topic";
$ubbt_lang['REPLY_MESS'] = "Reply To This Message";
$ubbt_lang['REPLY'] = "Reply";
$ubbt_lang['SUBMIT_REPLY'] = "Post Reply";
$ubbt_lang['PREVIEW'] = "Preview";
$ubbt_lang['IN_RESPONSE'] = "In Response To:";
$ubbt_lang['REMOVED'] = "has removed themself from this conversation.";
$ubbt_lang['PM_HOWMANY'] = "%%HOWMANY%% private messages have been processed";
$ubbt_lang['PM_SUBJECT'] = "Messages Processed";
$ubbt_lang['PM_RETURN'] = "Return To Messages";
$ubbt_lang['TOO_LONG'] = "This topic has reached its maximum length of %%TOTAL%% posts. You may not add another post to this topic.";
?>