<?php
$ubbt_lang['HEADER'] = "Follow A User";
$ubbt_lang['INSTRUCTIONS'] = "Type the Username (in whole or in part) for which you are searching.";
$ubbt_lang['SEARCH_USERS'] = "Search";
?>