<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.4

$name = ($name) ? $name : "Gallery Island $portal_id";

$smarty->assign("name", $name);

if (!$forums) return;

$forums = unserialize($forums);

if (!sizeof($forums)) return;
$inlist = "";
if (in_array("allforums", $forums)) {
	$forum_clause = "";
} else {
	foreach ($forums as $k => $forum) {
		$inlist .= "'$forum',";
	}
	$inlist = preg_replace("/,$/", "", $inlist);
	$forum_clause = "AND FORUM_ID IN ($inlist)";
}

// Maximum number of images to display
$limit = 5;

$config['MAX_THUMB_W_H'] = ($config['MAX_THUMB_W_H']) ? $config['MAX_THUMB_W_H'] : 200;

$html = new html;

$latest = 0;
$items = array();
$query = "
	SELECT
		TOPIC_ID, POST_ID, TOPIC_THUMBNAIL, TOPIC_SUBJECT, TOPIC_POSTER_NAME, TOPIC_CREATED_TIME
	FROM
		{$config['TABLE_PREFIX']}TOPICS
	WHERE
		TOPIC_IS_APPROVED = '1'
	AND TOPIC_STATUS <> 'M'
	$forum_clause
	ORDER BY
		TOPIC_CREATED_TIME DESC
	LIMIT $limit
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while ($posts = $dbh->fetch_array($sth)) {
	$posts['TOPIC_CREATED_TIME'] = $html->convert_time($posts['TOPIC_CREATED_TIME'], $offset = "{$config['SERVER_TIME_OFFSET']}", $timeformat = "F j", $full = 1, $tags = 0);
	$posts['TOPIC_SUBJECT'] = str_replace('"', '&quot;', $posts['TOPIC_SUBJECT']);
	$posts['TOPIC_THUMBNAIL'] = str_replace('/thumbs/', '/medium/', $posts['TOPIC_THUMBNAIL']);
//	$is = getimagesize("{$config['FULL_PATH']}/gallery/{$posts['TOPIC_THUMBNAIL']}");
	$posts['WIDTH_HEIGHT'] = "{$config['MAX_THUMB_W_H']}" - ("{$config['MAX_THUMB_W_H']}" / 10);
//	if ($is[0]) {
//		$posts['WIDTH_HEIGHT'] = "height:auto;width:{$is[0]}px;max-width:100%!important;";
//	}
	$items[] = $posts;
}

$smarty->assignByRef("items", $items);
$smarty->assign("island", $portal_id);
$smarty->assign("type", $type);
$island = $smarty->fetch("gallery_island.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/gallery_island_$portal_id.php", $island);

@chmod("{$config['FULL_PATH']}/cache/gallery_island_$portal_id.php", 0666);

?>