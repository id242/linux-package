<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.0

$island = $smarty->fetch("island_search.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/search.php", $island);

@chmod("{$config['FULL_PATH']}/cache/search.php", 0666);

?>