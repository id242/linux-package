<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.4

$limit = ($config['TOP_POSTERS']) ? $config['TOP_POSTERS'] : 10;

$i = 0;
$users = array();
$query = "
	SELECT
		u.USER_ID, u.USER_DISPLAY_NAME,
		up.USER_TOTAL_POSTS, up.USER_NAME_COLOR,
		u.USER_MEMBERSHIP_LEVEL
	FROM
		{$config['TABLE_PREFIX']}USERS AS u,
		{$config['TABLE_PREFIX']}USER_PROFILE AS up
	WHERE
		u.USER_ID <> 1
	AND u.USER_ID = up.USER_ID
	AND u.USER_IS_APPROVED = 'yes'
	AND	u.USER_IS_BANNED <> 1
	ORDER BY
		up.USER_TOTAL_POSTS DESC
	LIMIT $limit
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($uid, $username, $total, $namecolor, $memberlevel) = $dbh->fetch_array($sth)) {
	$users[$i]["namecolor"] = $html->user_color($username, $namecolor, $memberlevel);
	$users[$i]["name"] = $username;
	$users[$i]["posts"] = $total;
	$users[$i]["uid"] = $uid;
	$i++;
}

$smarty->assign("users", $users);

$island = $smarty->fetch("island_top_posters.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/top_posters.php", $island);

@chmod("{$config['FULL_PATH']}/cache/top_posters.php", 0666);

?>