<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.0

$island = $smarty->fetch("island_shoutbox.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/shoutbox.php", $island);

@chmod("{$config['FULL_PATH']}/cache/shoutbox.php", 0666);

?>