<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.4

// Maximum number of users to display
$limit = 5;

$query = "
	SELECT count(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_IS_APPROVED = 'yes'
		AND	USER_ID > 1
";
$sth = $dbh->do_query($query);
list($total) = $dbh->fetch_array($sth);

$i = 0;
$users = array();
$query = "
	SELECT
		u.USER_DISPLAY_NAME, u.USER_ID, u.USER_MEMBERSHIP_LEVEL, p.USER_NAME_COLOR
	FROM
		{$config['TABLE_PREFIX']}USERS AS u,
		{$config['TABLE_PREFIX']}USER_PROFILE AS p
	WHERE
		u.USER_IS_APPROVED = 'yes'
	AND u.USER_ID = p.USER_ID
	AND u.USER_IS_BANNED = '0'
	AND u.USER_ID <> '1'
	ORDER BY
		u.USER_ID DESC
	LIMIT $limit
";
$sth = $dbh->do_query($query);
while (list($uname, $uid, $level, $color) = $dbh->fetch_array($sth)) {
	$users[$i]['name'] = $html->user_color($uname, $color, $level);
	$users[$i]['uid'] = $uid;
	$i++;
}

$smarty->assign("users", $users);
$smarty->assign("total", $total);

$island = $smarty->fetch("island_new_users.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/new_users.php", $island);

@chmod("{$config['FULL_PATH']}/cache/new_users.php", 0666);

?>