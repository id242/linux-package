<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.4

if (!$name) $name = "Portal Box $portal_id";

include("{$config['FULL_PATH']}/cache_builders/custom/portal_box_$portal_id.php");

$smarty->assign("name", $name);
$smarty->assign("body", $body);
$smarty->assign("portal_id", $portal_id);

$island = $smarty->fetch("portal_box_custom.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/portal_box_$portal_id.php", $island);

@chmod("{$config['FULL_PATH']}/cache/portal_box_$portal_id.php", 0666);

?>