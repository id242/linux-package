<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.4

$limit = ($config['TOP_LIKES']) ? $config['TOP_LIKES'] : 10;

$i = 0;
$users = array();
$query = "
	SELECT
		l.POSTER_ID, count(l.POSTER_ID) AS LIKES, 
		u.USER_DISPLAY_NAME, u.USER_MEMBERSHIP_LEVEL,
		up.USER_NAME_COLOR
	FROM
		{$config['TABLE_PREFIX']}LIKES AS l,
		{$config['TABLE_PREFIX']}USERS AS u,
		{$config['TABLE_PREFIX']}USER_PROFILE AS up
	WHERE
		l.POSTER_ID <> 1
	AND l.TYPE = 'p'
	AND l.POSTER_ID = u.USER_ID
	AND l.POSTER_ID = up.USER_ID
	AND u.USER_ID <> 1
	AND u.USER_IS_APPROVED = 'yes'
	AND u.USER_IS_BANNED <> 1
	GROUP BY
		l.POSTER_ID,
		u.USER_DISPLAY_NAME,
		u.USER_MEMBERSHIP_LEVEL,
		up.USER_NAME_COLOR
	ORDER BY
		LIKES DESC
	LIMIT $limit
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($uid, $likes, $username, $memberlevel, $namecolor) = $dbh->fetch_array($sth)) {
	$users[$i]["namecolor"] = $html->user_color($username, $namecolor, $memberlevel);
	$users[$i]["name"] = $username;
	$users[$i]["likes"] = $likes;
	$users[$i]["uid"] = $uid;
	$i++;
}

$smarty->assign("users", $users);
$smarty->assign("total", count($users));

$island = $smarty->fetch("island_top_likes.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/top_likes.php", $island);

@chmod("{$config['FULL_PATH']}/cache/top_likes.php", 0666);

?>