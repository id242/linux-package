<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.4

$output_text = "<table><tr><th>{$ubbt_lang['CALENDAR']}</th><tr><tr></td></tr></table>";

lock_and_write("{$config['FULL_PATH']}/cache/calendar.php", $output_text);

@chmod("{$config['FULL_PATH']}/cache/calendar.php", 0666);

?>