<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.4

// Maximum number of topics to display
$limit = 10;

// Exclude forums?
$notin = "";
if ($config['EXCLUDE_POPULAR']) {
	$notin = "and f.FORUM_ID not in ({$config['EXCLUDE_POPULAR']})";
}

$i = 0;
$topics = array();
$query = "
	SELECT
		t.TOPIC_SUBJECT, t.TOPIC_VIEWS, t.TOPIC_REPLIES, t.POST_ID, u.USER_DISPLAY_NAME, t.USER_ID
	FROM
		{$config['TABLE_PREFIX']}TOPICS AS t,
		{$config['TABLE_PREFIX']}POSTS AS p,
		{$config['TABLE_PREFIX']}FORUMS AS f,
		{$config['TABLE_PREFIX']}USERS AS u
	WHERE
		t.FORUM_ID = f.FORUM_ID
	AND t.TOPIC_IS_APPROVED = 1
	AND t.TOPIC_ID = p.POST_ID
	AND t.USER_ID = u.USER_ID
	$notin
	ORDER BY
		t.TOPIC_VIEWS DESC
	LIMIT $limit
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($sub, $views, $replies, $pid, $poster, $posterid) = $dbh->fetch_array($sth)) {
	$topics[$i]['subject'] = $sub;
	$topics[$i]['views'] = $views;
	$topics[$i]['replies'] = $replies;
	$topics[$i]['post'] = $pid;
	$topics[$i]['poster'] = $poster;
	$topics[$i]['posterid'] = $posterid;
	$i++;
}

$smarty->assign("topics", $topics);

$island = $smarty->fetch("island_popular_topics.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/popular_topics.php", $island);

@chmod("{$config['FULL_PATH']}/cache/popular_topics.php", 0666);

?>