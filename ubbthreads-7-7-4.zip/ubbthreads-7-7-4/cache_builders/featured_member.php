<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.4

// Activity clause?
$thisclause = "";
if ($config['FEATURED_MEMBER']) {
	$now = $html->get_date();
	$date = $now - $config['FEATURED_MEMBER'] * 86400;
	$thisclause = "AND t3.USER_LAST_POST_TIME > $date";
}

$query = "
	SELECT
		t1.USER_DISPLAY_NAME, t1.USER_ID, t2.USER_NAME_COLOR, t1.USER_MEMBERSHIP_LEVEL,
		t2.USER_AVATAR, t1.USER_REGISTERED_ON, t2.USER_TOTAL_POSTS,
		t2.USER_AVATAR_WIDTH, t2.USER_AVATAR_HEIGHT, t2.USER_LOCATION
	FROM
		{$config['TABLE_PREFIX']}USERS AS t1,
		{$config['TABLE_PREFIX']}USER_PROFILE AS t2,
		{$config['TABLE_PREFIX']}USER_DATA AS t3
	WHERE
		t1.USER_ID = t2.USER_ID
	AND t1.USER_ID = t3.USER_ID
	AND t1.USER_IS_BANNED != '1'
	AND t1.USER_ID	> 1
	AND t2.USER_AVATAR != ''
	AND t2.USER_TOTAL_POSTS > 20
	$thisclause
	ORDER BY rand() LIMIT 1
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
list($uname, $uid, $color, $level, $avatar, $reged_on, $posts, $width, $height, $location) = $dbh->fetch_array($sth);

if (!$avatar) {
	if (!$style_array['general']) {
		$style_array['general'] = "general/default";
	}

	$avatar = "{$config['FULL_URL']}/images/{$style_array['general']}/nopicture.gif";
	$imagehw = getimagesize($avatar);
	$width = $imagehw[0];
	$height = $imagehw[1];
}

$picsize = "";
if ($width && $height) {
	$picsize = "width='$width'";
} else {
	if ($config['AVATAR_MAX_WIDTH'] && $config['AVATAR_MAX_HEIGHT']) {
		$picsize = "width=\"{$config['AVATAR_MAX_WIDTH']}\"";
	}
}


$uncolored = $uname;
$username = $html->user_color($uname, $color, $level);
$reg_date = $html->convert_time($reged_on, $offset = "{$config['SERVER_TIME_OFFSET']}", "F Y", 1);
preg_match("/<span class=\"date\">(.*?)<\/span>/", $reg_date, $matches);
$reg_date = trim($matches['1']);

$smarty->assign("avatar", $avatar);
$smarty->assign("username", $username);
$smarty->assign("uid", $uid);
$smarty->assign("reg", $reg_date);
$smarty->assign("uncolored", $uncolored);
$smarty->assign("posts", $posts);
$smarty->assign("picsize", $picsize);
$smarty->assign("location", $location);

$island = $smarty->fetch("island_featured_member.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/featured_member.php", $island);

@chmod("{$config['FULL_PATH']}/cache/featured_member.php", 0666);

?>