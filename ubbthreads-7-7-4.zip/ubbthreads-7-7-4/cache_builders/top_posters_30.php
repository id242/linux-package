<?php defined("UBB_MAIN_PROGRAM") or exit;
//	Script Version 7.7.4

// Change this to something other than 30 if you'd like.
// You'll also want to change the TOP_POSTERS_30 language string
// in the portal_islands.php language file
$days = 30;

$limittime = date("U") - (60 * 60 * 24 * $days);

$limit = ($config['TOP_POSTERS']) ? $config['TOP_POSTERS'] : 10;

$i = 0;
$users = array();
$query = "
	SELECT
		u.USER_ID, count(*) AS total,
		MAX(u.USER_DISPLAY_NAME), MAX(u.USER_MEMBERSHIP_LEVEL),
		MAX(up.USER_NAME_COLOR)
	FROM
		{$config['TABLE_PREFIX']}USERS AS u,
		{$config['TABLE_PREFIX']}USER_PROFILE AS up,
		{$config['TABLE_PREFIX']}POSTS AS p
	WHERE
		u.USER_ID <> 1
	AND u.USER_ID = up.USER_ID
	AND u.USER_IS_APPROVED = 'yes'
	AND u.USER_IS_BANNED <> 1
	AND u.USER_ID = p.USER_ID
	AND p.POST_POSTED_TIME > $limittime
	GROUP BY
		u.USER_ID
	ORDER BY
		total DESC
	LIMIT $limit
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
while (list($uid, $total, $username, $memberlevel, $namecolor) = $dbh->fetch_array($sth)) {
	$users[$i]["namecolor"] = $html->user_color($username, $namecolor, $memberlevel);
	$users[$i]["name"] = $username;
	$users[$i]["posts"] = $total;
	$users[$i]["uid"] = $uid;
	$i++;
}

$smarty->assign("users", $users);

$island = $smarty->fetch("island_top_posters_30.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/top_posters_30.php", $island);

@chmod("{$config['FULL_PATH']}/cache/top_posters_30.php", 0666);

?>