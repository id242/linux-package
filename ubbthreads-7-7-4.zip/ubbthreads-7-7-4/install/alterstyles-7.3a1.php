<?php

$newstyles['.ubb_popup_body']['copy'] = "body";
$newstyles['.inline_selected']['copy'] = ".tdheader";
$newstyles['.inline_selector']['copy'] = ".new-topicsubject";
$newstyles['.post_top_link']['copy'] = ".private_unread";
$newstyles['.globalmodname']['set'] = "color: #00AAFF;";
$newstyles['.bbcodecomment']['set'] = "color: green;";
$newstyles['.bbcodedefault']['set'] = "color: #000000;";
$newstyles['.bbcodekeyword']['set'] = "color: maroon;";
$newstyles['.bbcodestring']['set'] = "color: goldenrod;";
$newstyles['.bbcodehtml']['set'] = "color: dodgerblue;";
$newstyles['.popup_content_header']['set'] = "width: 502px;
display: block;
font-weight: bold;
padding: 4px;
color: #666666;
background: #EEEECC;
border: 1px solid #AAAAAA;
border-bottom: 1px solid #AAAA11;
font-size: 8pt;";
$newstyles['.popup_content']['set'] = "width: 502px;
overflow: auto;
font-size: 10pt;
display: block;
background: white;
border: 1px solid #AAAAAA;
padding: 4px;";

?>