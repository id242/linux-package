<?php
//	Script Version 7.7.1

include("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

$date = time();

$query = "
	UPDATE {$config['TABLE_PREFIX']}VERSION
	SET SCRIPT_VERSION = '$vnum',
	DB_VERSION = '$vnum',
	LAST_ALTER_STEP = '0',
	IS_RUNNING = 0
";
$dbh->do_query($query, "Updating version # to $vnum...");

echo "</table>";

?>