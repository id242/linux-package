<?php

$newconfigs['SOCIAL_FIELD_1'] = '1';
$newconfigs['SOCIAL_FIELD_2'] = '1';
$newconfigs['SOCIAL_FIELD_3'] = '1';
$newconfigs['SOCIAL_FIELD_4'] = '1';
$newconfigs['SOCIAL_FIELD_5'] = '1';
$newconfigs['SOCIAL_FIELD_6'] = '1';
$newconfigs['SOCIAL_FIELD_7'] = '1';
$newconfigs['SOCIAL_FIELD_8'] = '1';
$newconfigs['SOCIAL_FIELD_9'] = '1';
$newconfigs['UTF8'] = '';
$newconfigs['LOCINFO_URL'] = 'https://maps.google.com/maps?q=';
$newconfigs['IPINFO_URL'] = 'https://whatismyipaddress.com/ip/';
$newconfigs['NEWS_SLICE'] = '1500';

?>