<?php

define('VERSION', $vnum);

if (!defined('UPGRADE')) {
	$currentversion = "";
	require("install_header.tmpl");
	echo "<div class='alvt fw stdautorow'>";
	echo "This script must be called through the upgrade area.";
	echo "</div><br><br>";
	require("install_footer.tmpl");
	exit;
}

if (!$alterstep) {
	$alterstep = "1";
}

ignore_user_abort(1);

function do_query($query = "", $print = "") {

	global $dbh;
	if (!defined('IS_UPGRADE')) {
		define('IS_UPGRADE', 1);
	}
	$sth = $dbh->do_query($query);
	if ($print) echo "<tr><td class=\"alvm autobottom\">$print";
	if (!$sth) {
		$errno = mysqli_errno($check);
		if ($errno != '1060' && $errno != '1091' && $errno != '1051' && $errno != '1050') {
			if (!(defined('DIDFAIL'))) {
				define('DIDFAIL', 1);
			}
			$thisstatus = "<span class='mswarning fr'>FAILED</span>";
		} else {
			$thisstatus = "<span class='msgood fr'>OK</span>";
		}
	} else {
		if ($print) $thisstatus = "<span class='msgood fr'>OK</span>";
	}
//	if ($print) echo "</td><td class=\"alvt autobottom bold\">$thisstatus</td></tr>";
	if ($print) echo " <span class=\"bold\">$thisstatus</span></td></tr>";
	if (preg_match("/FAILED/", $thisstatus)) {
		report_error($query);
	}
	return $sth;
}

function report_error($query = "") {
	global $config;
	$error = mysqli_error($check) . $check;
	echo "<tr><td><table class='fw padding small'>";
	echo "<tr><td class='alvt bold nw'>SQL Query:</td><td class='alvt'>$query</td></tr>";
	echo "<tr><td class='alvt bold nw'>Reason for failure:</td><td class='alvt'>$error</td></tr>";
	echo "<tr><td class='alvt bold nw'>Upgrade Step:</td><td class='alvt'>{$config['phpurl']}/install/upgrade.php?step=altertable</td>";
	echo "</tr></table></td></tr>";
}

function step_start($alterstep = "") {

	global $config;
	$date = time();
	$query = "
		UPDATE {$config['TABLE_PREFIX']}VERSION
		SET SCRIPT_VERSION   = '" . VERSION . "',
		DB_VERSION = '" . VERSION . "',
		LAST_ALTER_STEP = '$alterstep',
		IS_RUNNING = 1
	";
	$sth = do_query($query, "<span class='bold'>Database Update: Step $alterstep</span>");
}

function step_refresh($alterstep = "") {
	global $config;
	$query = "
		update {$config['TABLE_PREFIX']}VERSION
		set LAST_ALTER_STEP = '$alterstep'
	";
	do_query($query, "");
}


function step_stop() {

	global $config;
	$date = time();
	$query = "
		UPDATE {$config['TABLE_PREFIX']}VERSION
		SET DB_VERSION = '" . VERSION . "',
		SCRIPT_VERSION = '" . VERSION . "',
		LAST_ALTER_STEP   = '0',
		IS_RUNNING = '0'
	";
	$sth = do_query($query, "Finalizing upgrade to version " . VERSION . "...");
}

?>