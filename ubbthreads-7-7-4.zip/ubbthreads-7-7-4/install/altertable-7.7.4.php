<?php

include("altertable.inc.php");

echo "<table class='center' style='width:98%;'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 8;
for ($i = $thisstep; $i <= $totalsteps; $i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !$defined('DIDFAIL')) {
			$currenstep = $i;
			break;
		}

		if (function_exists('ob_flush')) {
			ob_flush();
		} else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}REGISTRATION_FIELDS
		DROP PRIMARY KEY
	";
	$sth = do_query($query, "Correct Registration Field primary key...");
}

function alterstep2() {
	global $config;
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}REGISTRATION_FIELDS
		WHERE REGISTRATION_FIELD = 'USER_ICQ'
	";
	$sth = do_query($query, "Remove ICQ Registration fields...");
}

function alterstep3() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		MODIFY CUSTOM_ID varchar(190)
	";
	$sth = do_query($query, "Update Subscription Data table...");
}

function alterstep4() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}PAYPAL_DATA
		MODIFY CUSTOM_ID varchar(190)
	";
	$sth = do_query($query, "Update Paypal Data table...");
}

function alterstep5() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}CHECK_DATA
		MODIFY CUSTOM_ID varchar(190)
	";
	$sth = do_query($query, "Update Check Data table...");
}

function alterstep6() {
	global $config;
	$query = "
		CREATE TABLE {$config['TABLE_PREFIX']}LIKES (
			TYPE char(1) NOT NULL,
			POST_ID int(11) NOT NULL DEFAULT '0',
			POSTER_ID int(11) DEFAULT '0',
			TOPIC_ID int(11) NOT NULL DEFAULT '0',
			USER_ID int(11) NOT NULL DEFAULT '0',
			TIMESTAMP int(11) NOT NULL
		) ENGINE=MyISAM
	";
	$sth = do_query($query, "Creating {$config['TABLE_PREFIX']}LIKES table...");
}

function alterstep7() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}USER_PROFILE
		ADD USER_LIKES INT(9) NULL DEFAULT NULL AFTER USER_SHOW_SIGNATURES
	";
	$sth = do_query($query, "Adding LIKES column to {$config['TABLE_PREFIX']}USER_PROFILE table...");
}

function alterstep8() {
	global $config;
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}PORTAL_BOXES
			(PORTAL_NAME, PORTAL_CACHE, PORTAL_LAST_BUILD, PORTAL_CUSTOM, PORTAL_LOCK)
		VALUES
			('top_likes', 3600, 0, 0, 0),
			('top_likes_30', 3600, 0, 0, 0)
	";
	$sth = do_query($query, "Inserting Top Likes into default Portal Islands...");
}

?>