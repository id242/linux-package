<?php

include("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 6;
for ($i = $thisstep; $i <= $totalsteps; $i++) {
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh) {
			$currenstep = $i;
			break;
		}

		if (function_exists('ob_flush')) {
			ob_flush();
		} else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
}

function alterstep2() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}FORUMS
		ADD FORUM_ACTIVE_POSTS tinyint(1) default '1',
		ADD FORUM_POSTS_COUNT tinyint(1) default '1'
	";
	$sth = do_query($query, "{$config['TABLE_PREFIX']}FORUMS table altered.");
}


function alterstep3() {
	global $config;
	$query = "
                alter table {$config['TABLE_PREFIX']}USER_PROFILE
				add USER_SHOW_ALL_GRAEMLINS tinyint(1) default '0'
        ";
	$sth = do_query($query, "{$config['TABLE_PREFIX']}USER_PROFILE table altered.");
}

function alterstep4() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}SAVED_QUERIES
		add QUERY_DESCRIPTION text
        ";
	$sth = do_query($query, "{$config['TABLE_PREFIX']}SAVED_QUERIES table altered.");
}

function alterstep5() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}GRAEMLINS
		add GRAEMLIN_ORDER int(11) default '0'
        ";
	$sth = do_query($query, "{$config['TABLE_PREFIX']}GRAEMLINS table altered.");
}

function alterstep6() {
	global $config;
	$query = "
		TRUNCATE TABLE {$config['TABLE_PREFIX']}SHOUT_BOX
	";
	$sth = do_query($query, "{$config['TABLE_PREFIX']}SHOUT_BOX table cleared.");
}

?>