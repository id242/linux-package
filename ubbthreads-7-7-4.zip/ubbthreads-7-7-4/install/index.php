<?php
//	Script Version 7.7.3

$metarefresh = "";
$step_navigation = "";
require("install_header.tmpl");

// suhosin Check
if (extension_loaded("suhosin") && ini_get("suhosin.get.max_value_length")) {
	if (ini_get("suhosin.get.max_value_length") < 2048) {
		$suhosin = "<span style=\"color:#CC0000;\">You may experience issues with a blank configuration file if you continue, please see <a href=\"https://www.ubbwiki.com/article/view/16/issues-with-suhosin.html\" target=\"_blank\">UBB.Wiki: Issues with suhosin</a>; this issue pertains to the settings of the suhosin module with your webhost.  Your current suhousin length is: " . ini_get("suhosin.get.max_value_length") . ".</span><br><br>";
	} else {
		$suhosin = "";
	}
}

echo <<<UBBTPRINT
<table width="95%" align="center">
<tr><td class="stdautorow">
{$suhosin}

<div class="acvt padding"><b>Welcome to the Upgrade/Install Utility for UBB.threads</b></div>

UBBTPRINT;

if (file_exists("../cache/forum_cache.php")) {

//	UBB.threads Configuration Test
	if (file_exists("../includes/config.inc.php")) {
		require("../includes/config.inc.php");
		if (file_exists("../libs/ver.inc.php")) {
			require("../libs/ver.inc.php");
		} else {
			$currentver = 0;
			$VERSION = 0;
			$VERBUILD = 0;
			$VERTYPE = "none";
			$VERNOTES = "none";
		}

//	Lets check the database for version information
		$mysqli = new mysqli($config["DATABASE_SERVER"], $config["DATABASE_USER"], $config["DATABASE_PASSWORD"], $config["DATABASE_NAME"]);
		if ($mysqli->connect_errno) {
			printf("Could not connect to the MySQL Database: %s\n", $mysqli->connect_error);
			exit();
		}

		$data["version"]["script"] = "";
		$data["version"]["db"] = "";
		$data["upgrade"]["step"] = "";
		$data["upgrade"]["running"] = "";
		$query = $mysqli->query("
			SELECT
				`SCRIPT_VERSION`, `DB_VERSION`, `LAST_ALTER_STEP`, `IS_RUNNING`
			FROM
				`" . $config["TABLE_PREFIX"] . "VERSION`
		") or die(mysqli_error($mysqli));

		while ($fetch = $query->fetch_array(MYSQLI_ASSOC)) {
			$data["version"]["script"] = $fetch["SCRIPT_VERSION"];
			$data["version"]["db"] = $fetch["DB_VERSION"];
			$data["upgrade"]["step"] = (int)$fetch["LAST_ALTER_STEP"];
			$data["upgrade"]["running"] = (int)$fetch["IS_RUNNING"];
		}
		$query->close();

		$data["size"] = "";
		$query = $mysqli->query("
			SELECT
				SUM((data_length + index_length)/1024/1024) as `size`
			FROM
				`information_schema`.TABLES
			WHERE
				`table_schema`='" . $config["DATABASE_NAME"] . "'
		") or die(mysqli_error($mysqli));

		while ($fetch = $query->fetch_array(MYSQLI_ASSOC)) {
			$data["size"] = $fetch["size"];
		}
		$query->close();

		$data["version"]["mysql"] = "";
		$query = $mysqli->query("SELECT VERSION() as version") or die(mysqli_error($mysqli));

		while ($fetch = $query->fetch_array(MYSQLI_ASSOC)) {
			$data["version"]["mysql"] = $fetch["version"];
		}
		$query->close();
		mysqli_close($mysqli);

		if (($data["version"]["script"] != null) && ($VERSION != null)) {
			if ($VERTYPE != "Release") {
				$currentver = $VERSION . " (" . $VERBUILD . ")";
			} else {
				$currentver = $VERSION;
			}

			$version = "Database Version: " . $data["version"]["script"] . " Script Version: " . $currentver;
		} elseif ($data["version"]["script"] != null) {
			$version = "Database Version: " . $data["version"]["script"];
		} elseif ($VERSION != null) {
			$version = "Script Version: " . $VERSION;
		} else {
			$version = "";
		}

		echo <<<UBBTPRINT
<div class="alvt padding"><b><a href="upgrade.php">Upgrade UBB.threads from a previous version</a></b><br>
<br>
<b>Version checks:</b><br>
UBBTPRINT;

		if ($data["version"]["script"] != "") {
			echo("\t&bull; Database structure version: " . $data["version"]["db"] . "<br>\n");
		}
		if ($data["version"]["script"] != "") {
			echo("\t&bull; Script version from database: " . $data["version"]["script"] . "<br>\n");
		}
		if ($currentver != "") {
			echo("\t&bull; Script version from filesystem: " . $currentver . "<br>\n");
		}
	}

	echo <<<UBBTPRINT

<br>
<b>Continuing will perform the following tasks:</b><br>
&bull; Upgrade your current version of UBB.threads to UBB.threads $VERSION.<br>
&bull; Retain your current forum threads, posts, users and other information.<br>
<br>
<div class="acvm padding">
<form action="upgrade.php">
<input type="submit" value="Continue" class="form-button">
</form>
</div>
</div>

UBBTPRINT;
} else {
	echo <<<UBBTPRINT

<div class="alvt padding"><b><a href="install.php">Perform initial install of UBB.threads</a></b><br>
<br>
<b>Continuing will:</b><br>
&bull; Perform a new install of UBB.threads.<br>
<br>
<div class="acvm padding">
<form action="install.php">
<input type="submit" value="Continue" class="form-button">
</form>
</div>
</div>

UBBTPRINT;
}
echo <<<UBBTPRINT

</td></tr>
</table>

UBBTPRINT;
require("install_footer.tmpl");

?>