<?php
//	Script Version 7.7.4

define('UBB_MAIN_PROGRAM', 1);
chdir(dirname(__FILE__) . "/../");

$INSTALL_DATABASE_VERSION = 1;

define('INSTALL', 1);
define('HEADER_SENT', 1);
require_once("libs/phpmailer/PHPMailerAutoload.php");

// set the database type
if (function_exists('mysqli_connect')) {
	$dbtype = "MySQLi";
} else {
	print "<b>Fatal Error:</b> UBB.threads requires MySQLi.";
	exit;
}

// Setup the smarty class
require('libs/smarty/SmartyBC.class.php');
$smarty = new SmartyBC();

$smarty->setTemplateDir('templates/default');
$smarty->setCompileDir('templates/compile');

// include all of the required libraries
require_once("includes/config.inc.php");
require_once("libs/" . strtolower($dbtype) . ".inc.php");
require_once("libs/html.inc.php");
require_once("libs/user.inc.php");
require_once("libs/ubbthreads.inc.php");

$html = new html;
$userob = new user;

$display_name = get_input("display_name", "post");
$email = get_input("email", "post");
$password = get_input("password", "post");
$login_name = get_input("login_name", "post");

$metarefresh = "";
$step = 8;

$step_navigation = "";
$step_array = array(1, 2, 3, 4, 5, 6, 7, 8);
$step_instructions = array(
	1 => "Permissions",
	2 => "Database Info",
	3 => "Database Check",
	4 => "Paths/URLs",
	5 => "Paths/URLs Check",
	6 => "Config Creation",
	7 => "Admin Creation",
	8 => "Table Creation",
);

foreach ($step_array as $k => $v) {
	$font_open = "";
	$font_close = "";
	$mid_dot = "&nbsp;";
	if ($step == $v) {
		$mid_dot = "<b>&middot;</b>";
		$font_open = "<font color=\"green\">";
		$font_close = "</font>";
	}
	$step_navigation .= "$mid_dot $font_open{$step_instructions[$v]}$font_close<br>";
}


// Update the config
$newconf = <<<EOF
<?php

EOF;

$newconf .= "\$config = " . var_export($config, true);

$newconf .= "?>";

$fd = @fopen("{$config['FULL_PATH']}/includes/config.inc.php", "w");
if (!$fd) {
	include("install_header.tmpl");
	print "Failed to write config: $php_errormsg";
	include("install_footer.tmpl");
	exit;
}

fwrite($fd, $newconf);
fclose($fd);


// Let's see if this has already been run
$query = "
	SHOW TABLES
";
$sth = $dbh->do_query($query);
$norun = 0;
while (list ($check) = $dbh->fetch_array($sth)) {
	if ($check == "{$config['TABLE_PREFIX']}POSTS") {
		$norun = 1;
	}
}
if ($norun) {
	include("install_header.tmpl");
	echo "<div class=\"acvm padding\">Createtable.php has already been run. Your tables already exist.
	<br><br>
	To continue the installation, remove the tables and then refresh this page.
	</div>";
	include("install_footer.tmpl");
	exit;
}

$printer = "<table style=\"margin:auto;width:600px;\">";
$printer .= "<tr><td class=\"alvt stdautorow\">";

// The Board Table ##############################
// Create the Board Table
$query = "
	create table {$config['TABLE_PREFIX']}FORUMS (
	FORUM_TITLE text,
	FORUM_DESCRIPTION text,
	FORUM_ID int(9) unsigned auto_increment primary key,
	FORUM_PARENT int(9) unsigned,
	FORUM_POSTS int(9) unsigned  default '0',
	FORUM_LAST_POST_TIME int(11) unsigned,
	FORUM_CREATED_ON int(11) unsigned,
	FORUM_IS_MODERATED tinyint(1) unsigned default '0',
	CATEGORY_ID int(4) unsigned default '1' not null,
	FORUM_TOPICS int(9) unsigned default '0',
	FORUM_SORT_ORDER int(4) unsigned,
	FORUM_DEFAULT_TOPIC_AGE int(4) unsigned,
	FORUM_CUSTOM_HEADER int(1) unsigned,
	FORUM_STYLE mediumint(4) not null default '0',
	FORUM_LAST_POST_ID int(9) unsigned default '0',
	FORUM_LAST_TOPIC_ID int(9) unsigned,
	FORUM_LAST_POSTER_ID int(9) default '1',
	FORUM_LAST_POSTER_NAME varchar(64),
	FORUM_LAST_POST_SUBJECT text,
	FORUM_LAST_POST_ICON varchar(30),
	FORUM_IMAGE varchar(255),
	FORUM_IS_ACTIVE tinyint(1) default '1' not null,
	FORUM_ISLAND_INSERT mediumint(5) not null default '0',
	FORUM_IS_RSS tinyint(1) not null default '0',
	FORUM_RSS_TITLE varchar(255),
	FORUM_SHOW_INTRO tinyint(1) not null default '0',
	FORUM_INTRO_TITLE varchar(255),
	FORUM_IS_TEASER tinyint(1) not null default '0',
	FORUM_IS_GALLERY tinyint(1) not null default '0',
	FORUM_ACTIVE_POSTS	tinyint(1) default '1',
	FORUM_POSTS_COUNT	tinyint(1) default '1',
	FORUM_SORT_FIELD varchar(10),
	FORUM_SORT_DIR varchar(4),
	INDEX CAT_NDX (CATEGORY_ID),
	INDEX ACTIVE_NDX (FORUM_IS_ACTIVE)
) ENGINE=MyISAM";

$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}FORUMS table created...<br>";

// TOPICS TABLE
$query = "
create table {$config['TABLE_PREFIX']}TOPICS (
TOPIC_ID int(11) unsigned not null primary key auto_increment,
FORUM_ID int(9) unsigned not null,
POST_ID int(11) unsigned not null,
USER_ID int(9) unsigned not null,
TOPIC_VIEWS int(5) not null default '0',
TOPIC_REPLIES int(11) not null default '0',
TOPIC_SUBJECT varchar(255),
TOPIC_RATING int(1) not null default '0',
TOPIC_TOTAL_RATES mediumint(6) not null default '0',
TOPIC_CREATED_TIME int(11) unsigned,
TOPIC_ICON varchar(30),
TOPIC_IS_APPROVED tinyint(1) not null default '1',
TOPIC_STATUS varchar(1),
TOPIC_IS_STICKY tinyint(1) not null default '0',
TOPIC_LAST_REPLY_TIME int(11) unsigned not null default '0',
TOPIC_LAST_POST_ID int(11),
TOPIC_LAST_POSTER_NAME varchar(64),
TOPIC_LAST_POSTER_ID int(11) unsigned,
TOPIC_HAS_FILE int(3) not null default '0',
TOPIC_HAS_POLL tinyint(1) not null default '0',
TOPIC_IS_EVENT tinyint(1) not null default '0',
TOPIC_NEWS_ICON varchar(64),
TOPIC_POSTER_NAME varchar(50),
TOPIC_THUMBNAIL varchar(255),
index FORUM_NDX (FORUM_ID),
index POST_NDX (POST_ID),
index USER_NDX (USER_ID),
index TOPIC_TIME_NDX (FORUM_ID,TOPIC_CREATED_TIME),
index TOPIC_LAST_TIME_NDX (FORUM_ID,TOPIC_LAST_REPLY_TIME),
index TOPIC_LAST_REPLY_NDX (TOPIC_LAST_REPLY_TIME),
index APPROVED_NDX (TOPIC_IS_APPROVED)
) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}TOPICS table created...<br>";


// The Posts Table    ###################
$query = "
	create table {$config['TABLE_PREFIX']}POSTS (
	POST_ID int(11) unsigned auto_increment primary key,
	POST_PARENT_ID int(11) unsigned not null,
	TOPIC_ID int(11) unsigned not null,
	POST_IS_TOPIC tinyint(1) not null default '0',
	POST_POSTED_TIME int(11) unsigned not null,
	POST_POSTER_IP varchar(60),
	POST_SUBJECT text,
	POST_BODY text,
	POST_DEFAULT_BODY text,
	POST_IS_APPROVED tinyint(1) default '1' not null,
	POST_ICON varchar(30),
	POST_IS_MEMBER_POST tinyint(1) default '1',
	POST_HAS_POLL tinyint(1),
	POST_HAS_FILE int(3) not null default '0',
	POST_MARKUP_TYPE varchar(10) default 'markup',
	POST_LAST_EDITED_TIME int(11),
	POST_LAST_EDITED_BY varchar(64),
	POST_LAST_EDIT_REASON varchar(255),
	USER_ID int(9) unsigned not null,
	POST_PARENT_USER_ID int(9) unsigned not null default '0',
	POST_ADD_SIGNATURE int(1) not null default '0',
	POST_POSTER_NAME varchar(50),
	POST_MD5 varchar(32),
	INDEX indx_1(POST_PARENT_ID),
	INDEX indx_2(TOPIC_ID),
	INDEX indx_3(POST_POSTED_TIME),
	INDEX indx4 (POST_IS_APPROVED),
	INDEX ID_ndx(USER_ID),
	INDEX MD5_ndx(POST_MD5),
  	FULLTEXT(POST_SUBJECT,POST_DEFAULT_BODY)
	) ENGINE=MyISAM
";
$dbh->do_query($query);

$printer .= "{$config['TABLE_PREFIX']}POSTS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}FILES (
		FILE_ID int(11) unsigned not null auto_increment primary key,
		FILE_NAME varchar(255),
		FILE_ORIGINAL_NAME varchar(255),
		POST_ID int(11) not null default '0',
		FILE_DOWNLOADS int(11) unsigned not null default '0',
		FILE_ADD_TIME int(11) unsigned,
		FILE_TYPE varchar(10),
		FILE_SIZE mediumint(6),
		FILE_DESCRIPTION varchar(255),
		FILE_WIDTH mediumint(5),
		FILE_HEIGHT mediumint(5),
		FILE_MD5 varchar(32) not null,
		FILE_DIR varchar(25),
		USER_ID int(9) unsigned not null,
		FILE_SHA1 char(40) not null default '',
		index file_md5_ndx(FILE_MD5),
		index post_id_ndx(POST_ID),
		index user_id_ndx(USER_ID)
	) ENGINE=MyISAM
";
$sth = $dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}FILES table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}POLL_DATA (
	POLL_ID int(11) unsigned not null auto_increment primary key,
	POLL_START_TIME int(11) unsigned,
	POLL_STOP_TIME int(11) unsigned,
	POLL_MUST_VOTE int(1) unsigned,
	POLL_HIDE_RESULTS_UNTIL_END int(1) unsigned,
	POLL_MD5 varchar(32) not null,
	POLL_ADD_TIME int(11) unsigned,
	POST_ID int(11) not null default '0',
	POLL_BODY TEXT,
	POLL_TYPE varchar(4),
	USER_ID int(9) unsigned not null,
	index poll_md5_ndx(POLL_MD5),
	index post_id_ndx(POST_ID),
	index user_id_ndx(USER_ID)
	) ENGINE=MyISAM
";
$sth = $dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}POLL_DATA table created...<br>";


$query = "
	create table {$config['TABLE_PREFIX']}POLL_OPTIONS (
	OPTION_ID int(11) unsigned not null auto_increment primary key,
	OPTION_BODY varchar(255),
	POLL_ID int(11) unsigned not null,
	INDEX POLL_ndx(POLL_ID)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}POLL_OPTIONS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}POLL_VOTES (
	POLL_ID int(11) unsigned,
	OPTION_ID int(11) unsigned not null,
	VOTES_USER_ID_IP varchar(15),
	INDEX Option_ndx(POLL_ID,OPTION_ID),
	INDEX Voted_ndx(POLL_ID,VOTES_USER_ID_IP)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}POLL_VOTES table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}FORUM_LAST_VISIT(
	FORUM_ID int(9) unsigned not null,
	USER_ID int(9) not null,
	LAST_VISIT_TIME int(11) unsigned,
	primary key Last_index(USER_ID,FORUM_ID)
	) ENGINE=MyISAM
";
$dbh->do_query($query);

$printer .= "{$config['TABLE_PREFIX']}FORUM_LAST_VISIT table created...<br>";

// The Category Table ###################
$query = "
	create table {$config['TABLE_PREFIX']}CATEGORIES(
	CATEGORY_ID int(4) not null auto_increment primary key,
	CATEGORY_TITLE varchar(120) default 'General Discussion' not null,
	CATEGORY_SORT_ORDER int(9) default '0' not null,
	CATEGORY_DESCRIPTION text,
	INDEX indx1 (CATEGORY_TITLE),
	INDEX indx2 (CATEGORY_SORT_ORDER)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}CATEGORIES table created...<br>";

$query = "
	insert into {$config['TABLE_PREFIX']}CATEGORIES values ('1','General Discussion',1,'Forums for general discussion')
";
$dbh->do_query($query);


// The User Table ########################
$query = "
create table {$config['TABLE_PREFIX']}USERS(
USER_ID int(9) not null auto_increment primary key,
USER_LOGIN_NAME varchar(64) not null,
USER_DISPLAY_NAME varchar(64) not null,
USER_PASSWORD varchar(32) not null,
USER_MEMBERSHIP_LEVEL varchar(15) default 'User' not null,
USER_REGISTRATION_EMAIL char(50),
USER_REGISTRATION_IP char(46),
USER_SESSION_ID varchar(64) not null default '0',
USER_IS_APPROVED varchar(8) not null default 'no',
USER_REGISTERED_ON int(11),
USER_IS_BANNED int(1) default '0',
USER_IS_UNDERAGE int(1) unsigned default '0',
USER_RULES_ACCEPTED int(11) unsigned not null default '0',
INDEX indx1 (USER_LOGIN_NAME, USER_PASSWORD),
INDEX indx2 (USER_MEMBERSHIP_LEVEL),
INDEX sess_ndx(USER_SESSION_ID),
INDEX App_ndx(USER_IS_APPROVED),
INDEX Display_ndx (USER_DISPLAY_NAME),
INDEX time_ndx (USER_REGISTERED_ON),
INDEX reg_email_ndx (USER_REGISTRATION_EMAIL)
) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}USERS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}USER_PROFILE (
	USER_ID int(9) not null primary key,
	USER_REAL_EMAIL varchar(50) not null default '',
	USER_DISPLAY_EMAIL varchar(50),
	USER_UNVERIFIED_EMAIL varchar(50) not null default '',
	USER_LANGUAGE varchar(50),
	USER_SIGNATURE text,
	USER_DEFAULT_SIGNATURE text,
	USER_HOMEPAGE varchar(150),
	USER_OCCUPATION varchar(150),
	USER_HOBBIES varchar(200),
	USER_LOCATION varchar(200),
	USER_START_VIEW varchar(20) not null default 'cfrm',
	USER_FAVORITES_TAB varchar(10) not null default 'forums',
	USER_FAVORITES_SORT varchar (10) not null default 'reply',
	USER_TOPIC_VIEW_TYPE varchar(10) not null default 'flat',
	USER_TOPICS_PER_PAGE int(1),
	USER_NOTIFY_ON_PM varchar(3) not null default 'yes',
	USER_SOCIAL1 varchar(200),
	USER_SOCIAL2 varchar(200),
	USER_SOCIAL3 varchar(200),
	USER_SOCIAL4 varchar(200),
	USER_SOCIAL5 varchar(200),
	USER_SOCIAL6 varchar(200),
	USER_SOCIAL7 varchar(200),
	USER_SOCIAL8 varchar(200),
	USER_SOCIAL9 varchar(200),
	USER_EXTRA_FIELD_1 varchar(200),
	USER_EXTRA_FIELD_2 varchar(200),
	USER_EXTRA_FIELD_3 varchar(200),
	USER_EXTRA_FIELD_4 varchar(200),
	USER_EXTRA_FIELD_5 varchar(200),
	USER_AVATAR varchar(150),
	USER_SHOW_AVATARS tinyint(1) not null default '1',
	USER_VISIBLE_ONLINE_STATUS varchar(3) default 'yes',
	USER_ACCEPT_PM varchar(3) default 'yes',
	USER_EMAIL_WATCHLISTS tinyint(1) not null default '1',
	USER_TITLE varchar(100),
	USER_CUSTOM_TITLE varchar(255),
	USER_POSTS_PER_TOPIC varchar(2),
	USER_TEMPORARY_PASSWORD varchar(32),
	USER_NAME_COLOR varchar(15),
	USER_TIME_OFFSET varchar(50),
	USER_RELATIVE_TIME tinyint(1),
	USER_TOTAL_PM int(4) default '0',
	USER_TOTAL_POSTS int(9) default '0',
	USER_SHOW_SIGNATURES varchar(3),
	USER_LIKES int(9) null default null,
	USER_RATING int(1),
	USER_TOTAL_RATES mediumint(6) not null default '0',
	USER_AVATAR_WIDTH int(4) default '0',
	USER_AVATAR_HEIGHT int(4) default '0',
	USER_ACCEPT_ADMIN_EMAILS varchar(3),
	USER_BIRTHDAY varchar(10) not null default '0',
	USER_PUBLIC_BIRTHDAY int(1) not null default '0',
	USER_TIME_FORMAT varchar(30),
	USER_IGNORE_LIST text,
	USER_FLOOD_CONTROL_OVERRIDE mediumint(8) default '-1',
	USER_STYLE mediumint(4) not null default '0',
	USER_UNAPPROVED_POST_NOTIFY tinyint(1) not null default '0',
	USER_REPORT_POST_NOTIFY tinyint(1) not null default '0',
	USER_TEXT_EDITOR varchar(10) default 'standard',
	USER_HIDE_LEFT_COLUMN tinyint(1) not null default '0',
	USER_HIDE_RIGHT_COLUMN tinyint(1) not null default '0',
	USER_MOOD varchar(50),
	USER_NOTIFY_NEW_USER tinyint(1) not null default '0',
	USER_POST_LAYOUT varchar(4),
	USER_SHOW_ALL_GRAEMLINS	tinyint(1) default '0',
	USER_SHOW_LEFT_MYSTUFF tinyint(1) not null default '1',
	USER_GROUP_IMAGES varchar(255),
	USER_NOTIFY_MULTI tinyint(1) unsigned not null default '0',
	INDEX birthday_ndx (USER_BIRTHDAY, USER_PUBLIC_BIRTHDAY),
	INDEX email_ndx(USER_REAL_EMAIL)
) ENGINE=MyISAM";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}USER_PROFILE table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}USER_DATA (
	USER_ID int(9) not null primary key,
	USER_LAST_POST int(11) unsigned,
	USER_PROFILE_KEY varchar(32),
	USER_LAST_VISIT_TIME int(11),
	USER_LAST_POST_TIME int(11) unsigned,
	USER_LAST_IP varchar(46),
	USER_LAST_SEARCH_TIME int(11),
	SEARCH_SESSION_ID varchar(32)
) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}USER_DATA table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}USER_NOTES (
		USER_ID int(9) not null primary key,
		NOTE_TEXT text
	) ENGINE=MyISAM
";
$dbh->do_query($query);

$printer .= "{$config['TABLE_PREFIX']}USER_NOTES table created...<br>";

// BoModerators table #############################
$query = "
	create table {$config['TABLE_PREFIX']}MODERATORS (
	USER_ID int(9) not null,
	FORUM_ID int(9) not null,
	INDEX Modindx1 (USER_ID),
	INDEX Modindx2 (FORUM_ID)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}MODERATORS table created...<br>";

// Private Message Table ##########################

// Create the Private Messages Table
$query = "
	create table {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS (
		TOPIC_ID bigint(20) not null auto_increment primary key,
		TOPIC_TIME int(9) unsigned,
		TOPIC_REPLIES int(9) not null default '0',
		TOPIC_SUBJECT varchar(255),
		USER_ID int(9) unsigned not null,
		TOPIC_LAST_REPLY_TIME int(9) unsigned,
		TOPIC_LAST_POSTER_ID int(9) unsigned,
		TOPIC_LAST_POSTER_NAME varchar(64)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS (
	POST_ID bigint(20) not null auto_increment primary key,
	TOPIC_ID bigint(20) not null,
	USER_ID int(9) unsigned not null,
	POST_BODY text,
	POST_DEFAULT_BODY text,
	POST_TIME int(9) unsigned,
	INDEX sent_ndx(POST_TIME),
	INDEX parent_ndx(TOPIC_ID)
) ENGINE=MyISAM";

$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS table created...<br>";

// Create the table for Private Message Participants
$query = "
	create table {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS (
		TOPIC_ID bigint(20) not null,
		USER_ID int(9) not null,
		MESSAGE_LAST_READ int(9) unsigned,
		index user_ndx(USER_ID),
		index mesage_ndx(TOPIC_ID)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}PRIVAGE_MESSAGE_USERS table created...<br>";


// The Banned Table ###########################

$query = "
	create table {$config['TABLE_PREFIX']}BANNED_HOSTS(
	BANNED_HOST varchar(60) not null
) ENGINE=MyISAM";

$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}BANNED_HOSTS table created...<br>";

// The Banned User table
$query = "
create table {$config['TABLE_PREFIX']}BANNED_USERS (
	USER_ID int(9) not null,
	BAN_EXPIRATION int(11),
	BAN_REASON text,
	UNIQUE user_ndx (USER_ID)
) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}BANNED_USERS table created...<br>";


// The Groups Table ##################
$query = "
	create table {$config['TABLE_PREFIX']}GROUPS (
	GROUP_NAME varchar(250),
	GROUP_ID int(4) auto_increment primary key,
	GROUP_IS_DISABLED int(1) unsigned default '0',
	GROUP_POST_COUNT_JOIN int(10),
	GROUP_IMAGE varchar(50)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}GROUPS table created...<br>";

$query = "
	insert into {$config['TABLE_PREFIX']}GROUPS (GROUP_NAME,GROUP_IMAGE) values ('Administrators','adm.gif')
";
$dbh->do_query($query);
$query = "
	insert into {$config['TABLE_PREFIX']}GROUPS (GROUP_NAME,GROUP_IMAGE) values ('GlobalModerators','mod.gif')
";
$dbh->do_query($query);
$query = "
	insert into {$config['TABLE_PREFIX']}GROUPS (GROUP_NAME,GROUP_IMAGE) values ('Moderators','mod.gif')
";
$dbh->do_query($query);
$query = "
	insert into {$config['TABLE_PREFIX']}GROUPS (GROUP_NAME) values ('Users')
";
$dbh->do_query($query);
$query = "
	insert into {$config['TABLE_PREFIX']}GROUPS (GROUP_NAME) values ('Guests')
";
$dbh->do_query($query);

// The Online Table ##################
$query = "
	create table {$config['TABLE_PREFIX']}ONLINE(
	ONLINE_DISPLAY_NAME varchar(64) not null,
	USER_ID int(9) not null,
	ONLINE_LAST_ACTIVITY int(9) default '0' not null,
	ONLINE_SCRIPT_NAME varchar(64),
	ONLINE_USER_TYPE varchar(1) not null,
	ONLINE_BROWSING_FORUM varchar(100),
	ONLINE_USER_IP varchar(46),
	ONLINE_AGENT varchar(255),
	ONLINE_REFERER varchar(255),
	ONLINE_POST_ID int(9),
	ONLINE_POST_SUBJECT varchar(255),
	UNIQUE Oindx1 (ONLINE_DISPLAY_NAME),
	INDEX Oindx2 (ONLINE_LAST_ACTIVITY),
	INDEX Oindex3 (USER_ID),
	INDEX type_index(ONLINE_USER_TYPE)
	) ENGINE=heap
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}ONLINE table created...<br>";

// -----------------------
// Create the address book
$query = "
	create table {$config['TABLE_PREFIX']}ADDRESS_BOOK (
	USER_ID int(9) not null,
	ADDRESS_ENTRY_USER_ID int(9),
	INDEX address_ndx1 (USER_ID)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}ADDRESS_BOOK created..<br>";

$query = "
	create table {$config['TABLE_PREFIX']}MODERATOR_NOTIFICATIONS(
	POST_ID int(9) default '0' not null,
	INDEX modnotif_indx1 (POST_ID)
) ENGINE=MyISAM";

$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}MODERATOR_NOTIFICATIONS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}RATINGS (
	RATING_TARGET varchar(64),
	RATING_RATER varchar(64) not null,
	RATING_VALUE int(1) default '0',
	RATING_TYPE varchar(1) not null,
	INDEX r_indx1(RATING_TARGET,RATING_RATER,RATING_TYPE)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}RATINGS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}SEARCH_AGENTS (
	AGENTS text
	)
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}SEARCH_AGENTS table created...<br>";

// Robots (Crawlers) List for UBB.threads - UPDATED 2020-01-14
// SOURCE: https://www.ubbdev.com/forums/ubbthreads.php/topics/320566/7-x-robots-crawlers-list-for-ubb-threads.html
$agents = <<<EOF
007ac9=007ac9
13TABS=13TABS
1stwarning bot=1stwarning bot
28logsSpider=28logsSpider
2bone=2bone
2GDPR bot=2GDPR bot
2gisbot=2gisbot
2ip.ru=2ip.ru
360Spider=360Spider
3w24bot=3w24bot
A6-Indexer=A6-Indexer
Aboundex=Aboundex
acapbot=acapbot
acoonbot=acoonbot
AdAuth=AdAuth
Adbeat bot=Adbeat bot
adbeat_bot=adbeat_bot
AddSearchBot=AddSearchBot
AddThis.com=AddThis.com
AddThis=AddThis
Adform crawler=Adform crawler
Adidxbot=Adidxbot
ADmantX crawler=ADmantX crawler
ADmantX=ADmantX
AdminLabs=AdminLabs
Adolab bot=Adolab bot
AdsBot-Google=AdsBot-Google
AdsBot-Google-Mobile=AdsBot-Google-Mobile
adscanner=adscanner
AdsrvrBot=AdsrvrBot
adstxt.com crawler=adstxt.com crawler
AdsTxtCrawler=AdsTxtCrawler
adstxtlab.com Crawler=adstxtlab.com Crawler
AdvBot=AdvBot
agentslug=agentslug
Ahrefs=Ahrefs
aiHitBot=aiHitBot
AISearchBot=AISearchBot
Akamai crawler=Akamai crawler
Alertra=Alertra
Alexabot=Alexabot
Alignabot=Alignabot
AlphaBot=AlphaBot
AlphaSeoBot=AlphaSeoBot
alyze.info=alyze.info
Amazon bot=Amazon bot
Amazon CloudFront=Amazon CloudFront
AmazonAdBot=AmazonAdBot
AndersPinkBot=AndersPinkBot
AntBot=AntBot
antibot=antibot
Anturis Agent=Anturis Agent
AnyEvent=AnyEvent
Apercite bot=Apercite bot
Apercite=Apercite
APIs-Google=APIs-Google
AppBeat=AppBeat
AppEngine-Google=AppEngine-Google
AppInsights=AppInsights
Applebot=Applebot
AppNexus crawler=AppNexus crawler
arabot=arabot
arachnode.net=arachnode.net
Aranea=Aranea
archive.org_bot=archive.org_bot
Archive.St crawler=Archive.St crawler
ArchiveBot=ArchiveBot
ArchiveTeam crawler=ArchiveTeam crawler
Awario crawler=Awario crawler
awesomecrawler=awesomecrawler
axios=axios
aylienbot=aylienbot
B2B Bot=B2B Bot
backlink-check.de=backlink-check.de
BacklinkCrawler=BacklinkCrawler
BackupLand crawler=BackupLand crawler
Bad-Neighborhood=Bad-Neighborhood
Baidu-YunGuanCe=Baidu-YunGuanCe
Barkrowler=Barkrowler
BazQux=BazQux
BDCbot=BDCbot
BehloolBot=BehloolBot
betaBot=betaBot
bidswitchbot=bidswitchbot
BigInfoLabs crawler=BigInfoLabs crawler
BIGLOTRON=BIGLOTRON
bingbot=bingbot
BingPreview=BingPreview
binlar=binlar
BirilBot=BirilBot
bitlybot=bitlybot
bl.uk_lddc_bot=bl.uk_lddc_bot
Blackboard crawler=Blackboard crawler
Blackboard=Blackboard
BLEXBot=BLEXBot
blogmuraBot=blogmuraBot
Blogtrottr=Blogtrottr
BLP_bbot=BLP_bbot
bne.es crawler=bne.es crawler
bnf.fr_bot=bnf.fr_bot
BoardReader crawler=BoardReader crawler
BomboraBot=BomboraBot
Bot.AraTurka.com=Bot.AraTurka.com
botify=botify
bot-pge.chlooe.com=bot-pge.chlooe.com
BoxcarBot=BoxcarBot
brainobot=brainobot
BrandProtect bot=BrandProtect bot
BrandVerity=BrandVerity
Brandwatch crawler=Brandwatch crawler
BrokenLinkCheck.com=BrokenLinkCheck.com
Browsershots=Browsershots
BrowserSpyBot=BrowserSpyBot
BTWebClient=BTWebClient
BUbiNG=BUbiNG
BublupBot=BublupBot
Buck=Buck
BuiltWith=BuiltWith
bumb.ly crawler=bumb.ly crawler
Burf.co=Burf.co
buzzbot=buzzbot
ByteDance crawler=ByteDance crawler
Caliperbot=Caliperbot
CapsuleChecker=CapsuleChecker
careerbot=careerbot
CastFeedValidator=CastFeedValidator
CATExplorador=CATExplorador
CC Metadata Scaper=CC Metadata Scaper
CCBot=CCBot
centurybot9=centurybot9
changedetection=changedetection
check_http=check_http
Check-Host=Check-Host
CheckMarkNetwork=CheckMarkNetwork
Chirp=Chirp
Chrome-Lighthouse=Chrome-Lighthouse
citeseerxbot=citeseerxbot
CityGrid crawler=CityGrid crawler
Clarabot=Clarabot
CLcrawler=CLcrawler
Clickagy=Clickagy
Cliqzbot=Cliqzbot
Closure Compiler Service=Closure Compiler Service
Cloud mapping=Cloud mapping
CloudFlare crawler=CloudFlare crawler
CloudFlare-AlwaysOnline=CloudFlare-AlwaysOnline
Cloudinary=Cloudinary
CMS Crawler=CMS Crawler
coccoc=coccoc
Cocolyze bot=Cocolyze bot
collection@infegy.com=collection@infegy.com
CommaFeed=CommaFeed
Companybook-Crawler=Companybook-Crawler
COMSYS crawler=COMSYS crawler
content crawler spider=content crawler spider
ContentKing=ContentKing
ContextAd Bot=ContextAd Bot
contxbot=contxbot
convera=convera
CopperEgg=CopperEgg
Corax=Corax
CouponWCode Bot=CouponWCode Bot
Coveobot=Coveobot
crawler4j=crawler4j
CrawlForMe=CrawlForMe
CronDroid=CronDroid
Cronjob.de bot=Cronjob.de bot
cron-job.org=cron-job.org
Cronless=Cronless
CrowdTanglebot=CrowdTanglebot
CrunchBot=CrunchBot
CrystalSemanticsBot=CrystalSemanticsBot
Cula=Cula
cXensebot=cXensebot
CyberPatrol=CyberPatrol
DaaS.sh crawler=DaaS.sh crawler
DareBoost=DareBoost
Datafeedwatch=Datafeedwatch
datagnionbot=datagnionbot
Datanyze=Datanyze
Dataprovider Spider=Dataprovider Spider
Dataprovider.com=Dataprovider.com
DataXu=DataXu
Daum=Daum
Daumoa=Daumoa
DaveCrawler=DaveCrawler
DAWINCI ANTIPLAG=DAWINCI ANTIPLAG
dcrawl=dcrawl
ddline.cn crawler=ddline.cn crawler
Dead Link Checker=Dead Link Checker
deadlinkchecker=deadlinkchecker
deepcrawl=deepcrawl
demandbase-bot=demandbase-bot
Deskyobot=Deskyobot
DeuSu=DeuSu
DF Bot=DF Bot
Diffbot=Diffbot
Digg Deeper=Digg Deeper
Digincore bot=Digincore bot
DIGMATO.com crawler=DIGMATO.com crawler
discobot=discobot
Discordbot=Discordbot
Disqus=Disqus
dlvr.it=dlvr.it
DNS-Tools Header-Analyzer=DNS-Tools Header-Analyzer
DnyzBot=DnyzBot
Docoloc=Docoloc
Domain Re-Animator Bot=Domain Re-Animator Bot
domaincrawler=domaincrawler
domainsbot=domainsbot
DomainsDB.net MetaCrawler=DomainsDB.net MetaCrawler
DomainSigmaCrawler=DomainSigmaCrawler
DomainStatsBot=DomainStatsBot
dotbot=dotbot
Dotcom-Monitor bot=Dotcom-Monitor bot
DownloaderChrome=DownloaderChrome
downnotifier.com monitoring=downnotifier.com monitoring
DowntimeDetector=DowntimeDetector
draw.io=draw.io
drupact=drupact
DuckDuckBot=DuckDuckBot
DuckDuckGo-Favicons-Bot=DuckDuckGo-Favicons-Bot
Dun&BradstreetBot=Dun&BradstreetBot
e.ventures crawler=e.ventures crawler
EasyBib crawler=EasyBib crawler
EasyCron=EasyCron
Easy-Thumb=Easy-Thumb
ec2linkfinder=ec2linkfinder
EchoboxBot=EchoboxBot
edisterbot=edisterbot
electricmonk=electricmonk
Elefent=Elefent
elisabot=elisabot
Embedly=Embedly
EnliteAI crawler=EnliteAI crawler
EPFL cravler=EPFL cravler
epicbot=epicbot
eright=eright
europarchive.org=europarchive.org
evc-batch=evc-batch
Everyonedomainsbot=Everyonedomainsbot
EveryoneSocialBot=EveryoneSocialBot
exabot=exabot
Experian crawler=Experian crawler
Experibot=Experibot
ExtLinksBot=ExtLinksBot
EZID=EZID
ezooms=ezooms
FacebookBot=FacebookBot
facebookexternalhit=facebookexternalhit
Facebot=Facebot
Fake bot=Fake bot
FAST Enterprise Crawler=FAST Enterprise Crawler
FastCrawler=FastCrawler
FAST-WebCrawler=FAST-WebCrawler
Favicon=Favicon
faviconkit=faviconkit
FCCN crawler=FCCN crawler
fedoraplanet=fedoraplanet
Feedbin=Feedbin
FeedBunch=FeedBunch
FeedBurner=FeedBurner
feeder.co=feeder.co
Feedfetcher-Google=Feedfetcher-Google
Feedly=Feedly
Feedpresso crawler=Feedpresso crawler
Feedspot=Feedspot
Feedspotbot=Feedspotbot
FeedValidator=FeedValidator
FeedViewer=FeedViewer
Feedwind=Feedwind
FemtosearchBot=FemtosearchBot
Fetch=Fetch
Fever=Fever
Filestack=Filestack
filterdb.iss.netcrawler=filterdb.iss.netcrawler
FindITAnswersbot=FindITAnswersbot
findl.sk bot=findl.sk bot
findlink=findlink
findthatfile=findthatfile
findxbot=findxbot
FirmoGraph=FirmoGraph
Flamingo_SearchEngine=Flamingo_SearchEngine
FlipboardBot=FlipboardBot
FlipboardProxy=FlipboardProxy
fluffy=fluffy
fr-crawler=fr-crawler
freefind=freefind
FreeWebMonitoring SiteChecker=FreeWebMonitoring SiteChecker
Freshworks bot=Freshworks bot
Friendica=Friendica
Frontera=Frontera
fuelbot=fuelbot
Fuze_Bot=Fuze_Bot
Fyrebot=Fyrebot
g00g1e.net=g00g1e.net
G2 Web Services=G2 Web Services
g2reader-bot=g2reader-bot
GAChecker=GAChecker
GarlikCrawler=GarlikCrawler
GDNP crawler=GDNP crawler
Geek-Tools=Geek-Tools
Genieo Web filter=Genieo Web filter
Genieo=Genieo
GetLinkInfo.com=GetLinkInfo.com
Ghost Inspector=Ghost Inspector
Gigablast=Gigablast
Gigabot=Gigabot
GingerCrawler=GingerCrawler
github-camo=github-camo
Gluten Free Crawler=Gluten Free Crawler
gnam gnam spider=gnam gnam spider
GnowitNewsbot=GnowitNewsbot
gocrawl=gocrawl
Go-http-client=Go-http-client
Google AMP crawler=Google AMP crawler
Google AppsViewer=Google AppsViewer
Google Cloud AI=Google Cloud AI
Google Favicon=Google Favicon
Google Page Speed Insights=Google Page Speed Insights
Google Read Aloud=Google Read Aloud
Google Web Preview=Google Web Preview
Google-Ads=Google-Ads
Google-AdWords=Google-AdWords
Google-Adwords-Instant=Google-Adwords-Instant
Googlebot AdsBot Mobile=AdsBot-Google-Mobile
Googlebot AdSense=Mediapartners-Google
Googlebot Image=Googlebot-Image
Googlebot Mobile=Googlebot-Mobile
Googlebot Snippet=Googlebot snippet
Googlebot Video=Googlebot-Video
Googlebot Web Preview=Google Web Preview
Googlebot=Googlebot
Googlebot-Image=Googlebot-Image
Googlebot-Mobile=Googlebot-Mobile
Googlebot-News=Googlebot-News
Googlebot-Video=Googlebot-Video
GoogleDocs=GoogleDocs
Google-PhysicalWeb=Google-PhysicalWeb
GoogleSites=GoogleSites
Google-Site-Verification=Google-Site-Verification
Google-Structured-Data-Testing-Tool=Google-Structured-Data-Testing-Tool
Google-Test=Google-Test
google-xrawler=google-xrawler
Google-Youtube-Links=Google-Youtube-Links
Gosign crawler=Gosign crawler
GoSquared=GoSquared
GotSiteMonitor=GotSiteMonitor
Gowikibot=Gowikibot
Grammarly=Grammarly
GrapeshotCrawler=GrapeshotCrawler
Graydon crawler=Graydon crawler
Grobbot=Grobbot
GroupHigh=GroupHigh
grub.org=grub.org
gslfbot=gslfbot
GTmetrix=GTmetrix
GumGum Bot=GumGum Bot
HappyApps crawler=HappyApps crawler
Hatena=Hatena
hCardValidator=hCardValidator
HeadlessChrome=HeadlessChrome
HeartRailsBot=HeartRailsBot
heritrix=heritrix
HetrixTools crawler=HetrixTools crawler
Heurekabot=Heurekabot
Hexometer.com crawler=Hexometer.com crawler
historious=historious
hledejLevne.cz=hledejLevne.cz
Hlidam.to robot=Hlidam.to robot
hosterstats com=hosterstats com
HostTracker=HostTracker
htmlyse crawler=htmlyse crawler
http_get=http_get
httpunit=httpunit
HttpUrlConnection=HttpUrlConnection
HTTrack=HTTrack
HubSpot Crawler=HubSpot Crawler
HubSpot=HubSpot
Hypefactors crawler=Hypefactors crawler
HyperZbozi.cz Feeder=HyperZbozi.cz Feeder
HypeStat=HypeStat
ia_archiver=ia_archiver
IAB crawler=IAB crawler
IAS crawler=IAS crawler
ICBot=ICBot
ICC-Crawler=ICC-Crawler
ichiro=ichiro
iCjobs=iCjobs
Iframely=Iframely
iGooglePortal=iGooglePortal
ImageFetcher=ImageFetcher
ImplisenseBot=ImplisenseBot
imrbot=imrbot
IndeedBot=IndeedBot
Infegy=Infegy
InoopaBot=InoopaBot
integromedb=integromedb
intelium_bot=intelium_bot
InterfaxScanBot=InterfaxScanBot
InternetSeer=InternetSeer
internetVista monitor=internetVista monitor
internetwache.org crawler=internetwache.org crawler
iodc crawler=iodc crawler
IPIP.NET crawler=IPIP.NET crawler
ips-agent=ips-agent
ipv6-test.com validator=ipv6-test.com validator
ip-web-crawler.com=ip-web-crawler.com
iqdb=iqdb
Irokez.cz monitoring=Irokez.cz monitoring
Is it up=Is it up
isa=isa
iSec_Bot=iSec_Bot
iskanie=iskanie
ISOWQ=ISOWQ
IstellaBot=IstellaBot
isUp.li Website Monitoring=isUp.li Website Monitoring
it2media-domain-crawler=it2media-domain-crawler
IzABee Spider=IzABee Spider
JAHHO crawler=JAHHO crawler
James BOT=James BOT
JamesBOT=JamesBOT
Jamies Spider=Jamies Spider
Jeffrey Exif Viewer=Jeffrey Exif Viewer
Jetslide=Jetslide
Jetty=Jetty
JobboerseBot=JobboerseBot
JobKereso=JobKereso
Jooblebot=Jooblebot
jpg-newsbot=jpg-newsbot
Jugendschutzprogramm-Crawler=Jugendschutzprogramm-Crawler
jyxobot=jyxobot
K7MLWCBot=K7MLWCBot
kakao crawler=kakao crawler
kansalliskirjasto.fi crawler=kansalliskirjasto.fi crawler
Kaspersky Lab bot=Kaspersky Lab bot
kazbtbot=kazbtbot
KD Bot=KD Bot
KeepRight OpenStreetMap Checker=KeepRight OpenStreetMap Checker
Kemvibot=Kemvibot
Keybot Translation=Keybot Translation
KeyCDN bot=KeyCDN bot
keyword-hero bot=keyword-hero bot
KOCMOHABT bot=KOCMOHABT bot
KomodiaBot=KomodiaBot
KosmioBot=KosmioBot
Landau-Media-Spider=Landau-Media-Spider
Laserlikebot=Laserlikebot
lb-spider=lb-spider
LCC=LCC
Lead Inspector Crawler=Lead Inspector Crawler
leady.com crawler=leady.com crawler
Leikibot=Leikibot
LetsearchBot=LetsearchBot
letsencrypt bot=letsencrypt bot
libwww-perl=libwww-perl
Licorne crawler=Licorne crawler
LightspeedSystems Crawler=LightspeedSystems Crawler
Linespider=Linespider
Linguee Bot=Linguee Bot
Link Valet Online=Link Valet Online
link_thumbnailer=link_thumbnailer
LinkAlarm=LinkAlarm
linkapediabot=linkapediabot
LinkArchiver=LinkArchiver
linkdex=linkdex
linkdexbot=linkdexbot
LinkedInBot=LinkedInBot
linkfluence=linkfluence
LinkpadBot=LinkpadBot
linkpeek=linkpeek
LinkTiger=LinkTiger
LinqiaBot=LinqiaBot
lipperhey=lipperhey
LivelapBot=LivelapBot
looid.com crawler=looid.com crawler
lssbot=lssbot
lssrocketcrawler=lssrocketcrawler
ltx71=ltx71
Luminator-robots=Luminator-robots
LumtelBot=LumtelBot
LXRbot=LXRbot
MagiBot=MagiBot
magpie-crawler=magpie-crawler
Mail.Ru bot=Mail.Ru bot
Mail.RU_Bot=Mail.RU_Bot
Mailkit crawler=Mailkit crawler
Mappy=Mappy
mappydata=mappydata
MarketingMiner Bot=MarketingMiner Bot
MarketMuseBot=MarketMuseBot
masscan=masscan
Mastodon=Mastodon
MauiBot=MauiBot
MBCrawler=MBCrawler
MB-SiteCrawler=MB-SiteCrawler
Mediapartners=Mediapartners
Mediapartners-Google=Mediapartners-Google
Mediatoolkitbot=Mediatoolkitbot
Mediumbot=Mediumbot
MegaIndex=MegaIndex
MeltwaterNews=MeltwaterNews
memorybot=memorybot
Mergadobot=Mergadobot
MetaInspector=MetaInspector
MetaJobBot=MetaJobBot
MetaURI=MetaURI
Minds crawler=Minds crawler
mindUpBot=mindUpBot
Miniature.io=Miniature.io
Miniflux=Miniflux
Miralinks Robot=Miralinks Robot
Mixnode=Mixnode
MixnodeCache=MixnodeCache
MixrankBot=MixrankBot
MJ12bot=MJ12bot
mlbot=mlbot
moatbot=moatbot
MojeekBot=MojeekBot
Monibot=Monibot
monitis=monitis
Monitive Uptime Monitoring Bot=Monitive Uptime Monitoring Bot
monitorabot=monitorabot
monitorbacklinks.com bot=monitorbacklinks.com bot
montastic-monitor=montastic-monitor
MonTools.Com=MonTools.Com
MoodleBot=MoodleBot
Moreover=Moreover
msnbot=msnbot
msrbot=msrbot
MuckRack=MuckRack
Multiviewbot=Multiviewbot
Naver scrapbook=Naver scrapbook
NaverBot=NaverBot
nbertaupete95=nbertaupete95
NerdByNature.Bot=NerdByNature.Bot
nerdybot=nerdybot
netarkivet.dk crawler=netarkivet.dk crawler
Netcraft crawler=Netcraft crawler
NetcraftSurveyAgent=NetcraftSurveyAgent
netEstate Crawler=netEstate Crawler
netEstate NE Crawler=netEstate NE Crawler
Netpeak bot=Netpeak bot
netresearchserver=netresearchserver
NetSystemsResearch crawler=NetSystemsResearch crawler
Netvibes crawler=Netvibes crawler
Netvibes=Netvibes
netzzappen crawler=netzzappen crawler
newsharecounts=newsharecounts
newspaper=newspaper
NextCloud=NextCloud
niki-bot=niki-bot
Nimbostratus-Bot=Nimbostratus-Bot
NING=NING
NinjaBot=NinjaBot
NIXStatsbot=NIXStatsbot
Nmap Scripting Engine=Nmap Scripting Engine
Nmap=Nmap
Nodemeter=Nodemeter
NodePing=NodePing
northcutt.com crawler=northcutt.com crawler
NortheasternSysNetBot=NortheasternSysNetBot
NTENTbot=NTENTbot
nutch=nutch
Nuzzel=Nuzzel
oasis.go.kr crawler=oasis.go.kr crawler
oBot=oBot
Ocarinabot=Ocarinabot
OdklBot=OdklBot
OhDear crawler=OhDear crawler
okhttp=okhttp
omgili=omgili
omgilibot=omgilibot
OnCrawl=OnCrawl
Onespot crawler=Onespot crawler
Online Domain Tools=Online Domain Tools
online-webceo-bot=online-webceo-bot
OpenGraphCheck=OpenGraphCheck
OpenHoseBot=OpenHoseBot
openindexspider=openindexspider
Openstat=Openstat
OrangeBot=OrangeBot
OrgProbe=OrgProbe
OSZKbot=OSZKbot
outbrain=outbrain
OutclicksBot=OutclicksBot
Owlin=Owlin
page2rss=page2rss
PageModified Crawler=PageModified Crawler
PagePeeker=PagePeeker
Pagespeed=Pagespeed
Panopta=Panopta
Panscient crawler=Panscient crawler
panscient=panscient
PaperLiBot=PaperLiBot
ParaCrawl=ParaCrawl
PartyflockLinkChecker=PartyflockLinkChecker
Pcore-HTTP=Pcore-HTTP
PDFDriveCrawler=PDFDriveCrawler
Pearltrees=Pearltrees
PhantomJS=PhantomJS
PhantomJsCloud.com=PhantomJsCloud.com
Photon=Photon
phpcrawl=phpcrawl
phpservermon=phpservermon
pilicanbot=pilicanbot
Pingability.com bot=Pingability.com bot
PingAdmin.Ru=PingAdmin.Ru
Pingdom.com bot=Pingdom.com bot
pingdom=pingdom
Pinterest bot=Pinterest bot
pinterest.com.bot=pinterest.com.bot
PiplBot=PiplBot
PLAZOO bot=PLAZOO bot
PleskBot=PleskBot
Plukkie=Plukkie
PlurkBot=PlurkBot
Pocket bot=Pocket bot
PocketParser=PocketParser
Port Monitor check service=Port Monitor check service
postrank=postrank
PowerMapper Crawler=PowerMapper Crawler
pr-cy.ru Bot=pr-cy.ru Bot
PR-CY.RU=PR-CY.RU
Premsgo.fr bot=Premsgo.fr bot
Prerender.cloud=Prerender.cloud
Prerender=Prerender
presearch crawler=presearch crawler
Primalbot=Primalbot
PrintFriendly.com=PrintFriendly.com
PritTorrent=PritTorrent
PrivacyAwareBot=PrivacyAwareBot
PrivacyScore.org crawler=PrivacyScore.org crawler
Prlog=Prlog
probethenet.com scanner=probethenet.com scanner
Project 25499=Project 25499
Promotion_Tools=Promotion_Tools
Protopage=Protopage
proximic=proximic
psbot=psbot
PubMatic Crawler=PubMatic Crawler
Pulsepoint crawler=Pulsepoint crawler
Pulsepoint=Pulsepoint
purebot=purebot
python-requests=python-requests
Python-urllib=Python-urllib
Qwantify=Qwantify
R6 bot=R6 bot
Rambler bot=Rambler bot
RankActiveLinkBot=RankActiveLinkBot
RankingBot=RankingBot
RankurBot=RankurBot
RavenCrawler=RavenCrawler
REDbot=REDbot
redditbot=redditbot
RegionStuttgartBot=RegionStuttgartBot
Re-re crawler=Re-re crawler
RetrevoPageAnalyzer=RetrevoPageAnalyzer
Riddlerbot=Riddlerbot
Rigor crawler=Rigor crawler
Rivva=Rivva
Robots_Tester=Robots_Tester
RobotsChecker=RobotsChecker
rogerbot=rogerbot
Roistat Bot=Roistat Bot
ROR Sitemap Generator=ROR Sitemap Generator
RSiteAuditor=RSiteAuditor
RSSingBot=RSSingBot
RSSMicro.com RSS/Atom Feed Robot=RSSMicro.com RSS/Atom Feed Robot
RukiCrawler=RukiCrawler
Runet-Research-Crawler=Runet-Research-Crawler
rushBot=rushBot
RyowlEngine=RyowlEngine
Ryte Bot=Ryte Bot
s4a=s4a
SabsimBot=SabsimBot
SafeDNSBot=SafeDNSBot
SafeSearch microdata crawler=SafeSearch microdata crawler
SBL-BOT=SBL-BOT
SBSearch=SBSearch
SCFCrawler=SCFCrawler
ScoutJet=ScoutJet
Scrapy=Scrapy
Screaming Frog SEO Spider=Screaming Frog SEO Spider
screeenly-bot=screeenly-bot
scribdbot=scribdbot
seekbot=seekbot
Seeker=Seeker
Seekport Crawler=Seekport Crawler
SeeWithKids bot=SeeWithKids bot
semanticbot=semanticbot
SemanticJuice crawler=SemanticJuice crawler
SemanticScholarBot=SemanticScholarBot
semantic-visions.com crawler=semantic-visions.com crawler
SEMrushBot=SEMrushBot
Semtix.cz bot=Semtix.cz bot
SentiBot=SentiBot
sentry=sentry
Seo Servis=Seo Servis
Seobility=Seobility
SEOdiver=SEOdiver
SEOkicks=SEOkicks
SEOkicks-Robot=SEOkicks-Robot
SeopultContentAnalyzer=SeopultContentAnalyzer
seoscanners.net bot=seoscanners.net bot
seoscanners=seoscanners
SeoSiteCheckup=SeoSiteCheckup
SerendeputyBot=SerendeputyBot
serpstatbot=serpstatbot
SERPtimizerBot=SERPtimizerBot
Server Density=Server Density
ServiceUptime.robot=ServiceUptime.robot
SetCronJob=SetCronJob
Seznam Zbozi.cz=Seznam Zbozi.cz
seznambot=seznambot
Sideqik crawler=Sideqik crawler
SimpleCrawler=SimpleCrawler
SimpleScraper=SimpleScraper
SimplyFast.info=SimplyFast.info
sistrix crawler=sistrix crawler
SISTRIX Optimizer=SISTRIX Optimizer
Site24x7=Site24x7
sitebot=sitebot
SiteCheckerBot=SiteCheckerBot
Sitedomain-Bot=Sitedomain-Bot
siteexplorer.info=siteexplorer.info
SiteExplorer=SiteExplorer
Siteimprove.com bot=Siteimprove.com bot
Siteimprove.com=Siteimprove.com
SiteProbe=SiteProbe
Site-Shot=Site-Shot
SiteTruth.com=SiteTruth.com
SiteUptime.com=SiteUptime.com
SJUUPBot=SJUUPBot
SKB Kontur bot=SKB Kontur bot
SkypeUriPreview=SkypeUriPreview
Slackbot=Slackbot
Slack-ImgProxy=Slack-ImgProxy
Slurp=Slurp
smtbot=smtbot
Snacktory=Snacktory
snapchat-proxy=snapchat-proxy
SnapSearch=SnapSearch
sniptracker=sniptracker
SocialRankIOBot=SocialRankIOBot
SOLOFIELD bot=SOLOFIELD bot
Sonic=Sonic
SpazioDati bot=SpazioDati bot
spbot=spbot
Specificfeeds=Specificfeeds
speedy=speedy
SpiderLing=SpiderLing
Splash=Splash
SpuhexBot=SpuhexBot
SpyOnWeb=SpyOnWeb
SSL Labs=SSL Labs
ssl-tools.net=ssl-tools.net
sstbot=sstbot
startmebot=startmebot
statdom.ru/Bot=statdom.ru/Bot
StatOnlineRuBot=StatOnlineRuBot
StatusCake=StatusCake
Statusdroid=Statusdroid
Steeler=Steeler
Stephan Kopp bot=Stephan Kopp bot
StorygizeBot=StorygizeBot
Streamline3Bot=Streamline3Bot
Structured Data Markup Helper=Structured Data Markup Helper
Sucuri bot=Sucuri bot
summify=summify
Super Monitoring=Super Monitoring
SuperPagesUrlVerifyBot=SuperPagesUrlVerifyBot
SurdotlyBot=SurdotlyBot
SurveyBot=SurveyBot
SvetaBot=SvetaBot
SWIMGBot=SWIMGBot
Synthesio Crawler=Synthesio Crawler
Sysomos bot=Sysomos bot
Sysomos=Sysomos
TA SEO Crawler=TA SEO Crawler
tagoobot=tagoobot
TangibleeBot=TangibleeBot
Taringa=Taringa
TelegramBot=TelegramBot
Teoma=Teoma
Testomatobot=Testomatobot
TestURI crawler=TestURI crawler
TextRazor crawler=TextRazor crawler
The Knowledge AI=The Knowledge AI
theoldreader.com=theoldreader.com
Thinklab=Thinklab
Thither.Direct Bot=Thither.Direct Bot
thumbshots-de-Bot=thumbshots-de-Bot
TigerBot=TigerBot
TinEye=TinEye
Tiny Tiny RSS=Tiny Tiny RSS
TMM Crawler=TMM Crawler
TomBot=TomBot
Tools4noobs.com Spider=Tools4noobs.com Spider
toplistbot=toplistbot
ToutiaoSpider=ToutiaoSpider
Toweyabot=Toweyabot
Traackr.com=Traackr.com
tracemyfile=tracemyfile
trendictionbot=trendictionbot
Trove=Trove
TurnitinBot=TurnitinBot
TweetmemeBot=TweetmemeBot
Tweezler=Tweezler
twengabot=twengabot
Twingly Recon=Twingly Recon
Twingly=Twingly
Twitterbot=Twitterbot
Twurly=Twurly
UASlinkChecker=UASlinkChecker
uclassify.com=uclassify.com
uMBot=uMBot
umich.edu crawler=umich.edu crawler
um-LN=um-LN
Unshorten.It=Unshorten.It
updown.io bot=updown.io bot
Upflow=Upflow
uptime.com=uptime.com
Uptimebot.org=Uptimebot.org
Uptimebot=Uptimebot
UptimeRobot=UptimeRobot
Uptimia=Uptimia
uptm.io=uptm.io
urlappendbot=urlappendbot
Urlcheckr=Urlcheckr
URLitor.com=URLitor.com
useeBookChecker=useeBookChecker
UsineNouvelleCrawler=UsineNouvelleCrawler
Vagabondo=Vagabondo
Validator.nu=Validator.nu
vebidoobot=vebidoobot
VelenPublicWebCrawler=VelenPublicWebCrawler
Veoozbot=Veoozbot
VerticalLeap bot=VerticalLeap bot
veu=veu
Virusdie crawler=Virusdie crawler
virustotal=virustotal
vkShare=vkShare
voilabot=voilabot
Vsevjednom.cz crawler=Vsevjednom.cz crawler
vuhuvBot=vuhuvBot
W3C_CSS_Validator=W3C_CSS_Validator
W3C_I18n-Checker=W3C_I18n-Checker
W3C_Unicorn=W3C_Unicorn
W3C_Validator=W3C_Validator
W3C-checklink=W3C-checklink
W3C-mobileOK=W3C-mobileOK
w3dt.net crawler=w3dt.net crawler
Wappalyzer=Wappalyzer
WatchMouse=WatchMouse
wbsearchbot=wbsearchbot
Web Manifest Validator=Web Manifest Validator
webarchiv.cz=webarchiv.cz
web-archive-net.com.bot=web-archive-net.com.bot
WebBot=WebBot
webcompanycrawler=webcompanycrawler
WebCookies=WebCookies
WebCrawler=WebCrawler
Webcron.org crawler=Webcron.org crawler
WebDataStats=WebDataStats
webdepozit.sk crawler=webdepozit.sk crawler
WebGazer=WebGazer
webmon=webmon
weborama crawler=weborama crawler
Webshot=Webshot
websitepulse bot=websitepulse bot
WebSniffer=WebSniffer
WebThumb=WebThumb
WEDOS OnLine monitoring=WEDOS OnLine monitoring
WeSEE=WeSEE
WGETbot=WGETbot
WhatCMS.org bot=WhatCMS.org bot
WhatsApp=WhatsApp
WhoAPI=WhoAPI
WikiDo=WikiDo
Wikipedia crawler=Wikipedia crawler
wmtips.com=wmtips.com
wocbot=wocbot
woobot=woobot
WordPress.com bots=WordPress.com bots
WordupInfoSearch=WordupInfoSearch
woriobot=woriobot
WormlyBot=WormlyBot
wotbox=wotbox
WPSec=WPSec
WURFL ImageEngine=WURFL ImageEngine
WWRanks.com crawler=WWRanks.com crawler
Xenu Link Sleuth=Xenu Link Sleuth
XML Schema Validator=XML Schema Validator
XML Sitemaps Generator=XML Sitemaps Generator
XmlSitemapGenerator=XmlSitemapGenerator
xovibot=xovibot
yacybot=yacybot
Yahoo=Yahoo
Yandex.Metrica=Yandex.Metrica
Yandex.Webmaster=Yandex.Webmaster
YandexAccessibilityBot=YandexAccessibilityBot
YandexBot=YandexBot
YandexImages=YandexImages
YandexMobileBot=YandexMobileBot
yanga=yanga
YellowLabTools=YellowLabTools
Yeti=Yeti
YFF35=YFF35
YioopBot=YioopBot
YisouSpider=YisouSpider
YoozBot=yoozBot
YP crawler=YP crawler
Zabbix=Zabbix
zgrab=zgrab
Zombiebot=Zombiebot
ZoomBot=ZoomBot
Zoominfo=Zoominfo
Zoxh.Com Bot=Zoxh.Com Bot
ZumBot=ZumBot
ZuperlistBot=ZuperlistBot
Baiduspider (bad_bot)=Baiduspider
Bytespider (bad_bot)=Bytespider
Kinza (bad_bot)=Kinza
LieBaoFast (bad_bot)=LieBaoFast
Mb2345Browser (bad_bot)=Mb2345Browser
MicroMessenger (bad_bot)=MicroMessenger
Sogou (bad_bot)=Sogou
zh-CN (bad_bot)=zh-CN
zh_CN (bad_bot)=zh_CN
EOF;

$query = "
	insert into {$config['TABLE_PREFIX']}SEARCH_AGENTS
	values('$agents')
";
$dbh->do_query($query);
$printer .= "Agent Strings added into the {$config['TABLE_PREFIX']}SEARCH_AGENTS table...<br>";

$query = "
	insert into {$config['TABLE_PREFIX']}USERS
	(USER_ID,USER_LOGIN_NAME,USER_DISPLAY_NAME,USER_PASSWORD)
	values
	('1','**DONOTDELETE**','**DONOTDELETE**','badpass')
";
$dbh->do_query($query);

$query = "
	UPDATE {$config['TABLE_PREFIX']}USERS
	SET USER_ID='1'
	WHERE USER_DISPLAY_NAME='**DONOTDELETE**'
";
$dbh->do_query($query);

$query = "
	insert into {$config['TABLE_PREFIX']}USER_PROFILE
	(USER_ID)
	values
	('1')
";
$dbh->do_query($query);

$query = "
	insert into {$config['TABLE_PREFIX']}USER_DATA
	(USER_ID)
	values
	('1')
";
$dbh->do_query($query);

// Table for graemlins
$query = "
	create table {$config['TABLE_PREFIX']}GRAEMLINS (
	GRAEMLIN_ID int(11) not null auto_increment primary key,
	GRAEMLIN_MARKUP_CODE varchar(30),
	GRAEMLIN_SMILEY_CODE varchar(10),
	GRAEMLIN_IMAGE varchar(30),
	GRAEMLIN_IS_ACTIVE tinyint(1) default '1',
	GRAEMLIN_WIDTH int(4),
	GRAEMLIN_HEIGHT int(4),
	GRAEMLIN_ORDER	int(11) default '0',
	INDEX active_ndx (GRAEMLIN_IS_ACTIVE)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}GRAEMLINS table created...<br>";

$query = "
	SELECT COUNT(*)
	FROM {$config['TABLE_PREFIX']}GRAEMLINS
";
$sth = $dbh->do_query($query);
list ($check) = $dbh->fetch_array($sth);
if (!$check) {
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('eek','','eek.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('mad','','mad.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('cool','','cool.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('smile',':)','smile.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('frown',':(','frown.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('blush','','blush.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('crazy','','crazy.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('laugh',':D','laugh.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('shocked',':o','shocked.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('smirk',':/','smirk.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('confused','','confused.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('grin','','grin.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('wink',';)','wink.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('cry','','cry.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('sick','','sick.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('sleep','','sleep.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('tired','','tired.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		insert into {$config['TABLE_PREFIX']}GRAEMLINS
		(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
		values ('whistle','','whistle.gif','1','15','15')
	";
	$dbh->do_query($query);
	$query = "
		UPDATE {$config['TABLE_PREFIX']}GRAEMLINS SET GRAEMLIN_ORDER = GRAEMLIN_ID
	";
	$dbh->do_query($query);
}

$query = "
	create table {$config['TABLE_PREFIX']}DISPLAY_NAMES (
	DISPLAY_NAME_ID int(9) not null auto_increment primary key,
	USER_ID   int(9),
	DISPLAY_NAME_REQUEST varchar(255)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}DISPLAY_NAMES table created...<br>";

// --------------------------------------------------
// Add a table for storing languages that are offered
$query = "
	create table {$config['TABLE_PREFIX']}LANGUAGES (
	LANGUAGE_ID int(9) not null auto_increment primary key,
	LANGUAGE_TYPE   varchar(255),
	LANGUAGE_DESCRIPTION varchar(255),
	LANGUAGE_IS_ACTIVE int(1)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}LANGUAGES table created...<br>";

$query = "
	select COUNT(*)
	from {$config['TABLE_PREFIX']}LANGUAGES
";
$sth = $dbh->do_query($query);
list($check) = $dbh->fetch_array($sth);

if (!$check) {
	$query = "
		insert into {$config['TABLE_PREFIX']}LANGUAGES
		(LANGUAGE_TYPE,LANGUAGE_DESCRIPTION,LANGUAGE_IS_ACTIVE)
		values
		('english','English','1')
	";
	$dbh->do_query($query);
}

// --------------------------------------------------
// Add a new table for storing post likes
$query = "
	create table {$config['TABLE_PREFIX']}LIKES (
	TYPE char(1) NOT NULL,
	POST_ID int(11) NOT NULL DEFAULT '0',
	POSTER_ID int(11) DEFAULT '0',
	TOPIC_ID int(11) NOT NULL DEFAULT '0',
	USER_ID int(11) NOT NULL DEFAULT '0',
	TIMESTAMP int(11) NOT NULL
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}LIKES table created...<br>";
$dbh->do_query($query);

// -------------------------------------------
// Add a new table for saved mailer queries
$query = "
	create table {$config['TABLE_PREFIX']}MAILER (
	MAILER_TIME int(11),
	MAILER_SUBJECT varchar(255),
	MAILER_BODY text,
	MAILER_SEND_TO_GROUPS varchar(255),
	MAILER_DEFAULT_EMAIL varchar(255),
	MAILER_DO_NOT_BCC int(1),
	MAILER_CURRENT_CYCLE int(9),
	MAILER_TYPE varchar(10),
	MAILER_SAVED_QUERY text
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}MAILER table created...<br>";

// -------------------------------------------
// Add a new table for saved database queries
$query = "
	create table {$config['TABLE_PREFIX']}SAVED_QUERIES (
	QUERY_ID int(9) not null auto_increment primary key,
	QUERY_SYNTAX TEXT,
	QUERY_DESCRIPTION	text not null
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}SAVED_QUERIES table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}CALENDAR_EVENTS (
	CALENDAR_EVENT_ID int(11) unsigned not null auto_increment primary key,
	USER_ID int(9) unsigned,
	TOPIC_ID int(11) not null default '0',
	CALENDAR_EVENT_DAY  int(4) unsigned,
	CALENDAR_EVENT_MONTH int(4) unsigned,
	CALENDAR_EVENT_YEAR  int(4) unsigned,
	CALENDAR_EVENT_RECURRING ENUM ('monthly','yearly','never') default 'never',
	CALENDAR_EVENT_SUBJECT varchar(255),
	CALENDAR_EVENT_BODY TEXT,
	CALENDAR_EVENT_DEFAULT_BODY text,
	CALENDAR_EVENT_TYPE ENUM ('private','public'),
	INDEX owner_ndx (USER_ID),
	INDEX topic_ndx (TOPIC_ID),
	INDEX date_ndx (CALENDAR_EVENT_DAY,CALENDAR_EVENT_MONTH,CALENDAR_EVENT_YEAR),
	INDEX recur_ndx (CALENDAR_EVENT_RECURRING)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}CALENDAR_EVENTS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}CACHE (
		CACHE_FIELD varchar(255),
		CACHE_VALUE text
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}CACHE table created...<br>";


$query = "
	insert into {$config['TABLE_PREFIX']}CACHE
	(CACHE_FIELD,CACHE_VALUE)
	values
	('max_online','0')
";
$dbh->do_query($query);

$query = "
	insert into {$config['TABLE_PREFIX']}CACHE
	(CACHE_FIELD,CACHE_VALUE)
	values
	('max_online_timestamp','0')
";
$dbh->do_query($query);

$query = "
	insert into {$config['TABLE_PREFIX']}CACHE
	(CACHE_FIELD,CACHE_VALUE)
	values
	('birthdays','0')
";
$dbh->do_query($query);

$query = "
	CREATE TABLE `{$config['TABLE_PREFIX']}VERSION` (
	`SCRIPT_VERSION` VARCHAR( 10 ) NOT NULL ,
	`DB_VERSION` VARCHAR( 10 ) NOT NULL ,
	`LAST_ALTER_STEP` INT NOT NULL DEFAULT '0',
	`IS_RUNNING` TINYINT NOT NULL DEFAULT '0'
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}VERSION table created...<br>";

$query = "
	insert into {$config['TABLE_PREFIX']}VERSION
	(SCRIPT_VERSION,DB_VERSION,LAST_ALTER_STEP,IS_RUNNING)
	values
	('$VERSION','$VERSION',0,0)
";
$dbh->do_query($query);


$query = "
	create table {$config['TABLE_PREFIX']}ADMIN_SEARCHES (
		USER_ID int(9),
		ADMIN_SEARCH_TERMS text,
		ADMIN_SEARCH_QUERY text,
		ADMIN_SEARCH_TYPE varchar(25),
		ADMIN_SEARCH_REMOVED_RESULTS mediumtext,
		ADMIN_SEARCH_RESULTS longtext
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}ADMIN_SEARCHES table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}BANNED_EMAILS (
		BANNED_EMAIL varchar(255)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}BANNED_EMAILS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}RESERVED_NAMES (
		RESERVED_USERNAME varchar(255)
	)
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}RESERVED_NAMES table created...<br>";

$query = "
	insert into {$config['TABLE_PREFIX']}RESERVED_NAMES
	values
	('Anonymous')

";
$dbh->do_query($query);


$query = "
	create table {$config['TABLE_PREFIX']}CENSOR_LIST (
		CENSOR_WORD varchar(255),
		CENSOR_REPLACE_WITH varchar(255)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}CENSOR_LIST table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}USER_TITLES (
		USER_TITLE_ID int(4) unsigned not null auto_increment primary key,
		USER_TITLE_POST_COUNT mediumint(8) unsigned,
		USER_TITLE_NAME varchar(255)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}USER_TITLES table created...<br>";

$query = "
	insert into {$config['TABLE_PREFIX']}USER_TITLES
	values
	('1','0','stranger'),
	('2','25','newbie'),
	('3','50','journeyman'),
	('4','100','member'),
	('5','200','enthusiast'),
	('6','400','addict'),
	('7','700','old hand'),
	('8','1200','veteran'),
	('9','1600','pooh-bah'),
	('10','2500','carpal tunnel')
";
$dbh->do_query($query);


$query = "
	create table {$config['TABLE_PREFIX']}ANNOUNCEMENTS (
		TOPIC_ID int(11) unsigned not null,
		FORUM_ID varchar(25) not null,
		UNIQUE INDEX a_index (TOPIC_ID,FORUM_ID)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}ANNOUNCEMENTS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}REGISTRATION_FIELDS (
		REGISTRATION_FIELD varchar(255) not null,
		REGISTRATION_SHOW_FIELD tinyint(1),
		REGISTRATION_REQUIRE_FIELD tinyint(1)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}REGISTRATION_FIELDS table created...<br>";

$query = "
	insert into {$config['TABLE_PREFIX']}REGISTRATION_FIELDS
	values
	('USER_PASSWORD','0','1')
";
$dbh->do_query($query);

$query = "
	create table {$config['TABLE_PREFIX']}MEMBER_SEARCHES (
		MEMBER_SEARCH_ID mediumint(8) not null primary key auto_increment,
		MEMBER_SEARCH_TITLE varchar(255),
		MEMBER_SEARCH_QUERY text
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}MEMBER_SEARCHES table created...<br>";

$clause = addslashes("AND USER_LAST_VISIT_TIME > (UNIX_TIMESTAMP() - 259200) ORDER BY USER_LAST_VISIT_TIME");
$query = "
	insert into {$config['TABLE_PREFIX']}MEMBER_SEARCHES
	(MEMBER_SEARCH_TITLE,MEMBER_SEARCH_QUERY)
	values
	('Active in last 30 days','$clause')
";
$dbh->do_query($query);

$query = "
	create table {$config['TABLE_PREFIX']}PORTAL_BOXES (
		PORTAL_ID mediumint(8) not null primary key auto_increment,
		PORTAL_NAME varchar(255),
		PORTAL_BODY text,
		PORTAL_CACHE int(11),
		PORTAL_LAST_BUILD int(11),
		PORTAL_FORUMS text,
		PORTAL_POST_TYPE varchar(10),
		PORTAL_CUSTOM tinyint(1) not null default '0',
		PORTAL_LOCK int(11),
		PORTAL_ITEMS tinyint(3)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}PORTAL_BOXES table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}RSS_FEEDS (
		FEED_ID mediumint(8) not null primary key auto_increment,
		FEED_IS_ACTIVE tinyint(1) not null default '0',
		FEED_FORUM int(9) not null default '0',
		FEED_FORUM_ARRAY text,
		FEED_NAME varchar(255),
		FEED_LAST_BUILD int(11),
		FEED_TYPE varchar(10),
		FEED_INCLUDE_BODY mediumint(6),
		FEED_ITEMS mediumint(4) not null default '5',
		FEED_CACHE_TIME mediumint(5),
		FEED_IS_MULTI tinyint(1),
		FEED_LOCK int(11),
		INDEX feed_ndx (FEED_LOCK)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}RSS_FEEDS table created...<br>";


// Insert options for custom boxes
for ($i = 1; $i <= 10; $i++) {
	$query = "
		insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
		(PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
		values
		('0','0','0','1')
	";
	$dbh->do_query($query);
}

// POST ISLANDS
for ($i = 1; $i <= 10; $i++) {
	$query = "
		insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
		(PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
		values
		('0','0','0','2')
	";
	$dbh->do_query($query);
}

// THUMBNAIL ISLANDS
for ($i = 1; $i <= 10; $i++) {
	$query = "
		insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
		(PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
		values
		('0','0','0','3')
	";
	$dbh->do_query($query);
}

// Insert online portal box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
	values
	('online_now',0,120,0,0)
";
$dbh->do_query($query);

// Insert top_posters portal box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
	values
	('top_posters',0,300,0,0)
";
$dbh->do_query($query);

// Insert top_posters_30 portal box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
	values
	('top_posters_30',0,300,0,0)
";
$dbh->do_query($query);

// Insert forum_stats portal box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
	values
	('forum_stats',0,600,0,0)
";
$dbh->do_query($query);

// Insert public_calendar portal box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
	values
	('public_calendar',0,600,0,0)
";
$dbh->do_query($query);

// Insert birthday potal box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
	values
	('birthdays',0,600,0,0)
";
$dbh->do_query($query);

// Insert featured member box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
	values
	('featured_member',0,3600,0,0)
";
$dbh->do_query($query);

// Insert featured member box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
	values
	('popular_topics',0,300,0,0)
";
$dbh->do_query($query);

// Insert top_likes portal box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME, PORTAL_CACHE, PORTAL_LAST_BUILD, PORTAL_CUSTOM, PORTAL_LOCK)
	values
	('top_likes', 3600, 0, 0, 0)
";
$dbh->do_query($query);

// Insert top_likes_30 portal box
$query = "
	insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
	(PORTAL_NAME, PORTAL_CACHE, PORTAL_LAST_BUILD, PORTAL_CUSTOM, PORTAL_LOCK)
	values
	('top_likes_30', 3600, 0, 0, 0)
";
$dbh->do_query($query);

$query = "
	create table {$config['TABLE_PREFIX']}SEARCH_RESULTS (
		SEARCH_SESSION_ID varchar(32) not null primary key,
		SEARCH_WORDS varchar(255),
		SEARCH_EXCLUDED_WORDS varchar(255),
		SEARCH_RESULTS MEDIUMTEXT,
		SEARCH_TIMESTAMP int(11),
		SEARCH_PREVIEW_BODY tinyint(1),
		SEARCH_SQL_LIMIT tinyint(2),
		INDEX time_index(SEARCH_TIMESTAMP)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}SEARCH_RESULTS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}CACHED_PERMISSIONS (
		USER_ID int(9) unsigned not null primary key,
		FORUM_PERMISSIONS mediumtext,
		SITE_PERMISSIONS text,
		CP_PERMISSIONS text,
		CACHED_TIMESTAMP int(11) unsigned not null
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}CACHED_PERMISSIONS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}USER_GROUPS (
		USER_ID int(9) unsigned not null,
		GROUP_ID int(9) unsigned not null,
		primary key (USER_ID,GROUP_ID)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}USER_GROUPS table created...<br>";

$query = "
	insert into {$config['TABLE_PREFIX']}USER_GROUPS
	(USER_ID,GROUP_ID)
	values
	('1','5')
";
$dbh->do_query($query);

$query = "
	create table {$config['TABLE_PREFIX']}FORUM_PERMISSIONS (
		GROUP_ID int(9) unsigned not null,
		FORUM_ID varchar(100) not null,
		USE_HTML tinyint not null default '0',
		USE_MARKUP tinyint not null default '0',
		FILE_TOTAL smallint not null default '0',
		FILE_SIZE int not null default '0',
		POLLS_IN_TOPICS tinyint not null default '0',
		POLLS_IN_REPLIES tinyint not null default '0',
		POSTS_ARE_MODERATED tinyint not null default '0',
		SEE_FORUM tinyint not null default '0',
		READ_TOPICS tinyint not null default '0',
		READ_REPLIES tinyint not null default '0',
		CREATE_TOPICS tinyint not null default '0',
		CREATE_REPLIES tinyint not null default '0',
		GALLERY_TOTAL smallint not null default '0',
		GALLERY_SIZE int not null default '0',
		AD_ISLAND tinyint not null default '0',
		EDIT_POSTS int not null default '0',
		DELETE_POSTS int not null default '0',
		LOCK_ANY tinyint not null default '0',
		MOVE_ANY tinyint not null default '0',
		DELETE_ANY tinyint not null default '0',
		EDIT_ANY tinyint not null default '0',
		STICKY_ANY tinyint not null default '0',
		APPROVE_ANY tinyint not null default '0',
		CAPTCHA tinyint not null default '0',
		CAN_DOWNLOAD tinyint not null default '0',
		POST_THROTTLE int not null default '0',
		DELETE_TOPICS tinyint not null default '0',
		CREATE_NEWS tinyint not null default '0',
		primary key (GROUP_ID,FORUM_ID)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}FORUM_PERMISSIONS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}WATCH_LISTS (
		USER_ID int(9) unsigned not null,
		WATCH_ID int(11) unsigned not null,
		WATCH_NOTIFY_IMMEDIATE tinyint(1) not null default '0',
		WATCH_TYPE varchar(1) not null,
		index USER_NDX(USER_ID,WATCH_ID,WATCH_TYPE),
		index WATCH_NDX(WATCH_ID,WATCH_TYPE)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}WATCH_LISTS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}TOPIC_VIEWS (
		TOPIC_ID int(11) unsigned not null,
		index topic_ndx (TOPIC_ID)
	) ENGINE=heap
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}TOPIC_VIEWS table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}SHOUT_BOX (
		SHOUT_ID bigint(20) unsigned not null primary key auto_increment,
		USER_ID int(9) unsigned not null,
		SHOUT_DISPLAY_NAME varchar(64),
		SHOUT_TEXT text,
		SHOUT_TIME int(11) unsigned,
		USER_IP varchar(46)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}SHOUT_BOX table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}POINTER_DELETE (
		TOPIC_ID int(9) unsigned not null,
		DELETE_ON int(11) unsigned not null,
		index ndx1 (TOPIC_ID),
		index ndx2 (DELETE_ON)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}POINTER_DELETE table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}IMPORT_MAP (
		SITE_ID int(9) unsigned not null default '1',
		POST_ID int(9) unsigned not null,
		OLD_TOPIC_ID int(9) unsigned not null,
		OLD_POST_ID int(9) unsigned not null,
		OLD_FORUM_ID int(9) unsigned not null default '1',
		index site_ndx (SITE_ID),
		index old_forum_ndx (OLD_FORUM_ID),
		index old_topic_ndx (OLD_TOPIC_ID),
		index old_post_ndx (OLD_POST_ID)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}IMPORT_MAP table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}CAPTCHA (
		CAPTCHA_ID varchar(32) not null primary key,
		CAPTCHA_TIMESTAMP int(11)
	) ENGINE=MyISAM
";
$dbh->do_query($query);
$printer .= "{$config['TABLE_PREFIX']}CAPTCHA table created...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}STYLES (
		STYLE_ID mediumint(4) not null auto_increment primary key,
		STYLE_NAME varchar(100),
		STYLE_IMG text,
		STYLE_EDITED_TIME int(11),
		STYLE_VARS text,
		STYLE_WRAPPERS mediumint(4) not null default '0',
		STYLE_IS_ACTIVE tinyint(1) not null default '1'
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}STYLES table created...<br>";
$dbh->do_query($query);

include("install_styles.php");

$query = "
	create table {$config['TABLE_PREFIX']}REFERER_LOG (
		REFERER_DATE int(9) unsigned not null,
		REFERER_URL text,
		index referer_date (REFERER_DATE)
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}REFERER_LOG table created...<br>";
$dbh->do_query($query);

$query = "
	create table {$config['TABLE_PREFIX']}ADMIN_LOG (
		LOG_DATE int(9) unsigned not null,
		USER_ID int(9) unsigned not null,
		LOG_IP varchar(46) not null default '0.0.0.0',
		LOG_ACTION varchar(50) not null default 'undefined',
		LOG_INFO text,
		index log_date (LOG_DATE),
		index user_id (USER_ID),
		index log_ip (LOG_IP),
		index log_action (LOG_ACTION)
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}ADMIN_LOG table created...<br>";
$dbh->do_query($query);

$query = "
	create table {$config['TABLE_PREFIX']}BBCODE (
		BBCODE_ID int(4) NOT NULL auto_increment,
		BBCODE_MENU_SHOW tinyint(1) NOT NULL default '1',
		BBCODE_ENABLE tinyint(1) NOT NULL default '1',
		BBCODE_DESCRIPTION varchar(128) default NULL,
		BBCODE_MENU_PROMPT varchar(128) default NULL,
		BBCODE_TAG varchar(64) default NULL,
		BBCODE_MATCH_REGEX text,
		BBCODE_MARKUP_RESULT text,
		BBCODE_MENU_ORDER int(4) NOT NULL default '0',
		UNIQUE KEY BBCODE_ndx (BBCODE_ID,BBCODE_ENABLE)
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}BBCODE table table created...<br>";
$dbh->do_query($query);

include("{$config['FULL_PATH']}/install/custom_codes/tags.php");
$enabled = 1;
$show = 1;
$order = 0;

$query = "
	INSERT INTO {$config['TABLE_PREFIX']}BBCODE
	(BBCODE_MENU_ORDER, BBCODE_MENU_SHOW, BBCODE_ENABLE, BBCODE_TAG, BBCODE_DESCRIPTION,BBCODE_MENU_PROMPT, BBCODE_MATCH_REGEX, BBCODE_MARKUP_RESULT)
	VALUES
	( ? , ? , ? , ? , ? , ? , ? , ? )
";
foreach ($export_tags as $custom) {
	$tag = $custom['tag'];
	$descrip = $custom['descrip'];
	$prompt = $custom['prompt'];
	$regex = $custom['regex'];
	$markup = $custom['markup'];
	$query_vars = array($order, $show, $enabled, $tag, $descrip, $prompt, $regex, $markup);
	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	$order++;
}

$query = "
	create table {$config['TABLE_PREFIX']}SUBSCRIPTIONS (
		GROUP_ID int unsigned not null primary key,
		SUBSCRIPTION_NAME varchar(255),
		SUBSCRIPTION_DESCRIPTION text,
		SUBSCRIPTION_BY_DONATION tinyint unsigned,
		SUBSCRIPTION_DONATION_AMOUNT decimal(8,2) not null default '0.00',
		SUBSCRIPTION_BY_TRIAL tinyint unsigned,
		SUBSCRIPTION_TRIAL_AMOUNT decimal(8,2) not null default '0.00',
		SUBSCRIPTION_TRIAL_DURATION int,
		SUBSCRIPTION_TRIAL_INTERVAL varchar(1),
		SUBSCRIPTION_BY_REGULAR tinyint unsigned,
		SUBSCRIPTION_REGULAR_AMOUNT decimal(8,2) not null default '0.00',
		SUBSCRIPTION_REGULAR_DURATION int,
		SUBSCRIPTION_REGULAR_INTERVAL varchar(1),
		SUBSCRIPTION_IS_RECURRING tinyint not null default '0',
		SUBSCRIPTION_REATTEMPT tinyint not null default '0'
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}SUBSCRIPTIONS table created...<br>";
$dbh->do_query($query);

$query = "
	create table {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA (
		SUBSCRIPTION_ID int not null primary key auto_increment,
		CUSTOM_ID varchar(190) not null default '',
		USER_ID int not null,
		GROUP_ID int not null,
		SUBSCRIPTION_IS_ACTIVE tinyint not null default '0',
		SUBSCRIPTION_METHOD varchar(25),
		SUBSCRIPTION_STATUS varchar(25),
		SUBSCRIPTION_START_DATE int not null,
		SUBSCRIPTION_END_DATE int not null,
		SUBSCRIPTION_PAYMENT varchar(25) not null default '',
		SUBSCRIPTION_CREATED int not null,
		INDEX user_ndx(USER_ID),
		UNIQUE custom_ndx (CUSTOM_ID),
		INDEX payment_ndx(SUBSCRIPTION_PAYMENT),
		INDEX end_ndx(SUBSCRIPTION_END_DATE),
		INDEX created_ndx(SUBSCRIPTION_CREATED)
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}SUBSCRIPTION_DATA table created...<br>";
$dbh->do_query($query);


$query = "
	create table {$config['TABLE_PREFIX']}PAYPAL_DATA (
		LOG_ID int not null primary key auto_increment,
		SUBSCR_DATE varchar(255) not null default '',
		PAYMENT_DATE varchar(50) not null default '',
		SUBSCR_EFFECTIVE varchar(255) not null default '',
		ITEM_NAME varchar(255) default NULL,
		BUSINESS varchar(255) not null default '',
		ITEM_NUMBER varchar(50) default NULL,
		PAYMENT_STATUS varchar(15) not null default '',
		MC_GROSS varchar(6) not null default '',
		PAYMENT_CURRENCY varchar(10) not null default '',
		TXN_ID varchar(30) not null default '',
		RECEIVER_EMAIL varchar(255) not null default '',
		RECEIVER_ID varchar(50) not null default '',
		QUANTITY char(3) default null,
		NUM_CART_ITEMS varchar(10) not null default '',
		FIRST_NAME varchar(100) not null default '',
		LAST_NAME varchar(100) not null default '',
		PAYMENT_TYPE varchar(10) not null default '',
		PAYMENT_GROSS varchar(20) not null default '',
		PAYMENT_FEE varchar(20) not null default '',
		SETTLE_AMOUNT varchar(20) not null default '',
		MEMO varchar(255) default null,
		PAYER_EMAIL varchar(255) not null default '',
		TXN_TYPE varchar(20) not null default '',
		PAYER_STATUS varchar(50) not null default '',
		ADDRESS_STREET varchar(100) not null default '',
		ADDRESS_CITY varchar(50) not null default '',
		ADDRESS_STATE char(3) not null default '',
		ADDRESS_ZIP varchar(11) not null default '',
		ADDRESS_COUNTRY varchar(20) not null default '',
		ADDRESS_STATUS varchar(255) not null default '',
		TAX varchar(10) default null,
		OPTION_NAME1 varchar(255) not null default '',
		OPTION_SELECTION1 varchar(255) not null default '',
		OPTION_NAME2 varchar(255) not null default '',
		OPTION_SELECTION2 varchar(255) not null default '',
		INVOICE varchar(25) not null default '',
		CUSTOM_ID varchar(190) not null default '',
		NOTIFY_VERSION varchar(50) not null default '',
		VERIFY_SIGN varchar(255) not null default '',
		PAYER_BUSINESS_NAME varchar(255) not null default '',
		PAYER_ID varchar(50) not null default '',
		MC_CURRENCY varchar(5) not null default '',
		MC_FEE varchar(5) not null default '',
		EXCHANGE_RATE varchar(10) not null default '',
		SETTLE_CURRENCY varchar(10) not null default '',
		PARENT_TXN_ID varchar(50) not null default '',
		PENDING_REASON varchar(10) default null,
		REASON_CODE varchar(20) not null default '',
		SUBSCR_ID varchar(255) not null default '',
		PERIOD1 varchar(255) not null default '',
		PERIOD2 varchar(255) not null default '',
		PERIOD3 varchar(255) not null default '',
		AMOUNT1 varchar(255) not null default '',
		AMOUNT2 varchar(255) not null default '',
		AMOUNT3 varchar(255) not null default '',
		MC_AMOUNT1 varchar(255) not null default '',
		MC_AMOUNT2 varchar(255) not null default '',
		MC_AMOUNT3 varchar(255) not null default '',
		RECURRING varchar(255) not null default '',
		REATTEMPT varchar(255) not null default '',
		RETRY_AT varchar(255) not null default '',
		RECUR_TIMES varchar(255) not null default '',
		USERNAME varchar(255) not null default '',
		PASSWORD varchar(255) not null default '',
		INDEX txn_ndx(TXN_ID),
		INDEX custom_ndx(CUSTOM_ID)
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}PAYPAL_DATA table created...<br>";
$dbh->do_query($query);

$query = "
	create table {$config['TABLE_PREFIX']}CHECK_DATA (
		PAYMENT_DATE int,
		LOG_ID int not null primary key auto_increment,
		CUSTOM_ID varchar(190) not null default '',
		CHECK_NUMBER varchar(255),
		PAYMENT_AMOUNT varchar(15),
		INDEX custom_ndx (CUSTOM_ID)
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}CHECK_DATA table created...<br>";
$dbh->do_query($query);

$query = "
	create table {$config['TABLE_PREFIX']}PROFILE_COMMENTS (
		COMMENT_ID int(11) unsigned not null primary key auto_increment,
		PROFILE_ID int(9) unsigned not null,
		USER_ID int(9) unsigned not null,
		COMMENT_BODY text,
		COMMENT_DEFAULT_BODY text,
		COMMENT_MD5 varchar(32),
		COMMENT_TIME int(11) unsigned,
		INDEX profile_ndx (PROFILE_ID),
		INDEX user_ndx (USER_ID),
		INDEX md5_ndx (COMMENT_MD5)
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}PROFILE_COMMENTS table created...<br>";
$dbh->do_query($query);


$query = "
	create table {$config['TABLE_PREFIX']}PERMISSION_LIST (
		PERMISSION_NAME varchar(255),
		PERMISSION_IS_HIGH tinyint,
		PERMISSION_IS_LOW tinyint,
		PERMISSION_TYPE varchar(10),
		PERMISSION_ORDER float
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}PERMISSION_LIST table created...<br>";
$dbh->do_query($query);

$perms = array(
	"'USE_HTML','1','0','forum','50.1'",
	"'USE_MARKUP','1','0','forum','50.2'",
	"'FILE_TOTAL','1','0','forum','40.1'",
	"'FILE_SIZE','1','0','forum','40.2'",
	"'POLLS_IN_TOPICS','1','0','forum','45.0'",
	"'POLLS_IN_REPLIES','1','0','forum','45.1'",
	"'POSTS_ARE_MODERATED','0','1','forum','35.0'",
	"'SEE_FORUM','1','0','forum','0.0'",
	"'READ_TOPICS','1','0','forum','0.1'",
	"'CREATE_TOPICS','1','0','forum','0.3'",
	"'CREATE_REPLIES','1','0','forum','0.4'",
	"'POST_THROTTLE','0','1','forum','0.5'",
	"'CAPTCHA','1','0','forum','0.6'",
	"'CAN_DOWNLOAD','1','0','forum','0.7'",
	"'GALLERY_TOTAL','1','0','forum','40.3'",
	"'GALLERY_SIZE','1','0','forum','40.4'",
	"'AD_ISLAND','0','1','forum','60.0'",
	"'EDIT_POSTS','1','0','forum','55.1'",
	"'DELETE_POSTS','1','0','forum','55.0'",
	"'LOCK_ANY','1','0','forum','65.0'",
	"'MOVE_ANY','1','0','forum','65.1'",
	"'DELETE_ANY','1','0','forum','65.2'",
	"'EDIT_ANY','1','0','forum','65.3'",
	"'STICKY_ANY','1','0','forum','65.4'",
	"'APPROVE_ANY','1','0','forum','65.5'",
	"'DELETE_TOPICS','1','0','forum','65.15'",
	"'CREATE_NEWS', '1', '0', 'forum', '65.6'",
	"'SIGNATURE_IMAGES','1','0','site','2.0'",
	"'EXT_INFO','1','0','site','0.2'",
	"'MEMBER_LIST','1','0','site','0.0'",
	"'MEMBER_PROFILES','1','0','site','0.1'",
	"'MAIL_POST','1','0','site','1.0'",
	"'POLL_VOTE','1','0','site','3.0'",
	"'PM_TOTAL','1','0','site','3.1'",
	"'PM_LENGTH','1','0','site','3.15'",
	"'PM_INVITES','1','0','site','3.2'",
	"'CALENDAR_EVENTS','1','0','site','4.0'",
	"'SIGNATURE_LENGTH','1','0','site','2.1'",
	"'REMOTE_AVATARS','1','0','site','5.0'",
	"'STOCK_AVATARS','1','0','site','5.1'",
	"'UPLOAD_AVATARS','1','0','site','5.2'",
	"'CAN_SEE_SHOUTS','1','0','site','6.0'",
	"'CAN_SHOUT','1','0','site','6.1'",
	"'ANNOUNCEMENTS','1','0','site','0.0'",
	"'CAN_SEARCH','1','0','site','7.0'",
	"'SEARCH_THROTTLE','0','1','site','7.1'",
	"'CUSTOM_TITLE','1','0','site','8.0'",
	"'EDIT_USERS','1','0','cp','0.1'",
	"'FULL_ACCESS','1','0','cp','0.0'",
);

foreach ($perms as $k => $v) {
	$query = "
		insert into {$config['TABLE_PREFIX']}PERMISSION_LIST
		values
		($v)
	";
	$dbh->do_query($query, "Adding permissions into PERMISSION_LIST table");
}
$printer .= "Permissions added into the {$config['TABLE_PREFIX']}PERMISSION_LIST table...<br>";

$query = "
	create table {$config['TABLE_PREFIX']}SITE_PERMISSIONS (
		GROUP_ID mediumint not null PRIMARY KEY,
		SIGNATURE_IMAGES tinyint default '0',
		EXT_INFO tinyint default '0',
		MEMBER_LIST tinyint default '0',
		MEMBER_PROFILES tinyint default '0',
		MAIL_POST tinyint default '0',
		POLL_VOTE tinyint default '0',
		PM_TOTAL int default '0',
		PM_INVITES int default '0',
		CALENDAR_EVENTS tinyint default '0',
		SIGNATURE_LENGTH mediumint default '255',
		REMOTE_AVATARS tinyint default '0',
		STOCK_AVATARS tinyint default '0',
		UPLOAD_AVATARS tinyint default '0',
		CAN_SEE_SHOUTS tinyint default '1',
		CAN_SHOUT tinyint default '1',
		ANNOUNCEMENTS tinyint default '0',
		CAN_SEARCH tinyint default '0',
		SEARCH_THROTTLE smallint default '0',
		CUSTOM_TITLE mediumint default '0',
		PM_LENGTH mediumint not null default '100'
	) ENGINE=MyISAM
";
$printer .= "{$config['TABLE_PREFIX']}SITE_PERMISSIONS table created...<br>";
$dbh->do_query($query, "");


$query = "
	select GROUP_ID
	from {$config['TABLE_PREFIX']}GROUPS
	order by GROUP_ID asc
";
$sth = $dbh->do_query($query, "");

while (list($gid) = mysqli_fetch_array($sth)) {
	// Admins, Global Moderators, Moderators
	if ($gid < 4) {
		$sig_images = 1;
		$member_list = 1;
		$member_profiles = 1;
		$mail_post = 1;
		$poll_vote = 1;
		$pm_total = 10000;
		$pm_invites = 100;
		$cal_events = 1;
		$sig_length = 500;
		$remote_avatars = 1;
		$stock_avatars = 1;
		$upload_avatars = 0;
		$can_shout = 1;
		$see_shouts = 1;
		if ($gid == 1) {
			$announce = 1;
			$ext = 1;
		} else {
			$announce = 0;
			$ext = 0;
		}
		$custom_title = 1;
		$search = 1;
		$search_throttle = 0;
	}
	// Regular Users
	if ($gid == 4) {
		$sig_images = 1;
		$member_list = 1;
		$member_profiles = 1;
		$mail_post = 1;
		$poll_vote = 1;
		$pm_total = 200;
		$pm_invites = 5;
		$cal_events = 0;
		$sig_length = 255;
		$remote_avatars = 1;
		$stock_avatars = 0;
		$upload_avatars = 0;
		$can_shout = 1;
		$see_shouts = 1;
		$announce = 0;
		$search = 1;
		$search_throttle = 10;
		$custom_title = 0;
		$ext = 0;
	}
	// Guest group
	if ($gid == 5) {
		$sig_images = 0;
		$member_list = 0;
		$member_profiles = 0;
		$mail_post = 0;
		$poll_vote = 0;
		$pm_total = 0;
		$pm_invites = 0;
		$cal_events = 0;
		$sig_length = 0;
		$remote_avatars = 0;
		$stock_avatars = 0;
		$upload_avatars = 0;
		$can_shout = 0;
		$see_shouts = 1;
		$announce = 0;
		$search = 0;
		$search_throttle = 0;
		$custom_title = 0;
		$ext = 0;
	}
	$query = "
		insert into {$config['TABLE_PREFIX']}SITE_PERMISSIONS
		(GROUP_ID,SIGNATURE_IMAGES,MEMBER_LIST,MEMBER_PROFILES,MAIL_POST,POLL_VOTE,PM_TOTAL,PM_INVITES,CALENDAR_EVENTS,SIGNATURE_LENGTH,REMOTE_AVATARS,STOCK_AVATARS,UPLOAD_AVATARS,CAN_SEE_SHOUTS,CAN_SHOUT,ANNOUNCEMENTS,CAN_SEARCH,SEARCH_THROTTLE,CUSTOM_TITLE,EXT_INFO)
		values
		($gid,$sig_images,$member_list,$member_profiles,$mail_post,$poll_vote,$pm_total,$pm_invites,$cal_events,$sig_length,$remote_avatars,$stock_avatars,$upload_avatars,$see_shouts,$can_shout,$announce,$search,$search_throttle,$custom_title,$ext)
	";
	$dbh->do_query($query, "");
}

$query = "
	create table {$config['TABLE_PREFIX']}CP_PERMISSIONS (
		GROUP_ID mediumint not null PRIMARY KEY,
		EDIT_USERS tinyint not null default '0',
		FULL_ACCESS tinyint not null default '0'
	) ENGINE=MyISAM
";
$dbh->do_query($query, "");
$printer .= "{$config['TABLE_PREFIX']}CP_PERMISSIONS table created...<br>";

$query = "
	select GROUP_ID
	from {$config['TABLE_PREFIX']}GROUPS
	order by GROUP_ID asc
";
$sth = $dbh->do_query($query, "");

while (list($gid) = mysqli_fetch_array($sth)) {
	// Admins
	$edit_users = 0;
	$full_access = 0;
	if ($gid == 1) {
		$edit_users = 1;
		$full_access = 1;
	}
	$query = "
		insert into {$config['TABLE_PREFIX']}CP_PERMISSIONS
		(GROUP_ID,EDIT_USERS,FULL_ACCESS)
		values
		('$gid','$edit_users','$full_access')
	";
	$dbh->do_query($query, "");
}

$query = "
	select GROUP_ID
	from {$config['TABLE_PREFIX']}GROUPS
	order by GROUP_ID asc
";
$sth = $dbh->do_query($query, "Inserting the 'New Forum Permissions' template.");
while (list($gid) = mysqli_fetch_array($sth)) {

	// Generic
	$ftotal = 0;
	$fsize = 0;
	$captcha = 0;
	$gtotal = 0;
	$gsize = 0;
	$ad = 1;
	$moderated = 0;

	// Admins, Super Moderators and Moderators
	if ($gid < 4) {
		$allow_html = 1;
		$markup = 1;
		$poll_topic = 1;
		$poll_reply = 0;
		$see_forum = 1;
		$read_topics = 1;
		$create_topics = 1;
		$create_replies = 1;
		$download = 1;
		$edit_posts = 16777000;
		$delete_posts = 16777000;
		$lock_any = 1;
		$move_any = 1;
		$delete_any = 1;
		$edit_any = 1;
		$sticky_any = 1;
		$approve_any = 1;
		$delete_topics = 1;
		$create_news = 1;
	}
	// Regular Users
	if ($gid == 4) {
		$allow_html = 0;
		$markup = 1;
		$poll_topic = 0;
		$poll_reply = 0;
		$see_forum = 1;
		$read_topics = 1;
		$create_topics = 1;
		$create_replies = 1;
		$download = 1;
		$edit_posts = 3600;
		$delete_posts = 60;
		$lock_any = 0;
		$move_any = 0;
		$delete_any = 0;
		$edit_any = 0;
		$sticky_any = 0;
		$approve_any = 0;
		$delete_topics = 0;
		$create_news = 0;
	}
	// Guest Users and all other groups
	if ($gid > 4) {
		$allow_html = 0;
		$markup = 1;
		$poll_topic = 0;
		$poll_reply = 0;
		$see_forum = 1;
		$read_topics = 1;
		$create_topics = 0;
		$create_replies = 0;
		$download = 0;
		$edit_posts = 0;
		$delete_posts = 0;
		$lock_any = 0;
		$move_any = 0;
		$delete_any = 0;
		$edit_any = 0;
		$sticky_any = 0;
		$approve_any = 0;
		$delete_topics = 0;
		$create_news = 0;
	}
	$query = "
		insert into {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		(GROUP_ID,FORUM_ID,USE_HTML,USE_MARKUP,FILE_TOTAL,FILE_SIZE,POLLS_IN_TOPICS,POLLS_IN_REPLIES,POSTS_ARE_MODERATED,SEE_FORUM,READ_TOPICS,CREATE_TOPICS,CREATE_REPLIES,GALLERY_TOTAL,GALLERY_SIZE,AD_ISLAND,EDIT_POSTS,DELETE_POSTS,LOCK_ANY,MOVE_ANY,DELETE_ANY,EDIT_ANY,STICKY_ANY,APPROVE_ANY,CAPTCHA,CAN_DOWNLOAD,DELETE_TOPICS,CREATE_NEWS)
		values
		($gid,'New Forum Template',$allow_html,$markup,$ftotal,$fsize,$poll_topic,$poll_reply,$moderated,$see_forum,$read_topics,$create_topics,$create_replies,$gtotal,$gsize,$ad,$edit_posts,$delete_posts,$lock_any,$move_any,$delete_any,$edit_any,$sticky_any,$approve_any,$captcha,$download,$delete_topics,$create_news)
	";
	$dbh->do_query($query, "");
}

// Now let's create the admin user.
if ($display_name) {
	$date = $html->get_date();
	$ip = find_environmental('REMOTE_ADDR');
	$query_vars = array($login_name, $display_name, $password, 'Administrator', $date, $email, $ip, 'yes', 0);
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}USERS (USER_LOGIN_NAME,USER_DISPLAY_NAME,USER_PASSWORD,USER_MEMBERSHIP_LEVEL,USER_REGISTERED_ON,USER_REGISTRATION_EMAIL,USER_REGISTRATION_IP,USER_IS_APPROVED,USER_IS_UNDERAGE)
		VALUES ( ? , ? , ? , ? , ? , ? , ? , ? , ? )
	";
	$dbh->do_placeholder_query($query, $query_vars);

	$query = "
		select last_insert_id()
	";
	$sth = $dbh->do_query($query);
	list($user_id) = $dbh->fetch_array($sth);

	$array[] = 1;
	$sarray = serialize($array);
	$query_vars = array($user_id, $email, 0, 'Administrator', 0, $sarray);
	$query = "
		insert into {$config['TABLE_PREFIX']}USER_PROFILE
		(USER_ID,USER_REAL_EMAIL,USER_TOTAL_POSTS,USER_TITLE,USER_TOTAL_PM,USER_GROUP_IMAGES)
		values
		( ? , ? , ? , ? , ? , ? )
	";
	$dbh->do_placeholder_query($query, $query_vars);

	$query = "
		insert into {$config['TABLE_PREFIX']}USER_GROUPS
		(USER_ID,GROUP_ID)
		values
		('2','1')
	";
	$dbh->do_query($query);

	$query = "
		insert into {$config['TABLE_PREFIX']}USER_GROUPS
		(USER_ID,GROUP_ID)
		values
		('2','3')
	";
	$dbh->do_query($query);

	$query_vars = array($user_id, $date);
	$query = "
		insert into {$config['TABLE_PREFIX']}USER_DATA
		(USER_ID,USER_LAST_VISIT_TIME)
		values
		( ? , ? )
	";
	$dbh->do_placeholder_query($query, $query_vars);
	$printer .= "Admin user created...<br>";

// create a sample forum under the main category
	$query_vars = array($date);
	$query = "
		insert into {$config['TABLE_PREFIX']}FORUMS
		(FORUM_TITLE, FORUM_DESCRIPTION, FORUM_ID, FORUM_PARENT, FORUM_POSTS, FORUM_LAST_POST_TIME, FORUM_CREATED_ON, FORUM_IS_MODERATED, CATEGORY_ID, FORUM_TOPICS, FORUM_SORT_ORDER, FORUM_DEFAULT_TOPIC_AGE, FORUM_CUSTOM_HEADER, FORUM_STYLE, FORUM_LAST_POST_ID, FORUM_LAST_TOPIC_ID, FORUM_LAST_POSTER_ID, FORUM_LAST_POSTER_NAME, FORUM_LAST_POST_SUBJECT, FORUM_LAST_POST_ICON, FORUM_IMAGE, FORUM_IS_ACTIVE, FORUM_ISLAND_INSERT, FORUM_IS_RSS, FORUM_RSS_TITLE, FORUM_SHOW_INTRO, FORUM_INTRO_TITLE, FORUM_IS_TEASER, FORUM_IS_GALLERY, FORUM_ACTIVE_POSTS, FORUM_POSTS_COUNT, FORUM_SORT_FIELD, FORUM_SORT_DIR)
		values
		('General', 'Whatever you want to talk about.', 1, 0, 0, 0, ?, 0, 1, 0, NULL, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, '', 1, 0, 0, 'RSS Feed for General', 0, '', 0, 0, 1, 1, 'last', 'desc');
	";
	$dbh->do_placeholder_query($query, $query_vars);

	$query = "
		insert into {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		(GROUP_ID, FORUM_ID, USE_HTML, USE_MARKUP, FILE_TOTAL, FILE_SIZE, POLLS_IN_TOPICS, POLLS_IN_REPLIES, POSTS_ARE_MODERATED, SEE_FORUM, READ_TOPICS, READ_REPLIES, CREATE_TOPICS, CREATE_REPLIES, GALLERY_TOTAL, GALLERY_SIZE, AD_ISLAND, EDIT_POSTS, DELETE_POSTS, LOCK_ANY, MOVE_ANY, DELETE_ANY, EDIT_ANY, STICKY_ANY, APPROVE_ANY, CAPTCHA, CAN_DOWNLOAD, POST_THROTTLE, DELETE_TOPICS, CREATE_NEWS)
		values
		(1, '1', 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 16777000, 16777000, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1),
		(2, '1', 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 16777000, 16777000, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1),
		(3, '1', 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 16777000, 16777000, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0),
		(4, '1', 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 3600, 60, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0),
		(5, '1', 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	";
	$dbh->do_query($query);

	$query = "
		truncate table {$config['TABLE_PREFIX']}CACHED_PERMISSIONS;
	";
	$dbh->do_query($query);
	$printer .= "Sample forum added to main category...<br>";

	// Now let's log this user in.
	// --------------------------------------
	// Set a cookie or register a session var
	srand((double)microtime() * 1000000);
	$newsessionid = md5(rand(0, 32767));
	$config['COOKIE_LIFETIME'] = 604800;

	// -------------------------------------------------------------------
	// If this is their first visit for this browser session, set a cookie
	$laston = $html->get_date();
	$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_myid", "$user_id", time() + $config['COOKIE_LIFETIME']);
	$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_mysess", "$newsessionid", "0");
	$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_pass", "", time() - 3600);
	$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_dob", "", time() - 3600);

	include("install_header.tmpl");
	echo <<<EOF
$printer
	</td></tr></table>
	<div class="acvm bold padding">
	<br>All tables created.<br>
	</div>
	<div class="acvm padding">
	Congratulations, you are through with this installer!<br>
	Now go into the Control Panel to get started configuring your new forums.<br>
	<br><br>
	<form method="post" action="{$config['FULL_URL']}/ubbthreads.php">
	<input type="submit" name="submit" value="Continue To Your Forums" class="form-button" />
	</form>
	<br><br>
	Note: To better secure your forum, go to the Control Panel => Primary Settings to update your Forum Security Key.
	<br><br>
	<b>Don't forget to remove the install directory from your server.</b>
	</div>
EOF;

	$query = "
		update	{$config['TABLE_PREFIX']}USERS
		set			USER_SESSION_ID = ?
		where		USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($newsessionid, $user_id), __LINE__, __FILE__);

	$userob->build_permissions($user_id);

} else {
	include("install_header.tmpl");
	echo <<<EOF
	$printer
	</td></tr></table>
	<div class="acvm bold padding">
	<br>All tables created. Your database is ready for your import.<br>
	</div>
EOF;

}

include("install_footer.tmpl");
rebuild_islands(1);
build_custom_tag_cache();

?>