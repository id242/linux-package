<?php

$newstyles['.post-new']['set'] = "background-color:#d30303;
color:#fff;";
$newstyles['.post.op']['set'] = "background-color:#eee;
color:#666;";
$newstyles['.avatar-none']['set'] = "background-color:#eee!important;
color: #666!important;";
$newstyles['#top-button']['set'] = "background:#fff;
color:#00ab6c;
height:50px; /* same as width */
width:50px; /* same as height */
border-radius:50px; /* 10px for squared corners */
-webkit-border-radius:50px; /* 10px for squared corners */
-moz-border-radius:50px; /* 10px for squared corners */
bottom:25px; /* button location */
right:30px; /* button location */";
$newstyles['#top-button:hover']['set'] = "background-color:#555;";

?>