<?php

include("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 2;
for ($i = $thisstep; $i <= $totalsteps; $i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !$defined('DIDFAIL')) {
			$currenstep = $i;
			break;
		}

		if (function_exists('ob_flush')) {
			ob_flush();
		} else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
}

function alterstep2() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}FORUMS
		change FORUM_SORT_DIR FORUM_SORT_DIR varchar(4)
	";
	$sth = do_query($query, "{$config['TABLE_PREFIX']}FORUMS table altered.");
}

?>