<?php

$newstyles['.announce_css']['set'] = "background:#fffde7;";
$newstyles['.sticky_css']['set'] = "background:#cfd8dc;";
$newstyles['.post-nav']['set'] = "background: #fafafa;
border-bottom:1px solid #cccccc;
box-shadow: inset 0 -6px 8px -7px #e0e0e0;
color:#000000;
font-size:14px;
margin-right:2px;
padding:8px;";
$newstyles['.post-nav:hover']['set'] = "background:#FFFFFF;
color:#000000;";
$newstyles['.major-button']['set'] = "";
$newstyles['.pagination']['set'] = "border-radius:2px;
margin:0;";
$newstyles['.pages']['set'] = "background:#607d8b;
border:1px solid #263238;
color:#ffffff;
font-size:14px;
margin:4px;
padding:6px;";
$newstyles['.page-cur']['set'] = "background: #fafafa;
border-bottom:1px solid #cccccc;
color: #000000;
font-weight:700;
padding-left:8px;
padding-right:8px;";
$newstyles['.page-n']['set'] = "background: #fafafa;
border-bottom:1px solid #cccccc;
color: #000000;
padding-left:7px;
padding-right:7px;";
$newstyles['.pagenav']['set'] = "border:1px solid #D8D8D8;
font-size:11px;
padding:2px 5px";
$newstyles['.pagenavall']['set'] = "border:1px solid #D8D8D8;
font-size:11px;
padding:2px 5px";

?>