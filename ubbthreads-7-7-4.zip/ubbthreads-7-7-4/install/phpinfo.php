<?php
//	Script Version 7.7.2
echo <<<EOF
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>PHP Info Utility</title>
<link rel="stylesheet" href="../styles/common.css">
<link rel="stylesheet" href="../styles/admin.css">
</head>
<body>

<style>
h1{background-color:#3f51b5;color:#eee;border-bottom:1px solid #ebebeb;border-top:1px solid #ebebeb;display:block;font-size:14px;font-weight:700;padding:4px;}
h1 a:link, h1 a:visited{color:#eee;text-decoration:none;}
h1.p{all:inherit;display:block;font-size:18px;font-weight:700;padding:4px;}
h2{display:block;font-size:14px;font-weight:700;padding:10px 4px 6px;}
hr{display:none;}
table.phpinfo{background-color:#fff;border-bottom:solid 1px #ebebeb;font-size:12px;width:100%;}
table.phpinfo th{padding:6px 6px 0;}
table.phpinfo td{padding:6px 10px;}
table.phpinfo td.e{width:160px;}
table.phpinfo td.v{min-width:160px;}
table.phpinfo .v{word-break:break-all;}
</style>

<div id="header" class="headerlogo" style="padding:4px 4px 6px;position:relative">
<a href="https://www.ubbcentral.com/"><img src="../admin/image_files/ubb-logo.png" height="65" width="124" alt=""></a>.threads&#8482;
<div style="color:rgb(233, 233, 202);position: absolute; bottom:7px;right:6px;">PHP Info Utility</div>
</div>


<table class="fw"><tr><td class="admin-content alvt fw">
EOF;
function phpinfo_output() {

	ob_start();
	phpinfo(-1);
	$phpinfo_content = ob_get_contents();
	ob_end_clean();

	if (!empty($phpinfo_content))
		$phpinfo_array = explode('<table', $phpinfo_content);

	if (!empty($phpinfo_array)) {
		unset($phpinfo_array[0]);
		foreach ($phpinfo_array as $phpinfo_element) {
			$phpinfo_element = str_replace('<tr', '<tr valign="top"', $phpinfo_element);
			echo '<table class="phpinfo" ' . $phpinfo_element;
			echo '<div style="clear:both"></div>';
		}

	}
}

echo phpinfo_output();
echo <<<EOF
</td></tr></table>


<table class="fw">
	<tr>
		<td id="footer" class="fw">
		<span class="u_small" style="color: rgb(255, 255, 255);">
		<a href="https://www.ubbcentral.com/" target="_blank" class="u_footer_links">UBBCentral.com</a> &nbsp;&middot;&nbsp;
		<a href="https://www.ubbcentral.com/cgi-bin/directme.cgi?to=threadsmembers" target="_blank" class="u_footer_links">Member Area</a> &nbsp;&middot;&nbsp;
		<a href="https://www.ubbcentral.com/cgi-bin/directme.cgi?to=threadssupport" target="_blank" class="u_footer_links">Documents &amp; Support</a> &nbsp;&middot;&nbsp;
		<a href="https://www.ubbcentral.com/cgi-bin/directme.cgi?to=threads_forums" target="_blank" class="u_footer_links">Community Forums</a><br>
		<a href="https://www.ubbcentral.com/" target="_blank" class="u_footer_links tiny">Powered by UBB.threads&#8482; PHP Forum Software</a>
		</span>
		</td>
	</tr>
</table>

</body></html>
EOF;
?>