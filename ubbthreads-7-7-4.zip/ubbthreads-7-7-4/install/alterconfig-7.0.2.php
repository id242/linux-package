<?php

$query = "
	show INDEX from {$config['TABLE_PREFIX']}POSTS
";
$sth = $dbh->do_query($query);
while ($indexes = $dbh->fetch_array($sth)) {
	if (in_array("POST_BODY", $indexes)) {
		$newconfigs['FULL_TEXT'] = "POST_BODY";
	} else {
		$newconfigs['FULL_TEXT'] = "POST_DEFAULT_BODY";
	}
}

?>