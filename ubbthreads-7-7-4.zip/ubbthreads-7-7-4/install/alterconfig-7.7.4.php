<?php

$newconfigs['ENABLE_LIKES'] = '1';
$newconfigs['SHOW_USER_LIKES'] = '1';
$newconfigs['SHOW_USER_LIKES_LIMIT'] = '6';
$newconfigs['LIKE_SELF'] = '0';
$newconfigs['LIKES_REQUIRE_ACTIVE'] = '1';
$newconfigs['LIKES_PER_DAY_MAX'] = '20';
$newconfigs['TOP_LIKES'] = '10';

?>