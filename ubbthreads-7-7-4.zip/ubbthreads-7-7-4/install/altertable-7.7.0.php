<?php

include("altertable.inc.php");

echo "<table class='acvt' width='70%'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 1;
for ($i = $thisstep; $i <= $totalsteps; $i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !$defined('DIDFAIL')) {
			$currenstep = $i;
			break;
		}

		if (function_exists('ob_flush')) {
			ob_flush();
		} else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
	global $config;
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}PERMISSION_LIST
		(PERMISSION_NAME, PERMISSION_IS_HIGH, PERMISSION_IS_LOW, PERMISSION_TYPE, PERMISSION_ORDER) VALUES ('CREATE_NEWS', '1', '0', 'forum', '65.6')
	";
	$sth = do_query($query, "Adding CREATE_NEWS forum permission to permissions list...");

	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		ADD COLUMN CREATE_NEWS TINYINT(4) DEFAULT 0 NOT NULL AFTER DELETE_TOPICS
	";
	$sth = do_query($query, "Adding CREATE_NEWS column to forum permissions table...");
}

?>