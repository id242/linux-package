<?php

include("altertable.inc.php");

echo "<table class='acvt' width='70%'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 1;
for ($i = $thisstep; $i <= $totalsteps; $i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !$defined('DIDFAIL')) {
			$currenstep = $i;
			break;
		}

		if (function_exists('ob_flush')) {
			ob_flush();
		} else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
		CHANGE TOPIC_SUBJECT TOPIC_SUBJECT VARCHAR(255);
	";
	$sth = do_query($query, "Updating Private Message Topics table to 255 char limits...");
}

?>