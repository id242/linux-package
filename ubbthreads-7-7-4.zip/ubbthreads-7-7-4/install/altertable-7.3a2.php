<?php

include("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 24;
for ($i = $thisstep; $i <= $totalsteps; $i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !defined('DIDFAIL')) {
			$currentstep = $i;
			break;
		}
		if (function_exists('ob_flush')) {
			ob_flush();
		} else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL') && !$refresh) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
}

function alterstep2() {
	global $config;
	$query = "
		create table {$config['TABLE_PREFIX']}PERMISSION_LIST (
		PERMISSION_NAME varchar(255),
		PERMISSION_IS_HIGH tinyint,
		PERMISSION_IS_LOW tinyint,
		PERMISSION_TYPE varchar(10),
		PERMISSION_ORDER float
		) ENGINE=MyISAM
	";
	$sth = do_query($query, "{$config['TABLE_PREFIX']}PERMISSION_LIST table created.");
}

function alterstep3() {
	global $config;
	$perms = array(
		"'USE_HTML','1','0','forum','50.1'",
		"'USE_MARKUP','1','0','forum','50.2'",
		"'FILE_TOTAL','1','0','forum','40.1'",
		"'FILE_SIZE','1','0','forum','40.2'",
		"'POLLS_IN_TOPICS','1','0','forum','45.0'",
		"'POLLS_IN_REPLIES','1','0','forum','45.1'",
		"'POSTS_ARE_MODERATED','0','1','forum','35.0'",
		"'SEE_FORUM','1','0','forum','0.0'",
		"'READ_TOPICS','1','0','forum','0.1'",
		"'CREATE_TOPICS','1','0','forum','0.3'",
		"'CREATE_REPLIES','1','0','forum','0.4'",
		"'POST_THROTTLE','0','1','forum','0.5'",
		"'CAPTCHA','1','0','forum','0.6'",
		"'CAN_DOWNLOAD','1','0','forum','0.7'",
		"'GALLERY_TOTAL','1','0','forum','40.3'",
		"'GALLERY_SIZE','1','0','forum','40.4'",
		"'AD_ISLAND','0','1','forum','60.0'",
		"'EDIT_POSTS','1','0','forum','55.1'",
		"'DELETE_POSTS','1','0','forum','55.0'",
		"'LOCK_ANY','1','0','forum','65.0'",
		"'MOVE_ANY','1','0','forum','65.1'",
		"'DELETE_ANY','1','0','forum','65.2'",
		"'EDIT_ANY','1','0','forum','65.3'",
		"'STICKY_ANY','1','0','forum','65.4'",
		"'APPROVE_ANY','1','0','forum','65.5'",
		"'SIGNATURE_IMAGES','1','0','site','2.0'",
		"'EXT_INFO','1','0','site','0.2'",
		"'MEMBER_LIST','1','0','site','0.0'",
		"'MEMBER_PROFILES','1','0','site','0.1'",
		"'MAIL_POST','1','0','site','1.0'",
		"'POLL_VOTE','1','0','site','3.0'",
		"'PM_TOTAL','1','0','site','3.1'",
		"'PM_INVITES','1','0','site','3.2'",
		"'CALENDAR_EVENTS','1','0','site','4.0'",
		"'SIGNATURE_LENGTH','1','0','site','2.1'",
		"'REMOTE_AVATARS','1','0','site','5.0'",
		"'STOCK_AVATARS','1','0','site','5.1'",
		"'UPLOAD_AVATARS','1','0','site','5.2'",
		"'CAN_SEE_SHOUTS','1','0','site','6.0'",
		"'CAN_SHOUT','1','0','site','6.1'",
		"'ANNOUNCEMENTS','1','0','site','0.0'",
		"'CAN_SEARCH','1','0','site','7.0'",
		"'SEARCH_THROTTLE','0','1','site','7.1'",
		"'CUSTOM_TITLE','1','0','site','8.0'",
		"'EDIT_USERS','1','0','cp','0.1'",
		"'FULL_ACCESS','1','0','cp','0.0'",
	);

	foreach ($perms as $k => $v) {
		$query = "
			insert into {$config['TABLE_PREFIX']}PERMISSION_LIST
			values
			($v)
		";
		do_query($query, "Adding permissions into PERMISSION_LIST table");
	}

}

function alterstep4() {
	global $config;
	$query = "
		select GROUP_ID from {$config['TABLE_PREFIX']}GROUPS
		where GROUP_ID > 1
		order by GROUP_ID desc
	";
	$sth = do_query($query, "Grabbing current groups from {$config['TABLE_PREFIX']}GROUPS table");
	while (list($gid) = mysqli_fetch_array($sth)) {
		$query = "
			update {$config['TABLE_PREFIX']}GROUPS
			set GROUP_ID = GROUP_ID + 1
			where GROUP_ID = '$gid'
		";
		do_query($query, "Renumbering {$config['TABLE_PREFIX']}GROUPS table to make room for Super Moderators");

		$query = "
			update {$config['TABLE_PREFIX']}USER_GROUPS
			set GROUP_ID = GROUP_ID + 1
			where GROUP_ID = '$gid'
		";
		do_query($query, "");

		$query = "
			update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			set GROUP_ID = GROUP_ID + 1
			where GROUP_ID = '$gid'
		";
		do_query($query, "");

	}
	$refresh = 1;
	return ($refresh);
}

function alterstep5() {
	global $config;
	$query = "
		insert into {$config['TABLE_PREFIX']}GROUPS
		(GROUP_NAME,GROUP_ID,GROUP_IS_DISABLED,GROUP_CUSTOM_TITLE)
		values
		('GlobalModerators','2','0','0')
	";
	do_query($query, "Inserting GlobalModerators Group into the {$config['TABLE_PREFIX']}GROUPS table.");
}

function alterstep6() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		add USE_HTML tinyint not null default '0',
		add USE_MARKUP tinyint not null default '0',
		add FILE_TOTAL smallint not null default '0',
		add FILE_SIZE int not null default '0',
		add POLLS_IN_TOPICS tinyint not null default '0',
		add POLLS_IN_REPLIES tinyint not null default '0',
		add POSTS_ARE_MODERATED tinyint not null default '0',
		add SEE_FORUM tinyint not null default '0',
		add READ_TOPICS tinyint not null default '0',
		add READ_REPLIES tinyint not null default '0',
		add CREATE_TOPICS tinyint not null default '0',
		add CREATE_REPLIES tinyint not null default '0',
		add GALLERY_TOTAL smallint not null default '0',
		add GALLERY_SIZE int not null default '0',
		add AD_ISLAND tinyint not null default '0',
		add EDIT_POSTS int not null default '0',
		add DELETE_POSTS int not null default '0',
		add LOCK_ANY tinyint not null default '0',
		add MOVE_ANY tinyint not null default '0',
		add DELETE_ANY tinyint not null default '0',
		add EDIT_ANY tinyint not null default '0',
		add STICKY_ANY tinyint not null default '0',
		add APPROVE_ANY tinyint not null default '0',
		add CAPTCHA tinyint not null default '0',
		add CAN_DOWNLOAD tinyint not null default '0',
		add POST_THROTTLE int not null default '0'
	";
	do_query($query, "Adding new permission fields to the {$config['TABLE_PREFIX']}FORUM_PERMISSIOS table");
}

function alterstep7() {
	global $config;
	$edit_time = $config['MAX_EDIT_TIME'];
	$delete_time = $config['MAX_DELETE_TIME'];
	if (!$edit_time) $edit_time = 0;
	if (!$delete_time) $delete_time = 0;
	$query = "
		update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		set SEE_FORUM = 1,
			READ_TOPICS = 1,
			READ_REPLIES = 1,
			CAN_DOWNLOAD = 1,
			EDIT_POSTS = $edit_time,
			DELETE_POSTS = $delete_time
		where FORUM_PERMISSION_CAN_READ = 1
	";
	do_query($query, "Adding default permissions to the {$config['TABLE_PREFIX']}FORUM_PERMISSIONS table for existing groups.");
}

function alterstep8() {
	global $config;
	$query = "
		update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		set CREATE_TOPICS = 1,
			CREATE_REPLIES = 1
		where FORUM_PERMISSION_CAN_CREATE_TOPIC = 1
		and FORUM_PERMISSION_CAN_CREATE_REPLY = 1
	";
	do_query($query, "Adding default permissions to the {$config['TABLE_PREFIX']}FORUM_PERMISSIONS table for existing groups.");
}

function alterstep9() {
	global $config;
	$query = "
		update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		set CREATE_REPLIES = 1
		where FORUM_PERMISSION_CAN_CREATE_REPLY = 1
		and FORUM_PERMISSION_CAN_CREATE_TOPIC = 0
	";
	do_query($query, "Adding default permissions to the {$config['TABLE_PREFIX']}FORUM_PERMISSIONS table for existing groups.");
}

function alterstep10() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		drop FORUM_PERMISSION_CAN_READ,
		drop FORUM_PERMISSION_CAN_CREATE_REPLY,
		drop FORUM_PERMISSION_CAN_CREATE_TOPIC
	";
	do_query($query, "Dropping the old fields from the {$config['TABLE_PREFIX']}FORUM_PERMISSIONS table.");
	$refresh = 1;
	return ($refresh);
}

function alterstep11() {
	global $config;
	$query = "
		select FORUM_ID,SEE_FORUM,READ_TOPICS,READ_REPLIES,CREATE_TOPICS,CREATE_REPLIES
		from {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		where GROUP_ID = '3'
	";
	$sth = do_query($query, "Adding default permissions for the new Super Moderator group.");
	while (list($fid, $see, $read_t, $read_p, $create_t, $create_p) = mysqli_fetch_array($sth)) {
		$query = "
			insert into {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			(FORUM_ID,GROUP_ID,SEE_FORUM,READ_TOPICS,READ_REPLIES,CREATE_TOPICS,CREATE_REPLIES)
			values
			('$fid','2','$see','$read_t','$read_p','$create_t','$create_p')
		";
		do_query($query, "");
	}
	$refresh = 1;
	return ($refresh);
}

function alterstep12() {
	global $config;
	$query = "
		select FORUM_ID,FORUM_ALLOW_HTML,FORUM_ALLOW_MARKUP,FORUM_IS_MODERATED,FORUM_ALLOW_ATTACHMENTS,FORUM_ALLOW_POLLS,FORUM_POLLS_ANYWHERE,FORUM_IS_GALLERY,FORUM_GUEST_CAPTCHA
		from {$config['TABLE_PREFIX']}FORUMS
	";
	$sth = do_query($query, "Grabbing existing permissions from the {$config['TABLE_PREFIX']}FORUMS table.");
	while (list($id, $html, $markup, $mod, $attach, $tpoll, $rpoll, $gallery, $captcha) = mysqli_fetch_array($sth)) {

		// HTML
		$g_clause = "and GROUP_ID in ('1','2','3')";
		if ($html) $g_clause = "";
		$query = "
			update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			set USE_HTML = 1
			where FORUM_ID = '$id'
			$g_clause
		";
		do_query($query, "");

		// MARKUP
		$g_clause = "and GROUP_ID in ('1','2','3')";
		if ($markup) $g_clause = "";
		$query = "
			update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			set USE_MARKUP = 1
			where FORUM_ID = '$id'
			$g_clause
		";
		do_query($query, "");

		// MODERATED
		if ($mod) {
			$query = "
				update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
				set POSTS_ARE_MODERATED = 1
				where FORUM_ID = '$id'
				and GROUP_ID not in ('1','2','3')
			";
			do_query($query, "");
		}

		// Attachments
		if ($attach) {
			$query = "
				update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
				set FILE_TOTAL = '$attach',
				FILE_SIZE = '{$config['ATTACHMENT_SIZE']}'
				where FORUM_ID = '$id'
			";
			do_query($query, "");
		}

		// Polls
		$g_clause = "and GROUP_ID in ('1','2','3')";
		if ($tpoll) $g_clause = "";
		$query = "
			update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			set POLLS_IN_TOPICS = 1
			where FORUM_ID = '$id'
			$g_clause
		";
		do_query($query, "");

		// Polls in replies?
		if ($rpoll) {
			$query = "
				update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
				set POLLS_IN_REPLIES = 1
				where FORUM_ID = '$id'
			";
			do_query($query, "");
		}

		// Gallery
		if ($gallery) {
			$query = "
				update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
				set GALLERY_TOTAL = '$gallery',
				GALLERY_SIZE = '{$config['MAX_GALLERY_UPLOAD']}'
				where FORUM_ID = '$id'
			";
			do_query($query, "");
		}

		// CAPTCHA
		if ($captcha) {
			$query = "
				update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
				set CAPTCHA = '1'
				where GROUP_ID = '5'
				and FORUM_ID = '$id'
			";
			do_query($query, "");
		}

	}
	$refresh = 1;
	return ($refresh);
}


function alterstep13() {
	global $config;

	$query = "
		update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS set
		LOCK_ANY = 1,
		MOVE_ANY = 1,
		DELETE_ANY = 1,
		EDIT_ANY = 1,
		STICKY_ANY = 1,
		APPROVE_ANY = 1
		where GROUP_ID in ('1','2','3')
	";
	do_query($query, "Adding default moderator permissions for each forum.");

}

function alterstep14() {
	global $config;
	$query = "
		create table {$config['TABLE_PREFIX']}SITE_PERMISSIONS (
			GROUP_ID mediumint not null primary key,
			SIGNATURE_IMAGES tinyint default '0',
			EXT_INFO tinyint default '0',
			MEMBER_LIST tinyint default '0',
			MEMBER_PROFILES tinyint default '0',
			MAIL_POST tinyint default '0',
			POLL_VOTE tinyint default '0',
			PM_TOTAL int default '0',
			PM_INVITES int default '0',
			CALENDAR_EVENTS tinyint default '0',
			SIGNATURE_LENGTH mediumint default '255',
			REMOTE_AVATARS tinyint default '0',
			STOCK_AVATARS tinyint default '0',
			UPLOAD_AVATARS tinyint default '0',
			CAN_SEE_SHOUTS tinyint default '1',
			CAN_SHOUT tinyint default '1',
			ANNOUNCEMENTS tinyint default '0',
			CAN_SEARCH tinyint default '0',
			SEARCH_THROTTLE smallint default '0',
			CUSTOM_TITLE mediumint default '0'
		) ENGINE=MyISAM
	";
	do_query($query, "Creating {$config['TABLE_PREFIX']}SITE_PERMISSIONS table.");

}

function alterstep15() {
	global $config;

	// Make sure we don't have any site permissions already
	$query = "
		select count(*)
		from {$config['TABLE_PREFIX']}SITE_PERMISSIONS
	";
	$sth = do_query($query, "");
	list($check) = mysqli_fetch_array($sth);

	if (!$check) {
		$query = "
			select GROUP_ID ,GROUP_CUSTOM_TITLE
			from {$config['TABLE_PREFIX']}GROUPS
			order by GROUP_ID asc
		";
		$sth = do_query($query, "Inserting default Site Permissions");

		if (!$config['ALLOW_UPLOADED_AVATARS']) $config['ALLOW_UPLOADED_AVATARS'] = '0';
		if (!$config['MAIL_POST']) $config['MAIL_POST'] = '0';
		if (!$config['PUBLIC_CALENDAR_EVENTS']) $config['PUBLIC_CALENDAR_EVENTS'] = '0';
		if (!$config['ALLOW_REMOTE_AVATARS']) $config['ALLOW_REMOTE_AVATARS'] = '0';
		if (!$config['ALLOW_STOCK_AVATARS']) $config['ALLOW_STOCK_AVATARS'] = '0';

		while (list($gid, $custom) = mysqli_fetch_array($sth)) {
			// Admins, Global Moderators, Moderators
			if ($gid < 4) {
				$sig_images = 1;
				$member_list = 1;
				$member_profiles = 1;
				$mail_post = 1;
				$poll_vote = 1;
				$pm_total = 10000;
				$pm_invites = 100;
				$cal_events = 1;
				$sig_length = 500;
				$remote_avatars = 1;
				$stock_avatars = 1;
				$upload_avatars = $config['ALLOW_UPLOADED_AVATARS'];
				$can_shout = 1;
				$see_shouts = 1;
				if ($gid == 1) {
					$announce = 1;
					$ext = 1;
				} else {
					$announce = 0;
					$ext = 0;
				}
				$custom_title = $custom;
				$search = 1;
				$search_throttle = 0;
			}
			// Regular Users
			if ($gid == 4) {
				$sig_images = $config['IMAGE_MARKUP_IN_SIGS'];
				if (!$sig_images) $sig_images = 0;
				if (!$sig_images) $sig_images = 0;
				if ($config['MEMBER_DIRECTORY']) {
					$member_list = 1;
				} else {
					$member_list = 0;
				}
				$member_profiles = 1;
				$mail_post = $config['MAIL_POST'];
				$poll_vote = 1;
				$pm_total = $config['PM_LIMIT'];
				$pm_invites = $config['PM_PARTICIPANTS'];
				$cal_events = $config['PUBLIC_CALENDAR_EVENTS'];
				$sig_length = $config['SIGNATURE_LENGTH'];
				$remote_avatars = $config['ALLOW_REMOTE_AVATARS'];
				$stock_avatars = $config['ALLOW_STOCK_AVATARS'];
				$upload_avatars = $config['ALLOW_UPLOADED_AVATARS'];
				$can_shout = 1;
				$see_shouts = 1;
				$announce = 0;
				$search = 1;
				$search_throttle = $config['SEARCH_THROTTLE'];
				$custom_title = $custom;
				$ext = 0;
			}
			// Guest group
			if ($gid == 5) {
				$sig_images = 0;
				if ($config['MEMBER_DIRECTORY'] == 2) {
					$member_list = 1;
				} else {
					$member_list = 0;
				}
				$member_profiles = $config['ANON_VIEW_PROFILES'];
				$mail_post = 0;
				$poll_vote = $config['ANON_CAN_VOTE'];
				$pm_total = 0;
				$pm_invites = 0;
				$cal_events = 0;
				$sig_length = 0;
				$remote_avatars = 0;
				$stock_avatars = 0;
				$upload_avatars = 0;
				$can_shout = 0;
				$see_shouts = 1;
				$announce = 0;
				$search = 0;
				$search_throttle = 0;
				$custom_title = $custom;
				$ext = 0;
			}
			// All others, no perms
			if ($gid > 5) {
				$sig_images = 0;
				$member_list = 0;
				$member_profiles = 0;
				$mail_post = 0;
				$poll_vote = 0;
				$pm_total = 0;
				$pm_invites = 0;
				$cal_events = 0;
				$sig_length = 0;
				$remote_avatars = 0;
				$stock_avatars = 0;
				$upload_avatars = 0;
				$email_fav = 0;
				$can_shout = 0;
				$see_shouts = 1;
				$announce = 0;
				$search = 0;
				$search_throttle = 0;
				$custom_title = 0;
				$ext = 0;
			}

			if (!$member_profiles) $member_profiles = 1;
			if (!$poll_vote) $poll_vote = 0;
			if (!$pm_total) $pm_total = 0;
			if (!$pm_invites) $pm_invites = 5;
			if (!$search_throttle) $search_throttle = 0;


			$query = "
				insert into {$config['TABLE_PREFIX']}SITE_PERMISSIONS
				(GROUP_ID,SIGNATURE_IMAGES,MEMBER_LIST,MEMBER_PROFILES,MAIL_POST,POLL_VOTE,PM_TOTAL,PM_INVITES,CALENDAR_EVENTS,SIGNATURE_LENGTH,REMOTE_AVATARS,STOCK_AVATARS,UPLOAD_AVATARS,CAN_SEE_SHOUTS,CAN_SHOUT,ANNOUNCEMENTS,CAN_SEARCH,SEARCH_THROTTLE,CUSTOM_TITLE,EXT_INFO)
				values
				($gid,$sig_images,$member_list,$member_profiles,$mail_post,$poll_vote,$pm_total,$pm_invites,$cal_events,$sig_length,$remote_avatars,$stock_avatars,$upload_avatars,$see_shouts,$can_shout,$announce,$search,$search_throttle,$custom_title,$ext)
			";
			do_query($query, "");
		}

		$refresh = 1;
		return ($refresh);

	}

}

function alterstep16() {
	global $config;

	$query = "
		create table {$config['TABLE_PREFIX']}CP_PERMISSIONS (
			GROUP_ID mediumint not null primary key,
			EDIT_USERS tinyint not null default '0',
			FULL_ACCESS tinyint not null default '0'
		) ENGINE=MyISAM
	";
	do_query($query, "Creating {$config['TABLE_PREFIX']}CP_PERMISSIONS table.");

}


function alterstep17() {
	global $config;

	$query = "
		select GROUP_ID
		from {$config['TABLE_PREFIX']}GROUPS
		order by GROUP_ID asc
	";
	$sth = do_query($query, "Grabbing existing groups.");

	while (list($gid) = mysqli_fetch_array($sth)) {
		// Admins
		$edit_users = 0;
		$full_access = 0;
		if ($gid == 1) {
			$edit_users = 1;
			$full_access = 1;
		}
		$query = "
			insert into {$config['TABLE_PREFIX']}CP_PERMISSIONS
			(GROUP_ID,EDIT_USERS,FULL_ACCESS)
			values
			('$gid','$edit_users','$full_access')
		";
		do_query($query, "");
	}
	$refresh = 1;
	return ($refresh);
}

function alterstep18() {

	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
		add FORUM_PERMISSIONS text,
		add SITE_PERMISSIONS text,
		add CP_PERMISSIONS text,
		drop CACHED_PERMISSION_DATA
	";
	do_query($query, "Altering the {$config['TABLE_PREFIX']}CACHED_PERMISSIONS table.");

}

function alterstep19() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}USER_PROFILE
		drop USER_CANNOT_PM,
		add index post_ndx (USER_TOTAL_POSTS)
	";
	do_query($query, "Altering the {$config['TABLE_PREFIX']}USER_PROFILE table.");
}

function alterstep20() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}FORUMS
		drop FORUM_ALLOW_HTML,
		drop FORUM_ALLOW_MARKUP,
		drop FORUM_IS_MODERATED,
		drop FORUM_ALLOW_ATTACHMENTS,
		drop FORUM_ALLOW_POLLS,
		drop FORUM_POLLS_ANYWHERE,
		drop FORUM_GUEST_CAPTCHA
	";
	do_query($query, "Altering the {$config['TABLE_PREFIX']}FORUMS table.");
}

function alterstep21() {
	global $config;
	$query = "
		drop table {$config['TABLE_PREFIX']}MODERATOR_PERMISSIONS
	";
	do_query($query, "Dropping the {$config['TABLE_PREFIX']}MODERATOR_PERMISSIONS table.");
}

function alterstep22() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}GROUPS
		drop GROUP_CUSTOM_TITLE,
		add GROUP_POST_COUNT_JOIN int
	";
	do_query($query, "Altering the {$config['TABLE_PREFIX']}GROUPS table.");
	$refresh = 1;
	return ($refresh);
}


function alterstep23() {
	global $config;

	$query = "
		select GROUP_ID
		from {$config['TABLE_PREFIX']}GROUPS
		order by GROUP_ID asc
	";
	$sth = do_query($query, "Inserting the 'New Forum Permissions' template.");
	while (list($gid) = mysqli_fetch_array($sth)) {

		// Generic
		$ftotal = 0;
		$fsize = 0;
		$captcha = 0;
		$gtotal = 0;
		$gsize = 0;
		$ad = 1;
		$moderated = 0;

		// Admins, Super Moderators and Moderators
		if ($gid < 4) {
			$html = 1;
			$markup = 1;
			$poll_topic = 1;
			$poll_reply = 0;
			$see_forum = 1;
			$read_topics = 1;
			$create_topics = 1;
			$create_replies = 1;
			$download = 1;
			$edit_posts = 16777000;
			$delete_posts = 16777000;
			$lock_any = 1;
			$move_any = 1;
			$delete_any = 1;
			$edit_any = 1;
			$sticky_any = 1;
			$approve_any = 1;
		}
		// Regular Users
		if ($gid == 4) {
			$html = 0;
			$markup = 1;
			$poll_topic = 0;
			$poll_reply = 0;
			$see_forum = 1;
			$read_topics = 1;
			$create_topics = 1;
			$create_replies = 1;
			$download = 1;
			$edit_posts = 3600;
			$delete_posts = 60;
			$lock_any = 0;
			$move_any = 0;
			$delete_any = 0;
			$edit_any = 0;
			$sticky_any = 0;
			$approve_any = 0;
		}
		// Guest Users and all other groups
		if ($gid > 4) {
			$html = 0;
			$markup = 1;
			$poll_topic = 0;
			$poll_reply = 0;
			$see_forum = 1;
			$read_topics = 1;
			$create_topics = 0;
			$create_replies = 0;
			$download = 0;
			$edit_posts = 0;
			$delete_posts = 0;
			$lock_any = 0;
			$move_any = 0;
			$delete_any = 0;
			$edit_any = 0;
			$sticky_any = 0;
			$approve_any = 0;
		}
		$query = "
			insert into {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			(GROUP_ID,FORUM_ID,USE_HTML,USE_MARKUP,FILE_TOTAL,FILE_SIZE,POLLS_IN_TOPICS,POLLS_IN_REPLIES,POSTS_ARE_MODERATED,SEE_FORUM,READ_TOPICS,CREATE_TOPICS,CREATE_REPLIES,GALLERY_TOTAL,GALLERY_SIZE,AD_ISLAND,EDIT_POSTS,DELETE_POSTS,LOCK_ANY,MOVE_ANY,DELETE_ANY,EDIT_ANY,STICKY_ANY,APPROVE_ANY,CAPTCHA,CAN_DOWNLOAD)
			values
			($gid,'New Forum Template',$html,$markup,$ftotal,$fsize,$poll_topic,$poll_reply,$moderated,$see_forum,$read_topics,$create_topics,$create_replies,$gtotal,$gsize,$ad,$edit_posts,$delete_posts,$lock_any,$move_any,$delete_any,$edit_any,$sticky_any,$approve_any,$captcha,$download)
		";
		do_query($query, "");
	}

	$refresh = 1;
	return ($refresh);

}

function alterstep24() {
	global $config;

	$query = "
		delete from {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
	";
	do_query($query, "Purging old cached permissions.");
}

?>