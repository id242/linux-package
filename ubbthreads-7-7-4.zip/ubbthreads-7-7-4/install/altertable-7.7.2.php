<?php

include("altertable.inc.php");

echo "<table class='acvt' width='70%'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 4;
for ($i = $thisstep; $i <= $totalsteps; $i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !$defined('DIDFAIL')) {
			$currenstep = $i;
			break;
		}

		if (function_exists('ob_flush')) {
			ob_flush();
		} else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}FILES
		ADD COLUMN FILE_SHA1 CHAR(40) DEFAULT ''
	";
	$sth = do_query($query, "Adding SHA1 column to {$config['TABLE_PREFIX']}FILES table...");
}

function alterstep2() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}USER_PROFILE
		 CHANGE USER_YAHOO USER_SOCIAL1 varchar(200),
		 CHANGE USER_AIM USER_SOCIAL3 varchar(200),
		 CHANGE USER_ICQ USER_SOCIAL5 varchar(200),
		 CHANGE USER_MSN USER_SOCIAL9 varchar(200)
	";
	$sth = do_query($query, "Updating social profile column names in the {$config['TABLE_PREFIX']}USER_PROFILE table...");
}

function alterstep3() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}USER_PROFILE
		 ADD COLUMN USER_SOCIAL2 varchar(200),
		 ADD COLUMN USER_SOCIAL4 varchar(200),
		 ADD COLUMN USER_SOCIAL6 varchar(200),
		 ADD COLUMN USER_SOCIAL7 varchar(200),
		 ADD COLUMN USER_SOCIAL8 varchar(200)
	";
	$sth = do_query($query, "Adding social profile columns to {$config['TABLE_PREFIX']}USER_PROFILE table...");
}

function alterstep4() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}USER_PROFILE
		 MODIFY COLUMN USER_SOCIAL1 varchar(200) AFTER USER_NOTIFY_ON_PM,
		 MODIFY COLUMN USER_SOCIAL2 varchar(200) AFTER USER_SOCIAL1,
		 MODIFY COLUMN USER_SOCIAL3 varchar(200) AFTER USER_SOCIAL2,
		 MODIFY COLUMN USER_SOCIAL4 varchar(200) AFTER USER_SOCIAL3,
		 MODIFY COLUMN USER_SOCIAL5 varchar(200) AFTER USER_SOCIAL4,
		 MODIFY COLUMN USER_SOCIAL6 varchar(200) AFTER USER_SOCIAL5,
		 MODIFY COLUMN USER_SOCIAL7 varchar(200) AFTER USER_SOCIAL6,
		 MODIFY COLUMN USER_SOCIAL8 varchar(200) AFTER USER_SOCIAL7,
		 MODIFY COLUMN USER_SOCIAL9 varchar(200) AFTER USER_SOCIAL8
	";
	$sth = do_query($query, "Reordering social profile columns in the {$config['TABLE_PREFIX']}USER_PROFILE table...");
}

?>