<?php

$newdirs['0'] = "images/groups";

?>