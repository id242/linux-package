<?php
$wrappers = array (
  0 => 
  array (
    'name' => 'default',
    'open' => '<table class="t_outer fw">
<tr><td>
<table class="t_inner fw">
',
    'close' => '</table>
</td></tr>
</table>
',
  ),
)?>