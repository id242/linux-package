<?php
//	UBB.threads
//	Script Version 7.7.4
//
//	Copyright 2012-2020 UBB Systems, LLC.
//
//	You may not distribute this program in any manner,
//	modified or otherwise, without the express prior
//	written consent of UBB Systems, LLC.
//
//	You may make modifications, but only for your own use
//	and within the confines of the UBB.threads License
//	Agreement (https://www.ubbcentral.com/terms.php).
//
//	Note: If you modify ANY code within your UBB.threads,
//	we at UBB Systems cannot offer you support.
//	Thus, modify at your own peril :)

include("ubbthreads.php");
?>